local MODULES={"dev","fs","io","ipc","proc","sync","sys","task"};local libcall={};for _,name in ipairs(MODULES)do libcall[name]=require("libcall."..name);end libcall.modules=MODULES;function libcall.install(target)target=target or _G;for _
,name in ipairs(MODULES)do target[name]=libcall[name];end return libcall;end return libcall;
