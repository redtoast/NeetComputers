local Protocol=require("libvfs.protocol");local libvfs={Server=require("libvfs.server"),Device=require("libvfs.device"),File=require("libvfs.file"),Class=require("libvfs.class"),path=require("libvfs.path"),stat=require("libvfs.stat"),
access=require("libvfs.access"),errno=require("libvfs.errno"),Methods=Protocol.Methods,Status=Protocol.Status,};return libvfs;
