local args={};function args.trim(...)local packed=table.pack(...);while packed.n>0 and packed[packed.n]==nil do packed.n=packed.n-1;end return packed;end return args;
