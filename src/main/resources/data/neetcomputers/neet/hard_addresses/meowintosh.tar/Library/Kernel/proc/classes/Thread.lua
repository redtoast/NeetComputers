local Thread={}Thread.__index=Thread;function Thread.new(tid,pid,co,priority)local new={tid=tid,pid=pid,co=co,state="READY",priority=priority or 10,cpuTime=0,blockedBy=nil,error=nil,joiningThreads={},};setmetatable(new,Thread);return new;
end return Thread;
