local ObjectManager=require("core.ObjectManager");local ReceiveRight={}ReceiveRight.__index=ReceiveRight;function ReceiveRight.new(portId)local new={portId=portId,}setmetatable(new,ReceiveRight);return new;end function ReceiveRight:
onAcquire(by)local kernelObject=ObjectManager.get(self.portId);if(kernelObject and kernelObject.type=="PORT")then local port=kernelObject.impl;port.ownerPid=by;end end function ReceiveRight:onRelease(by)local kernelObject=ObjectManager.
get(self.portId);if(kernelObject and kernelObject.type=="PORT")then local port=kernelObject.impl;if(by~=port.ownerPid)then return;end;port.ownerPid=nil;end end function ReceiveRight:onDestroy()ObjectManager.release(self.portId);end return
ReceiveRight;
