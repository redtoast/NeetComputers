return{[1]={["OS Name"]="UwUntuCC",["OS Version"]="1.0",["OS Description"]="MacOS like system",["OS Boot Path"]="0:system:/startup.lua",},}
