local KernelObject={};KernelObject.__index=KernelObject;function KernelObject.new(type,impl)local new=setmetatable({},KernelObject);new.refs=0;new.type=type;new.impl=impl;return new end function KernelObject:retain()self.refs=self.refs+1;
end function KernelObject:release()self.refs=self.refs-1;return self.refs<=0;end function KernelObject:as(type)if(type==self.type)then return self.impl;else error(string.format(
"Trying to access KernelObject as %s, while it is actually %s",type,self.type))end end return KernelObject;
