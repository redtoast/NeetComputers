require("libcall").install();local liblaunch=require("liblaunch");local libcopy={};function libcopy.copy(content,type)type=type or"general";local pboard if liblaunch.available()then pboard=liblaunch.lookup("pboard");end if not pboard then
error("pboard daemon is unreachable!")end;ipc.send(pboard,{[type]=content},{type="PBOARD_COPY",})end function libcopy.paste(type)type=type or"general";local pboard if liblaunch.available()then pboard=liblaunch.lookup("pboard");end if not
pboard then error("pboard daemon is unreachable!")end;local replyPort=ipc.create();ipc.send(pboard,{},{type="PBOARD_PASTE",reply_port=replyPort,});local message=ipc.receive(replyPort);ipc.close(replyPort);return message.data[type];end
return libcopy;
