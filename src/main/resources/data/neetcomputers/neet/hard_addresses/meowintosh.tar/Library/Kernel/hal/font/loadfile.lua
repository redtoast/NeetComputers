function loadfile(filename,disk,mode,env)local handle=files.open(filename,"r",disk or 0)local data=handle.read("a")handle.close()return load(data,filename,mode,env or _ENV)end
