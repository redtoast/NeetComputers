local Class=require("libdev.class");local Surface=require("libdev.surface");local args=require("libdev.args");local Layer=Class.create("Layer");function Layer:init(surface)assert(type(surface)=="table",
"libdev: layer expects the object NEET returned");self.surface=surface;end function Layer.wrap(surface)return Layer:new(surface);end function Layer:call(method,...)local fn=self.surface[method];if type(fn)~="function"then error(
"libdev: layer has no method "..tostring(method));end local packed=args.trim(...);return fn(table.unpack(packed,1,packed.n));end Surface.apply(Layer);return Layer;
