local expect=require"cc.expect".expect local lassert=require"ccryptolib.internal.util".lassert local hw=require"ccryptolib.internal.hw"local util=require"ccryptolib.internal.util"local c25=require"ccryptolib.internal.curve25519"local
function publicKey(sk)expect(1,sk,"string")assert(#sk==32,"secret key length must be 32")local ok,out=hw.x25519PublicKey(sk)if ok then return out end return c25.encode(c25.scale(c25.mulG(util.bits(sk))))end local function exchange(sk,pk)
expect(1,sk,"string")lassert(#sk==32,"secret key length must be 32",2)expect(2,pk,"string")lassert(#pk==32,"public key length must be 32",2)local ok,out=hw.x25519Exchange(sk,pk)if ok then return out end return c25.encode(c25.scale(c25.
ladder8(c25.decode(pk),util.bits8(sk))))end return{publicKey=publicKey,exchange=exchange,}
