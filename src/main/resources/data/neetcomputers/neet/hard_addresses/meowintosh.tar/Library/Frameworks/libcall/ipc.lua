local ipc={};function ipc.create()return call(32);end function ipc.send(port,msg,opts)return call(33,port,msg,opts);end function ipc.receive(port,opts)return call(34,port,opts);end function ipc.close(port)return call(36,port);end function
ipc.stat(port)return call(37,port);end function ipc.poll(fds)return call(38,fds);end return ipc;
