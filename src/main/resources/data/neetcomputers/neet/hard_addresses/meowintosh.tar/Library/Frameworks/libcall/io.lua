local io={};function io.pipe()return call(73);end function io.dup(oldFd,newFd)return call(74,oldFd,newFd);end return io;
