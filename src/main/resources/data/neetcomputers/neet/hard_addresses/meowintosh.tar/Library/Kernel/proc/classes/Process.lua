local HAL=require("hal");local Process={};Process.__index=Process;function Process.new(pid,ppid,name,uid,gid,euid,egid)local new={pid=pid,name=name or"unknown",ppid=ppid,children={},pgid=pid,sid=pid,uid=uid or 0,euid=euid or uid or 0,suid=
euid or uid or 0,gid=gid or 0,egid=egid or gid or 0,sgid=egid or gid or 0,groups={},state="ALIVE",exitCode=nil,threads={},handles={},cwd="/",env={},globals={},signalPorts={},cpuTime=0,startTime=HAL.now(),limits={maxFiles=32,maxPorts=16,
maxProcesses=8,maxThreads=16,},threadsWaitingForChildren={},};setmetatable(new,Process);return new;end return Process;
