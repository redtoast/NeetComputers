package.path="/System/Library/CoreServices/plantd/?.lua;"..package.path;require("libcall").install();local rules=require("rules");local Planter=require("planter");local PREFERENCES=arg[1]or"/System/Library/Preferences/plantd.toml";local
planter=Planter.new();local ok,preferences=pcall(rules.read,PREFERENCES);if(not ok)then planter:log("FAIL",tostring(preferences));proc.exit(1);end planter:dirs(preferences.dirs);planter:seed(preferences.seeds);planter:plant(preferences.
rules);planter:homes(preferences.home);local report=planter.report;planter:log("INFO","planted "..report.planted.." path(s), made "..report.made.." director(ies), seeded "..report.seeded.." file(s), "..report.homes.." home(s), "..report.
failed.." failure(s)");proc.exit(0);
