local ProcessRegistry={};local processList={};local nextId=1;function ProcessRegistry.getNextPid()local next=nextId;nextId=next+1;return next;end function ProcessRegistry.register(pid,process)if(processList[pid])then error(string.format(
"Process with pid %s already exists!",pid))end;processList[pid]=process;end function ProcessRegistry.get(pid)return processList[pid];end function ProcessRegistry.getAll()local result={};for pid,_ in pairs(processList)do table.insert(
result,pid);end return result;end function ProcessRegistry.getByPgid(pgid)local result={};for pid,process in pairs(processList)do if(process.pgid==pgid)then table.insert(result,pid);end end table.sort(result);return result;end function
ProcessRegistry.remove(pid)processList[pid]=nil;end return ProcessRegistry;
