local Port={}Port.__index=Port;function Port.new()local new={queue={},capacity=math.huge,pollers={},receivers={},senders={},ownerPid=nil,receiveRight=nil,sendRight=nil,temporary=false,temporarySenders={},blockedSenders={},}setmetatable(new
,Port);return new;end return Port;
