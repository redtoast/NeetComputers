local access={};local ROOT={uid=0,gid=0,groups={}};function access.member(user,gid)if(user.gid==gid)then return true;end for _,entry in ipairs(user.groups or{})do if(entry==gid)then return true;end end return false;end function access.
class(info,user)local permissions=info.permissions;if(user.uid==info.uid)then return permissions.user;end if(access.member(user,info.gid))then return permissions.group;end return permissions.other;end function access.allows(info,want,user
)user=user or ROOT;if(user.uid==0 or not info.permissions)then return true;end local bits=access.class(info,user);return not((string.find(want,"r")and not bits.read)or(string.find(want,"w")and not bits.write)or(string.find(want,"x")and not
bits.execute));end return access;
