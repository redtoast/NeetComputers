local Class=require("libvfs.class");local errno=require("libvfs.errno");local stat=require("libvfs.stat");local File=Class.create("File");function File:init(opts)opts=opts or{};self.mode=opts.mode;self.path=opts.path;self.cookie=opts.
cookie;end function File:canRead()return string.find(self.mode or"","[r+]")~=nil;end function File:canWrite()return string.find(self.mode or"","[wa+]")~=nil;end function File:size()return 0;end function File:read(bytes,offset)errno.enosys
("read");end function File:write(data,offset)errno.enosys("write");end function File:flush()return true;end function File:stat()return stat.file({size=self:size()});end function File:ioctl(cmd,args)errno.enotty(cmd);end function File:
close()return true;end return File;
