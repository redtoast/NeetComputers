local ScreenDevice={};ScreenDevice.__index=ScreenDevice;local METHODS={"getSize","substitute","clone","writeData","readData","drawPixel","drawLine","set","fill","draw","createLayer",};function ScreenDevice.new()local new={type="screen",
exclusive=true,methods={},};for _,m in ipairs(METHODS)do new.methods[m]=true;end setmetatable(new,ScreenDevice);return new;end function ScreenDevice:ioctl(pcb,method,...)if not self.methods[method]then error(
"EINVAL: Unknown screen method: "..tostring(method));end return screen[method](...);end return ScreenDevice;
