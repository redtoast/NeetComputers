local sync={};function sync.create(type,init)return call(128,type,init);end function sync.lock(handle,timeout)return call(129,handle,timeout);end function sync.unlock(handle)return call(130,handle);end function sync.wait(cond,mutex,timeout
)return call(131,cond,mutex,timeout);end function sync.notify(cond,all)return call(132,cond,all);end return sync;
