local DeviceRegistry={};local devices={};function DeviceRegistry.register(name,device)devices[name]=device;end function DeviceRegistry.get(name)return devices[name];end function DeviceRegistry.getAll()local names={};for k,_ in pairs(
devices)do table.insert(names,k);end return names;end function DeviceRegistry.remove(name)devices[name]=nil;end return DeviceRegistry;
