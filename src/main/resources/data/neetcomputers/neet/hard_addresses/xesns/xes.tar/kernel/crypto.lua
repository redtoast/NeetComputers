local K = ...

local C = {}
K.crypto = C

local M = 0xffffffff

local KT = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2 }

local IV = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 }

local function compress(H, W)
    for i = 16, 63 do
        local x, y = W[i - 15], W[i - 2]
        local s0 = (((x >> 7) | (x << 25)) ~ ((x >> 18) | (x << 14)) ~ (x >> 3)) & M
        local s1 = (((y >> 17) | (y << 15)) ~ ((y >> 19) | (y << 13)) ~ (y >> 10)) & M
        W[i] = (W[i - 16] + s0 + W[i - 7] + s1) & M
    end
    local a, b, c, d, e, f, g, h = H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]
    for i = 0, 63 do
        local S1 = (((e >> 6) | (e << 26)) ~ ((e >> 11) | (e << 21)) ~ ((e >> 25) | (e << 7))) & M
        local ch = (e & f) ~ (~e & g)
        local t1 = h + S1 + ch + KT[i + 1] + W[i]
        local S0 = (((a >> 2) | (a << 30)) ~ ((a >> 13) | (a << 19)) ~ ((a >> 22) | (a << 10))) & M
        local maj = (a & b) ~ (a & c) ~ (b & c)
        h, g, f, e = g, f, e, (d + t1) & M
        d, c, b, a = c, b, a, (t1 + S0 + maj) & M
    end
    H[1] = (H[1] + a) & M; H[2] = (H[2] + b) & M; H[3] = (H[3] + c) & M; H[4] = (H[4] + d) & M
    H[5] = (H[5] + e) & M; H[6] = (H[6] + f) & M; H[7] = (H[7] + g) & M; H[8] = (H[8] + h) & M
end

local function newState() return { IV[1], IV[2], IV[3], IV[4], IV[5], IV[6], IV[7], IV[8] } end

local function finish(H, msg, prefix)
    local len = #msg
    msg = msg .. "\128" .. string.rep("\0", (55 - len) % 64) .. string.pack(">I8", (len + prefix) * 8)
    local W = {}
    for chunk = 1, #msg, 64 do
        for i = 0, 15 do W[i] = string.unpack(">I4", msg, chunk + i * 4) end
        compress(H, W)
    end
    return H
end

local function digest(H)
    return string.pack(">I4I4I4I4I4I4I4I4", H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8])
end

function C.sha256raw(msg) return digest(finish(newState(), msg, 0)) end

function C.tohex(s)
    return (s:gsub(".", function(c) return string.format("%02x", c:byte()) end))
end

function C.fromhex(h)
    if type(h) ~= "string" or #h % 2 ~= 0 or h:find("[^0-9a-fA-F]") then return nil end
    return (h:gsub("..", function(x) return string.char(tonumber(x, 16)) end))
end

function C.sha256(msg) return C.tohex(C.sha256raw(msg)) end

local function hmacKey(key)
    if #key > 64 then key = C.sha256raw(key) end
    return key .. string.rep("\0", 64 - #key)
end

function C.hmac(key, msg)
    key = hmacKey(key)
    local ipad = key:gsub(".", function(c) return string.char(c:byte() ~ 0x36) end)
    local opad = key:gsub(".", function(c) return string.char(c:byte() ~ 0x5c) end)
    return C.sha256raw(opad .. C.sha256raw(ipad .. msg))
end

function C.pbkdf2(pass, salt, iters, dklen)
    dklen = dklen or 32
    local key = hmacKey(pass)
    local function padState(x)
        local H, W = newState(), {}
        for i = 0, 15 do W[i] = string.unpack(">I4", key, i * 4 + 1) ~ x end
        compress(H, W)
        return H
    end
    local istate, ostate = padState(0x36363636), padState(0x5c5c5c5c)
    local out = {}
    for block = 1, (dklen + 31) // 32 do
        local function copy(H) return { H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8] } end
        local u = finish(copy(ostate), digest(finish(copy(istate), salt .. string.pack(">I4", block), 64)), 64)
        local acc = { u[1], u[2], u[3], u[4], u[5], u[6], u[7], u[8] }
        local W = { [8] = 0x80000000, [9] = 0, [10] = 0, [11] = 0, [12] = 0, [13] = 0, [14] = 0, [15] = 768 }
        local Hi, Ho = { 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0, 0 }
        for _ = 2, iters do
            for k = 1, 8 do
                W[k - 1] = u[k]; Hi[k] = istate[k]
            end
            compress(Hi, W)
            for k = 1, 8 do
                W[k - 1] = Hi[k]; Ho[k] = ostate[k]
            end
            compress(Ho, W)
            u = Ho
            for k = 1, 8 do acc[k] = acc[k] ~ u[k] end
        end
        out[#out + 1] = digest(acc)
    end
    return table.concat(out):sub(1, dklen)
end

function C.ctequal(a, b)
    if #a ~= #b then return false end
    local d = 0
    for i = 1, #a do d = d | (a:byte(i) ~ b:byte(i)) end
    return d == 0
end

local S = C.sha256raw("xesns-entropy-v1")
local counter = 0

function C.entropy_add(...)
    local parts = { S }
    for i = 1, select("#", ...) do parts[#parts + 1] = tostring((select(i, ...))) end
    local nowv = K.now and K.now() or 0
    parts[#parts + 1] = string.pack("<d", nowv)
    if chip and chip.getTime then parts[#parts + 1] = string.pack("<d", chip.getTime()) end
    parts[#parts + 1] = string.pack("<d", coroutine.memoryused(0))
    parts[#parts + 1] = tostring({})
    S = C.sha256raw(table.concat(parts, "\0"))
end

function C.random_bytes(n)
    local out, got = {}, 0
    while got < n do
        counter = counter + 1
        out[#out + 1] = C.sha256raw(S .. string.pack(">I8", counter) .. "out")
        got = got + 32
    end

    S = C.sha256raw(S .. string.pack(">I8", counter) .. "ratchet" .. tostring({}))
    return table.concat(out):sub(1, n)
end

local SEED = "var/db/random.seed"

function C.random_init()
    C.entropy_add("boot", tostring(print), tostring(K))
    local V = K.vfs
    if not V then return end
    local full = K.rootdir .. SEED
    local old = V.readFile(full)
    if old and #old > 0 then C.entropy_add("seed", old) end
    C.random_saveseed()
end

function C.random_saveseed()
    local V = K.vfs
    if not V or not K.rootdir then return end
    if V.stat(K.rootdir .. "var/db") ~= "dir" then
        if V.stat(K.rootdir .. "var") ~= "dir" then V.mkdir(nil, K.rootdir .. "var") end
        V.mkdir(nil, K.rootdir .. "var/db")
    end
    V.writeFile(K.rootdir .. SEED, C.random_bytes(64), 384)
end
