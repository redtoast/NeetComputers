local K, API, X = ...

local T = {}

local host = rawget(_G, "io")
if type(host) ~= "table" then
	T.__eventonly = true
	return T
end

local REQUIRED = {
	"getPeripherals",
	"isCompatibility",
	"broadcastLocal",
	"getType",
	"queryTag",
	"setTag",
	"wrapPeripheral",
	"getTag",
	"callFunction",
	"queryType",
	"isViewed",
}

for i = 1, #REQUIRED do
	local name = REQUIRED[i]
	if type(host[name]) ~= "function" then
		K.klog("kernel: ext: peripherals: host io lacks %s; ext.peripherals not reported", name)
		T.__eventonly = true
		return T
	end
end

local FIELD = "periph"

local function stateOf(p)
	local s = p and rawget(p, FIELD)
	if type(s) ~= "table" then
		return nil
	end
	return s
end

local function stateFor(p)
	local s = rawget(p, FIELD)
	if type(s) ~= "table" then
		s = { hidden = {} }
		p[FIELD] = s
	end
	if type(s.hidden) ~= "table" then
		s.hidden = {}
	end
	return s
end

local function isHidden(p, uuid)
	local s = stateOf(p)
	return s ~= nil and type(s.hidden) == "table" and s.hidden[uuid] == true
end

local function notFound()
	error("Peripheral not found", 0)
end

local function refuse(p, name, uuid)
	local s = stateOf(p)
	local fn = s and s.deny
	if type(fn) ~= "function" then
		return
	end
	local verdict, msg = fn(p, name, uuid)
	if verdict == nil or verdict == false then
		return
	end
	local text
	if type(verdict) == "string" then
		text = verdict
	elseif type(msg) == "string" and msg ~= "" then
		text = msg
	else
		text = "Operation not permitted"
	end
	error(text, 0)
end

local function guard(p, name, uuid)
	if uuid ~= nil and isHidden(p, uuid) then
		notFound()
	end
	refuse(p, name, uuid)
end

local function visibleList(p, list)
	if type(list) ~= "table" then
		return list
	end
	local out = {}
	for i = 1, #list do
		local uuid = list[i]
		if not isHidden(p, uuid) then
			out[#out + 1] = uuid
		end
	end
	return out
end

local function caller(p)
	return K.current or p
end

function T.getPeripherals(p)
	guard(p, "getPeripherals", nil)
	return visibleList(p, host.getPeripherals())
end

function T.queryType(p, ty)
	guard(p, "queryType", nil)
	return visibleList(p, host.queryType(ty))
end

function T.queryTag(p, tag)
	guard(p, "queryTag", nil)
	return visibleList(p, host.queryTag(tag))
end

function T.isViewed(p)
	guard(p, "isViewed", nil)
	return host.isViewed()
end

function T.broadcastLocal(p, ...)
	guard(p, "broadcastLocal", nil)
	return host.broadcastLocal(...)
end

function T.getType(p, uuid)
	guard(p, "getType", uuid)
	return host.getType(uuid)
end

function T.getTag(p, uuid)
	guard(p, "getTag", uuid)
	return host.getTag(uuid)
end

function T.setTag(p, uuid, tag)
	guard(p, "setTag", uuid)
	return host.setTag(uuid, tag)
end

function T.isCompatibility(p, uuid)
	guard(p, "isCompatibility", uuid)
	return host.isCompatibility(uuid)
end

function T.callFunction(p, uuid, name, ...)
	guard(p, "callFunction", uuid)
	return host.callFunction(uuid, name, ...)
end

function T.wrapPeripheral(p, uuid)
	guard(p, "wrapPeripheral", uuid)
	local tbl = host.wrapPeripheral(uuid)
	if type(tbl) ~= "table" then
		return tbl
	end
	local owner = p
	local out = {}
	for name, fn in pairs(tbl) do
		if type(fn) == "function" then
			out[name] = function(...)
				guard(caller(owner), name, uuid)
				return fn(...)
			end
		else
			out[name] = fn
		end
	end
	return out
end

for name, fn in pairs(host) do
	if type(name) == "string" and type(fn) == "function" and T[name] == nil then
		T[name] = function(p, ...)
			refuse(p, name, nil)
			return fn(...)
		end
	end
end

K.periph = {
	hide = function(p, uuid)
		if type(p) ~= "table" then
			return nil, "no process record"
		end
		if type(uuid) ~= "string" or uuid == "" then
			return nil, "uuid must be a non-empty string"
		end
		stateFor(p).hidden[uuid] = true
		return true
	end,

	reveal = function(p, uuid)
		local s = stateOf(p)
		if not s or type(s.hidden) ~= "table" then
			return true
		end
		s.hidden[uuid] = nil
		return true
	end,

	isHidden = isHidden,

	list = function(p)
		local out = {}
		local s = stateOf(p)
		for uuid in pairs((s and s.hidden) or {}) do
			out[#out + 1] = uuid
		end
		table.sort(out)
		return out
	end,

	deny = function(p, fn)
		if type(p) ~= "table" then
			return nil, "no process record"
		end
		if fn ~= nil and type(fn) ~= "function" then
			return nil, "deny predicate must be a function"
		end
		local s = stateFor(p)
		s.deny = fn
		return true
	end,

	allowAll = function(p)
		if type(p) ~= "table" then
			return nil, "no process record"
		end
		p[FIELD] = { hidden = {} }
		return true
	end,
}

T.__global = "io"
T.__ext = { ["ext.peripherals"] = 1 }

return T
