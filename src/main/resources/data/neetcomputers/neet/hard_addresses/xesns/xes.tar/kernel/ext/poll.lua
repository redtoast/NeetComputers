local K, API, X = ...

local argerr = K.argcheck.err

local T = {}

local function handleErr(h, writing)
	local e = K.neatoEntries[h]
	if not e then
		return nil
	end
	if e.pipe then
		if writing and not e.read and e.st.readers == 0 then
			return "EPIPE"
		end
		return nil
	end
	if e.stdio then
		local p = e.p or K.current
		if not (p and p.fds and p.fds[e.n]) then
			return "EBADF"
		end
	end
	return nil
end

local function collectErrs(read, write)
	local errs = {}
	local function scan(list, writing)
		if type(list) ~= "table" then
			return
		end
		for i = 1, #list do
			local h = list[i]
			if type(h) == "table" and errs[h] == nil then
				local code = handleErr(h, writing)
				if code then
					errs[h] = code
				end
			end
		end
	end
	scan(read, false)
	scan(write, true)
	return errs
end

function T.poll(p, read, timeout, write)
	if read ~= nil and type(read) ~= "table" then
		argerr(1, "poll", "table", read)
	end
	if timeout ~= nil and type(timeout) ~= "number" then
		argerr(2, "poll", "number", timeout)
	end
	if write ~= nil and type(write) ~= "table" then
		argerr(3, "poll", "table", write)
	end
	if timeout ~= nil and (timeout ~= timeout or timeout < 0) then
		return nil, "EINVAL", "invalid timeout"
	end
	read = read or {}
	write = write or {}
	local errs = collectErrs(read, write)
	if next(errs) ~= nil then
		local r, w = K.pollReady(p, read, write)
		return r, w, errs
	end
	local r, w = K.pollWait(p, read, write, timeout)
	return r, w, collectErrs(read, write)
end

function T.ready(p, h, writing)
	if writing ~= nil and type(writing) ~= "boolean" then
		argerr(2, "ready", "boolean", writing)
	end
	if h == "event" then
		return p.eh <= p.et
	end
	if type(h) ~= "table" then
		argerr(1, "ready", "handle", h)
	end
	local code = handleErr(h, writing == true)
	if code then
		return false, code
	end
	if writing then
		local _, w = K.pollReady(p, nil, { h })
		return #w > 0
	end
	local r = K.pollReady(p, { h }, nil)
	return #r > 0
end

local POLL = {}
POLL.ready = function(h, writing)
	return T.ready(K.current, h, writing)
end
POLL.poll = POLL
setmetatable(POLL, {
	__call = function(_, read, timeout, write)
		return T.poll(K.current, read, timeout, write)
	end,
})
T.__top = { poll = POLL }

T.__ext = { ["ext.poll"] = 1 }

return T
