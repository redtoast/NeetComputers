local K = ...

local ttfont = {}
K.ttfont = ttfont

local CellFont = {}
CellFont.__index = CellFont

ttfont.CACHE_MAX = 2048
ttfont.AMASK_MAX = 512

local function split(c)
	return math.floor(c / 65536) % 256, math.floor(c / 256) % 256, c % 256
end

local function fntpModule()
	if K.fntp == nil then
		local src = K.rawRead("/kernel/fntp.lua")
		if not src then
			return nil, "cannot read /kernel/fntp.lua"
		end
		local chunk, cerr = load(src, "=xes:/kernel/fntp.lua", "t", _G)
		if not chunk then
			return nil, cerr
		end
		local ok, fntp = pcall(chunk)
		if not ok or type(fntp) ~= "table" or type(fntp.load) ~= "function" then
			return nil, "bad fntp module"
		end
		K.fntp = fntp
	end
	return K.fntp
end

function ttfont.load(data, px, opts)
	opts = opts or {}
	px = math.floor(px or 16)
	if px < 8 or px > 64 then
		return nil, "pixel size must be in 8..64"
	end
	local fntp, merr = fntpModule()
	if not fntp then
		return nil, merr
	end
	local okf, font, ferr = pcall(fntp.load, data)
	if not okf then
		return nil, "bad font: " .. tostring(font)
	end
	if not font then
		return nil, ferr
	end
	local okm, m = pcall(font.metrics, font, px)
	if not okm or type(m) ~= "table" then
		return nil, "bad font metrics: " .. tostring(m)
	end
	local ss = opts.supersample or 2
	local oks, sp, serr = pcall(font.rasterize, font, 32, px, { supersample = ss })
	if not oks then
		return nil, "bad font glyph: " .. tostring(sp)
	end
	if not sp then
		return nil, serr
	end
	local cellW = sp.advance
	for _, c in ipairs({ 105, 109, 87, 65 }) do
		local okg, g = pcall(font.rasterize, font, c, px, { supersample = ss })
		if okg and g and g.advance and g.advance > cellW then
			cellW = g.advance
		end
	end
	if cellW > px * 3 then
		cellW = px * 3
	end
	if cellW < 4 or m.height < 4 then
		return nil, "degenerate cell size"
	end
	return setmetatable({
		kind = "ttfont",
		fontName = font.name or "truetype",
		backend = font,
		px = px,
		ss = ss,
		cellW = cellW,
		cellH = m.height,
		baseline = m.ascent,
		cache = {},
		ncache = 0,
		cord = {},
		chead = 1,
		amask = {},
		aord = {},
		ahead = 1,
		namask = 0,
	}, CellFont)
end

local function evictOld(store, order, head, count, max)
	while count > max do
		local old = order[head]
		if old == nil then
			break
		end
		order[head] = false
		head = head + 1
		if old ~= false then
			store[old] = nil
			count = count - 1
		end
	end
	if head > 4096 then
		local fresh = {}
		for k = head, #order do
			local v = order[k]
			if v then
				fresh[#fresh + 1] = v
			end
		end
		order, head = fresh, 1
	end
	return order, head, count
end

function CellFont:cell(code, fg, bg)
	local c = self.cache[code]
	local k2 = fg * 16777216 + bg
	if c then
		local hit = c[k2]
		if hit then
			return hit
		end
	end
	if self.ncache > ttfont.CACHE_MAX then
		self.cache, self.ncache = {}, 0
		c = nil
	end
	local cw, chh = self.cellW, self.cellH
	local fr, fgg, fb = split(fg)
	local br, bgg, bb = split(bg)
	local fgpx = string.char(fr, fgg, fb, 255)
	local bgpx = string.char(br, bgg, bb, 255)
	local am = nil
	if code > 32 then
		am = self.amask[code]
		if am == nil then
			local cp = code
			local okg, gid = pcall(self.backend.glyphIndex, self.backend, code)
			if not okg or gid == 0 then
				cp = 63
			end
			local okr, gl = pcall(self.backend.rasterize, self.backend, cp, self.px, { supersample = self.ss })
			if okr and gl and gl.width > 0 and gl.height > 0 then
				local gw, gh, data = gl.width, gl.height, gl.buffer
				local alpha, n = {}, 0
				for k = 1, gw * gh do
					n = n + 1
					alpha[n] = data:byte((k - 1) * 4 + 4) or 0
				end
				am = { w = gw, h = gh, bx = gl.bearingX, by = gl.bearingY, alpha = alpha }
			else
				am = false
			end
			self.amask[code] = am
			self.aord[#self.aord + 1] = code
			self.namask = self.namask + 1
			self.aord, self.ahead, self.namask =
				evictOld(self.amask, self.aord, self.ahead, self.namask, ttfont.AMASK_MAX)
		end
	end
	local buf
	if not am then
		buf = string.rep(bgpx, cw * chh)
	else
		local gx0 = am.bx
		local gy0 = self.baseline - am.by
		local gw, gh, alpha = am.w, am.h, am.alpha
		local out, n = {}, 0
		for y = 0, chh - 1 do
			for x = 0, cw - 1 do
				local a = 0
				local sx, sy = x - gx0, y - gy0
				if sx >= 0 and sx < gw and sy >= 0 and sy < gh then
					a = alpha[sy * gw + sx + 1] or 0
				end
				n = n + 1
				if a == 255 then
					out[n] = fgpx
				elseif a == 0 then
					out[n] = bgpx
				else
					local ia = 255 - a
					out[n] = string.char(
						math.floor((fr * a + br * ia) / 255),
						math.floor((fgg * a + bgg * ia) / 255),
						math.floor((fb * a + bb * ia) / 255),
						255
					)
				end
			end
		end
		buf = table.concat(out)
	end
	if not c then
		c = {}
		self.cache[code] = c
	end
	c[k2] = buf
	self.ncache = self.ncache + 1
	return buf
end
