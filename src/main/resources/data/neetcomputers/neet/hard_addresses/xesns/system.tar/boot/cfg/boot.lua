return {
  ["Config"] = {
    ["DefaultEntry"] = 1,
    ["Autoboot"] = 1,          
  },
  ["Bootlist"] = {
    {
      ["OS Name"] = "XesNS",
      ["OS Version"] = "0.1.0",
      ["OS Description"] = "Xes Neet System - a BSD-flavoured NEATO operating system",
      ["OS Args"] = {},
      ["OS Boot Path"] = "any:xes:/boot.lua",
      ["OS Environment Variable Definition"] = {
        ["XES_ROOT"] = "any:xes",
        ["XES_VERBOSE"] = 1,
      },
    },
  },
}
