local M = {}

M.VERSION = "0.4.0"

local MAX_DIM = 2048

local function backend(name)
	if type(require) == "function" then
		local ok, lib = pcall(require, name)
		if ok and type(lib) == "table" and type(lib.detect) == "function" then
			return lib
		end
	end
	return nil
end

local function at(s, off, sig)
	return s:sub(off, off + #sig - 1) == sig
end

local function has(s, needle)
	return s:find(needle, 1, true) ~= nil
end

local function u16be(s, p)
	local a, b = s:byte(p, p + 1)
	if not b then
		return nil
	end
	return a * 256 + b
end

local function u16le(s, p)
	local a, b = s:byte(p, p + 1)
	if not b then
		return nil
	end
	return a + b * 256
end

local function u32be(s, p)
	local a, b, c, d = s:byte(p, p + 3)
	if not d then
		return nil
	end
	return ((a * 256 + b) * 256 + c) * 256 + d
end

local function u32le(s, p)
	local a, b, c, d = s:byte(p, p + 3)
	if not d then
		return nil
	end
	return a + b * 256 + c * 65536 + d * 16777216
end

local function rgba_dims(data)
	if type(data) ~= "string" or #data < 9 then
		return nil
	end
	local w, h = u32le(data, 1), u32le(data, 5)
	if not w or w < 1 or w > MAX_DIM or h < 1 or h > MAX_DIM then
		return nil
	end
	if #data ~= 8 + w * h * 4 then
		return nil
	end
	return w, h
end

local SIGS = {
	{ "png", "\137PNG\r\n\26\n" },
	{ "jpg", "\255\216\255" },
	{ "gif", "GIF87a" },
	{ "gif", "GIF89a" },
	{ "bmp", "BM" },
	{ "qoi", "qoif" },
	{ "tiff", "II*\0" },
	{ "tiff", "MM\0*" },
	{ "ico", "\0\0\1\0" },
	{ "cur", "\0\0\2\0" },
	{ "psd", "8BPS" },
	{ "xcf", "gimp xcf " },
	{ "jxl", "\255\10" },
	{ "jxl", "\0\0\0\12JXL \r\n\135\n" },
	{ "jp2", "\0\0\0\12jP  \r\n\135\n" },
	{ "j2k", "\255\79\255\81" },
	{ "dds", "DDS " },
	{ "hdr", "#?RADIANCE" },
	{ "hdr", "#?RGBE" },
	{ "exr", "\118\47\49\1" },
	{ "farbfeld", "farbfeld" },
	{ "ktx", "\171KTX 11\187\r\n\26\n" },

	{ "woff2", "wOF2" },
	{ "woff", "wOFF" },
	{ "ttc", "ttcf" },
	{ "otf", "OTTO" },
	{ "ttf", "\0\1\0\0" },
	{ "pcf", "\1fcp" },
	{ "bdf", "STARTFONT " },
	{ "psf1", "\54\4" },
	{ "psf2", "\114\181\74\134" },

	{ "rpm", "\237\171\238\219" },
	{ "7z", "7z\188\175\39\28" },
	{ "rar", "Rar!\26\7\0" },
	{ "rar", "Rar!\26\7\1\0" },
	{ "cab", "MSCF" },
	{ "wim", "MSWIM\0\0\0" },
	{ "xar", "xar!" },
	{ "squashfs", "hsqs" },
	{ "squashfs", "sqsh" },
	{ "cramfs", "\69\61\205\40" },
	{ "xz", "\2537zXZ\0" },
	{ "lzip", "LZIP" },
	{ "lz4", "\4\34\77\24" },
	{ "lz4", "\2\33\76\24" },
	{ "zstd", "\40\181\47\253" },
	{ "lzop", "\137LZO\0\r\n\26\n" },
	{ "lrzip", "LRZI" },
	{ "compress", "\31\157" },
	{ "gzip", "\31\139" },
	{ "cpio", "070701" },
	{ "cpio", "070702" },
	{ "cpio", "070707" },
	{ "cpio", "\199\113" },
	{ "cpio", "\113\199" },
	{ "iso9660", "CD001", 32769 },
	{ "udf", "BEA01", 32769 },
	{ "udf", "NSR02", 32769 },
	{ "udf", "NSR03", 32769 },
	{ "tar", "ustar", 258 },

	{ "flac", "fLaC" },
	{ "mp3", "ID3" },
	{ "ogg", "OggS" },
	{ "midi", "MThd" },
	{ "au", ".snd" },
	{ "flv", "FLV\1" },
	{ "asf", "\48\38\178\117\142\102\207\17\166\217\0\170\0\98\206\108" },
	{ "wavpack", "wvpk" },
	{ "musepack", "MPCK" },
	{ "musepack", "MP+" },
	{ "ape", "MAC " },
	{ "tta", "TTA1" },
	{ "amr", "#!AMR-WB" },
	{ "amr", "#!AMR" },

	{ "pdf", "%PDF-" },
	{ "ps", "%!PS-Adobe-" },
	{ "ps", "%!PS" },
	{ "dvi", "\247\2" },
	{ "rtf", "{\\rtf" },
	{ "sqlite", "SQLite format 3\0" },
	{ "pgp", "-----BEGIN PGP" },
	{ "pem", "-----BEGIN " },
	{ "openssh-key", "openssh-key-v1\0" },
	{ "vcard", "BEGIN:VCARD" },
	{ "ical", "BEGIN:VCALENDAR" },

	{ "elf", "\127ELF" },
	{ "wasm", "\0asm" },
	{ "lua", "\27Lua" },
	{ "macho", "\254\237\250\206" },
	{ "macho", "\206\250\237\254" },
	{ "macho", "\254\237\250\207" },
	{ "macho", "\207\250\237\254" },
	{ "lnk", "\76\0\0\0\1\20\2\0\0\0\0\0\192\0\0\0" },
	{ "gitindex", "DIRC" },
	{ "gitpack", "PACK" },
	{ "regf", "regf" },
	{ "qcow", "QFI\251" },
	{ "vmdk", "KDMV" },
	{ "vmdk", "COWD" },
	{ "vdi", "<<< Oracle VM VirtualBox Disk Image >>>" },
	{ "vhd", "conectix" },
}

local function zipKind(data)
	local head = data:sub(1, 32768)
	if has(head, "application/epub+zip") then
		return "epub"
	elseif has(head, "AndroidManifest.xml") then
		return "apk"
	elseif has(head, "word/document.xml") then
		return "docx"
	elseif has(head, "xl/workbook.xml") then
		return "xlsx"
	elseif has(head, "ppt/presentation.xml") then
		return "pptx"
	elseif has(head, "META-INF/") then
		return "jar"
	end
	return "zip"
end

local function oleKind(data)
	local head = data:sub(1, 32768)
	if has(head, "WordDocument") then
		return "doc"
	elseif has(head, "Workbook") then
		return "xls"
	elseif has(head, "PowerPoint Document") then
		return "ppt"
	end
	return "ole"
end

local function ftypKind(data)
	local brand = data:sub(9, 12)
	if brand == "avif" or brand == "avis" then
		return "avif"
	elseif brand == "heic" or brand == "heix" or brand == "hevc" or brand == "hevx"
		or brand == "heim" or brand == "heis" or brand == "mif1" or brand == "msf1" then
		return "heic"
	elseif brand == "qt  " then
		return "mov"
	elseif brand == "M4A " or brand == "M4B " or brand == "M4P " then
		return "m4a"
	elseif brand:sub(1, 3) == "3gp" or brand:sub(1, 3) == "3g2" then
		return "3gp"
	end
	return "mp4"
end

local function detectContent(data)
	local n = #data
	local b1, b2, b3, b4 = data:byte(1, 4)

	if at(data, 1, "\0\0\254\255") then
		return "utf32be"
	elseif at(data, 1, "\255\254\0\0") then
		return "utf32le"
	elseif at(data, 1, "\239\187\191") then
		return "utf8bom"
	elseif at(data, 1, "\254\255") then
		return "utf16be"
	elseif at(data, 1, "\255\254") then
		return "utf16le"
	end

	if rgba_dims(data) then
		return "rgba"
	end

	if (at(data, 1, "RIFF") or at(data, 1, "RIFX")) and n >= 12 then
		local t = data:sub(9, 12)
		if t == "WAVE" then
			return "wav"
		elseif t == "AVI " then
			return "avi"
		elseif t == "WEBP" then
			return "webp"
		elseif t == "RMID" then
			return "midi"
		end
		return "riff"
	end

	if n >= 12 and at(data, 5, "ftyp") then
		return ftypKind(data)
	end

	if at(data, 1, "PK\3\4") or at(data, 1, "PK\5\6") or at(data, 1, "PK\7\8") then
		return zipKind(data)
	end

	if at(data, 1, "\208\207\17\224\161\177\26\225") then
		return oleKind(data)
	end

	if at(data, 1, "!<arch>\n") or at(data, 1, "!<thin>\n") then
		if n >= 21 and data:sub(9, 21) == "debian-binary" then
			return "deb"
		end
		return "ar"
	end

	if b1 == 0xCA and b2 == 0xFE and b3 == 0xBA and b4 == 0xBE then
		local major = u16be(data, 7)
		local nfat = u32be(data, 5)
		if major and major >= 45 then
			return "java"
		elseif nfat and nfat >= 1 and nfat <= 64 then
			return "macho"
		end
		return "java"
	end

	if b1 == 0x4D and b2 == 0x5A then
		if n >= 64 then
			local lfanew = u32le(data, 0x3D)
			if lfanew and lfanew + 4 <= n and at(data, lfanew + 1, "PE\0\0") then
				return "pe"
			end
		end
		return "mz"
	end

	if b1 == 0xFF and b2 then
		local layer = (b2 >> 1) & 3
		local version = (b2 >> 3) & 3
		if (b2 & 0xF6) == 0xF0 then
			return "aac"
		elseif (b2 & 0xE0) == 0xE0 and layer ~= 0 and version ~= 1 then
			return "mp3"
		end
	end

	if b1 == 0x42 and b2 == 0x5A and b3 == 0x68 and b4 and b4 >= 0x31 and b4 <= 0x39 then
		return "bzip2"
	end

	if b1 and b2 and (b1 & 0x0F) == 8 and (b1 >> 4) <= 7 and ((b1 << 8) + b2) % 31 == 0 then
		return "zlib"
	end

	if b1 == 0x5D and b2 == 0 and b3 == 0 and b4 == 0 and n >= 13 then
		return "lzma"
	end

	if b1 == 0x0A and (b2 == 0 or b2 == 2 or b2 == 3 or b2 == 4 or b2 == 5) then
		return "pcx"
	end

	if at(data, 1, "\26\69\223\163") then
		local head = data:sub(1, 64)
		if has(head, "webm") then
			return "webm"
		end
		return "mkv"
	end

	if at(data, 1, "dex\n") then
		local v = data:byte(5)
		if v and v >= 0x30 and v <= 0x39 then
			return "dex"
		end
	end

	local trimmed = data:sub(1, 512):gsub("^%s+", "")
	local low = trimmed:lower()
	if low:sub(1, 14) == "<!doctype html" or low:sub(1, 5) == "<html" or low:sub(1, 5) == "<head" then
		return "html"
	end
	if low:sub(1, 5) == "<?xml" then
		if has(data:sub(1, 2048):lower(), "<svg") then
			return "svg"
		end
		return "xml"
	end
	if low:sub(1, 4) == "<svg" then
		return "svg"
	end

	for _, r in ipairs(SIGS) do
		if at(data, r[3] or 1, r[2]) then
			return r[1]
		end
	end

	if n >= 18 and data:sub(n - 17, n - 1) == "TRUEVISION-XFILE." then
		return "tga"
	end
	if n >= 512 and at(data, n - 511, "koly") then
		return "dmg"
	end
	if n >= 512 and at(data, n - 511, "conectix") then
		return "vhd"
	end

	if at(data, 1, "#!") then
		return "script"
	end

	return nil
end

local function imageDesc(kind, label)
	return function(data)
		local lib = backend(kind)
		if lib and type(lib.natural_size) == "function" then
			local ok, w, h = pcall(lib.natural_size, data)
			if ok and w and h then
				return string.format("%s, %dx%d", label, w, h)
			end
		end
		return label
	end
end

local DESC = {
	png = "PNG image data",
	jpg = "JPEG image data",
	gif = "GIF image data",
	bmp = "BMP image data",
	qoi = "QOI image data",
	ppm = "Netpbm image data",
	svg = "SVG vector image",
	webp = "WebP image data",
	tiff = "TIFF image data",
	ico = "Windows icon",
	cur = "Windows cursor",
	psd = "Photoshop document",
	xcf = "GIMP XCF image",
	avif = "AVIF image data",
	heic = "HEIF image data",
	jxl = "JPEG XL image data",
	jp2 = "JPEG 2000 image",
	j2k = "JPEG 2000 codestream",
	dds = "DirectDraw surface",
	hdr = "Radiance HDR image",
	exr = "OpenEXR image",
	farbfeld = "farbfeld image data",
	pcx = "PCX image data",
	tga = "Targa image data",
	ktx = "Khronos texture",
	riff = "RIFF container",
	rgba = "XesNS RGBA bitmap",

	woff2 = "WOFF2 font",
	woff = "WOFF font",
	ttc = "TrueType font collection",
	otf = "OpenType font",
	ttf = "TrueType font",
	pcf = "PCF bitmap font",
	bdf = "BDF bitmap font",
	psf1 = "PC Screen Font (PSF1 bitmap font)",
	psf2 = "PC Screen Font (PSF2 bitmap font)",

	rpm = "RPM package",
	["7z"] = "7-zip archive data",
	rar = "RAR archive data",
	cab = "Microsoft Cabinet archive",
	wim = "Windows Imaging Format archive",
	xar = "xar archive",
	squashfs = "Squashfs filesystem image",
	cramfs = "cramfs filesystem image",
	xz = "XZ compressed data",
	lzip = "lzip compressed data",
	lz4 = "LZ4 compressed data",
	zstd = "Zstandard compressed data",
	lzop = "lzop compressed data",
	lrzip = "lrzip compressed data",
	compress = "compress'd data",
	gzip = "gzip compressed data",
	zlib = "zlib compressed data",
	bzip2 = "bzip2 compressed data",
	lzma = "LZMA compressed data",
	zip = "Zip archive data",
	epub = "EPUB ebook (Zip archive)",
	jar = "Java archive (Zip archive)",
	apk = "Android package (Zip archive)",
	docx = "Word document (Zip archive)",
	xlsx = "Excel workbook (Zip archive)",
	pptx = "PowerPoint presentation (Zip archive)",
	ar = "Unix ar archive",
	deb = "Debian package",
	cpio = "cpio archive",
	iso9660 = "ISO 9660 filesystem image",
	udf = "UDF filesystem image",
	tar = "POSIX tar archive",

	flac = "FLAC audio",
	ogg = "Ogg media",
	midi = "Standard MIDI file",
	au = "Sun/NeXT audio",
	flv = "Flash video",
	asf = "Windows Media",
	wavpack = "WavPack audio",
	musepack = "Musepack audio",
	ape = "Monkey's Audio",
	tta = "True Audio",
	amr = "Adaptive Multi-Rate audio",
	wav = "WAVE audio",
	avi = "AVI video",
	mp3 = "MPEG audio",
	aac = "AAC audio",
	mp4 = "MP4 media",
	mov = "QuickTime movie",
	m4a = "MPEG-4 audio",
	["3gp"] = "3GPP media",
	mkv = "Matroska media",
	webm = "WebM media",

	pdf = "PDF document",
	ps = "PostScript document",
	dvi = "TeX DVI file",
	rtf = "Rich Text Format document",
	ole = "OLE compound document",
	doc = "Microsoft Word document",
	xls = "Microsoft Excel workbook",
	ppt = "Microsoft PowerPoint presentation",
	sqlite = "SQLite 3 database",
	html = "HTML document",
	xml = "XML document",
	vcard = "vCard",
	ical = "iCalendar",
	pgp = "PGP message or key",
	pem = "PEM encoded data",
	["openssh-key"] = "OpenSSH private key",

	elf = "ELF executable",
	pe = "PE executable",
	mz = "DOS executable",
	macho = "Mach-O executable",
	java = "Java class data",
	wasm = "WebAssembly binary",
	lua = "Lua bytecode",
	dex = "Dalvik executable",
	lnk = "Windows shortcut",
	gitindex = "Git index",
	gitpack = "Git pack file",
	regf = "Windows registry hive",

	dmg = "Apple disk image",
	qcow = "QEMU QCOW disk image",
	vmdk = "VMware disk image",
	vdi = "VirtualBox disk image",
	vhd = "Virtual PC disk image",

	utf8bom = "UTF-8 Unicode text with BOM",
	utf16le = "UTF-16 little-endian text",
	utf16be = "UTF-16 big-endian text",
	utf32le = "UTF-32 little-endian text",
	utf32be = "UTF-32 big-endian text",
	script = "interpreted script",
}

local function elfDesc(data)
	local cls = data:byte(5)
	local enc = data:byte(6)
	local etype = enc == 2 and u16be(data, 17) or u16le(data, 17)
	local bits = cls == 2 and "64-bit" or "32-bit"
	local order = enc == 2 and "MSB" or "LSB"
	local kinds = { [1] = "relocatable", [2] = "executable", [3] = "shared object", [4] = "core file" }
	return "ELF " .. bits .. " " .. order .. " " .. (kinds[etype] or "file")
end

local function oggDesc(data)
	local head = data:sub(1, 512)
	if has(head, "OpusHead") then
		return "Ogg Opus audio"
	elseif has(head, "\1vorbis") then
		return "Ogg Vorbis audio"
	elseif has(head, "fLaC") then
		return "Ogg FLAC audio"
	elseif has(head, "Speex") then
		return "Ogg Speex audio"
	elseif has(head, "theora") then
		return "Ogg Theora video"
	end
	return "Ogg media"
end

local DESCRIBERS = {
	png = imageDesc("png", "PNG image data"),
	jpg = imageDesc("jpg", "JPEG image data"),
	qoi = imageDesc("qoi", "QOI image data"),
	bmp = imageDesc("bmp", "BMP image data"),
	ppm = imageDesc("ppm", "PPM image data"),
	svg = imageDesc("svg", "SVG vector image"),
	rgba = function(data)
		local w, h = rgba_dims(data)
		if w then
			return string.format("XesNS RGBA bitmap, %dx%d", w, h)
		end
		return "XesNS RGBA bitmap"
	end,
	gif = function(data)
		local w, h = u16le(data, 7), u16le(data, 9)
		if w and h then
			return string.format("GIF image data, %dx%d", w, h)
		end
		return "GIF image data"
	end,
	ico = function(data)
		local count = u16le(data, 5)
		if count then
			return string.format("Windows icon, %d image%s", count, count == 1 and "" or "s")
		end
		return "Windows icon"
	end,
	cur = function(data)
		local count = u16le(data, 5)
		if count then
			return string.format("Windows cursor, %d image%s", count, count == 1 and "" or "s")
		end
		return "Windows cursor"
	end,
	script = function(data)
		return "interpreted script for " .. (data:match("^#![ \t]*([^\r\n]+)") or "?")
	end,
	pem = function(data)
		local label = data:match("^%-%-%-%-%-BEGIN ([%w ]+)%-%-%-%-%-")
		return label and ("PEM encoded " .. label) or "PEM encoded data"
	end,
	elf = elfDesc,
	java = function(data)
		local major = u16be(data, 7)
		if major then
			return string.format("Java class data, major version %d", major)
		end
		return "Java class data"
	end,
	ogg = oggDesc,
}

function M.detect(data, path)
	if type(data) ~= "string" or #data == 0 then
		return nil
	end
	local kind = detectContent(data)
	if kind then
		return kind
	end
	for _, name in ipairs({ "png", "jpg", "qoi", "bmp", "ppm", "svg" }) do
		local lib = backend(name)
		if lib then
			local ok, hit = pcall(lib.detect, data, nil)
			if ok and hit then
				return name
			end
		end
	end
	if type(path) == "string" then
		for _, name in ipairs({ "png", "jpg", "qoi", "bmp", "ppm", "svg" }) do
			local lib = backend(name)
			if lib then
				local ok, hit = pcall(lib.detect, data, path)
				if ok and hit then
					return name
				end
			end
		end
	end
	return nil
end

function M.describe(data, path)
	local kind = M.detect(data, path)
	if not kind then
		return nil
	end
	local fn = DESCRIBERS[kind]
	if fn then
		local ok, text = pcall(fn, data)
		if ok and text then
			return text
		end
	end
	return DESC[kind]
end

function M.kinds()
	local out = {}
	for kind in pairs(DESC) do
		out[#out + 1] = kind
	end
	table.sort(out)
	return out
end

return M
