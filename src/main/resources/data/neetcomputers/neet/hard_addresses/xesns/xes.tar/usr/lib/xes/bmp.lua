local M = {}

M.VERSION = "0.2.0"

local mfloor = math.floor

local MAX_DIM = 2048
local MAX_BYTES = 8 * 1024 * 1024

local function u16le(s, p)
	local a, b = s:byte(p, p + 1)
	if not b then
		return nil
	end
	return a + b * 256
end

local function u32le(s, p)
	local a, b, c, d = s:byte(p, p + 3)
	if not d then
		return nil
	end
	return a + b * 256 + c * 65536 + d * 16777216
end

local function i32le(s, p)
	local v = u32le(s, p)
	if not v then
		return nil
	end
	if v >= 0x80000000 then
		return v - 0x100000000
	end
	return v
end

local function bg_to_rgb(bg)
	if type(bg) == "number" then
		return { mfloor(bg / 65536) % 256, mfloor(bg / 256) % 256, bg % 256 }
	elseif type(bg) == "table" then
		local function clamp(v)
			v = mfloor(tonumber(v) or 255)
			if v < 0 then
				return 0
			end
			if v > 255 then
				return 255
			end
			return v
		end
		return { clamp(bg[1] or bg.r), clamp(bg[2] or bg.g), clamp(bg[3] or bg.b) }
	end
	return { 255, 255, 255 }
end

local function mask_spec(mask)
	if not mask or mask == 0 or mask >= 0x100000000 then
		return nil
	end
	local shift = 0
	while mask % 2 == 0 do
		mask = mask / 2
		shift = shift + 1
	end
	local p = mask + 1
	while p % 2 == 0 do
		p = p / 2
	end
	if p ~= 1 then
		return nil
	end
	local width = 0
	while mask > 0 do
		width = width + 1
		mask = mfloor(mask / 2)
	end
	return shift, width
end

local function mask_apply(pxval, shift, width)
	local v = mfloor(pxval / (2 ^ shift)) % (2 ^ width)
	if width >= 8 then
		return mfloor(v / (2 ^ (width - 8)))
	end
	return mfloor(v * 255 / ((2 ^ width) - 1) + 0.5)
end

function M.detect(data, path)
	if type(data) == "string" and #data >= 2 then
		if data:sub(1, 2) == "BM" then
			return true
		end
	end
	if type(path) == "string" then
		local lp = path:lower()
		if lp:match("%.bmp$") or lp:match("%.dib$") then
			return true
		end
	end
	return false
end

local function headers(data)
	if type(data) ~= "string" or #data == 0 then
		return nil, "empty bmp data"
	end
	if #data > MAX_BYTES then
		return nil, "bmp too large"
	end
	if #data < 2 or data:sub(1, 2) ~= "BM" then
		return nil, "not a bmp image"
	end
	if #data < 26 then
		return nil, "truncated bmp data"
	end
	local offset = u32le(data, 11)
	local dibsize = u32le(data, 15)

	local info = { data = data, offset = offset }
	if dibsize == 12 then
		info.core = true
		info.width = u16le(data, 19)
		info.height = u16le(data, 21)
		info.topdown = false
		local planes, bpp = u16le(data, 23), u16le(data, 25)
		info.planes, info.bpp, info.comp = planes, bpp, 0
	elseif dibsize and dibsize >= 40 then
		if #data < 14 + dibsize then
			return nil, "truncated bmp data"
		end
		local w, h = i32le(data, 19), i32le(data, 23)
		local planes, bpp = u16le(data, 27), u16le(data, 29)
		local comp = u32le(data, 31)
		info.core = false
		info.dibsize = dibsize
		info.width = w
		if h and h < 0 then
			info.height, info.topdown = -h, true
		else
			info.height, info.topdown = h, false
		end
		info.planes, info.bpp, info.comp = planes, bpp, comp
	else
		return nil, "unsupported bmp header"
	end

	local w, h = info.width, info.height
	if not w or w < 1 or w > MAX_DIM or not h or h < 1 or h > MAX_DIM then
		return nil, "bad bmp dimensions"
	end
	if w * h * 4 > MAX_BYTES then
		return nil, "bmp too large"
	end
	if info.planes ~= 1 then
		return nil, "bad bmp planes"
	end
	local bpp = info.bpp
	if bpp ~= 1 and bpp ~= 4 and bpp ~= 8 and bpp ~= 16 and bpp ~= 24 and bpp ~= 32 then
		return nil, "unsupported bmp depth"
	end
	local comp = info.comp
	if comp == 1 or comp == 2 then
		return nil, "rle bmp not supported"
	elseif comp == 4 or comp == 5 then
		return nil, "compressed bmp not supported"
	elseif comp ~= 0 and comp ~= 3 then
		return nil, "unsupported bmp compression"
	end
	if comp == 3 and bpp ~= 16 and bpp ~= 32 then
		return nil, "unsupported bmp compression"
	end

	info.masks = nil
	if comp == 3 then
		local rmask, gmask, bmask, amask
		if dibsize > 40 then
			rmask, gmask, bmask = u32le(data, 55), u32le(data, 59), u32le(data, 63)
			amask = (dibsize >= 56) and u32le(data, 67) or 0
		else
			if #data < 14 + 40 + 12 then
				return nil, "truncated bmp data"
			end
			rmask, gmask, bmask = u32le(data, 55), u32le(data, 59), u32le(data, 63)
			amask = 0
		end
		local rs, rw = mask_spec(rmask)
		local gs, gw = mask_spec(gmask)
		local bs, bw = mask_spec(bmask)
		if not rs or not gs or not bs then
			return nil, "bad bmp masks"
		end
		local aspec = nil
		if amask and amask ~= 0 then
			local as, aw = mask_spec(amask)
			if not as then
				return nil, "bad bmp masks"
			end
			aspec = { as, aw }
		end
		info.masks = { r = { rs, rw }, g = { gs, gw }, b = { bs, bw }, a = aspec }
	elseif bpp == 16 then
		info.masks = { r = { 10, 5 }, g = { 5, 5 }, b = { 0, 5 }, a = nil }
	end

	info.palette = nil
	local head_end = 14 + dibsize
	if bpp <= 8 then
		local ncolors, palstart, entry
		if info.core then
			ncolors = 2 ^ bpp
			palstart, entry = 27, 3
		else
			local clrused = u32le(data, 47)
			ncolors = (clrused ~= 0) and clrused or (2 ^ bpp)
			if ncolors < 1 or ncolors > 2 ^ bpp then
				return nil, "bad bmp palette"
			end
			palstart = 14 + dibsize + 1
			if comp == 3 and dibsize == 40 then
				palstart = palstart + 12
			end
			entry = 4
		end
		local pal_end = palstart + ncolors * entry
		if pal_end - 1 > #data then
			return nil, "truncated bmp data"
		end
		local pal = {}
		for i = 1, ncolors do
			local o = palstart + (i - 1) * entry
			local b, g, r = data:byte(o, o + 2)
			pal[i] = { r, g, b }
		end
		info.palette = pal
		head_end = pal_end
	end

	if not offset or offset + 1 < head_end then
		return nil, "bad bmp offset"
	end
	info.stride = mfloor((bpp * w + 31) / 32) * 4
	return info
end

function M.parse(data)
	return headers(data)
end

function M.natural_size(data_or_info)
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = headers(info)
		if not inf2 then
			return nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, "not a parsed bmp image"
	end
	return info.width, info.height
end

function M.decode(data_or_info, opts)
	opts = opts or {}
	local info = data_or_info
	local data = nil
	if type(info) == "string" then
		data = info
		local inf2, err = headers(data)
		if not inf2 then
			return nil, nil, nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, nil, nil, "not a parsed bmp image"
	end
	data = data or info.data
	if type(data) ~= "string" then
		return nil, nil, nil, "not a parsed bmp image"
	end
	if #data > MAX_BYTES then
		return nil, nil, nil, "bmp too large"
	end

	local w, h = info.width, info.height
	local bpp, comp = info.bpp, info.comp
	local stride = info.stride
	if info.offset + stride * h > #data then
		return nil, nil, nil, "truncated bmp data"
	end

	local keep_alpha = opts.alpha == true
	local bg = nil
	if not keep_alpha then
		bg = bg_to_rgb(opts.background)
	end
	if bg == nil and not keep_alpha then
		bg = { 255, 255, 255 }
	end

	local schar = string.char
	local pal = info.palette
	local masks = info.masks
	local parts = {}

	for row = 1, h do
		local src = info.topdown and row or (h - row + 1)
		local base = info.offset + (src - 1) * stride
		local prow = data:sub(base + 1, base + stride)
		local px = {}
		if bpp == 24 then
			for x = 0, w - 1 do
				local b, g, r = prow:byte(x * 3 + 1, x * 3 + 3)
				if not r then
					return nil, nil, nil, "truncated bmp data"
				end
				px[x + 1] = schar(r, g, b, 255)
			end
		elseif bpp == 32 then
			if masks then
				local rs, rw = masks.r[1], masks.r[2]
				local gs, gw = masks.g[1], masks.g[2]
				local bs, bw = masks.b[1], masks.b[2]
				local aspec = masks.a
				for x = 0, w - 1 do
					local b1, b2, b3, b4 = prow:byte(x * 4 + 1, x * 4 + 4)
					if not b4 then
						return nil, nil, nil, "truncated bmp data"
					end
					local v = b1 + b2 * 256 + b3 * 65536 + b4 * 16777216
					local r = mask_apply(v, rs, rw)
					local g = mask_apply(v, gs, gw)
					local b = mask_apply(v, bs, bw)
					local a = aspec and mask_apply(v, aspec[1], aspec[2]) or 255
					if keep_alpha then
						px[x + 1] = schar(r, g, b, a)
					elseif a == 255 then
						px[x + 1] = schar(r, g, b, 255)
					elseif a == 0 then
						px[x + 1] = schar(bg[1], bg[2], bg[3], 255)
					else
						local ia = 255 - a
						px[x + 1] = schar(
							mfloor((r * a + bg[1] * ia) / 255 + 0.5),
							mfloor((g * a + bg[2] * ia) / 255 + 0.5),
							mfloor((b * a + bg[3] * ia) / 255 + 0.5),
							255
						)
					end
				end
			else
				for x = 0, w - 1 do
					local b, g, r = prow:byte(x * 4 + 1, x * 4 + 3)
					if not r then
						return nil, nil, nil, "truncated bmp data"
					end
					px[x + 1] = schar(r, g, b, 255)
				end
			end
		elseif bpp == 16 then
			local rs, rw = masks.r[1], masks.r[2]
			local gs, gw = masks.g[1], masks.g[2]
			local bs, bw = masks.b[1], masks.b[2]
			for x = 0, w - 1 do
				local lo, hi = prow:byte(x * 2 + 1, x * 2 + 2)
				if not hi then
					return nil, nil, nil, "truncated bmp data"
				end
				local v = lo + hi * 256
				px[x + 1] = schar(mask_apply(v, rs, rw), mask_apply(v, gs, gw), mask_apply(v, bs, bw), 255)
			end
		elseif bpp == 8 then
			for x = 1, w do
				local idx = prow:byte(x)
				if not idx then
					return nil, nil, nil, "truncated bmp data"
				end
				local e = pal[idx + 1]
				if not e then
					return nil, nil, nil, "bad bmp palette index"
				end
				px[x] = schar(e[1], e[2], e[3], 255)
			end
		elseif bpp == 4 then
			for x = 0, w - 1 do
				local by = prow:byte(mfloor(x / 2) + 1)
				if not by then
					return nil, nil, nil, "truncated bmp data"
				end
				local idx
				if x % 2 == 0 then
					idx = mfloor(by / 16)
				else
					idx = by % 16
				end
				local e = pal[idx + 1]
				if not e then
					return nil, nil, nil, "bad bmp palette index"
				end
				px[x + 1] = schar(e[1], e[2], e[3], 255)
			end
		else
			for x = 0, w - 1 do
				local by = prow:byte(mfloor(x / 8) + 1)
				if not by then
					return nil, nil, nil, "truncated bmp data"
				end
				local idx = mfloor(by / (2 ^ (7 - (x % 8)))) % 2
				local e = pal[idx + 1]
				if not e then
					return nil, nil, nil, "bad bmp palette index"
				end
				px[x + 1] = schar(e[1], e[2], e[3], 255)
			end
		end
		parts[row] = table.concat(px)
	end
	return w, h, table.concat(parts)
end

M.render = M.decode

return M
