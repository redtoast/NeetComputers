local K, API, X = ...
local T = {}

if K.extensions then
	K.extensions["x.xesns.binfmt"] = 1
end

local SIGNAMES = {
	hup = K.SIG.HUP,
	int = K.SIG.INT,
	quit = K.SIG.QUIT,
	ill = K.SIG.ILL,
	trap = K.SIG.TRAP,
	abrt = K.SIG.ABRT,
	fpe = K.SIG.FPE,
	kill = K.SIG.KILL,
	segv = K.SIG.SEGV,
	usr1 = K.SIG.USR1,
	usr2 = K.SIG.USR2,
	pipe = K.SIG.PIPE,
	alrm = K.SIG.ALRM,
	term = K.SIG.TERM,
	stop = K.SIG.STOP,
	cont = K.SIG.CONT,
	chld = K.SIG.CHLD,
}

function X.sigNumber(sig)
	if math.type(sig) == "integer" then
		if sig < 0 or sig > 64 then
			return nil, "invalid signal number"
		end
		return sig
	end
	if type(sig) == "string" then
		local n = SIGNAMES[sig:lower()]
		if not n then
			return nil, "unknown signal '" .. sig .. "'"
		end
		return n
	end
	return nil, "signal must be a name or a number"
end

local function procOf(pid)
	if pid == nil or pid == 0 then
		return K.current
	end
	local t = K.procs[pid]
	if not t or t.state == "Z" then
		return nil, "no such process"
	end
	return t
end

local function maySee(me, t)
	return t == me or me.uid == 0 or me.uid == t.uid or t.ppid == me.pid
end

local function maySignal(me, t)
	if t.pid == 1 and t ~= me then
		return false
	end
	return t == me or me.uid == 0 or me.uid == t.uid or t.ppid == me.pid
end

local function procMem(p)
	if type(p.memory) == "number" then
		return p.memory
	end
	if p.co and coroutine.memoryused then
		local ok, m = pcall(coroutine.memoryused, p.co)
		if ok and type(m) == "number" then
			return math.tointeger(m) or m
		end
	end
	return 0
end

local function groupLive(pgid)
	for _, q in pairs(K.procs) do
		if q.pgid == pgid and q.state ~= "Z" then
			return true
		end
	end
	return false
end

function T.fork(p)
	local pid, err = K.fork()
	if pid == nil then
		local em = tostring(err or "cannot fork")
		if em:find("too many processes", 1, true) then
			return nil, "ELIMIT", em
		end
		return nil, "EIO", em
	end
	return pid
end

function T.useSignalEvents(p, on)
	p.sigevents = on ~= false
	if p.sigevents and not p.termGrace then
		p.termGrace = 10
	end
	return true
end

function T.signal(p, pid, sig)
	K.argcheck.int(pid, 1, "signal")
	local signum, serr = X.sigNumber(sig)
	if not signum then
		return nil, "EINVAL", tostring(serr)
	end

	local targets = {}
	local function add(q)
		if q and q.state ~= "Z" and not targets[q.pid] then
			targets[q.pid] = q
		end
	end

	if pid > 0 then
		local t, err = procOf(pid)
		if not t then
			return nil, "ESRCH", err
		end
		add(t)
	else
		local pgid = pid == 0 and p.pgid or (pid == -1 and nil or -pid)
		for _, q in pairs(K.procs) do
			if q.state ~= "Z" and (pgid == nil or q.pgid == pgid) then
				add(q)
			end
		end
	end

	local pids = K.sortedKeys(targets)
	if #pids == 0 then
		return nil, "ESRCH", "no such process"
	end
	if pid > 0 and targets[1] and targets[1] ~= p then
		return nil, "EPERM", "operation not permitted"
	end
	local delivered, denied = 0, 0
	for _, tpid in ipairs(pids) do
		local t = targets[tpid]
		if maySignal(p, t) then
			if t == p and signum == K.SIG.KILL then
				K.exit(p, 128 + signum)
			end
			K.signal(t, signum)
			delivered = delivered + 1
			if t ~= p then
				K.authlog(
					"SIGNAL %s pid=%d from pid=%d uid=%d",
					K.sigName(signum),
					t.pid,
					p.pid,
					p.uid
				)
			end
		else
			denied = denied + 1
		end
	end
	if delivered == 0 then
		if denied > 0 then
			return nil, "EACCES", "permission denied"
		end
		return nil, "ESRCH", "no such process"
	end
	return true
end

function T.waitStatus(p, pid, nohang)
	if pid == nil then
		pid = -1
	end
	K.argcheck.int(pid, 1, "waitStatus")
	local cpid, status, sig, core, err = K.wait4(p, pid, nohang and true or false)
	if cpid == nil then
		return nil, "ECHILD", tostring(status or err or "no child processes")
	end
	if cpid == 0 then
		return nil
	end
	return {
		pid = cpid,
		status = (math.tointeger(status) or 0) % 256,
		signal = sig or 0,
		core = core == true,
	}
end

local function infoRow(t)
	return {
		pid = t.pid,
		ppid = t.ppid,
		pgid = t.pgid,
		sid = t.sid,
		uid = t.uid,
		gid = t.gid,
		state = t.state,
		cputime = t.cputime,
		memory = procMem(t),
		started = t.started - K.bootmonotonic,
		name = t.name,
	}
end

function T.info(p, pid)
	if pid == nil then
		local rows = {}
		for _, t in pairs(K.procs) do
			if maySee(p, t) then
				rows[#rows + 1] = infoRow(t)
			end
		end
		table.sort(rows, function(a, b)
			return a.pid < b.pid
		end)
		return rows
	end
	local t = K.procs[pid]
	if not t then
		return nil, "ESRCH", "no such process"
	end
	if not maySee(p, t) then
		return nil, "EACCES", "permission denied"
	end
	return infoRow(t)
end

function T.limits(p, pid)
	local t, err = procOf(pid)
	if not t then
		return nil, "ESRCH", err
	end
	if not maySee(p, t) then
		return nil, "EACCES", "permission denied"
	end
	local lim = t.limits or K.defaultLimits
	local as = t.memcap or lim.as or K.memcapDefault
	return {
		nofile = lim.nofile,
		nproc = lim.nproc,
		stack = lim.stack,
		as = as,
		cpu = lim.cpu or 0,
		memcap = as,
	}
end

function T.setLimits(p, pid, limits)
	if type(pid) == "table" and limits == nil then
		limits, pid = pid, nil
	end
	if type(limits) ~= "table" then
		K.argcheck.err(2, "setLimits", "table", limits)
	end
	local t, err = procOf(pid)
	if not t then
		return nil, "ESRCH", err
	end
	if t ~= p and p.uid ~= 0 and t.ppid ~= p.pid then
		return nil, "EACCES", "permission denied"
	end
	local lim = K.copy(t.limits or K.defaultLimits)
	for _, k in ipairs({ "nofile", "nproc", "stack", "as", "cpu", "memcap" }) do
		if limits[k] ~= nil then
			if type(limits[k]) ~= "number" or limits[k] < 0 then
				return nil, "EINVAL", "invalid " .. k .. " limit"
			end
			lim[k] = math.tointeger(limits[k]) or limits[k]
		end
	end
	if limits.as ~= nil then
		t.memcap = lim.as
	end
	if limits.memcap ~= nil then
		t.memcap = lim.memcap
		lim.as = lim.memcap
	end
	t.limits = lim
	return true
end

function T.setpgid(p, pid, pgid)
	pid = pid or 0
	pgid = pgid or 0
	K.argcheck.int(pid, 1, "setpgid")
	K.argcheck.int(pgid, 2, "setpgid")
	local t, err = procOf(pid)
	if not t then
		return nil, "ESRCH", err
	end
	if t ~= p and p.uid ~= 0 then
		if t.ppid ~= p.pid or p.uid ~= t.uid then
			return nil, "EACCES", "permission denied"
		end
	end
	if t.sid ~= p.sid and p.uid ~= 0 then
		return nil, "EPERM", "different session"
	end
	if pgid == 0 then
		pgid = t.pid
	end
	if pgid ~= t.pid then
		local j = K.jobs and K.jobs[pgid]
		if j then
			if p.uid ~= 0 and j.owner ~= p.pid and pgid ~= p.pgid then
				return nil, "EACCES", "permission denied"
			end
		elseif not groupLive(pgid) then
			return nil, "EPERM", "no such process group"
		elseif p.uid ~= 0 and not K.pgidAllowed(p, pgid) then
			return nil, "EACCES", "permission denied"
		end
	end
	t.pgid = pgid
	return true
end

function T.setsid(p)
	local oldpgid = p.pgid
	p.pgid, p.sid = p.pid, p.pid
	local tty = p.tty
	if tty and tty ~= K.nulltty and tty.fgpgid == oldpgid then
		tty.fgpgid = nil
	end
	return p.sid
end

function T.getsid(p, pid)
	local t, err = procOf(pid)
	if not t then
		return nil, "ESRCH", err
	end
	if t ~= p and p.uid ~= 0 and p.uid ~= t.uid then
		return nil, "EACCES", "permission denied"
	end
	return t.sid
end

function T.getpgid(p, pid)
	local t, err = procOf(pid)
	if not t then
		return nil, "ESRCH", err
	end
	if t ~= p and p.uid ~= 0 and p.uid ~= t.uid then
		return nil, "EACCES", "permission denied"
	end
	return t.pgid
end

function T.tcgetpgrp(p)
	local tty = p.tty
	if not tty or tty == K.nulltty then
		return nil, "ENOTSUP", "no controlling terminal"
	end
	local pgid = tty.fgpgid
	if pgid == nil then
		return nil, "ENOTSUP", "no foreground process group"
	end
	return pgid
end

function T.tcsetpgrp(p, pgid)
	K.argcheck.int(pgid, 1, "tcsetpgrp")
	local tty = p.tty
	if not tty or tty == K.nulltty then
		return nil, "ENOTSUP", "no controlling terminal"
	end
	if not K.pgidAllowed(p, pgid) then
		return nil, "EPERM", "operation not permitted"
	end
	tty.fgpgid = pgid
	K.tty_deliverPending(tty)
	return true
end

T.__ext = {
	["ext.fork"] = 1,
	["ext.signal"] = 1,
	["ext.wait4"] = 1,
	["ext.procinfo"] = 1,
}

return T
