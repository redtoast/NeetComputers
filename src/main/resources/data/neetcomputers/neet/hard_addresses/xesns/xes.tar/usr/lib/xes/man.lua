local M = {}

local P_IND = 2
local TAG_IND = 2
local BODY_IND = 6
local NF_IND = 2
local MIN_WIDTH = 20

local function colwidth(s)
    if not s:find("[\128-\255]") then return #s end
    if type(utf8) == "table" and type(utf8.len) == "function" then
        local ok, n = pcall(utf8.len, s)
        if ok and type(n) == "number" then return n end
    end
    return #s
end

local function words(s)
    local out = {}
    for w in s:gmatch("%S+") do out[#out + 1] = w end
    return out
end

local function splitword(w, width)
    local chunks, cur, curw = {}, "", 0
    local i, n = 1, #w
    while i <= n do
        local b = w:byte(i)
        local len = 1
        if b >= 240 then len = 4
        elseif b >= 224 then len = 3
        elseif b >= 192 then len = 2
        end
        if i + len - 1 > n then len = n - i + 1 end
        if curw + 1 > width then
            chunks[#chunks + 1] = cur
            cur, curw = "", 0
        end
        cur = cur .. w:sub(i, i + len - 1)
        curw = curw + 1
        i = i + len
    end
    if cur ~= "" then chunks[#chunks + 1] = cur end
    return chunks
end

local function reflow(wl, indent, width)
    local avail = width - indent
    if avail < 1 then avail = 1 end
    local pad = string.rep(" ", indent)
    local lines, cur, curw = {}, "", 0
    local function flush()
        if cur ~= "" then
            lines[#lines + 1] = pad .. cur
            cur, curw = "", 0
        end
    end
    for _, w in ipairs(wl) do
        local ww = colwidth(w)
        if cur == "" then
            if ww <= avail then
                cur, curw = w, ww
            else
                for _, c in ipairs(splitword(w, avail)) do
                    lines[#lines + 1] = pad .. c
                end
            end
        elseif curw + 1 + ww <= avail then
            local gap = cur:match("..[%.%?!]$") and "  " or " "
            if curw + #gap + ww > avail then
                flush()
                cur, curw = w, ww
            else
                cur, curw = cur .. gap .. w, curw + #gap + ww
            end
        else
            flush()
            if ww <= avail then
                cur, curw = w, ww
            else
                for _, c in ipairs(splitword(w, avail)) do
                    lines[#lines + 1] = pad .. c
                end
            end
        end
    end
    flush()
    return lines
end

local function unescape(s) return (s:gsub("\\&", "")) end

function M.parse(text)
    local doc = { th = nil, blocks = {} }
    local para = nil
    local nf = nil
    local lineno = 0

    local function fail(msg) return nil, "line " .. lineno .. ": " .. msg end
    local function close_para() para = nil end

    local function open_para(kind, tag)
        close_para()
        if kind == "tp" then
            para = { t = "tp", tag = tag, segs = {} }
        else
            para = { t = "p", segs = {} }
        end
        doc.blocks[#doc.blocks + 1] = para
    end

    local function add_segment(wl)
        if not para then open_para("p") end
        para.segs[#para.segs + 1] = wl
    end

    for raw in (text .. "\n"):gmatch("([^\n]*)\n") do
        lineno = lineno + 1
        local line = raw:gsub("\r$", "")
        local m, rest = line:match("^%.([A-Z][A-Z]+)%s*(.-)%s*$")
        if nf then
            if m == "FI" then
                nf = nil
            else
                nf[#nf + 1] = unescape(line)
            end
        elseif m then
            if para and para.t == "tp" and para.tag == nil then
                return fail(".TP without tag")
            end
            if m == "TH" then
                if doc.th then return fail("duplicate .TH") end
                local title, sect, manual =
                    rest:match("^(%S+)%s+(%S+)%s*(.-)%s*$")
                if not title or not sect then
                    return fail("usage: .TH title section manual")
                end
                manual = manual:gsub('^"(.-)"$', "%1")
                doc.th = { title = title, sect = sect, manual = manual }
                close_para()
            elseif m == "SH" or m == "SS" then
                if rest == "" then return fail("." .. m .. " needs a heading") end
                close_para()
                doc.blocks[#doc.blocks + 1] =
                    { t = m == "SH" and "sh" or "ss", s = unescape(rest) }
            elseif m == "TP" then
                if rest ~= "" then return fail(".TP takes no arguments") end
                para = { t = "tp", tag = nil, segs = {} }
                doc.blocks[#doc.blocks + 1] = para
            elseif m == "PP" then
                close_para()
            elseif m == "NF" then
                if rest ~= "" then return fail(".NF takes no arguments") end
                close_para()
                nf = {}
                doc.blocks[#doc.blocks + 1] = { t = "nf", lines = nf }
            elseif m == "FI" then
                return fail(".FI without .NF")
            elseif m == "BR" then
                if rest ~= "" then return fail(".BR takes no arguments") end
                if not para then open_para("p") end
                para.segs[#para.segs + 1] = {}
            else
                return fail("unknown macro ." .. m)
            end
        elseif line:match("^%s*$") then
            if para and para.t == "tp" and para.tag == nil then
            else
                close_para()
            end
        else
            local text_line = unescape(line)
            if para and para.t == "tp" and para.tag == nil then
                para.tag = words(text_line)
                if #para.tag == 0 then para.tag = nil end
            else
                add_segment(words(text_line))
            end
        end
    end
    if para and para.t == "tp" and para.tag == nil then
        return nil, "line " .. lineno .. ": .TP without tag"
    end
    if not doc.th then return nil, "missing .TH" end
    return doc
end

local function header_line(th, width)
    local lr = th.title .. "(" .. th.sect .. ")"
    local manual = th.manual or ""
    if width < MIN_WIDTH then width = MIN_WIDTH end
    if #lr * 2 + #manual + 2 > width or manual == "" then
        return lr
    end
    local mid = math.floor((width - colwidth(manual)) / 2)
    if mid < #lr + 1 then mid = #lr + 1 end
    if mid + colwidth(manual) > width - #lr then
        return lr
    end
    return lr .. string.rep(" ", mid - #lr) .. manual ..
        string.rep(" ", width - #lr - (mid - #lr) - colwidth(manual) - #lr) .. lr
end

function M.render(doc, width)
    width = math.tointeger(width) or 80
    if width < MIN_WIDTH then width = MIN_WIDTH end
    local out = {}
    local function emit(s) out[#out + 1] = s end

    emit(header_line(doc.th, width))
    for _, b in ipairs(doc.blocks) do
        if b.t == "sh" then
            emit("")
            emit(b.s)
        elseif b.t == "ss" then
            emit("")
            emit(b.s)
        elseif b.t == "p" then
            emit("")
            for _, seg in ipairs(b.segs) do
                if #seg > 0 then
                    for _, l in ipairs(reflow(seg, P_IND, width)) do emit(l) end
                end
            end
        elseif b.t == "tp" then
            emit(string.rep(" ", TAG_IND) .. table.concat(b.tag or {}, " "))
            for _, seg in ipairs(b.segs) do
                if #seg > 0 then
                    for _, l in ipairs(reflow(seg, BODY_IND, width)) do emit(l) end
                end
            end
        elseif b.t == "nf" then
            emit("")
            local pad = string.rep(" ", NF_IND)
            for _, l in ipairs(b.lines) do emit(pad .. l) end
        end
    end
    return out
end

function M.format(text, width)
    local doc, err = M.parse(text)
    if not doc then return nil, err end
    return M.render(doc, width)
end

function M.nameline(doc)
    local in_name = false
    for _, b in ipairs(doc.blocks) do
        if b.t == "sh" then
            in_name = (b.s == "NAME")
        elseif in_name and b.t == "p" then
            for _, seg in ipairs(b.segs) do
                if #seg > 0 then return table.concat(seg, " ") end
            end
            return nil
        end
    end
    return nil
end

return M
