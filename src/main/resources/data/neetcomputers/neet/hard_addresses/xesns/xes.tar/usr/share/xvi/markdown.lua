return {
    extensions = { "md", "markdown" },
    words = {},
    rules = {
        { "keyword", "^#+ .*" },
        { "special", "```.*" },
        { "string", "`[^`]*`" },
        { "type", "%*%*[^%*]+%*%*", "__[^_]+__" },
        { "constant", "%*[^%*]+%*", "_[^_]+_" },
        { "function", "%[[^%]]*%]%b()" },
        { "preproc", "^%s*[>%-%*%+] " },
        { "number", "^%s*%d+%. " },
    },
}
