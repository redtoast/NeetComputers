local M = {}

M.SYSTEM_PATH = "/etc/xeswmrc"
M.USER_NAME = ".xeswmrc"
M.THEME_KEYS = {
    "desktop",
    "title_active", "title_active_hi", "title_active_lo",
    "title_inactive", "title_inactive_hi", "title_inactive_lo",
    "title_fg", "title_fg_inactive",
    "border", "frame_hi", "frame_lo",
    "button", "button_hi", "button_lo", "button_fg",
    "content",
    "panel", "panel_hi", "panel_lo",
    "task_fg", "clock_fg",
    "menu", "menu_fg",
}

local function rgb(r, g, b) return (r << 16) | (g << 8) | b end

M.PRESETS = {
    default = {
        desktop = rgb(0x89, 0x98, 0xAA),
        title_active = rgb(0xED, 0xA8, 0x70),
        title_active_hi = rgb(0xF8, 0xD0, 0xA8),
        title_active_lo = rgb(0xA0, 0x68, 0x38),
        title_inactive = rgb(0x99, 0x99, 0x99),
        title_inactive_hi = rgb(0xC8, 0xC8, 0xC8),
        title_inactive_lo = rgb(0x58, 0x58, 0x58),
        title_fg = rgb(0x00, 0x00, 0x00),
        title_fg_inactive = rgb(0x18, 0x18, 0x18),
        border = rgb(0x99, 0x99, 0x99),
        frame_hi = rgb(0xC8, 0xC8, 0xC8),
        frame_lo = rgb(0x50, 0x50, 0x50),
        button = rgb(0xA8, 0xA8, 0xA8),
        button_hi = rgb(0xD8, 0xD8, 0xD8),
        button_lo = rgb(0x58, 0x58, 0x58),
        button_fg = rgb(0x00, 0x00, 0x00),
        content = rgb(0x00, 0x00, 0x00),
        panel = rgb(0x99, 0x99, 0x99),
        panel_hi = rgb(0xC8, 0xC8, 0xC8),
        panel_lo = rgb(0x58, 0x58, 0x58),
        task_fg = rgb(0x00, 0x00, 0x00),
        clock_fg = rgb(0x00, 0x00, 0x00),
        menu = rgb(0xA8, 0xA8, 0xA8),
        menu_fg = rgb(0x00, 0x00, 0x00),
    },
    midnight = {
        desktop = rgb(0x14, 0x18, 0x1F),
        title_active = rgb(0x2E, 0x4A, 0x6B),
        title_active_hi = rgb(0x55, 0x77, 0xA0),
        title_active_lo = rgb(0x16, 0x23, 0x3A),
        title_inactive = rgb(0x2A, 0x2E, 0x35),
        title_inactive_hi = rgb(0x4A, 0x50, 0x58),
        title_inactive_lo = rgb(0x14, 0x16, 0x1A),
        title_fg = rgb(0xE8, 0xE8, 0xE8),
        title_fg_inactive = rgb(0xB0, 0xB0, 0xB0),
        border = rgb(0x2A, 0x2E, 0x35),
        frame_hi = rgb(0x4A, 0x50, 0x58),
        frame_lo = rgb(0x0A, 0x0C, 0x10),
        button = rgb(0x2E, 0x34, 0x3C),
        button_hi = rgb(0x56, 0x5E, 0x68),
        button_lo = rgb(0x14, 0x16, 0x1A),
        button_fg = rgb(0xE8, 0xE8, 0xE8),
        content = rgb(0x00, 0x00, 0x00),
        panel = rgb(0x2A, 0x2E, 0x35),
        panel_hi = rgb(0x4A, 0x50, 0x58),
        panel_lo = rgb(0x14, 0x16, 0x1A),
        task_fg = rgb(0xE8, 0xE8, 0xE8),
        clock_fg = rgb(0xE8, 0xE8, 0xE8),
        menu = rgb(0x2E, 0x4A, 0x6B),
        menu_fg = rgb(0xFF, 0xFF, 0xFF),
    },
    paper = {
        desktop = rgb(0xC8, 0xCC, 0xC8),
        title_active = rgb(0xA8, 0xC8, 0xA8),
        title_active_hi = rgb(0xD0, 0xE8, 0xD0),
        title_active_lo = rgb(0x68, 0x88, 0x68),
        title_inactive = rgb(0xB8, 0xB8, 0xB8),
        title_inactive_hi = rgb(0xE0, 0xE0, 0xE0),
        title_inactive_lo = rgb(0x78, 0x78, 0x78),
        title_fg = rgb(0x00, 0x00, 0x00),
        title_fg_inactive = rgb(0x20, 0x20, 0x20),
        border = rgb(0xB8, 0xB8, 0xB8),
        frame_hi = rgb(0xE8, 0xE8, 0xE8),
        frame_lo = rgb(0x68, 0x68, 0x68),
        button = rgb(0xC0, 0xC0, 0xC0),
        button_hi = rgb(0xE8, 0xE8, 0xE8),
        button_lo = rgb(0x70, 0x70, 0x70),
        button_fg = rgb(0x00, 0x00, 0x00),
        content = rgb(0x00, 0x00, 0x00),
        panel = rgb(0xB8, 0xB8, 0xB8),
        panel_hi = rgb(0xE0, 0xE0, 0xE0),
        panel_lo = rgb(0x78, 0x78, 0x78),
        task_fg = rgb(0x00, 0x00, 0x00),
        clock_fg = rgb(0x00, 0x00, 0x00),
        menu = rgb(0x9D, 0xBE, 0x9D),
        menu_fg = rgb(0x00, 0x00, 0x00),
    },
}

M.PRESET_NAMES = { "default", "midnight", "paper" }
M.WALLPAPER_MODES = { "center", "tile", "stretch" }

function M.default_apps()
    return {
        { name = "Terminal",   cmd = "/bin/xterm" },
        { name = "Clock",      cmd = "/bin/xclock" },
        { name = "Calculator", cmd = "/bin/xcalc" },
        { name = "Files",      cmd = "/bin/xfile" },
        { name = "Editor",     cmd = "/bin/xedit" },
        { name = "Vi",         cmd = "/bin/gxvi" },
        { name = "Run...",     cmd = "/bin/xrun" },
        { name = "Processes",  cmd = "/bin/xps" },
        { name = "Pictures",   cmd = "/bin/ximg" },
        { name = "Settings",   cmd = "/bin/xconf" },
    }
end

function M.parse_color(v)
    if type(v) == "number" and v % 1 == 0 and v >= 0 and v <= 0xFFFFFF then
        return v
    end
    if type(v) == "string" then
        local h = v:match("^#(%x%x%x%x%x%x)$")
        if h then return tonumber(h, 16) end
    end
    return nil
end

function M.to_hex(n)
    return string.format("#%06x", (n or 0) & 0xFFFFFF)
end

function M.user_path()
    local home = nil
    if type(posix) == "table" and type(posix.getenv) == "function" then
        local ok, v = pcall(posix.getenv, "HOME")
        if ok and type(v) == "string" and v ~= "" then home = v end
    end
    if not home then return nil end
    if home:sub(-1) == "/" then home = home:sub(1, -2) end
    return home .. "/" .. M.USER_NAME
end

function M.mtime(path)
    if type(posix) ~= "table" or type(posix.stat) ~= "function" then
        return nil
    end
    local ok, st = pcall(posix.stat, path)
    if ok and type(st) == "table" and type(st.mtime) == "number" then
        return st.mtime
    end
    return nil
end

function M.load_file(path)
    if type(posix) ~= "table" or type(posix.readfile) ~= "function" then
        return nil, "no file access"
    end
    local ok, data = pcall(posix.readfile, path)
    if not ok or type(data) ~= "string" then return nil, nil end
    if type(load) ~= "function" then return nil, path .. ": load unavailable" end
    local chunk, lerr = load(data, "@" .. path, "t", {})
    if not chunk then return nil, path .. ": " .. tostring(lerr) end
    local ok2, val = pcall(chunk)
    if not ok2 then return nil, path .. ": " .. tostring(val) end
    if type(val) ~= "table" then
        return nil, path .. ": config must return a table"
    end
    return val, nil
end

local function is_array_of_strings(t, maxn)
    if type(t) ~= "table" then return false end
    for i, v in ipairs(t) do
        if type(v) ~= "string" or #v > 256 then return false end
    end
    return #t <= (maxn or 8)
end

local function check_entry(e, need_name)
    if type(e) ~= "table" then return nil, "not a table" end
    if type(e.cmd) ~= "string" or e.cmd == "" or #e.cmd > 256 then
        return nil, "bad cmd"
    end
    local out = { cmd = e.cmd }
    if need_name then
        if type(e.name) ~= "string" or e.name == "" or #e.name > 64 then
            return nil, "bad name"
        end
        out.name = e.name
    elseif type(e.name) == "string" and e.name ~= "" and #e.name <= 64 then
        out.name = e.name
    end
    if e.args ~= nil then
        if not is_array_of_strings(e.args, 8) then
            return nil, "bad args"
        end
        out.args = {}
        for i, a in ipairs(e.args) do out.args[i] = a end
    end
    return out, nil
end

local function check_apps(raw, need_name, maxn, what, warnings)
    local out = {}
    if type(raw) ~= "table" then
        warnings[#warnings + 1] = what .. " must be a table"
        return nil
    end
    for i, e in ipairs(raw) do
        if #out >= maxn then
            warnings[#warnings + 1] = what .. ": keeping first " .. maxn
            break
        end
        local clean, why = check_entry(e, need_name)
        if clean then
            out[#out + 1] = clean
        else
            warnings[#warnings + 1] = what .. " entry " .. i .. ": " .. why
        end
    end
    if #out == 0 then return nil end
    return out
end

function M.merge(sys, user)
    sys, user = sys or {}, user or {}
    local out = {}
    for k, v in pairs(sys) do out[k] = v end
    for k, v in pairs(user) do
        if k == "colors" and type(v) == "table" and type(out.colors) == "table" then
            local c = {}
            for ck, cv in pairs(out.colors) do c[ck] = cv end
            for ck, cv in pairs(v) do c[ck] = cv end
            out.colors = c
        else
            out[k] = v
        end
    end
    return out
end

function M.validate(raw)
    local warnings = {}
    local function warn(s) warnings[#warnings + 1] = s end
    if type(raw) ~= "table" then
        warn("config is not a table; using defaults")
        raw = {}
    end
    local cfg = {}
    if type(raw.theme) == "string" and M.PRESETS[raw.theme] then
        cfg.theme = raw.theme
    else
        if raw.theme ~= nil then warn("unknown theme " .. tostring(raw.theme)) end
        cfg.theme = "default"
    end
    cfg.colors = {}
    if raw.colors ~= nil then
        if type(raw.colors) ~= "table" then
            warn("colors must be a table")
        else
            for k, v in pairs(raw.colors) do
                local known = false
                for _, key in ipairs(M.THEME_KEYS) do
                    if k == key then
                        known = true; break
                    end
                end
                if not known then
                    warn("unknown color " .. tostring(k))
                else
                    local n = M.parse_color(v)
                    if n == nil then
                        warn("bad color " .. tostring(k))
                    else
                        cfg.colors[k] = n
                    end
                end
            end
        end
    end
    if raw.wallpaper == nil or raw.wallpaper == false then
        cfg.wallpaper = nil
    elseif type(raw.wallpaper) == "string" and raw.wallpaper ~= "" then
        cfg.wallpaper = raw.wallpaper
    else
        warn("wallpaper must be a path")
        cfg.wallpaper = nil
    end
    cfg.wallpaper_mode = "center"
    if raw.wallpaper_mode ~= nil then
        local okm = false
        for _, m in ipairs(M.WALLPAPER_MODES) do
            if raw.wallpaper_mode == m then
                okm = true; break
            end
        end
        if okm then
            cfg.wallpaper_mode = raw.wallpaper_mode
        else
            warn("unknown wallpaper_mode " .. tostring(raw.wallpaper_mode))
        end
    end
    if raw.mascot == nil then
        cfg.mascot = true
    else
        cfg.mascot = raw.mascot and true or false
    end
    cfg.apps = check_apps(raw.apps, true, 32, "apps", warnings)
        or M.default_apps()
    cfg.startup = nil
    if raw.startup ~= nil then
        cfg.startup = check_apps(raw.startup, false, 16, "startup", warnings)
    end
    cfg.placement = { x = 60, y = 40, step = 26 }
    if type(raw.placement) == "table" then
        local function num(v, lo, hi, dflt, name)
            if type(v) ~= "number" then
                if v ~= nil then warn("placement." .. name .. " must be a number") end
                return dflt
            end
            return math.min(math.max(math.floor(v), lo), hi)
        end
        cfg.placement.x = num(raw.placement.x, 0, 4096, 60, "x")
        cfg.placement.y = num(raw.placement.y, 0, 4096, 40, "y")
        cfg.placement.step = num(raw.placement.step, 4, 128, 26, "step")
    elseif raw.placement ~= nil then
        warn("placement must be a table")
    end
    return cfg, warnings
end

function M.effective()
    local sys, serr = M.load_file(M.SYSTEM_PATH)
    local upath = M.user_path()
    local user, uerr = nil, nil
    if upath then user, uerr = M.load_file(upath) end
    local cfg, warnings = M.validate(M.merge(sys, user))
    if serr then warnings[#warnings + 1] = serr end
    if uerr then warnings[#warnings + 1] = uerr end
    return cfg, warnings, {
        system = sys and M.SYSTEM_PATH or nil,
        user = user and upath or nil
    }
end

function M.write_path()
    return M.user_path() or M.SYSTEM_PATH
end

function M.theme_colors(cfg)
    local out = {}
    for k, v in pairs(M.PRESETS.default) do out[k] = v end
    local preset = M.PRESETS[cfg.theme]
    if preset then for k, v in pairs(preset) do out[k] = v end end
    if type(cfg.colors) == "table" then
        for k, v in pairs(cfg.colors) do
            local n = M.parse_color(v)
            if n ~= nil then out[k] = n end
        end
    end
    return out
end

function M.serialize(cfg)
    local p = {}
    p[#p + 1] = "-- xeswmrc - xeswm configuration. See xeswmrc(5).\n"
    p[#p + 1] = "-- Managed by xconf(1).\n"
    p[#p + 1] = "return {\n"
    p[#p + 1] = "  theme = " .. string.format("%q", cfg.theme or "default") .. ",\n"
    p[#p + 1] = "  colors = {"
    local first = true
    local keys = {}
    for k in pairs(cfg.colors or {}) do keys[#keys + 1] = k end
    table.sort(keys)
    for _, k in ipairs(keys) do
        if not first then p[#p + 1] = "," end
        first = false
        p[#p + 1] = "\n    " .. k .. " = " .. cfg.colors[k]
    end
    if not first then p[#p + 1] = "\n  " end
    p[#p + 1] = "},\n"
    local function entry(e, with_name)
        local s = "    { "
        if with_name then s = s .. "name = " .. string.format("%q", e.name) .. ", " end
        s = s .. "cmd = " .. string.format("%q", e.cmd)
        if e.args then
            s = s .. ", args = { "
            for i, a in ipairs(e.args) do
                if i > 1 then s = s .. ", " end
                s = s .. string.format("%q", a)
            end
            s = s .. " }"
        end
        return s .. " },\n"
    end
    p[#p + 1] = "  wallpaper = "
    if cfg.wallpaper then
        p[#p + 1] = string.format("%q", cfg.wallpaper)
    else
        p[#p + 1] = "nil"
    end
    p[#p + 1] = ",\n"
    p[#p + 1] = "  wallpaper_mode = "
        .. string.format("%q", cfg.wallpaper_mode or "center") .. ",\n"
    p[#p + 1] = "  mascot = " .. ((cfg.mascot ~= false) and "true" or "false") .. ",\n"
    p[#p + 1] = "  apps = {\n"
    for _, e in ipairs(cfg.apps or {}) do p[#p + 1] = entry(e, true) end
    p[#p + 1] = "  },\n"
    if cfg.startup and #cfg.startup > 0 then
        p[#p + 1] = "  startup = {\n"
        for _, e in ipairs(cfg.startup) do p[#p + 1] = entry(e, e.name ~= nil) end
        p[#p + 1] = "  },\n"
    end
    local pl = cfg.placement or {}
    p[#p + 1] = string.format("  placement = { x = %d, y = %d, step = %d },\n",
        pl.x or 60, pl.y or 40, pl.step or 26)
    p[#p + 1] = "}\n"
    return table.concat(p)
end

return M
