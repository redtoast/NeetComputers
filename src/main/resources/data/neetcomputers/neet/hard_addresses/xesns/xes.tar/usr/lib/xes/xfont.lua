local M = {}

local Font = {}
Font.__index = Font
M.Font = Font

local function readFile(path)
	if type(fs) == "table" and type(fs.open) == "function" then
		local h = fs.open(path, "r")
		if not h then
			return nil
		end
		local v = h:read("a")
		h:close()
		return v
	end
	return nil
end

local function utf8_at(s, i)
	local b = s:byte(i)
	if not b then
		return nil, i + 1
	end
	if b < 0x80 then
		return b, i + 1
	end
	local n, min
	if b >= 0xC2 and b <= 0xDF then
		n, min = 1, 0x80
	elseif b >= 0xE0 and b <= 0xEF then
		n, min = 2, 0x800
	elseif b >= 0xF0 and b <= 0xF4 then
		n, min = 3, 0x10000
	else
		return nil, i + 1
	end
	local cp = b & ((1 << (6 - n)) - 1)
	for k = 1, n do
		local c = s:byte(i + k)
		if not c or c < 0x80 or c > 0xBF then
			return nil, i + 1
		end
		cp = (cp << 6) | (c & 0x3F)
	end
	if cp < min or cp > 0x10FFFF or (cp >= 0xD800 and cp <= 0xDFFF) then
		return nil, i + 1
	end
	return cp, i + n + 1
end

local MAX_GLYPHS = 8192
local MAX_W = 256
local MAX_H = 512
local MAX_BPG = 8192

local function parse_psf1(data)
	local mode, size = data:byte(3, 4)
	if mode > 5 then
		return nil, "bad PSF1 mode"
	end
	if size < 1 or size > 128 then
		return nil, "bad PSF1 character size"
	end
	local declared = (mode % 2 == 1) and 512 or 256
	local avail = (#data - 4) // size
	if avail < 1 then
		return nil, "truncated PSF1 bitmaps"
	end
	local n = declared < avail and declared or avail
	local glyphs = {}
	for i = 0, n - 1 do
		local off = 4 + i * size
		glyphs[i] = data:sub(off + 1, off + size)
	end
	local uni = nil
	if (mode & 2) ~= 0 then
		local p = 4 + declared * size + 1
		local map, gi = {}, 0
		while p + 1 <= #data and gi < n do
			local a, b = data:byte(p, p + 1)
			local v = a + b * 256
			p = p + 2
			if v == 0xFFFF then
				gi = gi + 1
			elseif v == 0xFFFE then
			elseif v < 0xFFFE then
				if map[v] == nil then
					map[v] = gi
				end
			end
		end
		if next(map) ~= nil then
			uni = map
		end
	end
	return { glyphs = glyphs, w = 8, h = size, bpr = 1, uni = uni }
end

local function parse_psf2(data)
	local ver, headersize, flags, num, bpg, gh, gw = string.unpack("<I4I4I4I4I4I4I4", data, 5)
	if ver ~= 0 then
		return nil, "unsupported PSF2 version"
	end
	if headersize < 32 or headersize > #data then
		return nil, "bad PSF2 header size"
	end
	if num < 1 or num > MAX_GLYPHS then
		return nil, "bad PSF2 glyph count"
	end
	if gw < 1 or gw > MAX_W or gh < 1 or gh > MAX_H then
		return nil, "bad PSF2 glyph dimensions"
	end
	local bpr = (gw + 7) // 8
	if bpg < gh * bpr or bpg > MAX_BPG then
		return nil, "bad PSF2 character size"
	end
	local avail = (#data - headersize) // bpg
	if avail < 1 then
		return nil, "truncated PSF2 bitmaps"
	end
	local n = num < avail and num or avail
	local glyphs = {}
	for i = 0, n - 1 do
		local off = headersize + i * bpg
		glyphs[i] = data:sub(off + 1, off + bpg)
	end
	local uni = nil
	if (flags & 1) ~= 0 then
		local map, gi = {}, 0
		local start = headersize + num * bpg + 1
		local function flush(stop)
			local i = start
			while i < stop do
				local cp, ni = utf8_at(data, i)
				if cp ~= nil and map[cp] == nil then
					map[cp] = gi
				end
				i = ni
			end
		end
		local i = start
		while i <= #data and gi < n do
			local b = data:byte(i)
			if b == 0xFF then
				flush(i)
				gi = gi + 1
				i = i + 1
				start = i
			elseif b == 0xFE then
				flush(i)
				i = i + 1
				start = i
			else
				i = i + 1
			end
		end
		if gi < n and start <= #data then
			flush(#data + 1)
		end
		if next(map) ~= nil then
			uni = map
		end
	end
	return { glyphs = glyphs, w = gw, h = gh, bpr = bpr, uni = uni }
end

local PSF2_MAGIC = "\114\181\74\134"

local function parse(data)
	if type(data) ~= "string" or #data < 4 then
		return nil, "font too short"
	end
	local b1, b2 = data:byte(1, 2)
	if b1 == 0x36 and b2 == 0x04 then
		return parse_psf1(data)
	elseif data:sub(1, 4) == PSF2_MAGIC then
		if #data < 32 then
			return nil, "PSF2 data too short"
		end
		return parse_psf2(data)
	end
	return nil, string.format("not a PSF file (magic %02x %02x)", b1 or 0, b2 or 0)
end

local TTFnt

function M.load(path, px)
	local data = readFile(path)
	if not data then
		return nil, "cannot read " .. tostring(path)
	end
	if #data >= 4 then
		local b1, b2 = data:byte(1, 2)
		if b1 == 0x36 and b2 == 0x04 or data:sub(1, 4) == PSF2_MAGIC then
			local f, err = parse(data)
			if not f then
				return nil, err
			end
			f.cellW, f.cellH = f.w, f.h
			f.cache, f.ncache = {}, 0
			return setmetatable(f, Font)
		end
	end
	return M.ttload(data, px)
end

function M.ttload(data, px)
	px = math.floor(px or 12)
	if px < 8 or px > 64 then
		return nil, "pixel size must be in 8..64"
	end
	local ok, fntp = pcall(require, "fntp")
	if not ok or type(fntp) ~= "table" or type(fntp.load) ~= "function" then
		return nil, "cannot load fntp"
	end
	local okf, font, ferr = pcall(fntp.load, data)
	if not okf then
		return nil, "bad font: " .. tostring(font)
	end
	if not font then
		return nil, ferr
	end
	local okm, m = pcall(font.metrics, font, px)
	if not okm or type(m) ~= "table" then
		return nil, "bad font metrics: " .. tostring(m)
	end
	local oks, sp, serr = pcall(font.rasterize, font, 32, px, { supersample = 2 })
	if not oks then
		return nil, "bad font glyph: " .. tostring(sp)
	end
	if not sp then
		return nil, serr
	end
	local prop, minadv = false, sp.advance
	for _, c in ipairs({ 105, 109, 87, 65 }) do
		local okg, g = pcall(font.rasterize, font, c, px, { supersample = 2 })
		if okg and g and g.advance then
			if g.advance ~= sp.advance then
				prop = true
			end
			if g.advance < minadv then
				minadv = g.advance
			end
		end
	end
	if m.height < 4 or (not prop and sp.advance < 4) or (prop and minadv < 3) then
		return nil, "degenerate cell size"
	end
	return setmetatable({
		kind = "ttfont",
		fontName = font.name or "truetype",
		backend = font,
		px = px,
		prop = prop,
		sadv = sp.advance,
		cellW = sp.advance,
		cellH = m.height,
		baseline = m.ascent,
		cache = {},
		ncache = 0,
		cord = {},
		chead = 1,
		amask = {},
		aord = {},
		ahead = 1,
		namask = 0,
	}, TTFnt)
end

local function split(c)
	return math.floor(c / 65536) % 256, math.floor(c / 256) % 256, c % 256
end

local draw_hard

local function each_char(text, out)
	local i, n = 1, #text
	while i <= n do
		local cp = utf8.codepoint(text, i)
		local adv = utf8.offset(text, 2, i) or (n + 1)
		out(cp)
		i = adv
	end
end

local function run_width(self, text)
	local w = 0
	each_char(text, function(cp)
		local m = self:mask(cp)
		w = w + (m and m.adv or 0)
	end)
	return w
end

local function draw_transparent(self, surface, x, y, text, fg)
	local w = run_width(self, text)
	if w <= 0 then
		return 0
	end
	local h = self.cellH
	if type(surface.readData) ~= "function" then
		return draw_hard(self, surface, x, y, text, fg)
	end
	local ok, under = pcall(surface.readData, x, y, x + w - 1, y + h - 1)
	if not ok or type(under) ~= "string" or #under ~= w * h * 4 then
		return draw_hard(self, surface, x, y, text, fg)
	end
	local fr, fgg, fb = split(fg)
	local ub = { under:byte(1, #under) }
	local parts, n = {}, 0
	for p = 1, w * h do
		local i = (p - 1) * 4
		n = n + 1
		parts[n] = string.char(ub[i + 1] or 0, ub[i + 2] or 0, ub[i + 3] or 0, ub[i + 4] or 255)
	end
	local pen = x
	each_char(text, function(cp)
		local m = self:mask(cp)
		if m and m.alpha then
			local gx, gy = pen + m.gx, y + m.gy
			local mw, alpha = m.w, m.alpha
			for py = 0, m.h - 1 do
				local sy = gy + py
				if sy >= y and sy < y + h then
					local row = (sy - y) * w
					local base = py * mw
					for px = 0, mw - 1 do
						local sx = gx + px
						if sx >= x and sx < x + w then
							local a = alpha[base + px + 1] or 0
							if a > 0 then
								local pi = row + (sx - x) + 1
								if a >= 255 then
									parts[pi] = string.char(fr, fgg, fb, 255)
								else
									local prev = parts[pi]
									local ia = 255 - a
									parts[pi] = string.char(
										(fr * a + prev:byte(1) * ia) // 255,
										(fgg * a + prev:byte(2) * ia) // 255,
										(fb * a + prev:byte(3) * ia) // 255,
										255
									)
								end
							end
						end
					end
				end
			end
		end
		pen = pen + (m and m.adv or 0)
	end)
	surface.writeData(x, y, table.concat(parts), w)
	return w
end

draw_hard = function(self, surface, x, y, text, fg)
	local fr, fgg, fb = split(fg)
	local haspix = type(surface.writePixel) == "function"
	local pen = x
	each_char(text, function(cp)
		local m = self:mask(cp)
		if m and m.alpha and haspix then
			local gx, gy = pen + m.gx, y + m.gy
			for py = 0, m.h - 1 do
				for px = 0, m.w - 1 do
					if (m.alpha[py * m.w + px + 1] or 0) >= 128 then
						pcall(surface.writePixel, gx + px, gy + py, fr, fgg, fb, 255)
					end
				end
			end
		end
		pen = pen + (m and m.adv or 0)
	end)
	return pen - x
end

local TTFCACHE_MAX = 2048
local TTFAMASK_MAX = 512

local function evictOld(store, order, head, count, max)
	while count > max do
		local old = order[head]
		if old == nil then
			break
		end
		order[head] = false
		head = head + 1
		if old ~= false then
			store[old] = nil
			count = count - 1
		end
	end
	if head > 4096 then
		local fresh = {}
		for k = head, #order do
			local v = order[k]
			if v then
				fresh[#fresh + 1] = v
			end
		end
		order, head = fresh, 1
	end
	return order, head, count
end

TTFnt = {}
TTFnt.__index = TTFnt

function TTFnt:amget(code)
	local am = self.amask[code]
	if am ~= nil then
		return am
	end
	local cp = code
	local okg, gid = pcall(self.backend.glyphIndex, self.backend, code)
	if not okg or gid == 0 then
		cp = 63
	end
	local okr, gl = pcall(self.backend.rasterize, self.backend, cp, self.px, { supersample = 2 })
	if okr and gl and gl.width > 0 and gl.height > 0 then
		local gw, gh, data = gl.width, gl.height, gl.buffer
		local alpha, n = {}, 0
		for k = 1, gw * gh do
			n = n + 1
			alpha[n] = data:byte((k - 1) * 4 + 4) or 0
		end
		am = { w = gw, h = gh, bx = gl.bearingX, by = gl.bearingY, adv = gl.advance or self.cellW, alpha = alpha }
	else
		am = false
	end
	self.amask[code] = am
	self.aord[#self.aord + 1] = code
	self.namask = self.namask + 1
	self.aord, self.ahead, self.namask = evictOld(self.amask, self.aord, self.ahead, self.namask, TTFAMASK_MAX)
	return am
end

function TTFnt:mask(code)
	local blank = { w = 0, h = 0, gx = 0, gy = 0, adv = self.prop and self.sadv or self.cellW, alpha = false }
	if code <= 32 then
		return blank
	end
	local am = self:amget(code)
	if not am then
		return blank
	end
	return {
		w = am.w,
		h = am.h,
		gx = am.bx,
		gy = self.baseline - am.by,
		adv = am.adv or self.cellW,
		alpha = am.alpha,
	}
end

function TTFnt:cell(code, fg, bg)
	local c = self.cache[code]
	local k2 = fg * 16777216 + bg
	if c then
		local hit = c[k2]
		if hit then
			return hit
		end
	end
	if self.ncache > TTFCACHE_MAX then
		self.cache, self.ncache = {}, 0
		c = nil
	end
	local cw, chh = self.cellW, self.cellH
	local fr, fgg, fb = split(fg)
	local br, bgg, bb = split(bg)
	local fgpx = string.char(fr, fgg, fb, 255)
	local bgpx = string.char(br, bgg, bb, 255)
	local am = nil
	if code > 32 then
		am = self:amget(code)
	end
	local buf
	if not am then
		buf = string.rep(bgpx, cw * chh)
	else
		local gx0 = am.bx
		local gy0 = self.baseline - am.by
		local gw, gh, alpha = am.w, am.h, am.alpha
		local out, n = {}, 0
		for y = 0, chh - 1 do
			for x = 0, cw - 1 do
				local a = 0
				local sx, sy = x - gx0, y - gy0
				if sx >= 0 and sx < gw and sy >= 0 and sy < gh then
					a = alpha[sy * gw + sx + 1] or 0
				end
				n = n + 1
				if a == 255 then
					out[n] = fgpx
				elseif a == 0 then
					out[n] = bgpx
				else
					local ia = 255 - a
					out[n] = string.char(
						math.floor((fr * a + br * ia) / 255),
						math.floor((fgg * a + bgg * ia) / 255),
						math.floor((fb * a + bb * ia) / 255),
						255
					)
				end
			end
		end
		buf = table.concat(out)
	end
	if not c then
		c = {}
		self.cache[code] = c
	end
	c[k2] = buf
	self.ncache = self.ncache + 1
	return buf
end

function TTFnt:gcell(code, fg, bg, adv)
	self.pcache = self.pcache or {}
	local c = self.pcache[code]
	local k2 = fg * 16777216 + bg
	if c then
		local hit = c[k2]
		if hit and hit.adv == adv then
			return hit.buf
		end
	end
	local chh = self.cellH
	local fr, fgg, fb = split(fg)
	local br, bgg, bb = split(bg)
	local fgpx = string.char(fr, fgg, fb, 255)
	local bgpx = string.char(br, bgg, bb, 255)
	local m = self:mask(code)
	local out, n = {}, 0
	for y = 0, chh - 1 do
		for x = 0, adv - 1 do
			local a = 0
			if m.alpha then
				local sx, sy = x - m.gx, y - m.gy
				if sx >= 0 and sx < m.w and sy >= 0 and sy < m.h then
					a = m.alpha[sy * m.w + sx + 1] or 0
				end
			end
			n = n + 1
			if a >= 255 then
				out[n] = fgpx
			elseif a == 0 then
				out[n] = bgpx
			else
				local ia = 255 - a
				out[n] =
					string.char((fr * a + br * ia) // 255, (fgg * a + bgg * ia) // 255, (fb * a + bb * ia) // 255, 255)
			end
		end
	end
	local buf = table.concat(out)
	if (self.pcount or 0) > 4096 then
		self.pcache, self.pcount = {}, 0
		c = nil
	end
	if not c then
		c = {}
		self.pcache[code] = c
	end
	c[k2] = { buf = buf, adv = adv }
	self.pcount = (self.pcount or 0) + 1
	return buf
end

function TTFnt:draw(surface, x, y, text, fg, bg)
	if bg == nil then
		return draw_transparent(self, surface, x, y, text, fg)
	end
	if not self.prop then
		return Font.draw(self, surface, x, y, text, fg, bg)
	end
	local xx = x
	each_char(text, function(cp)
		local m = self:mask(cp)
		local adv = m and m.adv or self.sadv
		if adv > 0 then
			surface.writeData(xx, y, self:gcell(cp, fg, bg, adv), adv)
		end
		xx = xx + adv
	end)
	return xx - x
end

function TTFnt:width(text)
	if not self.prop then
		return utf8.len(text) * self.cellW
	end
	return run_width(self, text)
end

function M.parse(data)
	local f, err = parse(data)
	if not f then
		return nil, err
	end
	f.cellW, f.cellH = f.w, f.h
	f.cache, f.ncache = {}, 0
	return setmetatable(f, Font)
end

local strchar = string.char

function Font:cell(code, fg, bg)
	local c = self.cache[code]
	local k2 = fg * 16777216 + bg
	if c then
		local buf = c[k2]
		if buf then
			return buf
		end
	end
	if self.ncache > 4000 then
		self.cache, self.ncache = {}, 0
		c = nil
	end

	local fgs = string.char((fg >> 16) & 255, (fg >> 8) & 255, fg & 255, 255)
	local bgs = string.char((bg >> 16) & 255, (bg >> 8) & 255, bg & 255, 255)

	local gi = (self.uni and self.uni[code]) or code
	local gl = (code > 32) and (self.glyphs[gi] or self.glyphs[63]) or nil
	local parts, n = {}, 0
	local w, bpr = self.w, self.bpr
	for y = 0, self.h - 1 do
		if gl then
			for x = 0, w - 1 do
				local byte = gl:byte(y * bpr + (x >> 3) + 1) or 0
				n = n + 1
				parts[n] = ((byte >> (7 - (x & 7))) & 1) == 1 and fgs or bgs
			end
		else
			for _ = 0, w - 1 do
				n = n + 1
				parts[n] = bgs
			end
		end
	end
	local buf = table.concat(parts)
	if not c then
		c = {}
		self.cache[code] = c
	end
	c[k2] = buf
	self.ncache = self.ncache + 1
	return buf
end

function Font:mask(code)
	self.mcache = self.mcache or {}
	local m = self.mcache[code]
	if m then
		return m
	end
	m = { w = self.w, h = self.h, gx = 0, gy = 0, adv = self.cellW, alpha = false }
	if code > 32 then
		local gi = (self.uni and self.uni[code]) or code
		local gl = self.glyphs[gi] or self.glyphs[63]
		if gl then
			local alpha, n = {}, 0
			for y = 0, self.h - 1 do
				for x = 0, self.w - 1 do
					local byte = gl:byte(y * self.bpr + (x >> 3) + 1) or 0
					n = n + 1
					alpha[n] = ((byte >> (7 - (x & 7))) & 1) * 255
				end
			end
			m.alpha = alpha
		end
	end
	self.mcache[code] = m
	return m
end

function Font:draw(surface, x, y, text, fg, bg)
	if bg == nil then
		return draw_transparent(self, surface, x, y, text, fg)
	end
	local cw = self.cellW
	local xx = x
	local i, n = 1, #text
	while i <= n do
		local cp = utf8.codepoint(text, i)
		local adv = utf8.offset(text, 2, i) or (n + 1)
		surface.writeData(xx, y, self:cell(cp, fg, bg), cw)
		xx = xx + cw
		i = adv
	end
	return xx - x
end

function Font:width(text)
	return utf8.len(text) * self.cellW
end

return M
