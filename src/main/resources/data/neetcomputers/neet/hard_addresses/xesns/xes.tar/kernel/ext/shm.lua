local K, API, X = ...
local T = {}

local argerr = K.argcheck.err

local PER_OBJECT_CAP = 1048576
local TOTAL_CAP = 67108864
local MAX_NAME = 255
local DEFAULT_MODE = 0x180

local namespace = {}
local totalBytes = 0

local registry = setmetatable({}, { __mode = "k" })

local function nameError(name)
	if type(name) ~= "string" then
		return "shared memory name must be a string"
	end
	local n = #name
	if n == 0 then
		return "shared memory name must not be empty"
	end
	if n > MAX_NAME then
		return ("shared memory name is longer than %d bytes"):format(MAX_NAME)
	end
	if name:sub(1, 1) ~= "/" then
		return "shared memory name must start with '/'"
	end
	if n == 1 then
		return "shared memory name must have a name after '/'"
	end
	local rest = name:sub(2)
	if rest:find("/", 1, true) then
		return "shared memory name must not contain '/'"
	end
	if rest:find("%c") then
		return "shared memory name must not contain control characters"
	end
	if rest == "." or rest == ".." then
		return "reserved shared memory name"
	end
	return nil
end

local function checkName(name)
	local err = nameError(name)
	if err then
		return nil, "EINVAL", err
	end
	return true
end

local function liveHandles(obj)
	for _ in pairs(obj.handles) do
		return true
	end
	return false
end

local function releaseIfDead(obj)
	if obj.linked or liveHandles(obj) then
		return
	end
	totalBytes = totalBytes - obj.size
	obj.size = 0
	obj.buf = nil
	obj.dead = true
end

local function reserve(delta)
	if delta > 0 and totalBytes + delta > TOTAL_CAP then
		return nil, "ELIMIT", ("shared memory total limit of %d bytes reached"):format(TOTAL_CAP)
	end
	totalBytes = totalBytes + delta
	return true
end

local function record(handle)
	return registry[handle]
end

local function makeHandle(p, obj)
	local handle = {}
	registry[handle] = { obj = obj, p = p, open = true }
	obj.handles[handle] = true
	if p and p.handles then
		p.handles[handle] = true
	end

	function handle:size()
		local rec = record(self)
		if not rec or not rec.open then
			return nil, "EBADF", "shared memory handle is closed"
		end
		return rec.obj.size
	end

	function handle:readAt(off, len)
		local rec = record(self)
		if not rec or not rec.open then
			return nil, "EBADF", "shared memory handle is closed"
		end
		if type(off) ~= "number" then
			argerr(1, "readAt", "integer", off)
		end
		if type(len) ~= "number" then
			argerr(2, "readAt", "integer", len)
		end
		local o = math.tointeger(off)
		local n = math.tointeger(len)
		if not o or not n or o < 0 or n < 0 then
			return nil, "EINVAL", "offset and length must be non-negative integers"
		end
		local obj = rec.obj
		if o >= obj.size then
			return ""
		end
		if n > obj.size - o then
			n = obj.size - o
		end
		local first = o + 1
		return obj.buf:sub(first, first + n - 1)
	end

	function handle:writeAt(off, ...)
		local rec = record(self)
		if not rec or not rec.open then
			return nil, "EBADF", "shared memory handle is closed"
		end
		local n = select("#", ...)
		if n == 0 then
			return 0
		end
		local parts = {}
		for i = 1, n do
			local v = select(i, ...)
			if type(v) ~= "string" and type(v) ~= "number" then
				argerr(i + 1, "writeAt", "string", v)
			end
			parts[i] = tostring(v)
		end
		local data = table.concat(parts)
		if type(off) ~= "number" then
			argerr(1, "writeAt", "integer", off)
		end
		local o = math.tointeger(off)
		if not o or o < 0 then
			return nil, "EINVAL", "offset must be a non-negative integer"
		end
		local obj = rec.obj
		if o > obj.size or #data > obj.size - o then
			return nil, "ENOSPC", ("write of %d bytes at %d exceeds object size %d"):format(#data, o, obj.size)
		end
		if #data == 0 then
			return 0
		end
		obj.buf = obj.buf:sub(1, o) .. data .. obj.buf:sub(o + #data + 1)
		return #data
	end

	function handle:truncate(size)
		local rec = record(self)
		if not rec or not rec.open then
			return nil, "EBADF", "shared memory handle is closed"
		end
		if type(size) ~= "number" then
			argerr(1, "truncate", "integer", size)
		end
		local n = math.tointeger(size)
		if not n or n < 0 then
			return nil, "EINVAL", "size must be a non-negative integer"
		end
		if n > PER_OBJECT_CAP then
			return nil, "ELIMIT", ("shared memory object limit is %d bytes"):format(PER_OBJECT_CAP)
		end
		local obj = rec.obj
		local delta = n - obj.size
		if delta > 0 then
			local ok, code, msg = reserve(delta)
			if not ok then
				return nil, code, msg
			end
			obj.buf = obj.buf .. string.rep("\0", delta)
		elseif delta < 0 then
			obj.buf = obj.buf:sub(1, n)
			totalBytes = totalBytes + delta
		end
		obj.size = n
		return true
	end

	function handle:close()
		local rec = record(self)
		if not rec or not rec.open then
			return nil, "EBADF", "shared memory handle is closed"
		end
		local obj = rec.obj
		rec.open = false
		registry[self] = nil
		obj.handles[self] = nil
		if rec.p and rec.p.handles then
			rec.p.handles[self] = nil
		end
		releaseIfDead(obj)
		return true
	end

	return handle
end

local function accessBits(p, obj)
	local uid = (p and p.uid) or 0
	local gid = (p and p.gid) or 0
	if uid == obj.uid then
		return (obj.mode >> 6) & 7
	end
	if gid == obj.gid then
		return (obj.mode >> 3) & 7
	end
	return obj.mode & 7
end

function T.create(p, name, size, mode)
	local ok, code, msg = checkName(name)
	if not ok then
		return nil, code, msg
	end
	if namespace[name] then
		return nil, "EEXIST", "shared memory object already exists: " .. name
	end
	if type(size) ~= "number" then
		argerr(2, "create", "integer", size)
	end
	local n = math.tointeger(size)
	if not n or n < 0 then
		return nil, "EINVAL", "size must be a non-negative integer"
	end
	if n > PER_OBJECT_CAP then
		return nil, "ELIMIT", ("shared memory object limit is %d bytes"):format(PER_OBJECT_CAP)
	end
	local m = DEFAULT_MODE
	if mode ~= nil then
		if type(mode) ~= "number" then
			argerr(3, "create", "integer", mode)
		end
		m = math.tointeger(mode)
		if not m or m < 0 or m > 0x1FF then
			return nil, "EINVAL", "mode must be an integer in 0..0777"
		end
	end
	local rok, rcode, rmsg = reserve(n)
	if not rok then
		return nil, rcode, rmsg
	end
	local obj = {
		name = name,
		size = n,
		buf = string.rep("\0", n),
		uid = (p and p.uid) or 0,
		gid = (p and p.gid) or 0,
		mode = m,
		linked = true,
		handles = setmetatable({}, { __mode = "k" }),
	}
	namespace[name] = obj
	return makeHandle(p, obj)
end

function T.open(p, name)
	local ok, code, msg = checkName(name)
	if not ok then
		return nil, code, msg
	end
	local obj = namespace[name]
	if not obj then
		return nil, "ENOENT", "no such shared memory object: " .. name
	end
	if accessBits(p, obj) & 6 ~= 6 then
		return nil, "EACCES", "permission denied: " .. name
	end
	return makeHandle(p, obj)
end

function T.unlink(p, name)
	local ok, code, msg = checkName(name)
	if not ok then
		return nil, code, msg
	end
	local obj = namespace[name]
	if not obj then
		return nil, "ENOENT", "no such shared memory object: " .. name
	end
	namespace[name] = nil
	obj.linked = false
	obj.name = nil
	releaseIfDead(obj)
	return true
end

function T.list(p)
	local names = {}
	for name in pairs(namespace) do
		names[#names + 1] = name
	end
	table.sort(names)
	return names
end

T.__ext = { ["ext.shm"] = 1 }

return T
