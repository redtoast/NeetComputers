local K = ...

local V, P = K.vfs, K.path
local R = K.rawfs
local chipUnix = chip.getUnixTime

local function sysret(p, ok, ...)
	p.critical = p.critical - 1
	if not ok then
		error((...), 0)
	end
	return ...
end
function K.sys(f)
	return function(...)
		local p = K.current
		p.critical = p.critical + 1
		return sysret(p, pcall(f, ...))
	end
end

local sys_ = K.sys

local function argerr(n, fname, want, v)
	error(string.format("bad argument #%d to '%s' (%s expected, got %s)", n, fname, want, type(v)), 3)
end
local function str(v, n, fname)
	if type(v) == "string" then
		return v
	end
	if type(v) == "number" then
		return tostring(v)
	end
	argerr(n, fname, "string", v)
end
local function int(v, n, fname)
	local i = type(v) == "number" and math.tointeger(v)
	if not i then
		argerr(n, fname, "integer", v)
	end
	return i
end
K.argcheck = { str = str, int = int, err = argerr }

local function codeOf(msg)
	local m = type(msg) == "string" and msg:lower() or ""
	if m:find("partition root", 1, true) then
		return "EPERM"
	end
	if
		m:find("no such disk", 1, true)
		or m:find("no such device", 1, true)
		or m:find("no disk has", 1, true)
		or m:find("no current directory", 1, true)
	then
		return "ENODEV"
	end
	if
		m:find("no such file", 1, true)
		or m:find("no such directory", 1, true)
		or m:find("does not exist", 1, true)
		or m:find("not found", 1, true)
	then
		return "ENOENT"
	end
	if m:find("not a directory", 1, true) then
		return "ENOTDIR"
	end
	if m:find("is a directory", 1, true) then
		return "EISDIR"
	end
	if m:find("not empty", 1, true) then
		return "ENOTEMPTY"
	end
	if m:find("read-only", 1, true) or m:find("read only", 1, true) or m:find("operation not permitted", 1, true) then
		return "EROFS"
	end
	if m:find("permission denied", 1, true) or m:find("access denied", 1, true) then
		return "EACCES"
	end
	if m:find("no space", 1, true) then
		return "ENOSPC"
	end
	if m:find("too long", 1, true) then
		return "ENAMETOOLONG"
	end
	if m:find("too large", 1, true) or m:find("too big", 1, true) then
		return "EFBIG"
	end
	if m:find("already exists", 1, true) or m:find("file exists", 1, true) then
		return "EEXIST"
	end
	if m:find("in use", 1, true) or m:find("busy", 1, true) then
		return "EBUSY"
	end
	if m:find("not open for", 1, true) then
		return "EBADF"
	end
	if m:find("illegal seek", 1, true) then
		return "ESPIPE"
	end
	if m:find("offset", 1, true) or m:find("out of range", 1, true) then
		return "ERANGE"
	end
	if m:find("invalid", 1, true) or m:find("illegal", 1, true) then
		return "EINVAL"
	end
	return "EIO"
end

local function failfrom(msg)
	local text = type(msg) == "string" and msg or tostring(msg)
	return nil, codeOf(text), text
end
K.codeOf = codeOf

local function tty()
	return K.current.tty
end
local function color(r, g, b, fname)
	local c = { r, g, b }
	for i = 1, 3 do
		local v = math.tointeger(c[i])
		if type(c[i]) ~= "number" or not v or v < 0 or v > 255 then
			error(string.format("bad argument #%d to '%s' (integer 0-255 expected)", i, fname), 3)
		end
		c[i] = v
	end
	return K.rgb(c[1], c[2], c[3])
end

local term = {
	clear = sys_(function()
		local p = K.current
		p.tty:clear(p.bg)
	end),
	write = sys_(function(text)
		local p = K.current
		p.tty:write(str(text, 1, "write"), p.fg, p.bg)
	end),
	getSize = function()
		local t = tty()
		return t.cols, t.rows
	end,
	clearLine = sys_(function()
		local p = K.current
		p.tty:clearLine(p.bg)
	end),
	setCursorPos = sys_(function(x, y)
		local t = tty()
		t.cx, t.cy = int(x, 1, "setCursorPos"), int(y, 2, "setCursorPos")
	end),
	getCursorPos = function()
		local t = tty()
		return t.cx, t.cy
	end,
	setBackgroundColor = function(r, g, b)
		K.current.bg = color(r, g, b, "setBackgroundColor")
	end,
	setTextColor = function(r, g, b)
		K.current.fg = color(r, g, b, "setTextColor")
	end,
	getBackgroundColor = function()
		return K.unrgb(K.current.bg)
	end,
	getTextColor = function()
		return K.unrgb(K.current.fg)
	end,
	scroll = sys_(function(n)
		local p = K.current
		p.tty:scroll(int(n, 1, "scroll"), p.bg)
	end),
	readLine = sys_(function(options)
		if options ~= nil and type(options) ~= "table" then
			argerr(1, "readLine", "table", options)
		end
		options = options or {}
		if options.noecho ~= nil and type(options.noecho) ~= "boolean" then
			argerr(1, "readLine", "table", options)
		end
		if options.history ~= nil and type(options.history) ~= "table" then
			argerr(1, "readLine", "table", options)
		end
		local t = tty()
		while true do
			local line, err = K.readline(t, { noecho = options.noecho, history = options.history })
			if line ~= nil then
				if options.history then
					options.history[#options.history + 1] = line
				end
				return line
			end
			if err == "interrupted" then
				return nil, "EINTR", "interrupted"
			end
		end
	end),

	setAnsi = sys_(function(on)
		K.current.tty.ansi = on and true or false
	end),

	scrollback = sys_(function(n)
		if n ~= nil then
			n = int(n, 1, "scrollback")
		end
		return tty():getScrollback(n)
	end),

	scrollView = sys_(function(n)
		local t = tty()
		t:scrollView(int(n, 1, "scrollView"))
		return t.view
	end),
	getScrollView = function()
		return tty().view
	end,
}

local function nprint(...)
	local p = K.current
	local n = select("#", ...)
	local t = {}
	for i = 1, n do
		t[i] = tostring((select(i, ...)))
	end
	local fd = p.fds[1]
	if not fd then
		return
	end
	local ok, err = fd:write(table.concat(t, "\t") .. "\n")
	if not ok and err == "broken pipe" then
		K.exit(p, 141)
	end
end
K.nprint = sys_(nprint)

local event = {
	pull = function(filter, timeout)
		if filter ~= nil and type(filter) ~= "string" then
			argerr(1, "pull", "string", filter)
		end
		if timeout ~= nil and type(timeout) ~= "number" then
			argerr(2, "pull", "number", timeout)
		end
		return K.evpull(K.current, filter, timeout)
	end,
	poll = function()
		return K.evpoll(K.current)
	end,
	push = sys_(function(name, ...)
		if type(name) ~= "string" then
			argerr(1, "push", "string", name)
		end
		if not K.pushEvent(K.current, name, ...) then
			return nil, "ENOBUFS", "event queue is full"
		end
		return true
	end),
	clear = sys_(function()
		K.evclear(K.current)
	end),
}

local function rpath(path, fname)
	if type(path) ~= "string" then
		argerr(1, fname, "string", path)
	end
	return P.resolve(path, K.current.cwd or K.current.launchcwd, 3)
end

local function slotPartFor(fp)
	local best, bestm = nil, nil
	for _, m in ipairs(V.mountlist()) do
		local mp = m.mpfp or "/"
		if mp ~= "/" and (fp == mp or fp:sub(1, #mp + 1) == mp .. "/") then
			if not best or #mp > #best then
				best, bestm = mp, m
			end
		end
	end
	if bestm then
		local rel = fp:sub(#best + 1)
		if rel == "" then
			rel = "/"
		end
		return bestm.slot, bestm.part, rel
	end
	local rs, rp = nil, K.root and K.root.part
	if K.root then
		rs = K.root.slot
		if rs == nil then
			local d = R.diskByRef(K.root.id)
			rs = d and d.slot
		end
	end
	return rs, rp, fp
end

function K.wrapHandle(p, h, mode)
	local closed = false
	local entry = { h = h, refs = 1, mode = mode, readable = h.readable, writable = h.writable }
	local obj = {}
	local function live()
		if closed then
			error("attempt to use a closed handle", 3)
		end
	end
	function obj:read(fmt)
		live()
		if fmt ~= nil and type(fmt) ~= "number" and type(fmt) ~= "string" then
			argerr(1, "read", "string or integer", fmt)
		end
		if type(fmt) == "string" and fmt ~= "l" and fmt ~= "a" then
			return nil, "EINVAL", "invalid read format"
		end
		local r, e = K.sys(h.read)(h, fmt)
		if r == nil and e ~= nil then
			return failfrom(e)
		end
		return r
	end

	function obj:write(...)
		live()
		local n, parts = select("#", ...), {}
		for i = 1, n do
			local v = select(i, ...)
			if type(v) ~= "string" and type(v) ~= "number" then
				argerr(i, "write", "string or number", v)
			end
			parts[i] = tostring(v)
		end
		local r, e = K.sys(h.write)(h, table.concat(parts))
		if not r then
			return failfrom(e)
		end
		return self
	end

	function obj:seek(whence, off)
		live()
		if whence ~= nil and type(whence) ~= "string" then
			argerr(1, "seek", "string", whence)
		end
		if whence ~= nil and whence ~= "set" and whence ~= "cur" and whence ~= "end" then
			return nil, "EINVAL", "invalid whence"
		end
		if off ~= nil and math.tointeger(off) == nil then
			argerr(2, "seek", "integer", off)
		end
		local r, e = K.sys(h.seek)(h, whence, off)
		if r == nil and e ~= nil then
			return failfrom(e)
		end
		return r
	end

	function obj:flush()
		live()
		local r, e = K.sys(h.flush)(h)
		if not r then
			return failfrom(e)
		end
		return true
	end

	function obj:close()
		live()
		closed = true
		p.handles[obj] = nil
		K.neatoEntries[obj] = nil
		entry.refs = entry.refs - 1
		if entry.refs <= 0 then
			local r, e = K.sys(h.close)(h)
			if r == nil and e ~= nil then
				return failfrom(e)
			end
		end
		return true
	end

	p.handles[obj] = true
	K.neatoEntries[obj] = entry
	return obj
end

K.neatoEntries = setmetatable({}, { __mode = "k" })

function K.neatoBridge(entry)
	entry.refs = entry.refs + 1
	local o = { kind = "neato", refs = 1 }
	function o:read(fmt)
		return entry.h:read(fmt)
	end
	function o:write(s)
		return entry.h:write(s)
	end
	function o:seek(w, off)
		return entry.h:seek(w, off)
	end
	function o:isatty()
		return false
	end
	function o:onclose()
		entry.refs = entry.refs - 1
		if entry.refs <= 0 then
			pcall(entry.h.close, entry.h)
		end
	end
	return o
end

local POINT_DIRS = {
	["system.root"] = "",
	["system.bin"] = "bin/",
	["system.sbin"] = "sbin/",
	["system.libraries"] = "lib/",
	["system.include"] = "usr/include/",
	["system.source"] = "usr/src/",
	["system.config"] = "etc/",
	["system.boot"] = "boot/",
	["system.device"] = "dev/",
	["software.opt"] = "opt/",
	["software.opt.config"] = "etc/opt/",
	["software.opt.data"] = "var/opt/",
	["software.local"] = "usr/local/",
	["software.localData"] = "usr/local/share/",
	["software.data"] = "usr/share/",
	["storage.persistent"] = "var/",
	["storage.runtime"] = "var/run/",
	["storage.state"] = "var/db/",
	["storage.cache"] = "var/cache/",
	["storage.log"] = "var/log/",
	["storage.spool"] = "var/spool/",
	["storage.lock"] = "var/lock/",
	["storage.mail"] = "var/mail/",
	["storage.crash"] = "var/crash/",
	["storage.games"] = "var/games/",
	["storage.temporary"] = "tmp/",
	["storage.temporaryPersistent"] = "var/tmp/",
	["user.home"] = "home/",
	["user.admin"] = "root/",
	["mount.removable"] = "mnt/",
	["mount.temporary"] = "mnt/",
	["service.data"] = "srv/",
}

local function pointsTable()
	local out = {}
	for name, dir in pairs(POINT_DIRS) do
		out[name] = K.rootdir .. dir
	end
	return out
end

local fs = {
	exists = sys_(function(path)
		local full = rpath(path, "exists")
		if not full then
			return false
		end
		return V.exists(K.current, full)
	end),
	isFile = sys_(function(path)
		local full = rpath(path, "isFile")
		if not full then
			return false
		end
		return V.exists(K.current, full) and V.isFile(K.current, full)
	end),
	isDir = sys_(function(path)
		local full = rpath(path, "isDir")
		if not full then
			return false
		end
		return V.exists(K.current, full) and V.isDir(K.current, full)
	end),
	list = sys_(function(path)
		local full, err = rpath(path, "list")
		if not full then
			return failfrom(err)
		end
		if #full > 1 and full:sub(-1) == "/" and full:sub(-2, -2) ~= ":" then
			full = full:sub(1, -2)
		end
		local names, lerr = V.list(K.current, full)
		if not names then
			return failfrom(lerr)
		end
		return names
	end),
	makeDir = sys_(function(path)
		local full, err = rpath(path, "makeDir")
		if not full then
			return failfrom(err)
		end
		local ok, merr = V.mkdir(K.current, full)
		if not ok then
			return failfrom(merr)
		end
		return true
	end),
	mkfifo = sys_(function(path)
		local full, err = rpath(path, "mkfifo")
		if not full then
			return failfrom(err)
		end
		local ok, merr = V.mkfifo(K.current, full)
		if not ok then
			return failfrom(merr)
		end
		return true
	end),
	delete = sys_(function(path)
		local full, err = rpath(path, "delete")
		if not full then
			return failfrom(err)
		end
		local ok, derr = V.remove(K.current, full)
		if not ok then
			return failfrom(derr)
		end
		return true
	end),
	open = sys_(function(path, mode)
		if type(mode) ~= "string" then
			argerr(2, "open", "string", mode)
		end
		local m = mode:gsub("b$", "")
		if m ~= "r" and m ~= "w" and m ~= "a" then
			return nil, "EINVAL", "invalid open mode '" .. mode .. "'"
		end
		local full, err = rpath(path, "open")
		if not full then
			return failfrom(err)
		end
		local h, herr = V.open(K.current, full, m)
		if not h then
			return failfrom(herr)
		end
		return K.wrapHandle(K.current, h, m)
	end),
	resolve = sys_(function(path)
		local full, err = rpath(path, "resolve")
		if not full then
			return failfrom(err)
		end
		return full
	end),
	getDisks = function()
		local out = {}
		for _, d in ipairs(R.disks()) do
			out[#out + 1] = { slot = d.slot, id = d.id }
		end
		return out
	end,
	getPartitions = sys_(function(disk)
		local ref
		if type(disk) == "number" then
			local i = math.tointeger(disk)
			if not i or i < 0 then
				return nil, "EINVAL", "invalid disk slot"
			end
			ref = i
		elseif type(disk) == "string" then
			if disk:match("^%d+$") then
				ref = tonumber(disk)
			elseif disk:match("^[%a%d_%-]+$") and disk:match("[%a_%-]") then
				ref = disk
			else
				return nil, "EINVAL", "invalid disk id"
			end
		else
			argerr(1, "getPartitions", "int or string", disk)
		end
		local d = R.diskByRef(ref)
		if not d then
			return nil, "ENODEV", "no such disk"
		end
		local names, err = R.partitions(d.slot)
		if not names then
			return nil, "EIO", tostring(err)
		end
		return names
	end),
	getPoint = function(point)
		if type(point) ~= "string" then
			argerr(1, "getPoint", "string", point)
		end
		return K.points[point]
	end,
	getPoints = function()
		local out = {}
		for k, v in pairs(K.points) do
			out[k] = v
		end
		return out
	end,
}

local function mapErr(err, rules)
	local e = type(err) == "string" and err:lower() or ""
	for i = 1, #rules do
		if e:find(rules[i][1], 1, true) then
			return rules[i][2]
		end
	end
	return "EIO"
end

local CHMOD_CODES = {
	{ "no such file", "ENOENT" },
	{ "operation not supported", "ENOTSUP" },
	{ "operation not permitted", "EACCES" },
	{ "permission denied", "EACCES" },
	{ "read-only", "EROFS" },
	{ "read only", "EROFS" },
}

local CHOWN_CODES = {
	{ "invalid id", "EINVAL" },
	{ "no such file", "ENOENT" },
	{ "operation not supported", "ENOTSUP" },
	{ "operation not permitted", "EACCES" },
	{ "permission denied", "EACCES" },
	{ "read-only", "EROFS" },
	{ "read only", "EROFS" },
}

local RENAME_CODES = {
	{ "cannot move between partitions", "EXDEV" },
	{ "cannot move a directory into itself", "EINVAL" },
	{ "cannot rename a partition root", "EPERM" },
	{ "cannot move on a virtual file system", "EPERM" },
	{ "only files and directories can be moved", "ENOTSUP" },
	{ "not a directory", "ENOTDIR" },
	{ "is a directory", "ENOTDIR" },
	{ "directory not empty", "ENOTEMPTY" },
	{ "not empty", "ENOTEMPTY" },
	{ "no such disk", "ENODEV" },
	{ "no disk has", "ENODEV" },
	{ "no such file", "ENOENT" },
	{ "no such directory", "ENOENT" },
	{ "does not exist", "ENOENT" },
	{ "device busy", "EBUSY" },
	{ "in use", "EBUSY" },
	{ "permission denied", "EACCES" },
	{ "operation not permitted", "EROFS" },
	{ "read-only", "EROFS" },
	{ "read only", "EROFS" },
	{ "file exists", "EEXIST" },
}

fs.rename = sys_(function(old, new)
	local fa, e1 = rpath(old, "rename")
	if not fa then
		return failfrom(e1)
	end
	local fb, e2 = rpath(new, "rename")
	if not fb then
		return failfrom(e2)
	end
	local ok, err = V.move(K.current, fa, fb)
	if ok then
		return true
	end
	return nil, mapErr(err, RENAME_CODES), tostring(err)
end)

fs.stat = sys_(function(path)
	local full, err = rpath(path, "stat")
	if not full then
		return failfrom(err)
	end
	local info, serr = V.statx(K.current, full)
	if not info then
		return nil, codeOf(tostring(serr)), tostring(serr)
	end
	local out = { type = (info.type == "file" or info.type == "dir") and info.type or "other" }
	if info.size ~= nil then
		out.size = info.size
	end
	if info.mtime ~= nil then
		out.mtime = info.mtime
	end
	if info.mode ~= nil then
		out.mode = info.mode & 1023
	end
	if info.uid ~= nil then
		out.uid = info.uid
	end
	if info.gid ~= nil then
		out.gid = info.gid
	end
	return out
end)

fs.lstat = sys_(function(path)
	local full, err = rpath(path, "lstat")
	if not full then
		return failfrom(err)
	end
	local kind = V.stat(full)
	if not kind then
		return nil, "ENOENT", "no such file or directory"
	end
	local t = "other"
	if kind == "file" or kind == "dir" or kind == "link" or kind == "fifo" then
		t = kind
	end
	local out = { type = t }
	local _, _, fp = P.split(full)
	if fp and K.perm then
		local slot, part, sfp = slotPartFor(fp)
		local m = slot and K.perm.meta(slot, part, sfp, t == "dir")
		if m then
			out.mode = m.mode & 1023
			out.uid = m.uid
			out.gid = m.gid
		end
	end
	if t == "link" then
		local tgt = V.readlink(K.current, full)
		if tgt ~= nil then
			out.link = tgt
			out.size = #tgt
		end
		out.mode = 511
		local info = V.statx(K.current, full)
		if info and info.mtime ~= nil then
			out.mtime = info.mtime
		end
		return out
	end
	if t == "file" or t == "dir" then
		local info = V.statx(K.current, full)
		if info then
			if info.size ~= nil then
				out.size = info.size
			end
			if info.mtime ~= nil then
				out.mtime = info.mtime
			end
		end
	end
	return out
end)

fs.access = sys_(function(path, ways)
	if type(ways) ~= "string" then
		argerr(2, "access", "string", ways)
	end
	for i = 1, #ways do
		local c = ways:sub(i, i)
		if c ~= "r" and c ~= "w" and c ~= "x" then
			error(string.format("bad argument #2 to 'access' (invalid access way '%s')", c), 2)
		end
	end
	local full, err = rpath(path, "access")
	if not full then
		return false
	end
	local want = 0
	if ways:find("r", 1, true) then
		want = want | 4
	end
	if ways:find("w", 1, true) then
		want = want | 2
	end
	if ways:find("x", 1, true) then
		want = want | 1
	end
	return V.perm(K.current, full, want) == true
end)

fs.chmod = sys_(function(path, mode)
	local full, err = rpath(path, "chmod")
	if not full then
		return failfrom(err)
	end
	if math.type(mode) ~= "integer" or mode < 0 or mode > 1023 then
		return nil, "EINVAL", "mode must be an integer from 0 to 1023"
	end
	local ok, cerr = V.chmod(K.current, full, mode)
	if ok then
		return true
	end
	return nil, mapErr(cerr, CHMOD_CODES), tostring(cerr)
end)

fs.utimes = sys_(function(path, mtime)
	local full, err = rpath(path, "utimes")
	if not full then
		return failfrom(err)
	end
	if type(mtime) ~= "number" then
		argerr(2, "utimes", "number", mtime)
	end
	if math.type(mtime) ~= "integer" then
		return nil, "EINVAL", "mtime must be an integer"
	end
	local ok, uerr = V.utime(K.current, full, mtime)
	if ok then
		return true
	end
	return failfrom(uerr)
end)

fs.chown = sys_(function(path, user, group)
	local full, err = rpath(path, "chown")
	if not full then
		return failfrom(err)
	end
	local uid, gid = user, group
	if user ~= nil then
		if math.type(user) == "integer" then
			uid = user
		elseif type(user) == "string" then
			local u = K.getpwnam and K.getpwnam(user) or nil
			if not u then
				return nil, "EINVAL", "no such user '" .. user .. "'"
			end
			uid = u.uid
		else
			argerr(2, "chown", "user id or name", user)
		end
	end
	if group ~= nil then
		if math.type(group) == "integer" then
			gid = group
		elseif type(group) == "string" then
			local gr = K.getgrnam and K.getgrnam(group) or nil
			if not gr then
				return nil, "EINVAL", "no such group '" .. group .. "'"
			end
			gid = gr.gid
		else
			argerr(3, "chown", "group id or name", group)
		end
	end
	local ok, cerr = V.chown(K.current, full, uid, gid)
	if ok then
		return true
	end
	return nil, mapErr(cerr, CHOWN_CODES), tostring(cerr)
end)

fs.umask = function(mask)
	local p = K.current
	local old = p.umask
	if mask ~= nil then
		local m = math.tointeger(mask)
		if m == nil then
			argerr(1, "umask", "integer", mask)
		end
		p.umask = m & 511
	end
	return old
end

local function wantIntegral(v, n, fname)
	local i = type(v) == "number" and math.tointeger(v)
	if i == nil then
		argerr(n, fname, "integer", v)
	end
	return i
end

local function payloadSize(v, depth, seen)
	local t = type(v)
	if t == "boolean" then
		return 1
	end
	if t == "number" then
		if v ~= v then
			return nil
		end
		if math.type(v) == "integer" then
			return 1 + #tostring(v) + 1
		end
		return 1 + #string.format("%.17g", v) + 1
	end
	if t == "string" then
		return 1 + #tostring(#v) + 1 + #v
	end
	if t ~= "table" then
		return nil
	end
	if depth > 32 or seen[v] then
		return nil
	end
	seen[v] = true
	local total, count = 0, 0
	for k, x in pairs(v) do
		local ks = payloadSize(k, depth + 1, seen)
		if not ks then
			seen[v] = nil
			return nil
		end
		local vs = payloadSize(x, depth + 1, seen)
		if not vs then
			seen[v] = nil
			return nil
		end
		total = total + ks + vs
		count = count + 1
	end
	seen[v] = nil
	return 1 + #tostring(count) + 1 + total
end

local function validPayload(v)
	return payloadSize(v, 1, {}) ~= nil
end

local function clone(v)
	if type(v) ~= "table" then
		return v
	end
	local o = {}
	for k, x in pairs(v) do
		o[clone(k)] = clone(x)
	end
	return o
end

local function validPort(n)
	return math.type(n) == "integer" and n >= 1 and n <= 65535
end

local DPP_BROADCAST = "ffffffffffff"

local function validAddress(s)
	return type(s) == "string" and #s == 12 and s:match("^[0-9a-f]+$") ~= nil and s ~= "000000000000"
end

local DPP_MAXPAYLOAD = 65536

local ports = {}

local function localAddress()
	local ex = K.ext
	local rpp = type(ex) == "table" and ex.rpp or nil
	if type(rpp) ~= "table" or type(rpp.getAddress) ~= "function" then
		return nil
	end
	local ok, addr = pcall(rpp.getAddress, K.current)
	if ok and type(addr) == "string" then
		return addr
	end
	return nil
end

local function deliver(msg)
	if type(msg) ~= "table" or msg.protocol ~= "dpp" then
		return
	end
	local ta, tp, sp = msg.target_address, msg.target_port, msg.source_port
	if ta ~= nil and not validAddress(ta) then
		return
	end
	if not validPort(tp) or not (validPort(sp) or sp == -1) then
		return
	end
	if not validPayload(msg.payload) then
		return
	end
	if ta ~= nil and ta ~= DPP_BROADCAST then
		local me = localAddress()
		if me == nil or ta ~= me then
			return
		end
	end
	local owner = ports[tp]
	if owner and owner.state ~= "Z" then
		K.pushEvent(owner, "dpp", clone(msg.payload), msg.source_address, sp)
	end
end

local HTTP_MAXBODY = 8 * 1024 * 1024
local HTTP_DEFTIMEOUT = 15
local HTTP_MAXREDIR = 5
local httpPending = {}
K.httpPending = httpPending

local function httpHost()
	return rawget(_G, "internet")
end

local function httpAvailable()
	local hi = httpHost()
	if type(hi) ~= "table" then
		return false
	end
	if type(hi.hasAccess) == "function" then
		local ok, r = pcall(hi.hasAccess)
		if ok then
			return r and true or false
		end
		return false
	end
	return true
end

local function httpDeliver(ev)
	local id = ev[2]
	if type(id) ~= "number" then
		return
	end
	local pend = httpPending[id]
	if not pend then
		return
	end
	local p = pend.proc
	if not p or p.state == "Z" then
		httpPending[id] = nil
		return
	end
	pend.code, pend.msg, pend.headers, pend.body = ev[3], ev[4], ev[5], ev[6]
	pend.done = true
	p.wakeup = true
end

local function deliverRpp(ev, at)
	if type(K.rppFrame) ~= "function" then
		return
	end
	local frame = {}
	for i = at or 1, #ev do
		frame[#frame + 1] = ev[i]
	end
	pcall(K.rppFrame, frame, "wired")
end

function K.on_network(ev)
	if type(ev) ~= "table" then
		return
	end
	if ev.protocol == "dpp" then
		deliver(ev)
		return
	end
	if ev[1] == "HttpResponse" then
		httpDeliver(ev)
		return
	end
	if ev[1] == "rpp" then
		deliverRpp(ev)
		return
	end
	if ev[1] == "networkMessage" then
		if ev[2] == "rpp" then
			deliverRpp(ev, 2)
			return
		end
		if type(ev[2]) == "table" and ev[2].protocol == "dpp" then
			deliver(ev[2])
			return
		end
	end
	for i = 1, #ev do
		local m = ev[i]
		if type(m) == "table" then
			if m.protocol == "dpp" then
				deliver(m)
			elseif m[1] == "HttpResponse" then
				httpDeliver(m)
			elseif m[1] == "rpp" then
				deliverRpp(m)
			elseif m[1] == "networkMessage" then
				if m[2] == "rpp" then
					deliverRpp(m, 2)
				elseif type(m[2]) == "table" and m[2].protocol == "dpp" then
					deliver(m[2])
				end
			end
		end
	end
end

function K.dpp_release(p)
	for port, owner in pairs(ports) do
		if owner == p then
			ports[port] = nil
		end
	end
end

function K.http_release(p)
	for id, pend in pairs(httpPending) do
		if pend.proc == p then
			httpPending[id] = nil
		end
	end
end

local function httpCheckUrl(url)
	if type(url) ~= "string" then
		return nil
	end
	if url:match("^https://") then
		return "https"
	end
	if url:match("^http://") then
		return "http"
	end
	return nil
end

local function httpCheckHeaders(h)
	if h == nil then
		return {}, nil
	end
	if type(h) ~= "table" then
		return nil, "headers must be a table"
	end
	local out = {}
	for k, v in pairs(h) do
		if type(k) ~= "string" or type(v) ~= "string" then
			return nil, "header names and values must be strings"
		end
		out[k] = v
	end
	return out, nil
end

local function httpLocationOf(hdrs)
	if type(hdrs) ~= "table" then
		return nil
	end
	for k, v in pairs(hdrs) do
		if type(k) == "string" and k:lower() == "location" and type(v) == "string" and v ~= "" then
			return v
		end
	end
	return nil
end

local function httpJoin(base, loc)
	if loc:match("^https?://") then
		return loc
	end
	local scheme, auth = base:match("^(https?)://([^/]+)")
	if not scheme then
		return nil
	end
	if loc:sub(1, 1) == "/" then
		return scheme .. "://" .. auth .. loc
	end
	local dir = base:match("^(https?://.-/)") or (scheme .. "://" .. auth .. "/")
	local path = base:sub(#dir + 1)
	local slash = path:find("[?#]", 1)
	if slash then
		path = path:sub(1, slash - 1)
	end
	local bdir = path:match("^(.*/)[^/]*$") or ""
	return dir .. bdir .. loc
end

local function httpOnce(method, url, headers, body, timeout, maxbytes)
	local hi = httpHost()
	if type(hi) ~= "table" then
		return nil, "ENETDOWN", "network unavailable (no internet facility)"
	end
	if not httpAvailable() then
		return nil, "ENETDOWN", "network access disabled (NEETEMU_NO_NET?)"
	end
	if not httpCheckUrl(url) then
		return nil, "EINVAL", "url must start with http:// or https://"
	end
	local hdrs, herr = httpCheckHeaders(headers)
	if not hdrs then
		return nil, "EINVAL", herr
	end
	if body ~= nil and type(body) ~= "string" then
		return nil, "EINVAL", "body must be a string"
	end
	timeout = timeout == nil and HTTP_DEFTIMEOUT or timeout
	if type(timeout) ~= "number" or timeout < 0 then
		return nil, "EINVAL", "timeout must be a non-negative number"
	end
	maxbytes = maxbytes == nil and HTTP_MAXBODY or maxbytes
	if math.tointeger(maxbytes) == nil or maxbytes < 1 then
		return nil, "EINVAL", "maxbytes must be a positive integer"
	end
	local fn = method == "POST" and hi.POST or hi.GET
	if type(fn) ~= "function" then
		return nil, "ENOTSUP", "host http method not supported"
	end
	local id
	if method == "POST" then
		local ok, rid = pcall(fn, url, hdrs, body)
		if not ok then
			return nil, "EINVAL", tostring(rid)
		end
		id = rid
	else
		local ok, rid = pcall(fn, url, hdrs)
		if not ok then
			return nil, "EINVAL", tostring(rid)
		end
		id = rid
	end
	if type(id) ~= "number" then
		return nil, "EIO", "host did not return a request id"
	end
	local me = K.current
	local pend = { proc = me, done = false }
	httpPending[id] = pend
	local deadline = K.monotonic() + timeout
	while not pend.done do
		if K.monotonic() >= deadline then
			if httpPending[id] == pend then
				httpPending[id] = nil
			end
			return nil, "ETIMEDOUT", "request timed out"
		end
		K.block(me, function()
			return pend.done
		end, deadline)
	end
	if httpPending[id] == pend then
		httpPending[id] = nil
	end
	return pend.code, pend.msg, pend.headers, pend.body
end

local function httpFetch(method, url, headers, body, timeout, maxbytes)
	local cur, curBody = url, body
	local curMethod = method
	local lastHdrs = {}
	for _ = 0, HTTP_MAXREDIR do
		local code, msg, hdrs, rbody = httpOnce(curMethod, cur, headers, curBody, timeout, maxbytes)
		if not code then
			return nil, msg, hdrs
		end
		if type(code) ~= "number" then
			return nil, "EIO", "bad host response"
		end
		lastHdrs = type(hdrs) == "table" and hdrs or {}
		if code == 111 then
			return nil, "ECONNREFUSED", "network access disabled"
		elseif code == 110 then
			return nil, "ETIMEDOUT", "request timed out"
		elseif code == 301 or code == 302 or code == 303 or code == 307 or code == 308 then
			local loc = httpLocationOf(lastHdrs)
			if not loc then
				return nil, "EIO", "http redirect " .. code .. " without Location"
			end
			local nxt = httpJoin(cur, loc)
			if not nxt then
				return nil, "EIO", "bad redirect Location"
			end
			cur = nxt
			if code == 303 or ((code == 301 or code == 302) and curMethod == "POST") then
				curMethod, curBody = "GET", nil
			end
		elseif code >= 200 and code < 300 then
			local data = rbody == nil and "" or rbody
			if type(data) ~= "string" then
				data = tostring(data)
			end
			if #data > maxbytes then
				return nil, "EFBIG", "response too large (" .. #data .. " bytes, limit " .. maxbytes .. ")"
			end
			return data, lastHdrs, code
		else
			return nil, "EIO", "http error " .. code .. " " .. tostring(msg or "")
		end
	end
	return nil, "EIO", "too many redirects"
end

local dpp = {
	listen = sys_(function(port)
		if type(port) ~= "number" then
			argerr(1, "listen", "integer", port)
		end
		if not validPort(port) then
			return nil, "EINVAL", "port must be from 1 to 65535"
		end
		if port < 1024 and K.current.uid ~= 0 then
			return nil, "EACCES", "port is privileged"
		end
		local owner = ports[port]
		if owner and owner.state ~= "Z" then
			return nil, "EADDRINUSE", "port already in use"
		end
		ports[port] = K.current
		return true
	end),
	unlisten = sys_(function(port)
		if type(port) ~= "number" then
			argerr(1, "unlisten", "integer", port)
		end
		if not validPort(port) then
			return nil, "EINVAL", "port must be from 1 to 65535"
		end
		if ports[port] == K.current then
			ports[port] = nil
		end
		return true
	end),
	send = sys_(function(target_address, target, payload, source)
		if type(target_address) == "number" then
			target_address, target, payload, source = nil, target_address, target, payload
		end
		if target_address ~= nil and type(target_address) ~= "string" then
			argerr(1, "send", "string", target_address)
		end
		if type(target) ~= "number" then
			argerr(2, "send", "integer", target)
		end
		if source ~= nil and type(source) ~= "number" then
			argerr(4, "send", "integer", source)
		end
		source = source == nil and -1 or source
		target_address = target_address == nil and DPP_BROADCAST or target_address
		if not validAddress(target_address) then
			return nil, "EINVAL", "invalid target address"
		end
		if not validPort(target) then
			return nil, "EINVAL", "invalid target port"
		end
		if not (validPort(source) or source == -1) then
			return nil, "EINVAL", "invalid source port"
		end
		local size = payloadSize(payload, 1, {})
		if not size then
			return nil, "EINVAL", "payload cannot be sent"
		end
		if size > DPP_MAXPAYLOAD then
			return nil, "EMSGSIZE", "payload is too large"
		end
		local me = localAddress()
		local local_msg = target_address == DPP_BROADCAST or (me ~= nil and target_address == me)
		if not local_msg then
			return nil, "EHOSTUNREACH", "no route to " .. target_address
		end
		local msg = {
			protocol = "dpp",
			target_address = target_address,
			target_port = target,
			source_port = source,
			source_address = me,
			payload = clone(payload),
		}

		local bl = rawget(_G, "io") and io.broadcastLocal
		if bl then
			pcall(bl, msg)
		end
		deliver(msg)
		return true
	end),
}

local SPP_MAXPAYLOAD = 65536
local SPP_INBOX = 16
local SPP_BACKLOG = 16
local SPP_MAXCONN = 256

local sppListeners = {}
local connPorts = {}
local nextConnPort = 49152
local PEER = setmetatable({}, { __mode = "k" })

local Listener = {}
local Connection = {}
Listener.__index, Connection.__index = Listener, Connection

local function addHandle(h)
	local p = h.owner
	p.sppHandles = p.sppHandles or {}
	p.sppHandles[h] = true
end

local function removeHandle(h)
	local p = h.owner
	if p and p.sppHandles then
		p.sppHandles[h] = nil
	end
end

local function countHandles(p)
	local n = 0
	for _ in pairs(p.sppHandles or {}) do
		n = n + 1
	end
	return n
end

local function userName(proc)
	if not proc or proc.uid == nil or not K.getpwuid then
		return nil
	end
	local ok, u = pcall(K.getpwuid, proc.uid)
	if ok and type(u) == "table" and type(u.name) == "string" then
		return u.name
	end
	return nil
end

local function allocPort()
	for _ = 1, 16384 do
		local p = nextConnPort
		nextConnPort = nextConnPort + 1
		if nextConnPort > 65535 then
			nextConnPort = 49152
		end
		if not sppListeners[p] and not connPorts[p] then
			return p
		end
	end
	return nil
end

local function newLocalPair(clientProc, serverProc, clientPort, serverPort)
	local client = setmetatable({
		kind = "connection",
		owner = clientProc,
		port = clientPort,
		peerPort = serverPort,
		inbox = {},
		inboxMax = SPP_INBOX,
		maxPayload = SPP_MAXPAYLOAD,
		closed = false,
		reset = false,
		peerClosed = false,
		peer = { origin = "local", user = userName(serverProc), id = serverProc.pid },
	}, Connection)
	local server = setmetatable({
		kind = "connection",
		owner = serverProc,
		port = serverPort,
		peerPort = clientPort,
		inbox = {},
		inboxMax = SPP_INBOX,
		maxPayload = SPP_MAXPAYLOAD,
		closed = false,
		reset = false,
		peerClosed = false,
		peer = { origin = "local", user = userName(clientProc), id = clientProc.pid },
	}, Connection)
	PEER[client], PEER[server] = server, client
	return client, server
end

local function connReadable(c)
	return c.closed or #c.inbox > 0 or c.peerClosed or c.reset
end

local function connWritable(c)
	if c.closed or c.reset or c.peerClosed then
		return true
	end
	local pc = PEER[c]
	if not pc then
		return true
	end
	if pc.closed or pc.reset then
		return true
	end
	return #pc.inbox < pc.inboxMax
end

local function listenerReadable(l)
	return l.closed or #l.pending > 0
end

function Connection:send(payload, timeout)
	if self.closed then
		error("attempt to use a closed handle", 3)
	end
	if timeout ~= nil and type(timeout) ~= "number" then
		argerr(2, "send", "number", timeout)
	end
	if self.reset then
		return nil, "ECONNRESET", "connection reset"
	end
	if self.peerClosed then
		return nil, "EPIPE", "connection closed"
	end
	local size = payloadSize(payload, 1, {})
	if not size then
		return nil, "EINVAL", "payload cannot be sent"
	end
	if size > self.maxPayload then
		return nil, "EMSGSIZE", "payload is too large"
	end
	local pc = PEER[self]
	if not pc then
		return nil, "EPIPE", "connection closed"
	end
	local deadline = timeout and (K.monotonic() + timeout) or nil
	while true do
		if pc.reset then
			return nil, "ECONNRESET", "connection reset"
		end
		if pc.closed then
			return nil, "EPIPE", "connection closed"
		end
		if #pc.inbox < pc.inboxMax then
			break
		end
		if deadline and K.monotonic() >= deadline then
			return nil, "ETIMEDOUT", "timed out"
		end
		K.block(K.current, function()
			return pc.reset or pc.closed or #pc.inbox < pc.inboxMax
		end, deadline)
	end
	pc.inbox[#pc.inbox + 1] = clone(payload)
	return true
end

function Connection:recv(timeout)
	if self.closed then
		error("attempt to use a closed handle", 3)
	end
	if timeout ~= nil and type(timeout) ~= "number" then
		argerr(1, "recv", "number", timeout)
	end
	if self.reset then
		return nil, "ECONNRESET", "connection reset"
	end
	if #self.inbox > 0 then
		return table.remove(self.inbox, 1)
	end
	if self.peerClosed then
		return nil, "EPIPE", "connection closed"
	end
	local deadline = timeout and (K.monotonic() + timeout) or nil
	while true do
		if deadline and K.monotonic() >= deadline then
			return nil, "ETIMEDOUT", "timed out"
		end
		K.block(K.current, function()
			return #self.inbox > 0 or self.peerClosed or self.reset
		end, deadline)
		if self.reset then
			return nil, "ECONNRESET", "connection reset"
		end
		if #self.inbox > 0 then
			return table.remove(self.inbox, 1)
		end
		if self.peerClosed then
			return nil, "EPIPE", "connection closed"
		end
	end
end

function Connection:close()
	if self.closed then
		error("attempt to use a closed handle", 3)
	end
	self.closed = true
	self.inbox = {}
	removeHandle(self)
	if self.port and connPorts[self.port] == self then
		connPorts[self.port] = nil
	end
	local pc = PEER[self]
	if pc and not pc.reset then
		pc.peerClosed = true
	end
	return true
end

function Listener:accept(timeout)
	if self.closed then
		error("attempt to use a closed handle", 3)
	end
	if timeout ~= nil and type(timeout) ~= "number" then
		argerr(1, "accept", "number", timeout)
	end
	local function take()
		local c = table.remove(self.pending, 1)
		if countHandles(self.owner) >= SPP_MAXCONN then
			c.reset = true
			local pc = PEER[c]
			if pc and not pc.reset then
				pc.reset = true
			end
			return nil, "ELIMIT", "too many connections"
		end
		addHandle(c)
		return c
	end
	if #self.pending > 0 then
		return take()
	end
	local deadline = timeout and (K.monotonic() + timeout) or nil
	while true do
		if deadline and K.monotonic() >= deadline then
			return nil, "ETIMEDOUT", "timed out"
		end
		K.block(K.current, function()
			return #self.pending > 0 or self.closed
		end, deadline)
		if self.closed then
			return nil, "EIO", "listener closed"
		end
		if #self.pending > 0 then
			return take()
		end
	end
end

function Listener:close()
	if self.closed then
		error("attempt to use a closed handle", 3)
	end
	self.closed = true
	if sppListeners[self.port] == self then
		sppListeners[self.port] = nil
	end
	for _, c in ipairs(self.pending) do
		c.reset = true
		local pc = PEER[c]
		if pc and not pc.reset then
			pc.reset = true
		end
		removeHandle(c)
	end
	self.pending = {}
	removeHandle(self)
	return true
end

local PIPE_LIMIT = 8192

function K.fdReady(fd, writing)
	if type(fd) ~= "table" then
		return false
	end
	local pred = K.ready[fd.kind]
	if not pred then
		return false
	end
	local ok, ready = pcall(pred, fd, writing)
	return ok and ready and true or false
end

local function neatoEntryReady(h, writing)
	local e = K.neatoEntries[h]
	if not e then
		return false
	end
	if e.pipe then
		local st = e.st
		if e.read then
			if writing then
				return false
			end
			return #st.buf > 0 or st.writers == 0
		end
		if not writing then
			return false
		end
		return st.readers > 0 and #st.buf <= PIPE_LIMIT
	end
	if e.stdio then
		local p2 = e.p or K.current
		local fd = p2 and p2.fds and p2.fds[e.n]
		return K.fdReady(fd, writing)
	end
	if e.h then
		if writing then
			return e.writable ~= false
		end
		return e.readable ~= false
	end
	return false
end

local function pollReady(p, read, write)
	local r, w = {}, {}
	if read then
		for i = 1, #read do
			local h = read[i]
			if h == "event" then
				if p.eh <= p.et then
					r[#r + 1] = h
				end
			elseif type(h) == "table" and h.kind == "listener" then
				if listenerReadable(h) then
					r[#r + 1] = h
				end
			elseif type(h) == "table" and h.kind == "connection" then
				if connReadable(h) then
					r[#r + 1] = h
				end
			elseif neatoEntryReady(h, false) then
				r[#r + 1] = h
			end
		end
	end
	if write then
		for i = 1, #write do
			local h = write[i]
			if type(h) == "table" and h.kind == "connection" then
				if connWritable(h) then
					w[#w + 1] = h
				end
			elseif neatoEntryReady(h, true) then
				w[#w + 1] = h
			end
		end
	end
	return r, w
end

function K.pollWait(p, read, write, timeout)
	local r, w = pollReady(p, read, write)
	if #r > 0 or #w > 0 or timeout == 0 then
		return r, w
	end
	local deadline = timeout and (K.monotonic() + timeout) or nil
	while true do
		K.block(p, function()
			local rr, ww = pollReady(p, read, write)
			return #rr > 0 or #ww > 0
		end, deadline)
		r, w = pollReady(p, read, write)
		if #r > 0 or #w > 0 then
			return r, w
		end
		if deadline and K.monotonic() >= deadline then
			return r, w
		end
	end
end

K.pollReady = pollReady

local function spp_listen(port, opts)
	if type(port) ~= "number" then
		argerr(1, "listen", "integer", port)
	end
	if not validPort(port) then
		return nil, "EINVAL", "port must be from 1 to 65535"
	end
	if port < 1024 and K.current.uid ~= 0 then
		return nil, "EACCES", "port is privileged"
	end
	opts = opts or {}
	if type(opts) ~= "table" then
		argerr(2, "listen", "table", opts)
	end
	local scope = opts.scope == nil and "local" or opts.scope
	if scope ~= "local" and scope ~= "network" then
		return nil, "EINVAL", "invalid scope"
	end
	if scope == "network" then
		return nil, "ENOTSUP", "network scope is not supported"
	end
	local backlog = SPP_BACKLOG
	if opts.backlog ~= nil then
		if type(opts.backlog) ~= "number" then
			argerr(2, "listen", "table", opts)
		end
		local b = math.tointeger(opts.backlog)
		if not b or b < 1 then
			return nil, "EINVAL", "invalid backlog"
		end
		backlog = math.min(b, SPP_BACKLOG)
	end
	local p = K.current
	if sppListeners[port] or connPorts[port] then
		return nil, "EADDRINUSE", "port already in use"
	end
	if countHandles(p) >= SPP_MAXCONN then
		return nil, "ELIMIT", "too many connections"
	end
	local l = setmetatable({
		kind = "listener",
		owner = p,
		port = port,
		scope = scope,
		backlog = backlog,
		pending = {},
		closed = false,
	}, Listener)
	sppListeners[port] = l
	addHandle(l)
	return l
end

local function spp_connect(port, opts)
	if type(port) ~= "number" then
		argerr(1, "connect", "integer", port)
	end
	if not validPort(port) then
		return nil, "EINVAL", "port must be from 1 to 65535"
	end
	opts = opts or {}
	if type(opts) ~= "table" then
		argerr(2, "connect", "table", opts)
	end
	local scope = opts.scope == nil and "local" or opts.scope
	if scope ~= "local" and scope ~= "network" then
		return nil, "EINVAL", "invalid scope"
	end
	if opts.timeout ~= nil and type(opts.timeout) ~= "number" then
		argerr(2, "connect", "table", opts)
	end
	if opts.host ~= nil then
		if type(opts.host) ~= "string" then
			argerr(2, "connect", "table", opts)
		end
		if scope ~= "network" then
			return nil, "EINVAL", "host requires network scope"
		end
		return nil, "ENOTSUP", "network scope is not supported"
	end
	if scope == "network" then
		return nil, "ENOTSUP", "network scope is not supported"
	end
	local p = K.current
	if countHandles(p) >= SPP_MAXCONN then
		return nil, "ELIMIT", "too many connections"
	end
	local l = sppListeners[port]
	if not l or l.closed then
		return nil, "ECONNREFUSED", "connection refused"
	end
	if #l.pending >= l.backlog then
		return nil, "ECONNREFUSED", "connection refused"
	end
	local cport = allocPort()
	if not cport then
		return nil, "ELIMIT", "no free local port"
	end
	local client, server = newLocalPair(p, l.owner, cport, port)
	connPorts[cport] = client
	l.pending[#l.pending + 1] = server
	addHandle(client)
	return client
end

local function spp_poll(read, timeout, write)
	if read ~= nil and type(read) ~= "table" then
		argerr(1, "poll", "table", read)
	end
	if timeout ~= nil and type(timeout) ~= "number" then
		argerr(2, "poll", "number", timeout)
	end
	if write ~= nil and type(write) ~= "table" then
		argerr(3, "poll", "table", write)
	end
	local p = K.current
	local r, w = pollReady(p, read, write)
	if #r > 0 or #w > 0 then
		return r, w
	end
	local deadline = timeout and (K.monotonic() + timeout) or nil
	while true do
		if deadline and K.monotonic() >= deadline then
			return nil
		end
		K.block(p, function()
			local rr, ww = pollReady(p, read, write)
			return #rr > 0 or #ww > 0
		end, deadline)
		r, w = pollReady(p, read, write)
		if #r > 0 or #w > 0 then
			return r, w
		end
	end
end

local function spp_getLimits()
	return { maxPayload = SPP_MAXPAYLOAD, inbox = SPP_INBOX, backlog = SPP_BACKLOG, maxConnections = SPP_MAXCONN }
end

local spp = {
	listen = spp_listen,
	connect = spp_connect,
	poll = spp_poll,
	getLimits = spp_getLimits,
}

local http = {}

function http.available()
	return httpAvailable()
end

function http.getLimits()
	return { maxBody = HTTP_MAXBODY, timeout = HTTP_DEFTIMEOUT, maxRedirects = HTTP_MAXREDIR }
end

local function httpOpts(opts, fname)
	if opts == nil then
		return {}, nil
	end
	if type(opts) ~= "table" then
		argerr(2, fname, "table", opts)
	end
	local o = {}
	if opts.headers ~= nil then
		if type(opts.headers) ~= "table" then
			argerr(2, fname, "table", opts)
		end
		o.headers = opts.headers
	end
	if opts.timeout ~= nil then
		if type(opts.timeout) ~= "number" then
			argerr(2, fname, "table", opts)
		end
		o.timeout = opts.timeout
	end
	if opts.maxbytes ~= nil then
		if type(opts.maxbytes) ~= "number" then
			argerr(2, fname, "table", opts)
		end
		o.maxbytes = opts.maxbytes
	end
	return o, nil
end

function http.get(url, opts)
	if type(url) ~= "string" then
		argerr(1, "get", "string", url)
	end
	local o = httpOpts(opts, "get")
	local maxb = o.maxbytes == nil and HTTP_MAXBODY or o.maxbytes
	local body, hdrs, code = httpFetch("GET", url, o.headers, nil, o.timeout, maxb)
	if not body then
		return nil, hdrs, code
	end
	return body, hdrs, code
end

function http.post(url, data, opts)
	if type(url) ~= "string" then
		argerr(1, "post", "string", url)
	end
	if data ~= nil and type(data) ~= "string" then
		argerr(2, "post", "string", data)
	end
	local o = httpOpts(opts, "post")
	local maxb = o.maxbytes == nil and HTTP_MAXBODY or o.maxbytes
	local body, hdrs, code = httpFetch("POST", url, o.headers, data, o.timeout, maxb)
	if not body then
		return nil, hdrs, code
	end
	return body, hdrs, code
end

function K.spp_release(p)
	if not p.sppHandles then
		return
	end
	local handles = {}
	for h in pairs(p.sppHandles) do
		handles[#handles + 1] = h
	end
	for _, h in ipairs(handles) do
		if h.kind == "listener" then
			if not h.closed then
				h.closed = true
				if sppListeners[h.port] == h then
					sppListeners[h.port] = nil
				end
				for _, c in ipairs(h.pending) do
					c.reset = true
					local pc = PEER[c]
					if pc and not pc.reset then
						pc.reset = true
					end
				end
				h.pending = {}
			end
		elseif not h.closed then
			h.closed = true
			if h.port and connPorts[h.port] == h then
				connPorts[h.port] = nil
			end
			local pc = PEER[h]
			if pc then
				if p.killed then
					if not pc.reset then
						pc.reset = true
					end
				elseif not pc.reset then
					pc.peerClosed = true
				end
			end
		end
	end
	p.sppHandles = {}
end

K.points = pointsTable()

K.extensions = {
	core = 4,
	["ext.stdio"] = 1,
	["ext.env"] = 1,
	["ext.time"] = 1,
	["ext.proc"] = 1,
	["ext.user"] = 1,
	["ext.system"] = 1,
	["ext.perms"] = 1,
	["ext.job"] = 1,
	["ext.auth"] = 1,
	["ext.fifo"] = 1,
	["ext.utimes"] = 1,
	["ext.dpp"] = 3,
	["ext.spp"] = 2,
	["x.xesns.posix"] = 1,
	["x.xesns.http"] = 1,
	["x.xesns.gfx"] = 1,
}

if rawget(_G, "chip") then
	K.extensions["ext.chip"] = 1
end
if rawget(_G, "files") and type(K.rawfs) == "table" then
	K.extensions["ext.partitions"] = 1
end

local function fdCode(e)
	local m = type(e) == "string" and e:lower() or ""
	if m:find("not open for", 1, true) or m:find("bad file descriptor", 1, true) then
		return "EBADF"
	end
	if m:find("broken pipe", 1, true) then
		return "EPIPE"
	end
	if m:find("illegal seek", 1, true) then
		return "ESPIPE"
	end
	if m:find("invalid", 1, true) then
		return "EINVAL"
	end
	if m:find("no space", 1, true) then
		return "ENOSPC"
	end
	return "EIO"
end

local function stdioHandle(p, n, mode)
	local closed = false
	local obj = {}
	local function live()
		if closed then
			error("attempt to use a closed handle", 3)
		end
	end
	local function fd()
		return p.fds[n]
	end
	function obj:read(fmt)
		live()
		if mode ~= "r" then
			return nil, "EBADF", "stream is not open for reading"
		end
		if fmt ~= nil and type(fmt) ~= "number" and type(fmt) ~= "string" then
			argerr(1, "read", "string or integer", fmt)
		end
		if type(fmt) == "string" and fmt ~= "l" and fmt ~= "a" then
			return nil, "EINVAL", "invalid read format"
		end
		local o = fd()
		if not o or not o.read then
			return nil, "EBADF", "stream is closed"
		end
		local r, e = K.sys(o.read)(o, fmt)
		if r == nil and e ~= nil then
			if r == nil and o.read == nil then
				return nil, "EBADF", "stream is closed"
			end
			return nil, fdCode(e), tostring(e)
		end
		return r
	end
	function obj:write(...)
		live()
		if mode ~= "w" then
			return nil, "EBADF", "stream is not open for writing"
		end
		local parts = {}
		for i = 1, select("#", ...) do
			local v = select(i, ...)
			if type(v) ~= "string" and type(v) ~= "number" then
				argerr(i, "write", "string or number", v)
			end
			parts[i] = tostring(v)
		end
		local o = fd()
		if not o or not o.write then
			return nil, "EBADF", "stream is closed"
		end
		local data = table.concat(parts)
		local r, e = K.sys(o.write)(o, data)
		if not r then
			if e == "broken pipe" then
				K.exit(p, 128 + 13)
			end
			return nil, fdCode(e), tostring(e)
		end
		return self
	end
	function obj:seek(whence, off)
		live()
		local o = fd()
		if not o or not o.seek then
			return nil, "ESPIPE", "stream does not support seeking"
		end
		if whence ~= nil and type(whence) ~= "string" then
			argerr(1, "seek", "string", whence)
		end
		if whence ~= nil and whence ~= "set" and whence ~= "cur" and whence ~= "end" then
			return nil, "EINVAL", "invalid whence"
		end
		if off ~= nil and math.tointeger(off) == nil then
			argerr(2, "seek", "integer", off)
		end
		local r, e = K.sys(o.seek)(o, whence, off)
		if r == nil and e ~= nil then
			return nil, fdCode(e), tostring(e)
		end
		return r
	end
	function obj:flush()
		live()
		local o = fd()
		if o and o.flush then
			local r, e = K.sys(o.flush)(o)
			if not r then
				return nil, fdCode(e), tostring(e)
			end
		end
		return true
	end
	function obj:close()
		live()
		closed = true
		p.handles[obj] = nil
		K.neatoEntries[obj] = nil
		return true
	end
	function obj:isatty()
		live()
		local o = fd()
		return o ~= nil and o.isatty and o:isatty() or false
	end
	p.handles[obj] = true
	K.neatoEntries[obj] = { stdio = true, p = p, n = n, mode = mode }
	return obj
end

local function isNeatoHandle(v)
	return type(v) == "table" and K.neatoEntries[v] ~= nil
end

local stdio = {}
function stdio.isatty(stream)
	if not isNeatoHandle(stream) then
		argerr(1, "isatty", "handle", stream)
	end
	local ok, r = pcall(stream.isatty, stream)
	if not ok then
		return false
	end
	return r == true
end
stdio.readLine = sys_(function(options)
	if options ~= nil and type(options) ~= "table" then
		argerr(1, "readLine", "table", options)
	end
	options = options or {}
	if options.noecho ~= nil and type(options.noecho) ~= "boolean" then
		argerr(1, "readLine", "table", options)
	end
	if options.history ~= nil and type(options.history) ~= "table" then
		argerr(1, "readLine", "table", options)
	end
	local p = K.current
	local o = p.fds[0]
	local tty = nil
	if o then
		if o.kind == "tty" then
			tty = o.tty
		elseif o.kind == "neato-fd" and o.target and o.target.kind == "tty" then
			tty = o.target.tty
		end
	end
	if tty then
		local line, err = K.readline(tty, { noecho = options.noecho, history = options.history })
		if line ~= nil then
			if options.history then
				options.history[#options.history + 1] = line
			end
			return line
		end
		if err == "interrupted" then
			return nil, "EINTR", "interrupted"
		end
		return nil
	end
	if not o or not o.read then
		return nil
	end
	local line, err = o:read("l")
	if line ~= nil then
		return line
	end
	if err == nil then
		return nil
	end
	return nil, "EIO", tostring(err)
end)

local envapi = {
	get = function(name)
		if type(name) ~= "string" then
			argerr(1, "get", "string", name)
		end
		return K.current.env[name]
	end,
	set = sys_(function(name, value)
		if type(name) ~= "string" then
			argerr(1, "set", "string", name)
		end
		if value ~= nil and type(value) ~= "string" then
			argerr(2, "set", "string", value)
		end
		if name == "" or name:find("=", 1, true) then
			return nil, "EINVAL", "invalid variable name"
		end
		if value == nil then
			K.current.env[name] = nil
		else
			K.current.env[name] = value
		end
		return true
	end),
	all = function()
		return K.copy(K.current.env)
	end,
}

local timeapi = {
	monotonic = function()
		return K.monotonic()
	end,
	wall = function()
		if not chipUnix then
			return nil
		end
		return math.floor(chipUnix())
	end,
	date = function(secs)
		if secs ~= nil and math.type(secs) ~= "integer" then
			argerr(1, "date", "integer", secs)
		end
		local t = secs
		if t == nil then
			if not chipUnix then
				return nil
			end
			t = math.floor(chipUnix())
		end
		local d = K.date(t)
		return {
			year = d.year,
			month = d.month,
			day = d.day,
			hour = d.hour,
			min = d.min,
			sec = d.sec,
			wday = d.wday,
			yday = d.yday,
		}
	end,
}

local function neatoUser(u)
	if not u then
		return nil
	end
	local groups = { u.gid }
	if K.groupsForUser then
		for _, g in ipairs(K.groupsForUser(u.name, u.gid) or {}) do
			groups[#groups + 1] = g
		end
	end
	local home = nil
	if u.home and u.home ~= "" then
		home = u.home
		if home:sub(1, 1) == "/" then
			home = K.rootdir .. home:sub(2)
		end
		if home:sub(-1) ~= "/" then
			home = home .. "/"
		end
	end
	return { id = u.uid, name = u.name, admin = u.uid == 0, home = home, groups = groups }
end

local userapi = {
	current = function()
		local p = K.current
		local u = K.getpwuid and K.getpwuid(p.uid) or nil
		if u then
			return neatoUser(u)
		end
		return { id = p.uid, name = "uid" .. tostring(p.uid), admin = p.uid == 0, groups = { p.gid } }
	end,
	byName = function(name)
		if type(name) ~= "string" then
			argerr(1, "byName", "string", name)
		end
		if not K.getpwnam then
			return nil
		end
		return neatoUser(K.getpwnam(name))
	end,
	byId = function(id)
		local i = math.tointeger(id)
		if i == nil then
			argerr(1, "byId", "integer", id)
		end
		if not K.getpwuid then
			return nil
		end
		return neatoUser(K.getpwuid(i))
	end,
	list = function()
		local out = {}
		if K.posix and K.posix.getusers then
			local ok, users = pcall(K.posix.getusers)
			if ok and type(users) == "table" then
				for _, u in ipairs(users) do
					local nu = neatoUser(u)
					if nu then
						out[#out + 1] = nu
					end
				end
				return out
			end
		end
		local me = userapi.current()
		if me then
			out[1] = me
		end
		return out
	end,
}

local authapi = {
	verify = function(name, password)
		if type(name) ~= "string" then
			argerr(1, "verify", "string", name)
		end
		if type(password) ~= "string" then
			argerr(2, "verify", "string", password)
		end
		if not K.authVerify then
			return nil, "EIO", "authentication unavailable"
		end
		local u = K.authVerify(name, password, "login")
		return u ~= nil
	end,
	switchu = function(name, password)
		if type(name) ~= "string" then
			argerr(1, "switch", "string", name)
		end
		if type(password) ~= "string" then
			argerr(2, "switch", "string", password)
		end
		if not K.authVerify then
			return nil, "EIO", "authentication unavailable"
		end
		local p = K.current
		local u = K.authVerify(name, password, "login")
		if not u then
			return nil, "EAUTH", "authentication failed"
		end
		if u.uid == 0 and p.uid ~= 0 and K.loginConf().su_wheel_only ~= 0 then
			local me = K.getpwuid(p.uid)
			if not (me and K.inGroup(me, "wheel")) then
				return nil, "EACCES", "permission denied"
			end
		end
		p.uid = u.uid
		p.gid = u.gid
		p.home = u.home
		p.groups = K.groupsFor(u.name, u.gid) or {}
		return true
	end,
}

local systemapi = {
	hostname = function()
		return K.hostname
	end,
	setHostname = sys_(function(name)
		if type(name) ~= "string" then
			argerr(1, "setHostname", "string", name)
		end
		if name == "" then
			return nil, "EINVAL", "hostname must not be empty"
		end
		if #name > 64 then
			return nil, "ELIMIT", "hostname is too long"
		end
		if K.current.uid ~= 0 then
			return nil, "EACCES", "permission denied"
		end
		K.hostname = name
		pcall(V.writeFile, K.rootdir .. "etc/hostname", name .. "\n")
		return true
	end),
	machine = function()
		local g = chip.getMachine
		if not g then
			return nil
		end
		local ok, m = pcall(g)
		if not ok or type(m) ~= "string" or m == "" then
			return nil
		end
		return m:lower()
	end,
	uptime = function()
		return K.uptime()
	end,
}

local function pipeRead(st, fmt)
	local p = K.current
	fmt = fmt or "l"
	if type(fmt) == "number" then
		local n = math.floor(fmt)
		while #st.buf == 0 and st.writers > 0 do
			K.block(p, function()
				return #st.buf > 0 or st.writers == 0
			end)
		end
		if #st.buf == 0 then
			return nil
		end
		local s = st.buf:sub(1, n)
		st.buf = st.buf:sub(#s + 1)
		return s
	elseif fmt == "a" then
		while st.writers > 0 do
			K.block(p, function()
				return st.writers == 0
			end)
		end
		local s = st.buf
		st.buf = ""
		return s
	elseif fmt == "l" then
		while true do
			local nl = st.buf:find("\n", 1, true)
			if nl then
				local line = st.buf:sub(1, nl - 1)
				st.buf = st.buf:sub(nl + 1)
				return line
			end
			if st.writers == 0 then
				if st.buf == "" then
					return nil
				end
				local rest = st.buf
				st.buf = ""
				return rest
			end
			K.block(p, function()
				return st.buf:find("\n", 1, true) ~= nil or st.writers == 0
			end)
		end
	end
	return nil, "EINVAL", "invalid read format"
end

local function pipeWrite(st, data)
	if st.readers == 0 then
		return nil, "EPIPE", "broken pipe"
	end
	st.buf = st.buf .. data
	local p = K.current
	while #st.buf > PIPE_LIMIT and st.readers > 0 do
		K.block(p, function()
			return #st.buf <= PIPE_LIMIT or st.readers == 0
		end)
	end
	if st.readers == 0 then
		return nil, "EPIPE", "broken pipe"
	end
	return true
end

local function pipeEnd(p, st, isRead)
	if isRead then
		st.readers = st.readers + 1
	else
		st.writers = st.writers + 1
	end
	local closed = false
	local obj = {}
	local function live()
		if closed then
			error("attempt to use a closed handle", 3)
		end
	end
	function obj:read(fmt)
		live()
		if not isRead then
			return nil, "EBADF", "handle is not open for reading"
		end
		if fmt ~= nil and type(fmt) ~= "number" and type(fmt) ~= "string" then
			argerr(1, "read", "string or integer", fmt)
		end
		if type(fmt) == "string" and fmt ~= "l" and fmt ~= "a" then
			return nil, "EINVAL", "invalid read format"
		end
		return K.sys(pipeRead)(st, fmt)
	end
	function obj:write(...)
		live()
		if isRead then
			return nil, "EBADF", "handle is not open for writing"
		end
		local parts = {}
		for i = 1, select("#", ...) do
			local v = select(i, ...)
			if type(v) ~= "string" and type(v) ~= "number" then
				argerr(i, "write", "string or number", v)
			end
			parts[i] = tostring(v)
		end
		return K.sys(pipeWrite)(st, table.concat(parts))
	end
	function obj:seek()
		live()
		return nil, "ESPIPE", "pipe does not support seeking"
	end
	function obj:flush()
		live()
		return true
	end
	function obj:close()
		live()
		closed = true
		p.handles[obj] = nil
		K.neatoEntries[obj] = nil
		if isRead then
			st.readers = st.readers - 1
		else
			st.writers = st.writers - 1
		end
		return true
	end
	function obj:isatty()
		live()
		return false
	end
	p.handles[obj] = true
	K.neatoEntries[obj] = { pipe = true, st = st, read = isRead }
	return obj
end

local function pipeBridge(st, isRead)
	if isRead then
		st.readers = st.readers + 1
	else
		st.writers = st.writers + 1
	end
	local o = { kind = "pipe", refs = 1 }
	function o:read(fmt)
		local r, c, m = pipeRead(st, fmt == nil and "l" or fmt)
		if r ~= nil then
			return r
		end
		if c == nil then
			return nil
		end
		return nil, tostring(m or c)
	end
	function o:write(s)
		local r, c, m = pipeWrite(st, s)
		if r then
			return true
		end
		return nil, tostring(m or c)
	end
	function o:seek()
		return nil, "illegal seek"
	end
	function o:isatty()
		return false
	end
	function o:onclose()
		if isRead then
			st.readers = st.readers - 1
		else
			st.writers = st.writers - 1
		end
	end
	return o
end

local function fdBridge(target)
	K.fdref(target)
	local o = { kind = "neato-fd", refs = 1, target = target }
	function o:read(fmt)
		if not target.read then
			return nil, "not open for reading"
		end
		return target:read(fmt)
	end
	function o:write(s)
		if not target.write then
			return nil, "not open for writing"
		end
		return target:write(s)
	end
	function o:seek(w, off)
		if not target.seek then
			return nil, "illegal seek"
		end
		return target:seek(w, off)
	end
	function o:isatty()
		return target.isatty and target:isatty() or false
	end
	function o:onclose()
		K.fdclose(target)
	end
	return o
end

local function isExecFile(full)
	return V.isFile(nil, full) or V.stat(full) == "link"
end

local NEATO_DEFAULT_PATH = "/bin;/usr/bin;/sbin;/usr/sbin"
local MAXSPAWNARGS, MAXARGBYTES = 4096, 262144

local function findNeatoProgram(name, penv, launchcwd)
	if name:find("/", 1, true) or name:find(":", 1, true) then
		local full = P.resolve(name, launchcwd, 3)
		if full and isExecFile(full) then
			return full
		end
		return nil
	end
	local pathstr = (penv and penv.PATH) or NEATO_DEFAULT_PATH
	local sep = pathstr:find(";", 1, true) and ";" or ":"
	for dir in pathstr:gmatch("[^" .. sep .. "]+") do
		local base = dir:sub(-1) == "/" and dir:sub(1, -2) or dir
		local ok, full = pcall(P.resolve, base .. "/" .. name, launchcwd, 3)
		if ok and full and isExecFile(full) then
			return full
		end
	end
	return nil
end

local function checkSpawnArgs(args)
	if args == nil then
		return { n = 0 }
	end
	if type(args) ~= "table" then
		argerr(2, "spawn", "table", args)
	end
	local len = args.n or #args
	if type(len) ~= "number" or len < 0 then
		len = #args
	end
	len = math.floor(len)
	if len > MAXSPAWNARGS then
		return nil, "ELIMIT", "argument list is too long"
	end
	local out, total = {}, 0
	for i = 1, len do
		local v = args[i]
		if type(v) == "number" then
			v = tostring(v)
		elseif type(v) ~= "string" then
			argerr(2, "spawn", "table of strings", args)
		end
		total = total + #v
		if total > MAXARGBYTES then
			return nil, "ELIMIT", "argument list is too long"
		end
		out[i] = v
	end
	out.n = len
	return out
end

local function spawnStream(handle, wantRead, fname)
	local p = K.current
	if handle == nil then
		return nil
	end
	local info = K.neatoEntries[handle]
	if not info then
		return nil, "EINVAL", "not a stream handle"
	end
	if info.stdio then
		local o = info.p.fds[info.n]
		if not o then
			return nil, "EINVAL", "stream is not open"
		end
		if wantRead and not o.read then
			return nil, "EINVAL", "stream is not open for reading"
		end
		if not wantRead and not o.write then
			return nil, "EINVAL", "stream is not open for writing"
		end
		return fdBridge(o)
	end
	if info.pipe then
		if info.read ~= wantRead then
			return nil, "EINVAL", "stream is open the wrong way"
		end
		return pipeBridge(info.st, info.read)
	end
	if not info.h then
		return nil, "EINVAL", "not a stream handle"
	end
	local readable = info.mode == "r" or info.mode == nil
	local writable = info.mode == "w" or info.mode == "a" or info.mode == nil
	if wantRead and not readable then
		return nil, "EINVAL", "stream is not open for reading"
	end
	if not wantRead and not writable then
		return nil, "EINVAL", "stream is not open for writing"
	end
	return K.neatoBridge(info)
end

local procapi = {
	getpid = function()
		return K.current.pid
	end,
	getppid = function()
		local p = K.current
		local pp = K.procs[p.ppid]
		if not pp or pp.state == "Z" then
			return 0
		end
		return p.ppid
	end,
	exit = function(status)
		if status ~= nil and math.tointeger(status) == nil then
			argerr(1, "exit", "integer", status)
		end
		K.exit(K.current, status or 0)
	end,
	spawn = sys_(function(path, args, opts)
		local p = K.current
		local prog = str(path, 1, "spawn")
		if type(opts) ~= "table" and opts ~= nil then
			argerr(3, "spawn", "table", opts)
		end
		opts = opts or {}
		local aout, acode, amsg = checkSpawnArgs(args)
		if not aout then
			return nil, acode, amsg
		end
		local childEnv = nil
		if opts.env ~= nil then
			if type(opts.env) ~= "table" then
				argerr(3, "spawn", "table", opts)
			end
			childEnv = {}
			for k, v in pairs(opts.env) do
				childEnv[k] = tostring(v)
			end
		end
		local full = findNeatoProgram(prog, opts.env or p.env, p.launchcwd)
		if not full then
			return nil, "ENOENT", "command not found: " .. prog
		end
		local fds = {}
		local bridges = {}
		local function stream(n, wantRead)
			local br, code, msg =
				spawnStream(opts[n == 0 and "stdin" or (n == 1 and "stdout" or "stderr")], wantRead, "spawn")
			if code then
				for _, b in ipairs(bridges) do
					pcall(K.fdclose, b)
				end
				return nil, code, msg
			end
			if br then
				bridges[#bridges + 1] = br
				fds[n] = br
			end
			return true
		end
		local ok, code, msg = stream(0, true)
		if not ok then
			return nil, code, msg
		end
		ok, code, msg = stream(1, false)
		if not ok then
			return nil, code, msg
		end
		ok, code, msg = stream(2, false)
		if not ok then
			return nil, code, msg
		end
		local cwd = nil
		if opts.cwd ~= nil then
			if type(opts.cwd) ~= "string" then
				for _, b in ipairs(bridges) do
					pcall(K.fdclose, b)
				end
				argerr(3, "spawn", "table", opts)
			end
			local fc, ferr = P.resolve(opts.cwd, p.launchcwd, 3)
			if not fc or not V.list(p, fc) then
				for _, b in ipairs(bridges) do
					pcall(K.fdclose, b)
				end
				return nil, "EINVAL", "bad cwd: " .. tostring(ferr or opts.cwd)
			end
			cwd = fc:sub(-1) == "/" and fc or (fc .. "/")
		end
		local child, serr = K.spawn(p, full, aout, { fds = fds, env = childEnv, cwd = cwd })
		for _, b in ipairs(bridges) do
			pcall(K.fdclose, b)
		end
		if not child then
			local em = tostring(serr or "cannot start program")
			if em:find("too many processes", 1, true) then
				return nil, "ELIMIT", em
			end
			if em:find("permission denied", 1, true) then
				return nil, "EACCES", em
			end
			if em:find("exec format error", 1, true) then
				return nil, "ENOEXEC", em
			end
			if em:find("no such file", 1, true) then
				return nil, "ENOENT", em
			end
			if em:find("not a regular file", 1, true) then
				return nil, V.stat(full) == "dir" and "EISDIR" or "ENOEXEC", em
			end
			return nil, "EIO", em
		end
		return child.pid
	end),
	pipe = function()
		local st = { buf = "", readers = 0, writers = 0 }
		local p = K.current
		local r = pipeEnd(p, st, true)
		local w = pipeEnd(p, st, false)
		return r, w
	end,
	wait = function(pid)
		if pid ~= nil and math.tointeger(pid) == nil then
			argerr(1, "wait", "integer", pid)
		end
		local cpid, scode = K.wait(K.current, pid or -1, false)
		if cpid == nil then
			return nil, "ECHILD", tostring(scode or "no child processes")
		end
		return cpid, (math.tointeger(scode) or 0) % 256
	end,
	poll = function(pid)
		if pid ~= nil and math.tointeger(pid) == nil then
			argerr(1, "poll", "integer", pid)
		end
		local cpid, scode = K.wait(K.current, pid or -1, true)
		if cpid == nil then
			return nil, "ECHILD", tostring(scode or "no child processes")
		end
		if cpid == 0 then
			return nil
		end
		return cpid, (math.tointeger(scode) or 0) % 256
	end,
	kill = sys_(function(pid, how)
		local me = K.current
		pid = int(pid, 1, "kill")
		if how ~= nil and type(how) ~= "string" then
			argerr(2, "kill", "string", how)
		end
		how = how or "term"
		local sig
		if how == "term" then
			sig = K.SIG.TERM
		elseif how == "kill" then
			sig = K.SIG.KILL
		else
			return nil, "EINVAL", "invalid kill mode '" .. how .. "'"
		end
		local t = K.procs[pid]
		if not t or t.state == "Z" then
			return nil, "ESRCH", "no such process"
		end
		if t.pid == 1 and t ~= me then
			return nil, "EPERM", "operation not permitted"
		end
		if t ~= me and me.uid ~= 0 and me.uid ~= t.uid and me.children[pid] == nil then
			return nil, "EACCES", "permission denied"
		end
		if t == me then
			if sig == K.SIG.KILL then
				K.exit(me, 128 + sig)
			end
			K.signal(me, sig)
			return true
		end
		K.signal(t, sig)
		return true
	end),
}

local JOB_LIMIT = 1024
local JOB_FIRST = 1000000

K.jobs = {}
local nextjob = JOB_FIRST

local function jobInt(v)
	if type(v) ~= "number" then
		return nil
	end
	return math.tointeger(v)
end

local function jobLive(jid)
	for _, q in pairs(K.procs) do
		if q.pgid == jid then
			return true
		end
	end
	return false
end

local function jobKnown(me, jid)
	return K.jobs[jid] ~= nil or jid == me.pgid or jobLive(jid)
end

local function jobOwned(me, jid)
	local j = K.jobs[jid]
	return (j ~= nil and j.owner == me.pid) or jid == me.pgid
end

local jobapi = {
	create = sys_(function()
		local me = K.current
		local n = 0
		for _ in pairs(K.jobs) do
			n = n + 1
		end
		if n >= JOB_LIMIT then
			return nil, "ELIMIT", "too many jobs"
		end
		local jid = nextjob
		while K.jobs[jid] or jobLive(jid) do
			jid = jid + 1
		end
		nextjob = jid + 1
		K.jobs[jid] = { owner = me.pid }
		return jid
	end),
	join = sys_(function(jid, pid)
		local me = K.current
		jid = jobInt(jid)
		if jid == nil then
			return nil, "EINVAL", "invalid job id"
		end
		pid = jobInt(pid)
		if pid == nil then
			return nil, "EINVAL", "invalid process id"
		end
		if not jobKnown(me, jid) then
			return nil, "EINVAL", "no such job"
		end
		local p = K.procs[pid]
		if not p or p.state == "Z" then
			return nil, "ESRCH", "no such process"
		end
		if p.ppid ~= me.pid or not jobOwned(me, jid) then
			return nil, "EACCES", "permission denied"
		end
		p.pgid = jid
		return true
	end),
	current = function()
		return K.current.pgid
	end,
	getForeground = function()
		local me = K.current
		return me.tty and me.tty.fgpgid or nil
	end,
	setForeground = sys_(function(jid)
		local me = K.current
		jid = jobInt(jid)
		if jid == nil or not jobKnown(me, jid) then
			return nil, "EINVAL", "no such job"
		end
		if not jobOwned(me, jid) and me.uid ~= 0 then
			return nil, "EACCES", "permission denied"
		end
		if me.tty and me.tty ~= K.nulltty then
			me.tty.fgpgid = jid
			if K.tty_deliverPending then
				K.tty_deliverPending(me.tty)
			end
		end
		return true
	end),
	setBackground = sys_(function(jid)
		local me = K.current
		jid = jobInt(jid)
		if jid == nil or not jobKnown(me, jid) then
			return nil, "EINVAL", "no such job"
		end
		if not jobOwned(me, jid) and me.uid ~= 0 then
			return nil, "EACCES", "permission denied"
		end
		if me.tty and me.tty.fgpgid == jid then
			me.tty.fgpgid = nil
		end
		return true
	end),
	kill = sys_(function(jid, how)
		local me = K.current
		jid = jobInt(jid)
		if jid == nil or not jobKnown(me, jid) then
			return nil, "EINVAL", "no such job"
		end
		if how ~= nil and type(how) ~= "string" then
			argerr(2, "kill", "string", how)
		end
		how = how or "term"
		local sig
		if how == "term" then
			sig = K.SIG.TERM
		elseif how == "kill" then
			sig = K.SIG.KILL
		else
			return nil, "EINVAL", "invalid kill mode '" .. how .. "'"
		end
		if not jobOwned(me, jid) and me.uid ~= 0 then
			return nil, "EACCES", "permission denied"
		end
		for _, p in pairs(K.procs) do
			if p.pgid == jid and p.state ~= "Z" then
				K.signal(p, sig)
			end
		end
		return true
	end),
}

function K.job_release(p)
	for jid, j in pairs(K.jobs) do
		if j.owner == p.pid then
			K.jobs[jid] = nil
		end
	end
end

local sysapi = {
	getOSName = function()
		return K.NAME
	end,
	getOSVersion = function()
		return K.VERSION
	end,
	getExtensions = function()
		return K.copy(K.extensions)
	end,
	hasExtension = function(name, version)
		if type(name) ~= "string" then
			argerr(1, "hasExtension", "string", name)
		end
		if version ~= nil then
			version = wantIntegral(version, 2, "hasExtension")
		end
		local v = K.extensions[name]
		if not v then
			return false
		end
		if version ~= nil then
			return v == version
		end
		return true
	end,
	sleep = function(t)
		if type(t) ~= "number" then
			argerr(1, "sleep", "number", t)
		end
		local p = K.current
		if t < 0 then
			return nil, "EINVAL", "time must not be negative"
		end
		if t == 0 then
			coroutine.yield()
			return nil
		end
		K.block(p, nil, K.monotonic() + t)
		return nil
	end,
}

local function chipTable()
	local host = rawget(_G, "chip")
	if not host then
		return nil
	end
	return {
		version = host.version,
		getMachine = host.getMachine,
		getUUID = host.getUUID,
		getTime = host.getTime,
		getUnixTime = host.getUnixTime,
		getLunarTime = host.getLunarTime,
		sleep = function(ms)
			if type(ms) ~= "number" then
				argerr(1, "sleep", "number", ms)
			end
			if ms < 0 then
				return
			end
			if ms == 0 then
				coroutine.yield()
				return
			end
			K.block(K.current, nil, K.monotonic() + ms / 1000)
		end,
		shutdown = function()
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			K.shutdownRequested = "halt"
		end,
		reboot = function()
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			K.shutdownRequested = "reboot"
		end,
		crash = function(message)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			K.panic(tostring(message))
		end,
	}
end

local function partitionsTable()
	local host = rawget(_G, "files")
	if not host then
		return nil
	end
	return {
		getPartitions = host.getPartitions,
		getPartition = host.getPartition,
		getNumberOfDisks = host.getNumberOfDisks,
		getDisks = host.getDisks,
		getDiskID = host.getDiskID,
		getBootPath = host.getBootPath,
		getCapacity = function(disk, part)
			local d = K.rawfs and K.rawfs.diskByRef(disk)
			if not d then
				return nil, "no such disk"
			end
			if type(host.getCapacity) ~= "function" then
				return nil, "operation not supported"
			end
			return host.getCapacity(d.slot, part)
		end,
		getFreeSpace = function(disk, part)
			local d = K.rawfs and K.rawfs.diskByRef(disk)
			if not d then
				return nil, "no such disk"
			end
			if type(host.getFreeSpace) ~= "function" then
				return nil, "operation not supported"
			end
			return host.getFreeSpace(d.slot, part)
		end,
		createPartition = function(...)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			return host.createPartition(...)
		end,
		deletePartition = function(...)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			return host.deletePartition(...)
		end,
		setPartitionHidden = function(...)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			return host.setPartitionHidden(...)
		end,
		setPartitionReadOnly = function(...)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			return host.setPartitionReadOnly(...)
		end,
		removeDisk = function(...)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			return host.removeDisk(...)
		end,
		setBoot = function(...)
			if K.current.uid ~= 0 then
				error("permission denied", 2)
			end
			return host.setBoot(...)
		end,
	}
end

-- The only host globals a process receives as they are; debug, os, io,
-- dofile and collectgarbage are deliberately absent, and every library
-- makeEnv adds below is a copy or a wrapper.
local BASE = {
	"rawget",
	"rawequal",
	"rawlen",
	"rawset",
	"setmetatable",
	"getmetatable",
	"tostring",
	"tonumber",
	"pcall",
	"xpcall",
	"type",
	"load",
	"pairs",
	"ipairs",
	"next",
	"select",
	"error",
	"assert",
}

local function copyTable(t)
	local o = {}
	for k, v in pairs(t) do
		o[k] = v
	end
	return o
end

K.neato = {
	fs = fs,
	proc = procapi,
	job = jobapi,
	stdio = stdio,
	time = timeapi,
	sys = sysapi,
	user = userapi,
	auth = authapi,
	term = term,
	event = event,
}

function K.makeEnv(p)
	local env = {}
	for _, n in ipairs(BASE) do
		env[n] = _G[n]
	end

	local rawload = _G.load
	-- Text only: Lua does not verify bytecode, and a corrupt binary chunk
	-- can crash the VM, which here takes every process down at once.
	env.load = function(chunk, name, mode, e)
		if e == nil then
			e = env
		end
		return rawload(chunk, name, "t", e)
	end
	-- A process's _G is its own environment, never the host's.
	env._G, env._VERSION = env, _VERSION
	for _, n in ipairs({ "string", "table", "math", "utf8" }) do
		env[n] = copyTable(_G[n])
	end
	-- string is a copy and getmetatable hands strings that copy, so
	-- getmetatable cannot lead a process to the host's string table.
	env.string.dump = nil

	local strmt = { __index = env.string }
	env.getmetatable = function(o)
		if type(o) == "string" then
			return strmt
		end
		return getmetatable(o)
	end
	env.bit32 = copyTable(K.bit32)
	env.coroutine = copyTable(K.usercoroutine)

	env.CWD = p.launchcwd
	env.print = nprint and K.nprint
	env.term = copyTable(term)
	env.event = copyTable(event)
	env.fs = copyTable(fs)
	env.sys = copyTable(sysapi)
	env.stdio = {
		stdin = stdioHandle(p, 0, "r"),
		stdout = stdioHandle(p, 1, "w"),
		stderr = stdioHandle(p, 2, "w"),
		isatty = stdio.isatty,
		readLine = stdio.readLine,
	}
	env.env = copyTable(envapi)
	env.time = copyTable(timeapi)
	env.proc = copyTable(procapi)
	env.job = copyTable(jobapi)
	env.user = copyTable(userapi)
	env.auth = copyTable(authapi)
	env.system = copyTable(systemapi)
	env.dpp = copyTable(dpp)
	env.spp = copyTable(spp)
	env.http = copyTable(http)
	-- chipTable re-exports only host getters; shutdown, reboot and crash
	-- are gated on uid 0.
	env.chip = chipTable()
	env.partitions = partitionsTable()
	if rawget(_G, "crypto") then
		env.crypto = copyTable(rawget(_G, "crypto"))
	end

	-- A new cache for every environment built here, so a module one
	-- process requires is never the table another was handed (a forked
	-- child keeps sharing its parent's).
	local loaded = {}
	local pkg = {}
	pkg.config = "/\n;\n?\n"
	pkg.loaded = copyTable(loaded)
	pkg.path = K.rootdir .. "usr/lib/xes/?.lua;" .. K.rootdir .. "usr/lib/xes/?/init.lua"
	pkg.preload = {}
	pkg.searchers = {}

	function pkg.searchpath(name, path, sep, rep)
		if type(name) ~= "string" then
			argerr(1, "searchpath", "string", name)
		end
		if type(path) ~= "string" then
			argerr(2, "searchpath", "string", path)
		end
		if sep == nil then
			sep = "."
		elseif type(sep) ~= "string" then
			argerr(3, "searchpath", "string", sep)
		end
		if rep == nil then
			rep = "/"
		elseif type(rep) ~= "string" then
			argerr(4, "searchpath", "string", rep)
		end
		local cwd = (K.current or p).cwd or (K.current or p).launchcwd
		local sub = name
		if sep ~= "" then
			local pat = sep:gsub("%W", "%%%0")
			sub = name:gsub(pat, function()
				return rep
			end)
		end
		local tried = {}
		for tpl in path:gmatch("[^;]+") do
			local cand = tpl:gsub("%?", function()
				return sub
			end)
			local pok, full = pcall(P.resolve, cand, cwd, 3)
			if pok and full then
				local ok, h = pcall(V.open, K.current or p, full, "r")
				if ok and h then
					pcall(h.close, h)
					return cand
				end
			end
			tried[#tried + 1] = "\n\tno file '" .. cand .. "'"
		end
		return nil, table.concat(tried)
	end

	local function loadlua(modname, loaderdata)
		local cp = K.current or p
		local full, rerr = P.resolve(loaderdata, cp.cwd or cp.launchcwd, 3)
		if not full then
			error(tostring(rerr or "bad module path"), 0)
		end
		local h, oerr = V.open(cp, full, "r")
		if not h then
			error("cannot open '" .. loaderdata .. "': " .. tostring(oerr), 0)
		end
		local src, serr, smsg = h:read("a")
		local cok, cerr, cmsg = h:close()
		if src == nil then
			error(smsg or serr or cerr or "read error", 0)
		end
		if cok == nil then
			error(cmsg or cerr, 0)
		end
		local lenv = setmetatable({}, { __index = env })
		lenv._G = lenv
		local chunk, lerr = rawload(src, "@" .. loaderdata, "t", lenv)
		if not chunk then
			error(lerr, 0)
		end
		return chunk(modname, loaderdata)
	end

	pkg.searchers[1] = function(name)
		local v = pkg.preload[name]
		if v ~= nil then
			return v, ":preload:"
		end
		return "\n\tno field package.preload['" .. name .. "']"
	end

	pkg.searchers[2] = function(name)
		local ok, found, err = pcall(pkg.searchpath, name, pkg.path)
		if not ok then
			return tostring(found)
		end
		if not found then
			return err
		end
		return loadlua, found
	end

	env.require = function(modname)
		if type(modname) ~= "string" then
			argerr(1, "require", "string", modname)
		end
		local v = loaded[modname]
		if v then
			return v
		end
		local msgs = {}
		for i = 1, #pkg.searchers do
			local ok, loader, data = pcall(pkg.searchers[i], modname)
			if not ok then
				msgs[#msgs + 1] = tostring(loader)
			elseif type(loader) == "function" then
				local lok, res = pcall(loader, modname, data)
				if not lok then
					error(
						"error loading module '"
							.. modname
							.. "' from "
							.. tostring(data)
							.. ":\n\t"
							.. tostring(res)
							.. table.concat(msgs),
						2
					)
				end
				if res ~= nil then
					loaded[modname] = res
				elseif loaded[modname] == nil then
					loaded[modname] = true
				end
				pkg.loaded[modname] = loaded[modname]
				return loaded[modname], data
			elseif type(loader) == "string" then
				msgs[#msgs + 1] = loader
			end
		end
		error("module '" .. modname .. "' not found:" .. table.concat(msgs), 2)
	end
	env.package = pkg

	env.loadfile = function(filename, mode, e)
		if type(filename) ~= "string" then
			argerr(1, "loadfile", "string", filename)
		end
		local cp = K.current or p
		local full, rerr = P.resolve(filename, cp.cwd or cp.launchcwd, 3)
		if not full then
			return nil, rerr
		end
		local h, oerr = V.open(cp, full, "r")
		if not h then
			return nil, oerr
		end
		local src, serr, smsg = h:read("a")
		local cok, cerr, cmsg = h:close()
		if src == nil then
			return nil, smsg or serr or cerr
		end
		if cok == nil then
			return nil, cmsg or cerr
		end
		if mode == "b" then
			return nil, "@" .. filename .. ": attempt to load a text chunk (mode is 'b')"
		end
		return rawload(src, "@" .. filename, "t", e or env)
	end

	env.requestNeato = function()
		return nil
	end

	env.posix = K.posixtable(p)
	if K.extbind then
		local x = K.extbind(p)
		for area, tbl in pairs(x) do
			if env[area] == nil then
				env[area] = tbl
			elseif type(env[area]) == "table" and type(tbl) == "table" then
				for name, fn in pairs(tbl) do
					env[area][name] = fn
				end
			else
				env[area] = tbl
			end
		end
	end
	if K.testsink then
		env._testlog = K.testsink
		if p.uid == 0 then
			env._kernel = K
			env._hostchip = rawget(_G, "chip")
		end
	end
	if K.dbgapi then
		env.dbg = K.dbgapi()
	end
	return env
end
