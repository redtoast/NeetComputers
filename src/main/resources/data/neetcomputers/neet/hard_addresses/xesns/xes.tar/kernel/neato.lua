local K = ...

local V, P = K.vfs, K.path
local R = K.rawfs

local function sysret(p, ok, ...)
    p.critical = p.critical - 1
    if not ok then error((...), 0) end
    return ...
end
function K.sys(f)
    return function(...)
        local p = K.current
        p.critical = p.critical + 1
        return sysret(p, pcall(f, ...))
    end
end

local sys_ = K.sys

local function argerr(n, fname, want, v)
    error(string.format("bad argument #%d to '%s' (%s expected, got %s)", n, fname, want, type(v)), 3)
end
local function str(v, n, fname)
    if type(v) == "string" then return v end
    if type(v) == "number" then return tostring(v) end
    argerr(n, fname, "string", v)
end
local function int(v, n, fname)
    local i = type(v) == "number" and math.tointeger(v)
    if not i then argerr(n, fname, "integer", v) end
    return i
end
K.argcheck = { str = str, int = int, err = argerr }

local function codeOf(msg)
    local m = type(msg) == "string" and msg:lower() or ""
    if m:find("partition root", 1, true) then return "EPERM" end
    if m:find("no such disk", 1, true) or m:find("no such device", 1, true)
        or m:find("no disk has", 1, true) or m:find("no current directory", 1, true) then return "ENODEV" end
    if m:find("no such file", 1, true) or m:find("no such directory", 1, true)
        or m:find("does not exist", 1, true) or m:find("not found", 1, true) then return "ENOENT" end
    if m:find("not a directory", 1, true) then return "ENOTDIR" end
    if m:find("is a directory", 1, true) then return "EISDIR" end
    if m:find("not empty", 1, true) then return "ENOTEMPTY" end
    if m:find("read-only", 1, true) or m:find("read only", 1, true)
        or m:find("operation not permitted", 1, true) then return "EROFS" end
    if m:find("permission denied", 1, true) or m:find("access denied", 1, true) then return "EACCES" end
    if m:find("no space", 1, true) then return "ENOSPC" end
    if m:find("too long", 1, true) then return "ENAMETOOLONG" end
    if m:find("too large", 1, true) or m:find("too big", 1, true) then return "EFBIG" end
    if m:find("already exists", 1, true) or m:find("file exists", 1, true) then return "EEXIST" end
    if m:find("in use", 1, true) or m:find("busy", 1, true) then return "EBUSY" end
    if m:find("not open for", 1, true) then return "EBADF" end
    if m:find("offset", 1, true) or m:find("out of range", 1, true) then return "ERANGE" end
    if m:find("invalid", 1, true) or m:find("illegal", 1, true) then return "EINVAL" end
    return "EIO"
end

local function failfrom(msg)
    local text = type(msg) == "string" and msg or tostring(msg)
    return nil, codeOf(text), text
end
K.codeOf = codeOf

local function tty() return K.current.tty end
local function color(r, g, b, fname)
    local c = { r, g, b }
    for i = 1, 3 do
        local v = math.tointeger(c[i])
        if type(c[i]) ~= "number" or not v or v < 0 or v > 255 then
            error(string.format("bad argument #%d to '%s' (integer 0-255 expected)", i, fname), 3)
        end
        c[i] = v
    end
    return K.rgb(c[1], c[2], c[3])
end

local term = {
    clear = sys_(function()
        local p = K.current; p.tty:clear(p.bg)
    end),
    write = sys_(function(text)
        local p = K.current; p.tty:write(str(text, 1, "write"), p.fg, p.bg)
    end),
    getSize = function()
        local t = tty()
        return t.cols, t.rows
    end,
    clearLine = sys_(function()
        local p = K.current; p.tty:clearLine(p.bg)
    end),
    setCursorPos = sys_(function(x, y)
        local t = tty()
        t.cx, t.cy = int(x, 1, "setCursorPos"), int(y, 2, "setCursorPos")
    end),
    getCursorPos = function()
        local t = tty()
        return t.cx, t.cy
    end,
    setBackgroundColor = function(r, g, b) K.current.bg = color(r, g, b, "setBackgroundColor") end,
    setTextColor = function(r, g, b) K.current.fg = color(r, g, b, "setTextColor") end,
    getBackgroundColor = function() return K.unrgb(K.current.bg) end,
    getTextColor = function() return K.unrgb(K.current.fg) end,
    scroll = sys_(function(n)
        local p = K.current; p.tty:scroll(int(n, 1, "scroll"), p.bg)
    end),

    setAnsi = sys_(function(on) K.current.tty.ansi = on and true or false end),

    scrollback = sys_(function(n)
        if n ~= nil then n = int(n, 1, "scrollback") end
        return tty():getScrollback(n)
    end),

    scrollView = sys_(function(n)
        local t = tty()
        t:scrollView(int(n, 1, "scrollView"))
        return t.view
    end),
    getScrollView = function() return tty().view end,
}

local function nprint(...)
    local p = K.current
    local n = select("#", ...)
    local t = {}
    for i = 1, n do t[i] = tostring((select(i, ...))) end
    local fd = p.fds[1]
    if not fd then return end
    local ok, err = fd:write(table.concat(t, "\t") .. "\n")
    if not ok and err == "broken pipe" then K.exit(p, 141) end
end
K.nprint = sys_(nprint)

local event = {
    pull = function(filter, timeout)
        if filter ~= nil and type(filter) ~= "string" then argerr(1, "pull", "string", filter) end
        if timeout ~= nil and type(timeout) ~= "number" then argerr(2, "pull", "number", timeout) end
        return K.evpull(K.current, filter, timeout)
    end,
    poll = function() return K.evpoll(K.current) end,
    push = sys_(function(name, ...)
        if type(name) ~= "string" then argerr(1, "push", "string", name) end
        if not K.pushEvent(K.current, name, ...) then
            return nil, "ENOBUFS", "event queue is full"
        end
        return true
    end),
    clear = sys_(function() K.evclear(K.current) end),
}

local function rpath(path, fname)
    if type(path) ~= "string" then argerr(1, fname, "string", path) end
    return P.resolve(path, K.current.launchcwd, 3)
end

function K.wrapHandle(p, h)
    local closed = false
    local obj = {}
    local function live() if closed then error("attempt to use a closed handle", 3) end end
    function obj:read(fmt)
        live()
        if fmt ~= nil and type(fmt) ~= "number" and type(fmt) ~= "string" then
            argerr(1, "read", "string or integer", fmt)
        end
        if type(fmt) == "string" and fmt ~= "l" and fmt ~= "a" then
            return nil, "EINVAL", "invalid read format"
        end
        local r, e = K.sys(h.read)(h, fmt)
        if r == nil and e ~= nil then return failfrom(e) end
        return r
    end

    function obj:write(...)
        live()
        local n, parts = select("#", ...), {}
        for i = 1, n do
            local v = select(i, ...)
            if type(v) ~= "string" and type(v) ~= "number" then argerr(i, "write", "string or number", v) end
            parts[i] = tostring(v)
        end
        local r, e = K.sys(h.write)(h, table.concat(parts))
        if not r then return failfrom(e) end
        return self
    end

    function obj:seek(whence, off)
        live()
        if whence ~= nil and type(whence) ~= "string" then argerr(1, "seek", "string", whence) end
        if whence ~= nil and whence ~= "set" and whence ~= "cur" and whence ~= "end" then
            return nil, "EINVAL", "invalid whence"
        end
        if off ~= nil and math.tointeger(off) == nil then argerr(2, "seek", "integer", off) end
        local r, e = K.sys(h.seek)(h, whence, off)
        if r == nil and e ~= nil then return failfrom(e) end
        return r
    end

    function obj:flush()
        live()
        local r, e = K.sys(h.flush)(h)
        if not r then return failfrom(e) end
        return true
    end

    function obj:close()
        live()
        closed = true
        p.handles[h] = nil
        local r, e = K.sys(h.close)(h)
        if r == nil and e ~= nil then return failfrom(e) end
        return true
    end

    p.handles[h] = true
    return obj
end

local POINT_DIRS = {
    ["system.root"] = "",
    ["system.bin"] = "bin/",
    ["system.sbin"] = "sbin/",
    ["system.libraries"] = "lib/",
    ["system.include"] = "usr/include/",
    ["system.source"] = "usr/src/",
    ["system.config"] = "etc/",
    ["system.boot"] = "boot/",
    ["system.device"] = "dev/",
    ["software.opt"] = "opt/",
    ["software.opt.config"] = "etc/opt/",
    ["software.opt.data"] = "var/opt/",
    ["software.local"] = "usr/local/",
    ["software.localData"] = "usr/local/share/",
    ["software.data"] = "usr/share/",
    ["storage.persistent"] = "var/",
    ["storage.runtime"] = "var/run/",
    ["storage.state"] = "var/db/",
    ["storage.cache"] = "var/cache/",
    ["storage.log"] = "var/log/",
    ["storage.spool"] = "var/spool/",
    ["storage.lock"] = "var/lock/",
    ["storage.mail"] = "var/mail/",
    ["storage.crash"] = "var/crash/",
    ["storage.games"] = "var/games/",
    ["storage.temporary"] = "tmp/",
    ["storage.temporaryPersistent"] = "var/tmp/",
    ["user.home"] = "home/",
    ["user.admin"] = "root/",
    ["mount.temporary"] = "mnt/",
    ["service.data"] = "srv/",
}

local function pointsTable()
    local out = {}
    for name, dir in pairs(POINT_DIRS) do out[name] = K.rootdir .. dir end
    return out
end

local fs = {
    exists = sys_(function(path)
        local full = rpath(path, "exists")
        if not full then return false end
        return V.exists(K.current, full)
    end),
    isFile = sys_(function(path)
        local full = rpath(path, "isFile")
        if not full then return false end
        return V.exists(K.current, full) and V.isFile(K.current, full)
    end),
    isDir = sys_(function(path)
        local full = rpath(path, "isDir")
        if not full then return false end
        return V.exists(K.current, full) and V.isDir(K.current, full)
    end),
    list = sys_(function(path)
        local full, err = rpath(path, "list")
        if not full then return failfrom(err) end
        local names, lerr = V.list(K.current, full)
        if not names then return failfrom(lerr) end
        return names
    end),
    makeDir = sys_(function(path)
        local full, err = rpath(path, "makeDir")
        if not full then return failfrom(err) end
        local ok, merr = V.mkdir(K.current, full)
        if not ok then return failfrom(merr) end
        return true
    end),
    delete = sys_(function(path)
        local full, err = rpath(path, "delete")
        if not full then return failfrom(err) end
        local ok, derr = V.remove(K.current, full)
        if not ok then return failfrom(derr) end
        return true
    end),
    open = sys_(function(path, mode)
        if type(mode) ~= "string" then argerr(2, "open", "string", mode) end
        local m = mode:gsub("b$", "")
        if m ~= "r" and m ~= "w" and m ~= "a" then
            return nil, "EINVAL", "invalid open mode '" .. mode .. "'"
        end
        local full, err = rpath(path, "open")
        if not full then return failfrom(err) end
        local h, herr = V.open(K.current, full, m)
        if not h then return failfrom(herr) end
        return K.wrapHandle(K.current, h)
    end),
    resolve = sys_(function(path)
        local full, err = rpath(path, "resolve")
        if not full then return failfrom(err) end
        return full
    end),
    getDisks = function()
        local out = {}
        for _, d in ipairs(R.disks()) do out[#out + 1] = { slot = d.slot, id = d.id } end
        return out
    end,
    getPartitions = sys_(function(disk)
        local ref
        if type(disk) == "number" then
            local i = math.tointeger(disk)
            if not i or i < 0 then return nil, "EINVAL", "invalid disk slot" end
            ref = i
        elseif type(disk) == "string" then
            if disk:match("^%d+$") then
                ref = tonumber(disk)
            elseif disk:match("^[%a%d_%-]+$") and disk:match("[%a_%-]") then
                ref = disk
            else
                return nil, "EINVAL", "invalid disk id"
            end
        else
            argerr(1, "getPartitions", "int or string", disk)
        end
        local d = R.diskByRef(ref)
        if not d then return nil, "ENODEV", "no such disk" end
        local names, err = R.partitions(d.slot)
        if not names then return nil, "EIO", tostring(err) end
        return names
    end),
    getPoint = function(point)
        if type(point) ~= "string" then argerr(1, "getPoint", "string", point) end
        return K.points[point]
    end,
    getPoints = function()
        local out = {}
        for k, v in pairs(K.points) do out[k] = v end
        return out
    end,
}

local function wantIntegral(v, n, fname)
    local i = type(v) == "number" and math.tointeger(v)
    if i == nil then argerr(n, fname, "integer", v) end
    return i
end

local function payloadSize(v, depth, seen)
    local t = type(v)
    if t == "boolean" then return 1 end
    if t == "number" then
        if v ~= v then return nil end
        if math.type(v) == "integer" then return 1 + #tostring(v) + 1 end
        return 1 + #string.format("%.17g", v) + 1
    end
    if t == "string" then return 1 + #tostring(#v) + 1 + #v end
    if t ~= "table" then return nil end
    if depth > 32 or seen[v] then return nil end
    seen[v] = true
    local total, count = 0, 0
    for k, x in pairs(v) do
        local ks = payloadSize(k, depth + 1, seen)
        if not ks then seen[v] = nil; return nil end
        local vs = payloadSize(x, depth + 1, seen)
        if not vs then seen[v] = nil; return nil end
        total = total + ks + vs
        count = count + 1
    end
    seen[v] = nil
    return 1 + #tostring(count) + 1 + total
end

local function validPayload(v) return payloadSize(v, 1, {}) ~= nil end

local function clone(v)
    if type(v) ~= "table" then return v end
    local o = {}
    for k, x in pairs(v) do o[clone(k)] = clone(x) end
    return o
end

local function validPort(n) return math.type(n) == "integer" and n >= 1 and n <= 65535 end

local DPP_MAXPAYLOAD = 65536

local ports = {}

local function deliver(msg)
    if type(msg) ~= "table" or msg.protocol ~= "dpp" then return end
    local tp, sp = msg.target_port, msg.source_port
    if not validPort(tp) or not (validPort(sp) or sp == -1) then return end
    if not validPayload(msg.payload) then return end
    local owner = ports[tp]
    if owner and owner.state ~= "Z" then K.pushEvent(owner, "dpp", clone(msg.payload), sp, tp) end
end

function K.on_network(ev)
    if type(ev) ~= "table" then return end
    for i = 1, #ev do
        local m = ev[i]
        if type(m) == "table" and m.protocol == "dpp" then
            deliver(m)
            return
        end
    end
end

function K.dpp_release(p)
    for port, owner in pairs(ports) do if owner == p then ports[port] = nil end end
end

local dpp = {
    listen = sys_(function(port)
        if type(port) ~= "number" then argerr(1, "listen", "integer", port) end
        if not validPort(port) then return nil, "EINVAL", "port must be from 1 to 65535" end
        if port < 1024 and K.current.uid ~= 0 then return nil, "EACCES", "port is privileged" end
        local owner = ports[port]
        if owner and owner.state ~= "Z" then
            return nil, "EADDRINUSE", "port already in use"
        end
        ports[port] = K.current
        return true
    end),
    unlisten = sys_(function(port)
        if type(port) ~= "number" then argerr(1, "unlisten", "integer", port) end
        if not validPort(port) then return nil, "EINVAL", "port must be from 1 to 65535" end
        if ports[port] == K.current then ports[port] = nil end
        return true
    end),
    send = sys_(function(target, payload, source)
        if type(target) ~= "number" then argerr(1, "send", "integer", target) end
        if source ~= nil and type(source) ~= "number" then argerr(3, "send", "integer", source) end
        source = source == nil and -1 or source
        if not validPort(target) then return nil, "EINVAL", "invalid target port" end
        if not (validPort(source) or source == -1) then return nil, "EINVAL", "invalid source port" end
        local size = payloadSize(payload, 1, {})
        if not size then return nil, "EINVAL", "payload cannot be sent" end
        if size > DPP_MAXPAYLOAD then return nil, "EMSGSIZE", "payload is too large" end
        local msg = { protocol = "dpp", target_port = target, source_port = source, payload = clone(payload) }

        local bl = rawget(_G, "io") and io.broadcastLocal
        if bl then pcall(bl, msg) end
        deliver(msg)
        return true
    end),
}

local SPP_MAXPAYLOAD = 65536
local SPP_INBOX = 16
local SPP_BACKLOG = 16
local SPP_MAXCONN = 256

local sppListeners = {}
local connPorts = {}
local nextConnPort = 49152
local PEER = setmetatable({}, { __mode = "k" })

local Listener = {}
local Connection = {}
Listener.__index, Connection.__index = Listener, Connection

local function addHandle(h)
    local p = h.owner
    p.sppHandles = p.sppHandles or {}
    p.sppHandles[h] = true
end

local function removeHandle(h)
    local p = h.owner
    if p and p.sppHandles then p.sppHandles[h] = nil end
end

local function countHandles(p)
    local n = 0
    for _ in pairs(p.sppHandles or {}) do n = n + 1 end
    return n
end

local function userName(proc)
    if not proc or proc.uid == nil or not K.getpwuid then return nil end
    local ok, u = pcall(K.getpwuid, proc.uid)
    if ok and type(u) == "table" and type(u.name) == "string" then return u.name end
    return nil
end

local function allocPort()
    for _ = 1, 16384 do
        local p = nextConnPort
        nextConnPort = nextConnPort + 1
        if nextConnPort > 65535 then nextConnPort = 49152 end
        if not sppListeners[p] and not connPorts[p] then return p end
    end
    return nil
end

local function newLocalPair(clientProc, serverProc, clientPort, serverPort)
    local client = setmetatable({
        kind = "connection", owner = clientProc, port = clientPort, peerPort = serverPort,
        inbox = {}, inboxMax = SPP_INBOX, maxPayload = SPP_MAXPAYLOAD,
        closed = false, reset = false, peerClosed = false,
        peer = { origin = "local", user = userName(serverProc), id = serverProc.pid },
    }, Connection)
    local server = setmetatable({
        kind = "connection", owner = serverProc, port = serverPort, peerPort = clientPort,
        inbox = {}, inboxMax = SPP_INBOX, maxPayload = SPP_MAXPAYLOAD,
        closed = false, reset = false, peerClosed = false,
        peer = { origin = "local", user = userName(clientProc), id = clientProc.pid },
    }, Connection)
    PEER[client], PEER[server] = server, client
    return client, server
end

local function connReadable(c)
    return c.closed or #c.inbox > 0 or c.peerClosed or c.reset
end

local function connWritable(c)
    if c.closed or c.reset or c.peerClosed then return true end
    local pc = PEER[c]
    if not pc then return true end
    if pc.closed or pc.reset then return true end
    return #pc.inbox < pc.inboxMax
end

local function listenerReadable(l)
    return l.closed or #l.pending > 0
end

function Connection:send(payload, timeout)
    if self.closed then error("attempt to use a closed handle", 3) end
    if timeout ~= nil and type(timeout) ~= "number" then argerr(2, "send", "number", timeout) end
    if self.reset then return nil, "ECONNRESET", "connection reset" end
    if self.peerClosed then return nil, "EPIPE", "connection closed" end
    local size = payloadSize(payload, 1, {})
    if not size then return nil, "EINVAL", "payload cannot be sent" end
    if size > self.maxPayload then return nil, "EMSGSIZE", "payload is too large" end
    local pc = PEER[self]
    if not pc then return nil, "EPIPE", "connection closed" end
    local deadline = timeout and (K.now() + timeout) or nil
    while true do
        if pc.reset then return nil, "ECONNRESET", "connection reset" end
        if pc.closed then return nil, "EPIPE", "connection closed" end
        if #pc.inbox < pc.inboxMax then break end
        if deadline and K.now() >= deadline then return nil, "ETIMEDOUT", "timed out" end
        K.block(K.current, function()
            return pc.reset or pc.closed or #pc.inbox < pc.inboxMax
        end, deadline)
    end
    pc.inbox[#pc.inbox + 1] = clone(payload)
    return true
end

function Connection:recv(timeout)
    if self.closed then error("attempt to use a closed handle", 3) end
    if timeout ~= nil and type(timeout) ~= "number" then argerr(1, "recv", "number", timeout) end
    if self.reset then return nil, "ECONNRESET", "connection reset" end
    if #self.inbox > 0 then return table.remove(self.inbox, 1) end
    if self.peerClosed then return nil, "EPIPE", "connection closed" end
    local deadline = timeout and (K.now() + timeout) or nil
    while true do
        if deadline and K.now() >= deadline then return nil, "ETIMEDOUT", "timed out" end
        K.block(K.current, function()
            return #self.inbox > 0 or self.peerClosed or self.reset
        end, deadline)
        if self.reset then return nil, "ECONNRESET", "connection reset" end
        if #self.inbox > 0 then return table.remove(self.inbox, 1) end
        if self.peerClosed then return nil, "EPIPE", "connection closed" end
    end
end

function Connection:close()
    if self.closed then error("attempt to use a closed handle", 3) end
    self.closed = true
    self.inbox = {}
    removeHandle(self)
    if self.port and connPorts[self.port] == self then connPorts[self.port] = nil end
    local pc = PEER[self]
    if pc and not pc.reset then pc.peerClosed = true end
    return true
end

function Listener:accept(timeout)
    if self.closed then error("attempt to use a closed handle", 3) end
    if timeout ~= nil and type(timeout) ~= "number" then argerr(1, "accept", "number", timeout) end
    local function take()
        local c = table.remove(self.pending, 1)
        if countHandles(self.owner) >= SPP_MAXCONN then
            c.reset = true
            local pc = PEER[c]
            if pc and not pc.reset then pc.reset = true end
            return nil, "ELIMIT", "too many connections"
        end
        addHandle(c)
        return c
    end
    if #self.pending > 0 then return take() end
    local deadline = timeout and (K.now() + timeout) or nil
    while true do
        if deadline and K.now() >= deadline then return nil, "ETIMEDOUT", "timed out" end
        K.block(K.current, function() return #self.pending > 0 or self.closed end, deadline)
        if self.closed then return nil, "EIO", "listener closed" end
        if #self.pending > 0 then return take() end
    end
end

function Listener:close()
    if self.closed then error("attempt to use a closed handle", 3) end
    self.closed = true
    if sppListeners[self.port] == self then sppListeners[self.port] = nil end
    for _, c in ipairs(self.pending) do
        c.reset = true
        local pc = PEER[c]
        if pc and not pc.reset then pc.reset = true end
        removeHandle(c)
    end
    self.pending = {}
    removeHandle(self)
    return true
end

local function pollReady(p, read, write)
    local r, w = {}, {}
    if read then
        for i = 1, #read do
            local h = read[i]
            if h == "event" then
                if p.eh <= p.et then r[#r + 1] = h end
            elseif type(h) == "table" and h.kind == "listener" then
                if listenerReadable(h) then r[#r + 1] = h end
            elseif type(h) == "table" and h.kind == "connection" then
                if connReadable(h) then r[#r + 1] = h end
            end
        end
    end
    if write then
        for i = 1, #write do
            local h = write[i]
            if type(h) == "table" and h.kind == "connection" and connWritable(h) then
                w[#w + 1] = h
            end
        end
    end
    return r, w
end

local function spp_listen(port, opts)
    if type(port) ~= "number" then argerr(1, "listen", "integer", port) end
    if not validPort(port) then return nil, "EINVAL", "port must be from 1 to 65535" end
    if port < 1024 and K.current.uid ~= 0 then return nil, "EACCES", "port is privileged" end
    opts = opts or {}
    if type(opts) ~= "table" then argerr(2, "listen", "table", opts) end
    local scope = opts.scope == nil and "local" or opts.scope
    if scope ~= "local" and scope ~= "network" then return nil, "EINVAL", "invalid scope" end
    if scope == "network" then return nil, "ENOTSUP", "network scope is not supported" end
    local backlog = SPP_BACKLOG
    if opts.backlog ~= nil then
        if type(opts.backlog) ~= "number" then argerr(2, "listen", "table", opts) end
        local b = math.tointeger(opts.backlog)
        if not b or b < 1 then return nil, "EINVAL", "invalid backlog" end
        backlog = math.min(b, SPP_BACKLOG)
    end
    local p = K.current
    if sppListeners[port] or connPorts[port] then return nil, "EADDRINUSE", "port already in use" end
    if countHandles(p) >= SPP_MAXCONN then return nil, "ELIMIT", "too many connections" end
    local l = setmetatable({
        kind = "listener", owner = p, port = port, scope = scope,
        backlog = backlog, pending = {}, closed = false,
    }, Listener)
    sppListeners[port] = l
    addHandle(l)
    return l
end

local function spp_connect(port, opts)
    if type(port) ~= "number" then argerr(1, "connect", "integer", port) end
    if not validPort(port) then return nil, "EINVAL", "port must be from 1 to 65535" end
    opts = opts or {}
    if type(opts) ~= "table" then argerr(2, "connect", "table", opts) end
    local scope = opts.scope == nil and "local" or opts.scope
    if scope ~= "local" and scope ~= "network" then return nil, "EINVAL", "invalid scope" end
    if opts.timeout ~= nil and type(opts.timeout) ~= "number" then argerr(2, "connect", "table", opts) end
    if opts.host ~= nil then
        if type(opts.host) ~= "string" then argerr(2, "connect", "table", opts) end
        if scope ~= "network" then return nil, "EINVAL", "host requires network scope" end
        return nil, "ENOTSUP", "network scope is not supported"
    end
    if scope == "network" then return nil, "ENOTSUP", "network scope is not supported" end
    local p = K.current
    if countHandles(p) >= SPP_MAXCONN then return nil, "ELIMIT", "too many connections" end
    local l = sppListeners[port]
    if not l or l.closed then return nil, "ECONNREFUSED", "connection refused" end
    if #l.pending >= l.backlog then return nil, "ECONNREFUSED", "connection refused" end
    local cport = allocPort()
    if not cport then return nil, "ELIMIT", "no free local port" end
    local client, server = newLocalPair(p, l.owner, cport, port)
    connPorts[cport] = client
    l.pending[#l.pending + 1] = server
    addHandle(client)
    return client
end

local function spp_poll(read, timeout, write)
    if read ~= nil and type(read) ~= "table" then argerr(1, "poll", "table", read) end
    if timeout ~= nil and type(timeout) ~= "number" then argerr(2, "poll", "number", timeout) end
    if write ~= nil and type(write) ~= "table" then argerr(3, "poll", "table", write) end
    local p = K.current
    local r, w = pollReady(p, read, write)
    if #r > 0 or #w > 0 then return r, w end
    local deadline = timeout and (K.now() + timeout) or nil
    while true do
        if deadline and K.now() >= deadline then return nil end
        K.block(p, function()
            local rr, ww = pollReady(p, read, write)
            return #rr > 0 or #ww > 0
        end, deadline)
        r, w = pollReady(p, read, write)
        if #r > 0 or #w > 0 then return r, w end
    end
end

local function spp_getLimits()
    return { maxPayload = SPP_MAXPAYLOAD, inbox = SPP_INBOX, backlog = SPP_BACKLOG, maxConnections = SPP_MAXCONN }
end

local spp = {
    listen = spp_listen,
    connect = spp_connect,
    poll = spp_poll,
    getLimits = spp_getLimits,
}

function K.spp_release(p)
    if not p.sppHandles then return end
    local handles = {}
    for h in pairs(p.sppHandles) do handles[#handles + 1] = h end
    for _, h in ipairs(handles) do
        if h.kind == "listener" then
            if not h.closed then
                h.closed = true
                if sppListeners[h.port] == h then sppListeners[h.port] = nil end
                for _, c in ipairs(h.pending) do
                    c.reset = true
                    local pc = PEER[c]
                    if pc and not pc.reset then pc.reset = true end
                end
                h.pending = {}
            end
        elseif not h.closed then
            h.closed = true
            if h.port and connPorts[h.port] == h then connPorts[h.port] = nil end
            local pc = PEER[h]
            if pc then
                if p.killed then
                    if not pc.reset then pc.reset = true end
                elseif not pc.reset then
                    pc.peerClosed = true
                end
            end
        end
    end
    p.sppHandles = {}
end

K.points = pointsTable()

K.extensions = { core = 2, ["x.xesns.posix"] = 1, ["ext.dpp"] = 2, ["ext.spp"] = 2, ["x.xesns.gfx"] = 1 }

local sysapi = {
    getOSName = function() return K.NAME end,
    getOSVersion = function() return K.VERSION end,
    getExtensions = function() return K.copy(K.extensions) end,
    hasExtension = function(name, version)
        if type(name) ~= "string" then argerr(1, "hasExtension", "string", name) end
        if version ~= nil then version = wantIntegral(version, 2, "hasExtension") end
        local v = K.extensions[name]
        if not v then return false end
        if version ~= nil then return v == version end
        return true
    end,
    sleep = function(t)
        if type(t) ~= "number" then argerr(1, "sleep", "number", t) end
        local p = K.current
        if t < 0 then return nil, "EINVAL", "time must not be negative" end
        if t == 0 then
            coroutine.yield()
            return nil
        end
        K.block(p, nil, K.now() + t)
        return nil
    end,
}

local BASE = { "rawget", "rawequal", "rawlen", "rawset", "setmetatable", "getmetatable", "tostring",
    "tonumber", "pcall", "xpcall", "type", "load", "pairs", "ipairs", "next", "select", "error", "assert" }

local function copyTable(t)
    local o = {}
    for k, v in pairs(t) do o[k] = v end
    return o
end

function K.makeEnv(p)
    local env = {}
    for _, n in ipairs(BASE) do env[n] = _G[n] end

    local rawload = _G.load
    env.load = function(chunk, name, mode, e)
        if e == nil then e = env end
        return rawload(chunk, name, "t", e)
    end
    env._G, env._VERSION = env, _VERSION
    for _, n in ipairs({ "string", "table", "math", "utf8" }) do env[n] = copyTable(_G[n]) end
    env.string.dump = nil

    local strmt = { __index = env.string }
    env.getmetatable = function(o)
        if type(o) == "string" then return strmt end
        return getmetatable(o)
    end
    env.bit32 = copyTable(K.bit32)
    env.coroutine = copyTable(K.usercoroutine)

    env.CWD = p.launchcwd
    env.print = nprint and K.nprint
    env.term = copyTable(term)
    env.event = copyTable(event)
    env.fs = copyTable(fs)
    env.sys = copyTable(sysapi)
    env.dpp = copyTable(dpp)
    env.spp = copyTable(spp)
    if rawget(_G, "crypto") then env.crypto = copyTable(rawget(_G, "crypto")) end
    env.posix = K.posixtable(p)
    return env
end
