local M = {}

M.VERSION = "0.2.0"

local mfloor = math.floor

local QOI_MAGIC = "qoif"
local QOI_HEADER_SIZE = 14
local QOI_END_MARKER = "\0\0\0\0\0\0\0\1"

local MAX_DIM = 2048
local MAX_BYTES = 8 * 1024 * 1024

local function u32be(s, p)
	local a, b, c, d = s:byte(p, p + 3)
	if not d then
		return nil
	end
	return ((a * 256 + b) * 256 + c) * 256 + d
end

local function bg_to_rgb(bg)
	if type(bg) == "number" then
		return { mfloor(bg / 65536) % 256, mfloor(bg / 256) % 256, bg % 256 }
	elseif type(bg) == "table" then
		local function clamp(v)
			v = mfloor(tonumber(v) or 255)
			if v < 0 then
				return 0
			end
			if v > 255 then
				return 255
			end
			return v
		end
		return { clamp(bg[1] or bg.r), clamp(bg[2] or bg.g), clamp(bg[3] or bg.b) }
	end
	return { 255, 255, 255 }
end

function M.detect(data, path)
	if type(data) == "string" and #data >= 4 then
		if data:sub(1, 4) == QOI_MAGIC then
			return true
		end
	end
	if type(path) == "string" and path:lower():match("%.qoi$") then
		return true
	end
	return false
end

function M.parse(data)
	if type(data) ~= "string" or #data == 0 then
		return nil, "empty qoi data"
	end
	if #data > MAX_BYTES then
		return nil, "qoi too large"
	end
	if #data < QOI_HEADER_SIZE or data:sub(1, 4) ~= QOI_MAGIC then
		return nil, "not a qoi image"
	end
	local w, h = u32be(data, 5), u32be(data, 9)
	local channels, colorspace = data:byte(13), data:byte(14)
	if not w or w < 1 or w > MAX_DIM or not h or h < 1 or h > MAX_DIM then
		return nil, "bad qoi dimensions"
	end
	if w * h * 4 > MAX_BYTES then
		return nil, "qoi too large"
	end
	if channels ~= 3 and channels ~= 4 then
		return nil, "unsupported qoi channels"
	end
	if colorspace ~= 0 and colorspace ~= 1 then
		return nil, "unsupported qoi colorspace"
	end
	return {
		width = w,
		height = h,
		channels = channels,
		colorspace = colorspace,
		data = data,
	}
end

function M.natural_size(data_or_info)
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = M.parse(info)
		if not inf2 then
			return nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, "not a parsed qoi image"
	end
	return info.width, info.height
end

function M.decode(data_or_info, opts)
	opts = opts or {}
	local info = data_or_info
	local data = nil
	if type(info) == "string" then
		data = info
		local inf2, err = M.parse(data)
		if not inf2 then
			return nil, nil, nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, nil, nil, "not a parsed qoi image"
	end
	data = data or info.data
	if type(data) ~= "string" then
		return nil, nil, nil, "not a parsed qoi image"
	end
	if #data > MAX_BYTES then
		return nil, nil, nil, "qoi too large"
	end

	local w, h = info.width, info.height
	local npix = w * h
	if #data < QOI_HEADER_SIZE + 8 then
		return nil, nil, nil, "truncated qoi data"
	end
	local chunk_end = #data - 8
	local p = QOI_HEADER_SIZE + 1

	local function truncated()
		return nil, nil, nil, "truncated qoi data"
	end

	local ir, ig, ib, ia = {}, {}, {}, {}
	for i = 0, 63 do
		ir[i], ig[i], ib[i], ia[i] = 0, 0, 0, 0
	end
	local pr, pg, pb, pa = 0, 0, 0, 255

	local keep_alpha = opts.alpha == true
	local bg = nil
	if not keep_alpha then
		bg = bg_to_rgb(opts.background)
	end
	if bg == nil and not keep_alpha then
		bg = { 255, 255, 255 }
	end

	local schar = string.char
	local srep = string.rep
	local parts = {}
	local nparts = 0
	local function pixel_bytes()
		if keep_alpha then
			return schar(pr, pg, pb, pa)
		elseif pa == 255 then
			return schar(pr, pg, pb, 255)
		elseif pa == 0 then
			return schar(bg[1], bg[2], bg[3], 255)
		else
			local ia2 = 255 - pa
			return schar(
				mfloor((pr * pa + bg[1] * ia2) / 255 + 0.5),
				mfloor((pg * pa + bg[2] * ia2) / 255 + 0.5),
				mfloor((pb * pa + bg[3] * ia2) / 255 + 0.5),
				255
			)
		end
	end

	local done = 0
	while done < npix do
		if p > chunk_end then
			return truncated()
		end
		local b1 = data:byte(p)
		p = p + 1
		local is_run = b1 >= 0xC0 and b1 < 0xFE
		if b1 == 0xFE then
			if p + 2 > chunk_end then
				return truncated()
			end
			pr, pg, pb = data:byte(p, p + 2)
			p = p + 3
		elseif b1 == 0xFF then
			if p + 3 > chunk_end then
				return truncated()
			end
			pr, pg, pb, pa = data:byte(p, p + 3)
			p = p + 4
		elseif b1 < 0x40 then
			pr = ir[b1]
			pg = ig[b1]
			pb = ib[b1]
			pa = ia[b1]
		elseif b1 < 0x80 then
			local t = b1 - 0x40
			pr = (pr + mfloor(t / 16) - 2) % 256
			pg = (pg + mfloor(t / 4) % 4 - 2) % 256
			pb = (pb + t % 4 - 2) % 256
		elseif b1 < 0xC0 then
			if p > chunk_end then
				return truncated()
			end
			local b2 = data:byte(p)
			p = p + 1
			local vg = (b1 - 0x80) - 32
			local dr_dg = mfloor(b2 / 16) - 8
			local db_dg = b2 % 16 - 8
			pr = (pr + vg + dr_dg) % 256
			pg = (pg + vg) % 256
			pb = (pb + vg + db_dg) % 256
		else
			local total = (b1 - 0xC0) + 1
			if done + total > npix then
				return nil, nil, nil, "bad qoi run"
			end
			local hp = (pr * 3 + pg * 5 + pb * 7 + pa * 11) % 64
			ir[hp], ig[hp], ib[hp], ia[hp] = pr, pg, pb, pa
			nparts = nparts + 1
			parts[nparts] = srep(pixel_bytes(), total)
			done = done + total
		end
		if is_run then
		else
			local hp = (pr * 3 + pg * 5 + pb * 7 + pa * 11) % 64
			ir[hp], ig[hp], ib[hp], ia[hp] = pr, pg, pb, pa
			nparts = nparts + 1
			parts[nparts] = pixel_bytes()
			done = done + 1
		end
	end

	if p ~= chunk_end + 1 then
		return nil, nil, nil, "bad qoi data"
	end
	if data:sub(chunk_end + 1) ~= QOI_END_MARKER then
		return nil, nil, nil, "bad qoi end marker"
	end
	return w, h, table.concat(parts)
end

M.render = M.decode

return M
