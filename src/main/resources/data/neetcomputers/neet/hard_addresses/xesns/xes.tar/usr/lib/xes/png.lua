local M = {}

M.VERSION = "0.2.0"

local mfloor = math.floor

local PNG_SIG = "\137PNG\r\n\26\n"

local MAX_DIM = 2048
local MAX_BYTES = 8 * 1024 * 1024

local function zlib_lib()
	if type(require) == "function" then
		local ok, lib = pcall(require, "zlib")
		if ok and type(lib) == "table" then
			return lib
		end
	end
	return nil, "zlib library unavailable"
end

local function u32be(s, p)
	local a, b, c, d = s:byte(p, p + 3)
	if not d then
		return nil
	end
	return ((a * 256 + b) * 256 + c) * 256 + d
end

local function bg_to_rgb(bg)
	if type(bg) == "number" then
		return { mfloor(bg / 65536) % 256, mfloor(bg / 256) % 256, bg % 256 }
	elseif type(bg) == "table" then
		local function clamp(v)
			v = mfloor(tonumber(v) or 255)
			if v < 0 then
				return 0
			end
			if v > 255 then
				return 255
			end
			return v
		end
		return { clamp(bg[1] or bg.r), clamp(bg[2] or bg.g), clamp(bg[3] or bg.b) }
	end
	return { 255, 255, 255 }
end

function M.detect(data, path)
	if type(data) == "string" and #data >= 8 then
		if data:sub(1, 8) == PNG_SIG then
			return true
		end
	end
	if type(path) == "string" and path:lower():match("%.png$") then
		return true
	end
	return false
end

function M.parse(data)
	if type(data) ~= "string" or #data == 0 then
		return nil, "empty png data"
	end
	if #data > MAX_BYTES then
		return nil, "png too large"
	end
	if data:sub(1, 8) ~= PNG_SIG then
		return nil, "not a png image"
	end
	local zl, zerr = zlib_lib()
	if not zl then
		return nil, zerr
	end

	local pos = 9
	local n = #data
	local info = {
		width = nil,
		height = nil,
		bitdepth = nil,
		colortype = nil,
		interlace = nil,
		palette = nil,
		trns = nil,
		idat = {},
	}
	local seen_ihdr, seen_plte, seen_idat, seen_iend = false, false, false, false
	local idat_len = 0

	while pos <= n do
		if pos + 7 > n then
			return nil, "truncated png chunk header"
		end
		local len = u32be(data, pos)
		local ctype = data:sub(pos + 4, pos + 7)
		if not len or len > MAX_BYTES then
			return nil, "bad png chunk length"
		end
		local cdata_s = pos + 8
		local cdata_e = cdata_s + len - 1
		if cdata_e + 4 > n then
			return nil, "truncated png chunk"
		end
		local cdata = len > 0 and data:sub(cdata_s, cdata_e) or ""
		local want_crc = u32be(data, cdata_e + 1)
		if zl.crc32(ctype .. cdata) ~= want_crc then
			return nil, "png chunk crc mismatch (" .. ctype .. ")"
		end
		pos = cdata_e + 5

		if ctype == "IHDR" then
			if seen_ihdr then
				return nil, "duplicate png IHDR"
			end
			if len ~= 13 then
				return nil, "bad png IHDR"
			end
			seen_ihdr = true
			local w, h = u32be(cdata, 1), u32be(cdata, 5)
			local bd, ct = cdata:byte(9), cdata:byte(10)
			local comp, filt, inter = cdata:byte(11), cdata:byte(12), cdata:byte(13)
			if not w or w < 1 or w > MAX_DIM or not h or h < 1 or h > MAX_DIM then
				return nil, "bad png dimensions"
			end
			if w * h * 4 > MAX_BYTES then
				return nil, "png too large"
			end
			if comp ~= 0 then
				return nil, "unsupported png compression"
			end
			if filt ~= 0 then
				return nil, "unsupported png filter method"
			end
			if inter ~= 0 and inter ~= 1 then
				return nil, "unsupported png interlace method"
			end
			local okbd = bd == 1 or bd == 2 or bd == 4 or bd == 8 or bd == 16
			local okct = ct == 0 or ct == 2 or ct == 3 or ct == 4 or ct == 6
			if not (okbd and okct) then
				return nil, "unsupported png color type"
			end
			if (ct == 2 or ct == 4 or ct == 6) and bd ~= 8 and bd ~= 16 then
				return nil, "unsupported png color type"
			end
			if
				(ct == 0 and bd ~= 1 and bd ~= 2 and bd ~= 4 and bd ~= 8 and bd ~= 16)
				or (ct == 3 and bd ~= 1 and bd ~= 2 and bd ~= 4 and bd ~= 8)
			then
				return nil, "unsupported png color type"
			end
			info.width, info.height = w, h
			info.bitdepth, info.colortype, info.interlace = bd, ct, inter
		elseif ctype == "PLTE" then
			if not seen_ihdr then
				return nil, "png PLTE before IHDR"
			end
			if seen_idat then
				return nil, "png PLTE after IDAT"
			end
			if seen_plte then
				return nil, "duplicate png PLTE"
			end
			if len == 0 or len % 3 ~= 0 or len > 768 then
				return nil, "bad png PLTE"
			end
			seen_plte = true
			local pal = {}
			for i = 1, len, 3 do
				pal[#pal + 1] = { cdata:byte(i, i + 2) }
			end
			info.palette = pal
		elseif ctype == "tRNS" then
			if not seen_ihdr then
				return nil, "png tRNS before IHDR"
			end
			if seen_idat then
				return nil, "png tRNS after IDAT"
			end
			info.trns = cdata
		elseif ctype == "IDAT" then
			if not seen_ihdr then
				return nil, "png IDAT before IHDR"
			end
			if seen_iend then
				return nil, "png IDAT after IEND"
			end
			seen_idat = true
			idat_len = idat_len + len
			if idat_len > MAX_BYTES then
				return nil, "png too large"
			end
			info.idat[#info.idat + 1] = cdata
		elseif ctype == "IEND" then
			seen_iend = true
			break
		elseif ctype == "acTL" or ctype == "fcTL" or ctype == "fdAT" then
			return nil, "animated png not supported"
		else
		end
	end

	if not seen_ihdr then
		return nil, "png missing IHDR"
	end
	if not seen_idat then
		return nil, "png missing IDAT"
	end
	if not seen_iend then
		return nil, "png missing IEND"
	end
	if info.interlace ~= 0 then
		return nil, "interlaced png not supported"
	end
	if info.colortype == 3 and not info.palette then
		return nil, "png missing PLTE"
	end
	info.idat = table.concat(info.idat)
	return info
end

function M.natural_size(data_or_info)
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = M.parse(info)
		if not inf2 then
			return nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, "not a parsed png image"
	end
	return info.width, info.height
end

local function paeth(a, b, c)
	local p = a + b - c
	local pa, pb, pc = p - a, p - b, p - c
	if pa < 0 then
		pa = -pa
	end
	if pb < 0 then
		pb = -pb
	end
	if pc < 0 then
		pc = -pc
	end
	if pa <= pb and pa <= pc then
		return a
	end
	if pb <= pc then
		return b
	end
	return c
end

function M.decode(data_or_info, opts)
	opts = opts or {}
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = M.parse(info)
		if not inf2 then
			return nil, nil, nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width or not info.idat then
		return nil, nil, nil, "not a parsed png image"
	end
	local zl, zerr = zlib_lib()
	if not zl then
		return nil, nil, nil, zerr
	end

	local w, h, bd, ct = info.width, info.height, info.bitdepth, info.colortype
	local channels = (ct == 0 or ct == 3) and 1 or (ct == 4 and 2 or (ct == 2 and 3 or 4))
	local rowbits = w * bd * channels
	local stride = mfloor((rowbits + 7) / 8)
	local bpp = mfloor((bd * channels + 7) / 8)
	if bpp < 1 then
		bpp = 1
	end

	local raw, derr = zl.uncompress(info.idat, h * (stride + 1) + 16)
	if not raw then
		return nil, nil, nil, "png decompression failed: " .. tostring(derr)
	end
	if #raw ~= h * (stride + 1) then
		return nil, nil, nil, "png data size mismatch"
	end

	local rows = {}
	local rpos = 1
	local prev = nil
	for y = 1, h do
		local f = raw:byte(rpos)
		rpos = rpos + 1
		if f < 0 or f > 4 then
			return nil, nil, nil, "bad png filter"
		end
		local cur = { raw:byte(rpos, rpos + stride - 1) }
		rpos = rpos + stride
		if f == 1 then
			for i = bpp + 1, stride do
				cur[i] = (cur[i] + cur[i - bpp]) % 256
			end
		elseif f == 2 then
			if prev then
				for i = 1, stride do
					cur[i] = (cur[i] + prev[i]) % 256
				end
			end
		elseif f == 3 then
			for i = 1, stride do
				local a = i > bpp and cur[i - bpp] or 0
				local b = prev and prev[i] or 0
				cur[i] = (cur[i] + mfloor((a + b) / 2)) % 256
			end
		elseif f == 4 then
			for i = 1, stride do
				local a = i > bpp and cur[i - bpp] or 0
				local b = prev and prev[i] or 0
				local c = (i > bpp and prev) and prev[i - bpp] or 0
				cur[i] = (cur[i] + paeth(a, b, c)) % 256
			end
		end
		rows[y] = cur
		prev = cur
	end

	local pal = info.palette
	local pal_alpha = nil
	local gray_key, rgb_key = nil, nil
	if type(info.trns) == "string" then
		if ct == 3 and pal then
			pal_alpha = {}
			for i = 1, #pal do
				pal_alpha[i] = info.trns:byte(i) or 255
			end
		elseif ct == 0 and #info.trns >= 2 then
			local hi, lo = info.trns:byte(1, 2)
			gray_key = hi * 256 + lo
			if bd < 16 then
				gray_key = lo
			end
		elseif ct == 2 and #info.trns >= 6 then
			local r1, r2, g1, g2, b1, b2 = info.trns:byte(1, 6)
			if bd < 16 then
				rgb_key = { r2, g2, b2 }
			else
				rgb_key = { r1 * 256 + r2, g1 * 256 + g2, b1 * 256 + b2 }
			end
		end
	end

	local keep_alpha = opts.alpha == true
	local bg = nil
	if not keep_alpha then
		bg = bg_to_rgb(opts.background)
	end
	if bg == nil and not keep_alpha then
		bg = { 255, 255, 255 }
	end

	local schar = string.char
	local parts = {}
	for y = 1, h do
		local row = rows[y]
		local px = {}
		local n = 0
		local function emit(r, g, b, a)
			n = n + 1
			if keep_alpha then
				px[n] = schar(r, g, b, a)
			elseif a == 255 then
				px[n] = schar(r, g, b, 255)
			elseif a == 0 then
				px[n] = schar(bg[1], bg[2], bg[3], 255)
			else
				local ia = 255 - a
				px[n] = schar(
					mfloor((r * a + bg[1] * ia) / 255 + 0.5),
					mfloor((g * a + bg[2] * ia) / 255 + 0.5),
					mfloor((b * a + bg[3] * ia) / 255 + 0.5),
					255
				)
			end
		end
		if bd >= 8 then
			local hi16 = bd == 16
			local step = channels * (hi16 and 2 or 1)
			local p = 1
			for _ = 1, w do
				local r, g, b, a
				if ct == 0 then
					local v = row[p]
					r, g, b = v, v, v
					local rawv = hi16 and (row[p] * 256 + row[p + 1]) or row[p]
					a = (gray_key ~= nil and rawv == gray_key) and 0 or 255
				elseif ct == 2 then
					if hi16 then
						r, g, b = row[p], row[p + 2], row[p + 4]
					else
						r, g, b = row[p], row[p + 1], row[p + 2]
					end
					a = 255
					if rgb_key then
						local rv, gv, bv
						if hi16 then
							rv = row[p] * 256 + row[p + 1]
							gv = row[p + 2] * 256 + row[p + 3]
							bv = row[p + 4] * 256 + row[p + 5]
						else
							rv, gv, bv = row[p], row[p + 1], row[p + 2]
						end
						if rv == rgb_key[1] and gv == rgb_key[2] and bv == rgb_key[3] then
							a = 0
						end
					end
				elseif ct == 4 then
					local v = hi16 and row[p] or row[p]
					r, g, b = v, v, v
					a = hi16 and row[p + 2] or row[p + 1]
				elseif ct == 6 then
					if hi16 then
						r, g, b, a = row[p], row[p + 2], row[p + 4], row[p + 6]
					else
						r, g, b, a = row[p], row[p + 1], row[p + 2], row[p + 3]
					end
				elseif ct == 3 then
					local idx = (hi16 and row[p] or row[p]) + 1
					local e = pal[idx] or { 0, 0, 0 }
					r, g, b = e[1], e[2], e[3]
					a = (pal_alpha and pal_alpha[idx]) or 255
				end
				emit(r, g, b, a)
				p = p + step
			end
		else
			local mask = (bd == 1) and 1 or ((bd == 2) and 3 or 15)
			local perbyte = 8 / bd
			local bi, bits_left = 1, 0
			local curbyte = 0
			for _ = 1, w do
				if bits_left == 0 then
					curbyte = row[bi]
					bi = bi + 1
					bits_left = perbyte
				end
				bits_left = bits_left - 1
				local sample = mfloor(curbyte / (2 ^ (bits_left * bd))) % (mask + 1)
				if ct == 0 then
					local v = mfloor(sample * 255 / mask + 0.5)
					local a = (gray_key ~= nil and sample == gray_key) and 0 or 255
					emit(v, v, v, a)
				else
					local e = pal[sample + 1] or { 0, 0, 0 }
					local a = (pal_alpha and (pal_alpha[sample + 1] or 255)) or 255
					emit(e[1], e[2], e[3], a)
				end
			end
		end
		parts[y] = table.concat(px)
	end
	return w, h, table.concat(parts)
end

M.render = M.decode

return M
