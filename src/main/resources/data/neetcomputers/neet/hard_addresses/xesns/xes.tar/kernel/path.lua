local K = ...

local P = {}
K.path = P

local function bad(msg, level) error("invalid path: " .. msg, level or 3) end

local RESERVED = { con = true, prn = true, aux = true, nul = true }
for i = 1, 9 do
    RESERVED["com" .. i] = true; RESERVED["lpt" .. i] = true
end

local function validName(n)
    if n == "" or n:find("[/:\\%c]") then return false end
    if n == "." or n == ".." then return true end
    if n:find("[%. ]$") or n:find("^ ") then return false end
    if RESERVED[n:lower():match("^([^%.]*)")] then return false end
    return true
end

function P.normalize(fp)
    local segs = {}
    for seg in fp:gmatch("[^/]+") do
        if seg == "." then

        elseif seg == ".." then
            if #segs > 0 then segs[#segs] = nil end
        else
            segs[#segs + 1] = seg
        end
    end
    local last = fp:match("([^/]*)$")
    local isdir = fp:sub(-1) == "/" or last == "." or last == ".." or #segs == 0
    return "/" .. table.concat(segs, "/"), isdir
end

local function checkFilepath(fp, level)
    if fp:sub(1, 1) ~= "/" then bad("filepath must begin with '/': " .. fp, level) end
    local body = fp:sub(2)
    if body == "" then return end
    if body:sub(-1) == "/" then body = body:sub(1, -2) end
    for name in (body .. "/"):gmatch("([^/]*)/") do
        if not validName(name) then bad("bad name in '" .. fp .. "'", level) end
    end
end

function P.split(full)
    local d, p, f = full:match("^([^:]+):([^:]+):(/.*)$")
    return d, p, f
end

function P.join(disk, part, fp, isdir)
    if isdir and fp:sub(-1) ~= "/" then fp = fp .. "/" end
    return disk .. ":" .. part .. ":" .. fp
end

function P.resolve(path, cwd, level)
    level = (level or 2) + 1
    if type(path) ~= "string" then error("bad argument: path must be a string", level) end
    if path == "" then bad("empty path", level) end
    if path:find("%c") then bad("control character in path", level) end

    local _, colons = path:gsub(":", "")
    local disk, part, fp
    if colons == 2 then
        disk, part, fp = path:match("^([^:]*):([^:]*):(.*)$")
        if disk == "" or not disk:match("^[%w_%-]+$") then bad("bad disk in '" .. path .. "'", level) end
        if part == "" or part:find("[/%c]") then bad("bad partition in '" .. path .. "'", level) end
        checkFilepath(fp, level)
    elseif colons == 0 then
        local cdisk, cpart, cfp = P.split(cwd or "")
        if not cdisk then return nil, "no current directory" end
        disk, part = cdisk, cpart
        if path:sub(1, 1) == "/" then
            fp = path
        else
            fp = cfp:sub(-1) == "/" and (cfp .. path) or (cfp .. "/" .. path)
        end

        local rel = path:sub(1, 1) == "/" and path or path
        for name in (rel:gsub("^/+", ""):gsub("/+$", "") .. "/"):gmatch("([^/]*)/") do
            if name ~= "" and not validName(name) then bad("bad name in '" .. path .. "'", level) end
        end
    else
        bad("':' only allowed in a full path: " .. path, level)
    end

    local nfp, isdir = P.normalize(fp)


    local id
    if disk == "any" then
        for _, d in ipairs(K.rawfs.disks()) do
            if K.rawfs.hasPartition(d.slot, part) then
                id = d.id
                break
            end
        end
        if not id then return nil, "no disk has a partition named '" .. part .. "'" end
    else
        local d = K.rawfs.diskByRef(disk)
        if not d then return nil, "no such disk: " .. disk end
        id = d.id
    end
    return P.join(id, part, nfp, isdir and nfp ~= "/")
end

function P.dirname(full)
    local d, p, f = P.split(full)
    if not d then return full end
    f = f:gsub("/+$", "")
    local parent = f:match("^(.*)/[^/]*$") or ""
    return d .. ":" .. p .. ":" .. parent .. "/"
end

function P.basename(full)
    local _, _, f = P.split(full)
    f = (f or full):gsub("/+$", "")
    return f:match("([^/]*)$") or f
end

function P.pretty(full)
    local d, p, f = P.split(full)
    if d and K.root and d == K.root.id and p == K.root.part then
        if #f > 1 and f:sub(-1) == "/" then f = f:sub(1, -2) end
        return f
    end
    if #f > 1 and f:sub(-1) == "/" then return full:sub(1, -2) end
    return full
end
