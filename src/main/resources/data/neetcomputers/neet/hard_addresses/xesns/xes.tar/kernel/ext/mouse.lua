local K, API, X = ...

local T = {}

local hostEvent = rawget(_G, "event")
local PUMP = type(hostEvent) == "table" and type(hostEvent.getQueue) == "function"

local floor = math.floor

local function point(x, y)
	if type(x) ~= "number" or x ~= x or type(y) ~= "number" or y ~= y then
		return nil
	end
	x, y = floor(x), floor(y)
	if x < 0 or y < 0 then
		return nil
	end
	return x, y
end

local function button(k)
	if type(k) ~= "number" or k ~= k then
		return nil
	end
	k = floor(k)
	if k < 0 then
		return nil
	end
	return k
end

local function delta(v)
	if type(v) ~= "number" or v ~= v then
		return 0
	end
	return v
end

local function onMouse(e)
	if not PUMP or type(e) ~= "table" then
		return
	end
	if type(K.kbd) == "table" and type(K.kbd.grabbed) == "function" and K.kbd.grabbed() then
		return
	end

	local kind = e[1]
	if kind == "mouseMoved" then
		local x, y = point(e[2], e[3])
		if not x then
			return
		end
		K.input("mouseMoved", x, y)
	elseif kind == "mouseClicked" or kind == "mouseDragged" or kind == "mouseReleased" then
		local x, y = point(e[2], e[3])
		local k = button(e[4])
		if not x or not k then
			return
		end
		K.input(kind, x, y, k)
	elseif kind == "mouseScrolled" then
		local x, y = point(e[2], e[3])
		if not x then
			return
		end
		K.input("mouseScrolled", x, y, delta(e[4]), delta(e[5]))
	end
end

T.__eventonly = true

if PUMP then
	T.__ext = { ["ext.mouse"] = 1 }
	T.__hooks = { user = onMouse }
end

return T
