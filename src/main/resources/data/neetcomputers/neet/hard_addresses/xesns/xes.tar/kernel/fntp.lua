local fntp = {}

fntp.VERSION = "0.4.0"
fntp._DESCRIPTION = "libfntp : TrueType/OpenType + bitmap font parser + software rasterizer"

local function u8(d, o)
	return string.byte(d, o) or 0
end

local function u16(d, o)
	local a, b = string.byte(d, o, o + 1)
	if not b then
		return 0
	end
	return a * 256 + b
end

local function u32(d, o)
	local a, b, c, e = string.byte(d, o, o + 3)
	if not e then
		return 0
	end
	return ((a * 256 + b) * 256 + c) * 256 + e
end

local function i16(d, o)
	local v = u16(d, o)
	if v >= 0x8000 then
		return v - 0x10000
	end
	return v
end

local function i32(d, o)
	local v = u32(d, o)
	if v >= 0x80000000 then
		return v - 0x100000000
	end
	return v
end

local function tag(d, o)
	return string.sub(d, o, o + 3)
end

local function le16(d, o)
	local a, b = string.byte(d, o, o + 1)
	if not b then
		return 0
	end
	return a + b * 256
end

local function le32(d, o)
	local a, b, c, e = string.byte(d, o, o + 3)
	if not e then
		return 0
	end
	return ((e * 256 + c) * 256 + b) * 256 + a
end

local bmpDetect
local bmpCount
local bmpLoad
local bmpRaster
local bmpSdf

local function reqLen(d, need, what)
	if #d < need then
		return nil, ("truncated font data while reading %s (need %d bytes, have %d)"):format(what, need, #d)
	end
	return true
end

function fntp.decodeUTF8(s)
	local out = {}
	local i, n = 1, #s
	while i <= n do
		local b = string.byte(s, i)
		local cp, size
		if b < 0x80 then
			cp, size = b, 1
		elseif b >= 0xC2 and b <= 0xDF then
			local b2 = string.byte(s, i + 1) or 0
			if b2 < 0x80 or b2 > 0xBF then
				cp, size = 0xFFFD, 1
			else
				cp = (b - 0xC0) * 64 + (b2 - 0x80)
				size = 2
			end
		elseif b >= 0xE0 and b <= 0xEF then
			local b2 = string.byte(s, i + 1) or 0
			local b3 = string.byte(s, i + 2) or 0
			local ok = b2 >= 0x80 and b2 <= 0xBF and b3 >= 0x80 and b3 <= 0xBF
			if b == 0xE0 and b2 < 0xA0 then
				ok = false
			end
			if b == 0xED and b2 > 0x9F then
				ok = false
			end
			if ok then
				cp = (b - 0xE0) * 4096 + (b2 - 0x80) * 64 + (b3 - 0x80)
				size = 3
			else
				cp, size = 0xFFFD, 1
			end
		elseif b >= 0xF0 and b <= 0xF4 then
			local b2 = string.byte(s, i + 1) or 0
			local b3 = string.byte(s, i + 2) or 0
			local b4 = string.byte(s, i + 3) or 0
			local ok = b2 >= 0x80 and b2 <= 0xBF and b3 >= 0x80 and b3 <= 0xBF and b4 >= 0x80 and b4 <= 0xBF
			if b == 0xF0 and b2 < 0x90 then
				ok = false
			end
			if b == 0xF4 and b2 > 0x8F then
				ok = false
			end
			if ok then
				cp = (b - 0xF0) * 262144 + (b2 - 0x80) * 4096 + (b3 - 0x80) * 64 + (b4 - 0x80)
				size = 4
			else
				cp, size = 0xFFFD, 1
			end
		else
			cp, size = 0xFFFD, 1
		end
		out[#out + 1] = cp
		i = i + size
	end
	return out
end

local function readDirectory(d, base)
	local ok, err = reqLen(d, base + 11, "sfnt header")
	if not ok then
		return nil, nil, err
	end
	local version = u32(d, base)
	local numTables = u16(d, base + 4)
	if numTables <= 0 or numTables > 64 then
		return nil, nil, ("bad table count %d in sfnt at offset %d"):format(numTables, base)
	end
	local need = base + 12 + numTables * 16 - 1
	local ok2, err2 = reqLen(d, need, "sfnt directory")
	if not ok2 then
		return nil, nil, err2
	end
	local tables = {}
	for i = 0, numTables - 1 do
		local o = base + 12 + i * 16
		local t = tag(d, o)
		local off = u32(d, o + 8)
		local len = u32(d, o + 12)
		tables[t] = { offset = off, length = len }
	end
	return tables, version
end

function fntp.inspect(data)
	if type(data) ~= "string" then
		return nil, "font data must be a string"
	end
	if #data < 12 then
		return nil, "font data too short"
	end
	do
		local bk = bmpDetect(data)
		if bk then
			local n, nerr = bmpCount(data, bk)
			if not n then
				return nil, nerr
			end
			return { kind = bk, count = n }
		end
	end
	local magic = tag(data, 1)
	if magic == "wOF2" then
		return nil, "WOFF2 fonts are not supported (needs Brotli); use WOFF 1.0 or raw TTF/OTF"
	end
	if magic == "wOFF" then
		if #data < 44 then
			return nil, "WOFF data too short"
		end
		local flavor = u32(data, 5)
		if flavor == 0x00010000 or flavor == 0x74727565 then
			return { kind = "ttf", count = 1 }
		elseif flavor == 0x4F54544F then
			return { kind = "otf", count = 1 }
		end
		return nil, ("unsupported WOFF flavor 0x%08X"):format(flavor)
	end
	if magic == "ttcf" then
		local version = u32(data, 5)
		if version ~= 0x00010000 and version ~= 0x00020000 then
			return nil, ("unsupported TTC version 0x%08X"):format(version)
		end
		local count = u32(data, 9)
		if count < 1 or count > 256 then
			return nil, "bad TTC font count"
		end
		return { kind = "ttc", count = count }
	end
	local tables, version, err = readDirectory(data, 1)
	if not tables then
		return nil, err
	end
	if version == 0x00010000 or version == 0x74727565 then
		return { kind = "ttf", count = 1 }
	elseif version == 0x4F54544F then
		return { kind = "otf", count = 1 }
	end
	return nil, ("unsupported sfnt version 0x%08X"):format(version)
end

local function inflateZlib(comp, maxout)
	local n = #comp
	if n < 6 then
		return nil, "zlib data too short"
	end
	local cmf, flg = string.byte(comp, 1, 2)
	if cmf % 16 ~= 8 then
		return nil, "not deflate data"
	end
	if (cmf * 256 + flg) % 31 ~= 0 then
		return nil, "bad zlib header check"
	end
	if math.floor(flg / 32) % 2 == 1 then
		return nil, "zlib preset dictionary unsupported"
	end
	local pos = 3
	local bitbuf, bitcnt = 0, 0
	local dend = n - 4
	local sbyte = string.byte
	local mfloor = math.floor

	local P2 = {
		[0] = 1,
		2,
		4,
		8,
		16,
		32,
		64,
		128,
		256,
		512,
		1024,
		2048,
		4096,
		8192,
		16384,
		32768,
		65536,
		131072,
		262144,
		524288,
		1048576,
	}

	local function need(k)
		while bitcnt < k do
			if pos > dend then
				return false
			end
			bitbuf = bitbuf + sbyte(comp, pos) * P2[bitcnt]
			bitcnt = bitcnt + 8
			pos = pos + 1
		end
		return true
	end
	local function bits(k)
		if not need(k) then
			return nil
		end
		local p = P2[k]
		local v = bitbuf % p
		bitbuf = mfloor(bitbuf / p)
		bitcnt = bitcnt - k
		return v
	end
	local function buildHuff(lens, total)
		local maxl = 0
		for i = 1, total do
			if lens[i] > maxl then
				maxl = lens[i]
			end
		end
		local bl = {}
		for i = 0, maxl do
			bl[i] = 0
		end
		for i = 1, total do
			bl[lens[i]] = (bl[lens[i]] or 0) + 1
		end
		local code, nextc = 0, {}
		for b = 1, maxl do
			code = (code + (bl[b - 1] or 0)) * 2
			nextc[b] = code
		end
		local map = {}
		for i = 1, total do
			local L = lens[i]
			if L > 0 then
				local c = nextc[L]
				local rev = 0
				for _ = 1, L do
					rev = rev * 2 + (c % 2)
					c = math.floor(c / 2)
				end
				map[L] = map[L] or {}
				map[L][rev] = i - 1
				nextc[L] = nextc[L] + 1
			end
		end
		return { map = map, maxl = maxl }
	end
	local function decode(h)
		local code, L = 0, 0
		while true do
			local b = bits(1)
			if not b then
				return nil
			end
			code = code + b * P2[L]
			L = L + 1
			local row = h.map[L]
			if row then
				local v = row[code]
				if v ~= nil then
					return v
				end
			end
			if L > h.maxl then
				return nil
			end
		end
	end
	local fixedLit, fixedDist
	do
		local lens = {}
		for i = 1, 288 do
			lens[i] = (i <= 144) and 8 or ((i <= 256) and 9 or ((i <= 280) and 7 or 8))
		end
		fixedLit = buildHuff(lens, 288)
		local dl = {}
		for i = 1, 32 do
			dl[i] = 5
		end
		fixedDist = buildHuff(dl, 32)
	end
	local LEN_BASE = {
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		13,
		15,
		17,
		19,
		23,
		27,
		31,
		35,
		43,
		51,
		59,
		67,
		83,
		99,
		115,
		131,
		163,
		195,
		227,
		258,
	}
	local LEN_EXT = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 }
	local DIST_BASE = {
		1,
		2,
		3,
		4,
		5,
		7,
		9,
		13,
		17,
		25,
		33,
		49,
		65,
		97,
		129,
		193,
		257,
		385,
		513,
		769,
		1025,
		1537,
		2049,
		3073,
		4097,
		6145,
		8193,
		12289,
		16385,
		24577,
	}
	local DIST_EXT =
		{ 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 }
	local out, outB, outLen = {}, {}, 0
	local schar = string.char
	local function emitByte(b)
		outLen = outLen + 1
		outB[outLen] = b
		out[outLen] = schar(b)
	end
	local function emitMatch(dist, len)
		for _ = 1, len do
			local b = outB[outLen - dist + 1]
			outLen = outLen + 1
			outB[outLen] = b
			out[outLen] = schar(b)
		end
	end
	local CL_ORDER = { 17, 18, 19, 1, 9, 8, 10, 7, 11, 6, 12, 5, 13, 4, 14, 3, 15, 2, 16 }
	while true do
		local final = bits(1)
		local btype = bits(2)
		if not final or not btype then
			return nil, "truncated deflate stream"
		end
		if btype == 3 then
			return nil, "bad deflate block type"
		end
		local lit, dist
		if btype == 0 then
			bitbuf, bitcnt = 0, 0
			if pos + 3 > dend then
				return nil, "truncated stored block"
			end
			local len = string.byte(comp, pos) + string.byte(comp, pos + 1) * 256
			local nlen = string.byte(comp, pos + 2) + string.byte(comp, pos + 3) * 256
			pos = pos + 4
			if len + nlen ~= 65535 then
				return nil, "bad stored block lengths"
			end
			for _ = 1, len do
				if pos > dend then
					return nil, "truncated stored data"
				end
				emitByte(string.byte(comp, pos))
				pos = pos + 1
				if outLen > (maxout or 20000000) then
					return nil, "inflate output too large"
				end
			end
		else
			if btype == 1 then
				lit, dist = fixedLit, fixedDist
			else
				local hlit = bits(5)
				local hdist = bits(5)
				local hclen = bits(4)
				if not hlit or not hdist or not hclen then
					return nil, "truncated dynamic header"
				end
				hlit, hdist, hclen = hlit + 257, hdist + 1, hclen + 4
				local cl = {}
				for i = 1, 19 do
					cl[i] = 0
				end
				for i = 1, hclen do
					local v = bits(3)
					if not v then
						return nil, "truncated code lengths"
					end
					cl[CL_ORDER[i]] = v
				end
				local clHuff = buildHuff(cl, 19)
				local lens = {}
				local i = 1
				local total = hlit + hdist
				local bad = false
				while i <= total do
					local s = decode(clHuff)
					if not s then
						bad = true
						break
					end
					if s <= 15 then
						lens[i] = s
						i = i + 1
					elseif s == 16 then
						local r = bits(2)
						if not r then
							bad = true
							break
						end
						local prev = lens[i - 1] or 0
						for _ = 1, r + 3 do
							lens[i] = prev
							i = i + 1
						end
					elseif s == 17 then
						local r = bits(3)
						if not r then
							bad = true
							break
						end
						for _ = 1, r + 3 do
							lens[i] = 0
							i = i + 1
						end
					else
						local r = bits(7)
						if not r then
							bad = true
							break
						end
						for _ = 1, r + 11 do
							lens[i] = 0
							i = i + 1
						end
					end
				end
				if bad then
					return nil, "bad dynamic code lengths"
				end
				local ll, dl = {}, {}
				for k = 1, hlit do
					ll[k] = lens[k] or 0
				end
				for k = 1, hdist do
					dl[k] = lens[hlit + k] or 0
				end
				lit = buildHuff(ll, hlit)
				dist = buildHuff(dl, hdist)
			end
			while true do
				local s = decode(lit)
				if not s then
					return nil, "bad literal/length code"
				end
				if s < 256 then
					emitByte(s)
				elseif s == 256 then
					break
				else
					local li = s - 256
					if li < 1 or li > 29 then
						return nil, "bad length symbol"
					end
					local needEB = LEN_EXT[li]
					local eb = 0
					if needEB > 0 then
						local v = bits(needEB)
						if not v then
							return nil, "truncated length bits"
						end
						eb = v
					end
					local len = LEN_BASE[li] + eb
					local ds = decode(dist)
					if not ds then
						return nil, "bad distance code"
					end
					if ds < 0 or ds > 29 then
						return nil, "bad distance symbol"
					end
					local needDB = DIST_EXT[ds + 1]
					local db = 0
					if needDB > 0 then
						local v = bits(needDB)
						if not v then
							return nil, "truncated distance bits"
						end
						db = v
					end
					local dd = DIST_BASE[ds + 1] + db
					if dd < 1 or dd > outLen then
						return nil, "bad match distance"
					end
					emitMatch(dd, len)
					if outLen > (maxout or 20000000) then
						return nil, "inflate output too large"
					end
				end
			end
		end
		if final == 1 then
			break
		end
	end
	local raw = table.concat(out)
	local a1, a2 = 1, 0
	for i = 1, #raw do
		a1 = a1 + sbyte(raw, i)
		a2 = a2 + a1
		if i % 4096 == 0 then
			a1 = a1 % 65521
			a2 = a2 % 65521
		end
	end
	a1 = a1 % 65521
	a2 = a2 % 65521
	local want = u32(comp, n - 3)
	if a2 * 65536 + a1 ~= want then
		return nil, "zlib checksum mismatch"
	end
	return raw
end

local function woffUnpack(data)
	if #data < 44 then
		return nil, "WOFF data too short"
	end
	local flavor = u32(data, 5)
	local totalLen = u32(data, 9)
	local numTables = u16(data, 13)
	if totalLen ~= #data then
		return nil, "bad WOFF length"
	end
	if numTables < 1 or numTables > 64 then
		return nil, "bad WOFF table count"
	end
	if #data < 44 + numTables * 20 then
		return nil, "WOFF directory truncated"
	end
	local tabs = {}
	for i = 0, numTables - 1 do
		local o = 45 + i * 20
		local t = tag(data, o)
		local off, compLen, origLen = u32(data, o + 4), u32(data, o + 8), u32(data, o + 12)
		if off < 44 or compLen < 1 or origLen < 1 or origLen > 20000000 or off + compLen > #data + 1 then
			return nil, ("bad WOFF table '%s'"):format(t)
		end
		local comp = string.sub(data, off + 1, off + compLen)
		local raw
		if compLen == origLen then
			raw = comp
		else
			local derr
			raw, derr = inflateZlib(comp, origLen)
			if not raw then
				return nil, ("WOFF table '%s': %s"):format(t, derr)
			end
			if #raw ~= origLen then
				return nil, ("WOFF table '%s' length mismatch"):format(t)
			end
		end
		local pad = (4 - #raw % 4) % 4
		if pad > 0 then
			raw = raw .. string.rep("\0", pad)
		end
		tabs[#tabs + 1] = { tag = t, raw = raw }
	end
	local n = #tabs
	local function u16s(v)
		return string.char(math.floor(v / 256) % 256, v % 256)
	end
	local function u32s(v)
		return string.char(
			math.floor(v / 16777216) % 256,
			math.floor(v / 65536) % 256,
			math.floor(v / 256) % 256,
			v % 256
		)
	end
	local log2, hi = 0, 1
	while hi * 2 <= n do
		hi = hi * 2
		log2 = log2 + 1
	end
	local head = u32s(flavor) .. u16s(n) .. u16s(hi * 16) .. u16s(log2) .. u16s(n * 16 - hi * 16)
	local dir, blob = {}, {}
	local at = 12 + n * 16
	for _, t in ipairs(tabs) do
		dir[#dir + 1] = t.tag .. u32s(0) .. u32s(at) .. u32s(#t.raw)
		blob[#blob + 1] = t.raw
		at = at + #t.raw
	end
	return table.concat({ head, table.concat(dir), table.concat(blob) })
end

local function parseHead(d, off)
	return {
		unitsPerEm = u16(d, off + 18),
		xMin = i16(d, off + 36),
		yMin = i16(d, off + 38),
		xMax = i16(d, off + 40),
		yMax = i16(d, off + 42),
		indexToLocFormat = i16(d, off + 50),
	}
end

local function parseMaxp(d, off)
	return { numGlyphs = u16(d, off + 4) }
end

local function parseHhea(d, off)
	return {
		ascender = i16(d, off + 4),
		descender = i16(d, off + 6),
		lineGap = i16(d, off + 8),
		numberOfHMetrics = u16(d, off + 34),
	}
end

local function parseHmtx(d, off, numGlyphs, numMetrics)
	local advances, lsbs = {}, {}
	local o = off
	local lastAdv = 0
	for i = 0, numMetrics - 1 do
		lastAdv = u16(d, o)
		local lsb = i16(d, o + 2)
		advances[i] = lastAdv
		lsbs[i] = lsb
		o = o + 4
	end
	for i = numMetrics, numGlyphs - 1 do
		advances[i] = lastAdv
		lsbs[i] = i16(d, o)
		o = o + 2
	end
	return advances, lsbs
end

local function parseLoca(d, off, numGlyphs, fmt)
	local loc = {}
	if fmt == 0 then
		for i = 0, numGlyphs do
			loc[i] = u16(d, off + i * 2) * 2
		end
	else
		for i = 0, numGlyphs do
			loc[i] = u32(d, off + i * 4)
		end
	end
	return loc
end

local function parseCmap(d, off, length)
	local limit = off + (length or (#d - off + 1)) - 1
	if limit > #d then
		limit = #d
	end
	if off + 3 > limit then
		return nil, "truncated cmap header"
	end
	local version = u16(d, off)
	local nsubs = u16(d, off + 2)
	if version ~= 0 or nsubs < 1 or nsubs > 64 then
		return nil, "bad cmap header"
	end
	local fmt4, fmt12, fmt0, fmt6, fmt10, fmt13, fmt2
	local cands = {}
	for i = 0, nsubs - 1 do
		local o = off + 4 + i * 8
		if o + 7 > limit then
			break
		end
		local plat, enc = u16(d, o), u16(d, o + 2)
		local sub = u32(d, o + 4)
		if sub + 4 <= limit - off then
			local f = u16(d, off + sub)
			local score = -1
			if plat == 3 and enc == 10 then
				score = 40
			elseif plat == 0 and enc == 4 then
				score = 30
			elseif plat == 3 and enc == 1 then
				score = 20
			elseif plat == 0 and enc == 3 then
				score = 10
			elseif plat == 1 and enc == 0 then
				score = 5
			end
			cands[#cands + 1] = { f = f, sub = sub, score = score }
		end
	end
	for pass = 1, 2 do
		for _, cd in ipairs(cands) do
			local f, sub = cd.f, cd.sub
			local score = cd.score
			if pass == 2 then
				if score <= 0 and (f == 0 or f == 2 or f == 4 or f == 6 or f == 10 or f == 12 or f == 13) then
					score = 1
				end
			end
			if f == 12 and score > 0 then
				local len = u32(d, off + sub + 4)
				local nGroups = u32(d, off + sub + 12)
				if len >= 16 and nGroups <= 100000 and off + sub + len - 1 <= #d and 16 + nGroups * 12 <= len then
					local groups = {}
					for g = 0, nGroups - 1 do
						local go = off + sub + 16 + g * 12
						groups[g + 1] = { u32(d, go), u32(d, go + 4), u32(d, go + 8) }
					end
					if not fmt12 or score > fmt12.score then
						fmt12 = { groups = groups, score = score }
					end
				end
			elseif f == 4 and score > 0 then
				local segX2 = u16(d, off + sub + 6)
				local segCount = math.floor(segX2 / 2)
				local len4 = u16(d, off + sub + 2)
				if segCount >= 1 and segCount <= 1024 and len4 >= 16 + segCount * 8 and off + sub + len4 - 1 <= #d then
					local base = off + sub
					local ends = {}
					for s = 1, segCount do
						ends[s] = u16(d, base + 14 + (s - 1) * 2)
					end
					local starts = {}
					local sbase = base + 14 + segCount * 2 + 2
					for s = 1, segCount do
						starts[s] = u16(d, sbase + (s - 1) * 2)
					end
					local dbase = sbase + segCount * 2
					local deltas = {}
					for s = 1, segCount do
						deltas[s] = i16(d, dbase + (s - 1) * 2)
					end
					local rbase = dbase + segCount * 2
					local ranges = {}
					for s = 1, segCount do
						ranges[s] = u16(d, rbase + (s - 1) * 2)
					end
					local c = {
						segCount = segCount,
						ends = ends,
						starts = starts,
						deltas = deltas,
						ranges = ranges,
						roBase = rbase,
						score = score,
					}
					if not fmt4 or score > fmt4.score then
						fmt4 = c
					end
				end
			elseif f == 0 and score > 0 then
				local len = u16(d, off + sub + 2)
				if len >= 262 and off + sub + len - 1 <= #d and not fmt0 then
					local arr = {}
					for k = 0, 255 do
						arr[k] = u8(d, off + sub + 6 + k)
					end
					fmt0 = { array = arr, score = score }
				end
			elseif f == 6 and score > 0 then
				local len = u16(d, off + sub + 2)
				local first = u16(d, off + sub + 6)
				local count = u16(d, off + sub + 8)
				if len >= 10 + count * 2 and count <= 4096 and off + sub + len - 1 <= #d and not fmt6 then
					local arr = {}
					for k = 0, count - 1 do
						arr[k] = u16(d, off + sub + 10 + k * 2)
					end
					fmt6 = { first = first, array = arr, score = score }
				end
			elseif f == 10 and score > 0 then
				local len = u32(d, off + sub + 4)
				local first = u32(d, off + sub + 12)
				local count = u32(d, off + sub + 16)
				if
					len >= 20 + count * 2
					and count >= 1
					and count <= 65536
					and off + sub + len - 1 <= #d
					and not fmt10
				then
					local arr = {}
					for k = 0, count - 1 do
						arr[k] = u16(d, off + sub + 20 + k * 2)
					end
					fmt10 = { first = first, array = arr, score = score }
				end
			elseif f == 13 and score > 0 then
				local len = u32(d, off + sub + 4)
				local nGroups = u32(d, off + sub + 12)
				if
					len >= 16
					and nGroups >= 1
					and nGroups <= 100000
					and 16 + nGroups * 12 <= len
					and off + sub + len - 1 <= #d
					and not fmt13
				then
					local groups = {}
					for g = 0, nGroups - 1 do
						local go = off + sub + 16 + g * 12
						groups[g + 1] = { u32(d, go), u32(d, go + 4), u32(d, go + 8) }
					end
					fmt13 = { groups = groups, score = score }
				end
			elseif f == 2 and score > 0 then
				local len = u16(d, off + sub + 2)
				if len >= 518 and len <= 65536 and off + sub + len - 1 <= #d and not fmt2 then
					local base = off + sub
					local keys = {}
					for k = 0, 255 do
						keys[k] = math.floor(u16(d, base + 6 + k * 2) / 8)
					end
					local hiKey = 0
					for k = 0, 255 do
						if keys[k] > hiKey then
							hiKey = keys[k]
						end
					end
					if hiKey <= 64 then
						local subs = {}
						for s = 0, hiKey do
							local so = base + 518 + s * 8
							subs[s] = {
								first = u16(d, so),
								count = u16(d, so + 2),
								delta = i16(d, so + 4),
								range = u16(d, so + 6),
								pos = so,
							}
						end
						fmt2 = { keys = keys, subs = subs, base = base, score = score }
					end
				end
			end
		end
	end
	if not fmt4 and not fmt12 and not fmt0 and not fmt6 and not fmt10 and not fmt13 and not fmt2 then
		return nil, "no usable cmap subtable (need format 0, 2, 4, 6, 10, 12 or 13)"
	end
	return {
		fmt4 = fmt4,
		fmt12 = fmt12,
		fmt0 = fmt0,
		fmt6 = fmt6,
		fmt10 = fmt10,
		fmt13 = fmt13,
		fmt2 = fmt2,
	}
end

local function cmapGroupSearch(groups, cp)
	local sorted = groups._sorted
	if sorted == nil then
		sorted = true
		for i = 2, #groups do
			if groups[i][1] < groups[i - 1][1] then
				sorted = false
				break
			end
		end
		groups._sorted = sorted
	end
	if sorted then
		local lo, hi = 1, #groups
		while lo <= hi do
			local mid = math.floor((lo + hi) / 2)
			local g = groups[mid]
			if cp < g[1] then
				hi = mid - 1
			elseif cp > g[2] then
				lo = mid + 1
			else
				return g
			end
		end
		return nil
	end
	for i = 1, #groups do
		local g = groups[i]
		if cp >= g[1] and cp <= g[2] then
			return g
		end
	end
	return nil
end

local function cmapLookupFull(font, cp)
	local cmap = font._cmap
	local f12 = cmap.fmt12
	if f12 then
		local g = cmapGroupSearch(f12.groups, cp)
		if g then
			local gid = g[3] + (cp - g[1])
			if gid < font.numGlyphs then
				return gid
			end
			return 0
		end
	end
	local f4 = cmap.fmt4
	if f4 and cp <= 0xFFFF then
		for s = 1, f4.segCount do
			local st, en = f4.starts[s], f4.ends[s]
			if cp >= st and cp <= en then
				local ro = f4.ranges[s]
				if ro == 0 then
					return (cp + f4.deltas[s]) % 65536
				else
					local cell = f4.roBase + (s - 1) * 2
					local p = cell + ro + (cp - st) * 2
					local d = font._data
					if p < 1 or p + 1 > #d then
						return 0
					end
					local g = u16(d, p)
					if g == 0 then
						return 0
					end
					return (g + f4.deltas[s]) % 65536
				end
			end
		end
	end
	local f10 = cmap.fmt10
	if f10 and cp >= f10.first then
		local k = cp - f10.first
		local g = f10.array[k]
		if g ~= nil then
			return (g < font.numGlyphs) and g or 0
		end
	end
	local f6 = cmap.fmt6
	if f6 and cp >= f6.first and cp <= 0xFFFF then
		local k = cp - f6.first
		local g = f6.array[k]
		if g ~= nil then
			return (g < font.numGlyphs) and g or 0
		end
	end
	local f0 = cmap.fmt0
	if f0 and cp <= 0xFF then
		local g = f0.array[cp] or 0
		return (g < font.numGlyphs) and g or 0
	end
	local f13 = cmap.fmt13
	if f13 then
		local g = cmapGroupSearch(f13.groups, cp)
		if g then
			return (g[3] < font.numGlyphs) and g[3] or 0
		end
	end
	local f2 = cmap.fmt2
	if f2 and cp <= 0xFFFF then
		local hi = math.floor(cp / 256)
		local lo = cp % 256
		local key, val
		if hi == 0 then
			key, val = f2.keys[lo], lo
			if key ~= 0 then
				key = nil
			end
		else
			key, val = f2.keys[hi], lo
			if key == 0 then
				key = nil
			end
		end
		if key ~= nil then
			local sh = f2.subs[key]
			if sh and val >= sh.first and val < sh.first + sh.count then
				if sh.range == 0 then
					local g = (val + sh.delta) % 65536
					return (g < font.numGlyphs) and g or 0
				else
					local p = sh.pos + 6 + sh.range + (val - sh.first) * 2
					local d = font._data
					if p >= 1 and p + 1 <= #d then
						local g = u16(d, p)
						if g ~= 0 then
							g = (g + sh.delta) % 65536
							return (g < font.numGlyphs) and g or 0
						end
					end
				end
			end
		end
	end
	return 0
end

local function parseName(d, off, length)
	if length < 6 then
		return nil
	end
	local count = u16(d, off + 2)
	local strOff = u16(d, off + 4)
	if count > 100 then
		return nil
	end
	local best, fallback
	for i = 0, count - 1 do
		local ro = off + 6 + i * 12
		local plat, enc, lang = u16(d, ro), u16(d, ro + 2), u16(d, ro + 4)
		local nameID = u16(d, ro + 6)
		local len = u16(d, ro + 8)
		local so = u16(d, ro + 10)
		if (nameID == 4 or nameID == 1) and len > 0 and len <= 512 then
			local p = off + strOff + so
			if p >= 1 and p + len - 1 <= #d then
				local raw = string.sub(d, p, p + len - 1)
				local s
				if plat == 3 or plat == 0 then
					local chars = {}
					for k = 1, len - 1, 2 do
						local hi, lo = string.byte(raw, k, k + 1)
						local cp = hi * 256 + (lo or 0)
						chars[#chars + 1] = (cp >= 32 and cp < 127) and string.char(cp) or "?"
					end
					s = table.concat(chars)
				else
					s = raw
				end
				if nameID == 4 and not best then
					best = s
				end
				if nameID == 1 and not fallback then
					fallback = s
				end
			end
		end
	end
	return best or fallback
end

local function parseNameFull(d, off, length)
	if length < 6 then
		return {}
	end
	local count = u16(d, off + 2)
	local strOff = u16(d, off + 4)
	if count < 1 or count > 256 then
		return {}
	end
	local out, prio = {}, {}
	for i = 0, count - 1 do
		local ro = off + 6 + i * 12
		if ro + 11 > #d then
			break
		end
		local plat, enc = u16(d, ro), u16(d, ro + 2)
		local nameID = u16(d, ro + 6)
		local len = u16(d, ro + 8)
		local so = u16(d, ro + 10)
		if nameID <= 256 and len > 0 and len <= 1024 then
			local p = off + strOff + so
			if p >= 1 and p + len - 1 <= #d then
				local raw = string.sub(d, p, p + len - 1)
				local s
				if plat == 3 or plat == 0 then
					local chars = {}
					for k = 1, len - 1, 2 do
						local hi, lo = string.byte(raw, k, k + 1)
						local cp = hi * 256 + (lo or 0)
						chars[#chars + 1] = (cp >= 32 and cp < 127) and string.char(cp) or "?"
					end
					s = table.concat(chars)
				else
					s = raw
				end
				local pr = (plat == 3 and enc == 1) and 3 or ((plat == 0) and 2 or 1)
				if not out[nameID] or pr > (prio[nameID] or 0) then
					out[nameID], prio[nameID] = s, pr
				end
			end
		end
	end
	return out
end

local function parseKern(d, off, length)
	local map = {}
	if length < 4 then
		return map
	end
	if u16(d, off) ~= 0 then
		return map
	end
	local nTables = u16(d, off + 2)
	if nTables < 1 or nTables > 32 then
		return map
	end
	local p = off + 4
	for _ = 1, nTables do
		if p + 6 > off + length then
			break
		end
		local len = u16(d, p + 2)
		local coverage = u16(d, p + 4)
		local fmt = math.floor(coverage / 256)
		local horiz = (coverage % 2) == 1
		if len < 6 or p + len > off + length + 1 then
			break
		end
		if fmt == 0 and horiz then
			local nPairs = u16(d, p + 6)
			if nPairs <= 32768 then
				local q = p + 14
				for i = 1, nPairs do
					if q + 5 > p + len then
						break
					end
					local l, r, v = u16(d, q), u16(d, q + 2), i16(d, q + 4)
					map[l * 65536 + r] = v
					q = q + 6
				end
			end
		end
		p = p + len
	end
	return map
end

local function parseOS2(d, off, length)
	if length < 78 then
		return nil
	end
	local o = {
		version = u16(d, off),
		avgCharWidth = i16(d, off + 2),
		weightClass = u16(d, off + 4),
		widthClass = u16(d, off + 6),
		fsType = u16(d, off + 8),
		subscriptXSize = i16(d, off + 10),
		subscriptYSize = i16(d, off + 12),
		subscriptXOff = i16(d, off + 14),
		subscriptYOff = i16(d, off + 16),
		superscriptXSize = i16(d, off + 18),
		superscriptYSize = i16(d, off + 20),
		superscriptXOff = i16(d, off + 22),
		superscriptYOff = i16(d, off + 24),
		strikeoutSize = i16(d, off + 26),
		strikeoutPos = i16(d, off + 28),
		familyClass = i16(d, off + 30),
	}
	o.vendor = string.sub(d, off + 58, off + 61)
	o.fsSelection = u16(d, off + 62)
	o.firstChar = u16(d, off + 64)
	o.lastChar = u16(d, off + 66)
	o.typoAscender = i16(d, off + 68)
	o.typoDescender = i16(d, off + 70)
	o.typoLineGap = i16(d, off + 72)
	o.winAscent = u16(d, off + 74)
	o.winDescent = u16(d, off + 76)
	if length >= 96 then
		o.xHeight = i16(d, off + 86)
		o.capHeight = i16(d, off + 88)
		o.defaultChar = u16(d, off + 90)
		o.breakChar = u16(d, off + 92)
	end
	return o
end

local MAC_GLYPH_NAMES = {
	".notdef",
	".null",
	"nonmarkingreturn",
	"space",
	"exclam",
	"quotedbl",
	"numbersign",
	"dollar",
	"percent",
	"ampersand",
	"quotesingle",
	"parenleft",
	"parenright",
	"asterisk",
	"plus",
	"comma",
	"hyphen",
	"period",
	"slash",
	"zero",
	"one",
	"two",
	"three",
	"four",
	"five",
	"six",
	"seven",
	"eight",
	"nine",
	"colon",
	"semicolon",
	"less",
	"equal",
	"greater",
	"question",
	"at",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"bracketleft",
	"backslash",
	"bracketright",
	"asciicircum",
	"underscore",
	"grave",
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h",
	"i",
	"j",
	"k",
	"l",
	"m",
	"n",
	"o",
	"p",
	"q",
	"r",
	"s",
	"t",
	"u",
	"v",
	"w",
	"x",
	"y",
	"z",
	"braceleft",
	"bar",
	"braceright",
	"asciitilde",
	"Adieresis",
	"Aring",
	"Ccedilla",
	"Eacute",
	"Ntilde",
	"Odieresis",
	"Udieresis",
	"aacute",
	"agrave",
	"acircumflex",
	"adieresis",
	"atilde",
	"aring",
	"ccedilla",
	"eacute",
	"egrave",
	"ecircumflex",
	"edieresis",
	"iacute",
	"igrave",
	"icircumflex",
	"idieresis",
	"ntilde",
	"oacute",
	"ograve",
	"ocircumflex",
	"odieresis",
	"otilde",
	"uacute",
	"ugrave",
	"ucircumflex",
	"udieresis",
	"dagger",
	"degree",
	"cent",
	"sterling",
	"section",
	"bullet",
	"paragraph",
	"germandbls",
	"registered",
	"copyright",
	"trademark",
	"acute",
	"dieresis",
	"notequal",
	"AE",
	"Oslash",
	"infinity",
	"plusminus",
	"lessequal",
	"greaterequal",
	"yen",
	"mu",
	"partialdiff",
	"summation",
	"product",
	"pi",
	"integral",
	"ordfeminine",
	"ordmasculine",
	"Omega",
	"ae",
	"oslash",
	"questiondown",
	"exclamdown",
	"logicalnot",
	"radical",
	"florin",
	"approxequal",
	"Delta",
	"guillemotleft",
	"guillemotright",
	"ellipsis",
	"nbspace",
	"Agrave",
	"Atilde",
	"Otilde",
	"OE",
	"oe",
	"endash",
	"emdash",
	"quotedblleft",
	"quotedblright",
	"quoteleft",
	"quoteright",
	"divide",
	"lozenge",
	"ydieresis",
	"Ydieresis",
	"fraction",
	"currency",
	"guilsinglleft",
	"guilsinglright",
	"fi",
	"fl",
	"daggerdbl",
	"periodcentered",
	"quotesinglbase",
	"quotedblbase",
	"perthousand",
	"Acircumflex",
	"Ecircumflex",
	"Aacute",
	"Edieresis",
	"Egrave",
	"Iacute",
	"Icircumflex",
	"Idieresis",
	"Igrave",
	"Oacute",
	"Ocircumflex",
	"apple",
	"Ograve",
	"Uacute",
	"Ucircumflex",
	"Ugrave",
	"dotlessi",
	"circumflex",
	"tilde",
	"macron",
	"breve",
	"dotaccent",
	"ring",
	"cedilla",
	"hungarumlaut",
	"ogonek",
	"caron",
	"Lslash",
	"lslash",
	"Scaron",
	"scaron",
	"Zcaron",
	"zcaron",
	"brokenbar",
	"Eth",
	"eth",
	"Yacute",
	"yacute",
	"Thorn",
	"thorn",
	"minus",
	"multiply",
	"onesuperior",
	"twosuperior",
	"threesuperior",
	"onehalf",
	"onequarter",
	"threequarters",
	"franc",
	"Gbreve",
	"gbreve",
	"Idot",
	"Scedilla",
	"scedilla",
	"Cacute",
	"cacute",
	"Ccaron",
	"ccaron",
	"dbar",
}

local function parsePost(d, off, length)
	if length < 32 then
		return nil
	end
	local fmt = u32(d, off)
	local angle = i32(d, off + 4) / 65536
	local underPos, underThick = i16(d, off + 8), i16(d, off + 10)
	local fixed = u32(d, off + 12) ~= 0
	local o = {
		format = fmt,
		italicAngle = angle,
		underlinePos = underPos,
		underlineThick = underThick,
		isFixedPitch = fixed,
		names = nil,
	}
	if fmt == 0x00020000 and length >= 34 then
		local n = u16(d, off + 32)
		if n >= 1 and n <= 65535 then
			local idx = {}
			local q = off + 34
			local ok = true
			for i = 1, n do
				if q + 1 > off + length then
					ok = false
					break
				end
				idx[i] = u16(d, q)
				q = q + 2
			end
			if ok then
				local custom = {}
				local ci = 0
				while q < off + length do
					local L = u8(d, q)
					q = q + 1
					if q + L - 1 > off + length then
						break
					end
					custom[ci] = string.sub(d, q, q + L - 1)
					ci = ci + 1
					q = q + L
				end
				local names = {}
				for i = 1, n do
					local gi = idx[i]
					if gi <= 257 then
						names[i - 1] = MAC_GLYPH_NAMES[gi + 1]
					else
						names[i - 1] = custom[gi - 258]
					end
				end
				o.names = names
			end
		end
	end
	return o
end

local function parseVhea(d, off)
	return {
		ascender = i16(d, off + 4),
		descender = i16(d, off + 6),
		lineGap = i16(d, off + 8),
		numVerMetrics = u16(d, off + 34),
	}
end

local function parseVmtx(d, off, numGlyphs, numMetrics)
	local adv, tsb = {}, {}
	local o = off
	local last = 0
	for i = 0, numMetrics - 1 do
		last = u16(d, o)
		local t = i16(d, o + 2)
		adv[i] = last
		tsb[i] = t
		o = o + 4
	end
	for i = numMetrics, numGlyphs - 1 do
		adv[i] = last
		tsb[i] = i16(d, o)
		o = o + 2
	end
	return adv, tsb
end

local function parseVorg(d, off, length)
	if length < 8 then
		return nil
	end
	if u16(d, off) ~= 1 then
		return nil
	end
	local def = i16(d, off + 4)
	local n = u16(d, off + 6)
	if n > 4096 or 8 + n * 4 > length then
		return nil
	end
	local rec = {}
	for i = 0, n - 1 do
		rec[u16(d, off + 8 + i * 4)] = i16(d, off + 10 + i * 4)
	end
	return { defaultY = def, rec = rec }
end

local function parseCoverage(d, off, dend)
	if off + 3 > dend then
		return nil
	end
	local fmt = u16(d, off)
	if fmt == 1 then
		local count = u16(d, off + 2)
		if count < 1 or count > 65535 or off + 3 + count * 2 > dend then
			return nil
		end
		local map, list = {}, {}
		for i = 0, count - 1 do
			local g = u16(d, off + 4 + i * 2)
			map[g] = i
			list[i + 1] = g
		end
		return { map = map, list = list }
	elseif fmt == 2 then
		local count = u16(d, off + 2)
		if count < 1 or count > 8192 or off + 3 + count * 6 > dend then
			return nil
		end
		local map, list = {}, {}
		local idx = 0
		for i = 0, count - 1 do
			local s, e = u16(d, off + 4 + i * 6), u16(d, off + 6 + i * 6)
			for g = s, e do
				if g > 65535 then
					break
				end
				map[g] = idx
				list[idx + 1] = g
				idx = idx + 1
				if idx > 65535 then
					break
				end
			end
		end
		return { map = map, list = list }
	end
	return nil
end

local function parseClassDef(d, off, dend)
	if off + 3 > dend then
		return nil
	end
	local fmt = u16(d, off)
	if fmt == 1 then
		local start = u16(d, off + 2)
		local count = u16(d, off + 4)
		if count < 1 or count > 65535 or off + 5 + count * 2 > dend then
			return nil
		end
		local map = {}
		for i = 0, count - 1 do
			map[start + i] = u16(d, off + 6 + i * 2)
		end
		return map
	elseif fmt == 2 then
		local count = u16(d, off + 2)
		if count < 1 or count > 8192 or off + 3 + count * 6 > dend then
			return nil
		end
		local map = {}
		for i = 0, count - 1 do
			local s, e, c = u16(d, off + 4 + i * 6), u16(d, off + 6 + i * 6), u16(d, off + 8 + i * 6)
			for g = s, e do
				map[g] = c
			end
		end
		return map
	end
	return nil
end

local function readValue(d, p, vf, dend)
	local r = { dx = 0, dy = 0, adv = 0, yAdv = 0 }
	local function takeU16()
		if p + 1 > dend then
			return 0
		end
		local v = u16(d, p)
		p = p + 2
		return v
	end
	local function takeI16()
		if p + 1 > dend then
			return 0
		end
		local v = i16(d, p)
		p = p + 2
		return v
	end
	if vf % 2 >= 1 then
		r.dx = takeI16()
	end
	if math.floor(vf / 2) % 2 == 1 then
		r.dy = takeI16()
	end
	if math.floor(vf / 4) % 2 == 1 then
		r.adv = takeI16()
	end
	if math.floor(vf / 8) % 2 == 1 then
		r.yAdv = takeI16()
	end
	local dev = math.floor(vf / 16)
	local bit = 16
	while bit <= 256 do
		if dev % 2 == 1 then
			takeU16()
		end
		dev = math.floor(dev / 2)
		bit = bit * 2
	end
	return r, p
end

local function parseAnchor(d, off, dend)
	if off + 3 > dend then
		return nil
	end
	local fmt = u16(d, off)
	if fmt == 1 or fmt == 2 or fmt == 3 then
		return { x = i16(d, off + 2), y = i16(d, off + 4) }
	end
	return nil
end

local function parseLayoutCommon(d, off, dend)
	if off + 9 > dend then
		return nil
	end
	local scriptOff = u16(d, off + 4)
	local featureOff = u16(d, off + 6)
	local lookupOff = u16(d, off + 8)
	local features = {}
	if featureOff > 0 and off + featureOff + 1 <= dend then
		local fo = off + featureOff
		if fo + 1 <= dend then
			local nFeat = u16(d, fo)
			if nFeat <= 512 then
				for i = 0, nFeat - 1 do
					local ro = fo + 2 + i * 6
					if ro + 5 > dend then
						break
					end
					local t = string.sub(d, ro, ro + 3)
					local sub = u16(d, ro + 4)
					local fbase = fo + sub
					if sub > 0 and fbase + 3 <= dend then
						local nLk = u16(d, fbase + 2)
						if nLk <= 64 then
							local lks = {}
							for k = 0, nLk - 1 do
								if fbase + 4 + k * 2 + 1 > dend then
									break
								end
								lks[#lks + 1] = u16(d, fbase + 4 + k * 2)
							end
							features[t] = lks
						end
					end
				end
			end
		end
	end
	local lookups = {}
	if lookupOff > 0 and off + lookupOff + 1 <= dend then
		local lo = off + lookupOff
		if lo + 1 <= dend then
			local nLk = u16(d, lo)
			if nLk <= 1024 then
				for i = 0, nLk - 1 do
					if lo + 2 + i * 2 + 1 > dend then
						break
					end
					local sub = u16(d, lo + 2 + i * 2)
					local base = lo + sub
					if sub > 0 and base + 5 <= dend then
						local ltype = u16(d, base)
						local flag = u16(d, base + 2)
						local nSub = u16(d, base + 4)
						if nSub <= 64 then
							local subs = {}
							for k = 0, nSub - 1 do
								if base + 6 + k * 2 + 1 > dend then
									break
								end
								subs[#subs + 1] = base + u16(d, base + 6 + k * 2)
							end
							lookups[i] = { type = ltype, flag = flag, subs = subs }
						end
					end
				end
			end
		end
	end
	return { features = features, lookups = lookups }
end

local function unwrapExt(d, so, dend)
	if so + 7 > dend then
		return nil
	end
	if u16(d, so) ~= 1 then
		return nil
	end
	local itype = u16(d, so + 2)
	local eoff = u32(d, so + 4)
	if eoff < 8 or eoff > 1000000 or so + eoff > dend then
		return nil
	end
	return so + eoff, itype
end

local function parseGPOS(d, off, length)
	local dend = math.min(off + length - 1, #d)
	local common = parseLayoutCommon(d, off, dend)
	if not common then
		return nil
	end
	local gpos = {
		pairs = {},
		singles = {},
		marks = {},
		hasPairs = false,
		hasSingles = false,
		hasMarks = false,
	}
	local wantTags = { kern = 1, dist = 1, abvm = 1, blwm = 1, mark = 1, mkmk = 1 }
	local enabled = {}
	local anyWant = false
	for t, lks in pairs(common.features) do
		if wantTags[t] then
			anyWant = true
			for _, li in ipairs(lks) do
				enabled[li] = true
			end
		end
	end
	local function useLookup(li, ltype)
		if anyWant then
			return enabled[li]
		end
		return ltype == 1 or ltype == 2 or ltype == 4
	end
	for li, lk in pairs(common.lookups) do
		local work = {}
		for _, so in ipairs(lk.subs) do
			if lk.type == 9 then
				local inner, itype = unwrapExt(d, so, dend)
				if inner then
					work[#work + 1] = { off = inner, type = itype }
				end
			else
				work[#work + 1] = { off = so, type = lk.type }
			end
		end
		for _, w in ipairs(work) do
			local so, effType = w.off, w.type
			if effType == 2 and useLookup(li, 2) then
				if so + 9 <= dend then
					local fmt = u16(d, so)
					if fmt == 1 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local vf1, vf2 = u16(d, so + 4), u16(d, so + 6)
						local nSet = u16(d, so + 8)
						if cov and nSet <= 4096 then
							for si = 0, nSet - 1 do
								if so + 10 + si * 2 + 1 > dend then
									break
								end
								local first = cov.list[si + 1]
								local setOff = u16(d, so + 10 + si * 2)
								local sb = so + setOff
								if first and setOff > 0 and sb + 1 <= dend then
									local nP = u16(d, sb)
									if nP <= 4096 then
										local q = sb + 2
										for pi = 1, nP do
											if q + 1 > dend then
												break
											end
											local second = u16(d, q)
											local r1, nq = readValue(d, q + 2, vf1, dend)
											local r2
											r2, nq = readValue(d, nq, vf2, dend)
											local adv = (r1 and r1.adv or 0) + (r2 and r2.adv or 0)
											local dx = (r1 and r1.dx or 0) + (r2 and r2.dx or 0)
											local dy = (r1 and r1.dy or 0) + (r2 and r2.dy or 0)
											if adv ~= 0 or dx ~= 0 or dy ~= 0 then
												local key = first * 65536 + second
												if gpos.pairs[key] == nil then
													gpos.pairs[key] = { adv = adv, dx = dx, dy = dy }
													gpos.hasPairs = true
												end
											end
											q = nq
										end
									end
								end
							end
						end
					elseif fmt == 2 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local vf1, vf2 = u16(d, so + 4), u16(d, so + 6)
						local c1off, c2off = u16(d, so + 8), u16(d, so + 10)
						local nC1, nC2 = u16(d, so + 12), u16(d, so + 14)
						if cov and nC1 >= 1 and nC1 <= 512 and nC2 >= 1 and nC2 <= 512 then
							local c1 = parseClassDef(d, so + c1off, dend) or {}
							local c2 = parseClassDef(d, so + c2off, dend) or {}
							local recSize = 0
							do
								local _, nq = readValue(d, so + 16, vf1, dend)
								local _, nq2 = readValue(d, nq, vf2, dend)
								recSize = nq2 - (so + 16)
								if recSize < 0 then
									recSize = 0
								end
							end
							if recSize >= 0 then
								gpos.classPairs = gpos.classPairs or {}
								gpos.classPairs[#gpos.classPairs + 1] = {
									cov = cov,
									c1 = c1,
									c2 = c2,
									nC1 = nC1,
									nC2 = nC2,
									base = so + 16,
									vf1 = vf1,
									vf2 = vf2,
									recSize = recSize,
								}
								gpos.hasPairs = true
							end
						end
					end
				end
			elseif effType == 1 and useLookup(li, 1) then
				if so + 3 <= dend then
					local fmt = u16(d, so)
					if fmt == 1 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local vf = u16(d, so + 4)
						if cov then
							local r, _np = readValue(d, so + 6, vf, dend)
							if r and (r.dx ~= 0 or r.dy ~= 0 or r.adv ~= 0) then
								for _, g in ipairs(cov.list) do
									if gpos.singles[g] == nil then
										gpos.singles[g] = r
										gpos.hasSingles = true
									end
								end
							end
						end
					elseif fmt == 2 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local vf = u16(d, so + 4)
						local n = u16(d, so + 6)
						if cov and n >= 1 and n <= 4096 then
							local q = so + 8
							for i = 1, math.min(n, #cov.list) do
								local r
								r, q = readValue(d, q, vf, dend)
								local g = cov.list[i]
								if r and g and gpos.singles[g] == nil and (r.dx ~= 0 or r.dy ~= 0 or r.adv ~= 0) then
									gpos.singles[g] = r
									gpos.hasSingles = true
								end
							end
						end
					end
				end
			elseif effType == 4 and useLookup(li, 4) then
				if so + 11 <= dend then
					local fmt = u16(d, so)
					if fmt == 1 then
						local markCov = parseCoverage(d, so + u16(d, so + 2), dend)
						local baseCov = parseCoverage(d, so + u16(d, so + 4), dend)
						local nClass = u16(d, so + 6)
						local markOff, baseOff = u16(d, so + 8), u16(d, so + 10)
						if markCov and baseCov and nClass >= 1 and nClass <= 16 then
							local mb = markOff > 0 and (so + markOff) or nil
							local bb = baseOff > 0 and (so + baseOff) or nil
							if mb and bb and mb + 1 <= dend and bb + 1 <= dend then
								local nMark = u16(d, mb)
								local nBase = u16(d, bb)
								if nMark <= 4096 and nBase <= 4096 then
									for mi = 0, nMark - 1 do
										local ro = mb + 2 + mi * 4
										if ro + 3 > dend then
											break
										end
										local cls, ao = u16(d, ro), u16(d, ro + 2)
										local g = markCov.list[mi + 1]
										if g and ao > 0 then
											local a = parseAnchor(d, mb + ao, dend)
											if a then
												gpos.marks[g] = gpos.marks[g] or {}
												gpos.marks[g].mark = a
												gpos.marks[g].class = cls
												gpos.hasMarks = true
											end
										end
									end
									local q = bb + 2
									for bi = 0, nBase - 1 do
										local g = baseCov.list[bi + 1]
										for ci = 0, nClass - 1 do
											if q + 1 > dend then
												break
											end
											local ao = u16(d, q)
											q = q + 2
											if g and ao > 0 then
												local a = parseAnchor(d, bb + ao, dend)
												if a then
													gpos.marks["b" .. g .. ":" .. ci] = a
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	if not gpos.hasPairs and not gpos.hasSingles and not gpos.hasMarks and gpos.classPairs == nil then
		return nil
	end
	return gpos
end

local function gposPairAt(font, l, r)
	local gp = font._gpos
	if not gp then
		return nil
	end
	local key = l * 65536 + r
	local direct = gp.pairs[key]
	if direct then
		return direct
	end
	if gp.classPairs then
		local cache = gp._pairCache
		if cache then
			local hit = cache[key]
			if hit ~= nil then
				return (hit == false) and nil or hit
			end
		else
			cache = {}
			gp._pairCache = cache
		end
		local d = font._data
		local dlen = #d
		for _, cp in ipairs(gp.classPairs) do
			local k1 = cp.c1[l] or 0
			local k2 = cp.c2[r] or 0
			if k1 < cp.nC1 and k2 < cp.nC2 then
				local p = cp.base + (k1 * cp.nC2 + k2) * cp.recSize
				local r1, nq = readValue(d, p, cp.vf1, dlen)
				local r2, _nq = readValue(d, nq, cp.vf2, dlen)
				local adv = (r1 and r1.adv or 0) + (r2 and r2.adv or 0)
				local dx = (r1 and r1.dx or 0) + (r2 and r2.dx or 0)
				local dy = (r1 and r1.dy or 0) + (r2 and r2.dy or 0)
				if adv ~= 0 or dx ~= 0 or dy ~= 0 then
					local rec = { adv = adv, dx = dx, dy = dy }
					cache[key] = rec
					return rec
				else
					cache[key] = false
					return nil
				end
			end
		end
		cache[key] = false
	end
	return nil
end

local function parseGSUB(d, off, length)
	local dend = math.min(off + length - 1, #d)
	local common = parseLayoutCommon(d, off, dend)
	if not common then
		return nil
	end
	local gsub = {
		single = {},
		multi = {},
		ligs = {},
		hasSingle = false,
		hasMulti = false,
		hasLig = false,
	}
	local wantTags = { liga = 1, clig = 1, rlig = 1, dlig = 1, rclt = 1, calt = 1 }
	local enabled = {}
	local anyWant = false
	for t, lks in pairs(common.features) do
		if wantTags[t] then
			anyWant = true
			for _, li in ipairs(lks) do
				enabled[li] = true
			end
		end
	end
	local function useLookup(li, ltype)
		if anyWant then
			return enabled[li]
		end
		return ltype == 1 or ltype == 2 or ltype == 4
	end
	for li, lk in pairs(common.lookups) do
		local work = {}
		for _, so in ipairs(lk.subs) do
			if lk.type == 7 then
				local inner, itype = unwrapExt(d, so, dend)
				if inner then
					work[#work + 1] = { off = inner, type = itype }
				end
			else
				work[#work + 1] = { off = so, type = lk.type }
			end
		end
		for _, w in ipairs(work) do
			local so, effType = w.off, w.type
			if effType == 1 and useLookup(li, 1) then
				if so + 3 <= dend then
					local fmt = u16(d, so)
					if fmt == 1 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local delta = i16(d, so + 4)
						if cov then
							for _, g in ipairs(cov.list) do
								if gsub.single[g] == nil then
									gsub.single[g] = (g + delta) % 65536
									gsub.hasSingle = true
								end
							end
						end
					elseif fmt == 2 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local n = u16(d, so + 4)
						if cov and n >= 1 and n <= 4096 then
							for i = 1, math.min(n, #cov.list) do
								if so + 6 + (i - 1) * 2 + 1 > dend then
									break
								end
								local g = cov.list[i]
								if g and gsub.single[g] == nil then
									gsub.single[g] = u16(d, so + 6 + (i - 1) * 2)
									gsub.hasSingle = true
								end
							end
						end
					end
				end
			elseif effType == 2 and useLookup(li, 2) then
				if so + 3 <= dend then
					local fmt = u16(d, so)
					if fmt == 1 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local n = u16(d, so + 4)
						if cov and n >= 1 and n <= 4096 then
							for i = 1, math.min(n, #cov.list) do
								if so + 6 + (i - 1) * 2 + 1 > dend then
									break
								end
								local seqOff = u16(d, so + 6 + (i - 1) * 2)
								local g = cov.list[i]
								local sb = so + seqOff
								if g and seqOff > 0 and sb + 1 <= dend then
									local cnt = u16(d, sb)
									if cnt >= 1 and cnt <= 16 then
										local out = {}
										for k = 0, cnt - 1 do
											if sb + 2 + k * 2 + 1 > dend then
												break
											end
											out[#out + 1] = u16(d, sb + 2 + k * 2)
										end
										if #out == cnt and gsub.multi[g] == nil then
											gsub.multi[g] = out
											gsub.hasMulti = true
										end
									end
								end
							end
						end
					end
				end
			elseif effType == 4 and useLookup(li, 4) then
				if so + 3 <= dend then
					local fmt = u16(d, so)
					if fmt == 1 then
						local cov = parseCoverage(d, so + u16(d, so + 2), dend)
						local nSet = u16(d, so + 4)
						if cov and nSet >= 1 and nSet <= 4096 then
							for i = 1, math.min(nSet, #cov.list) do
								if so + 6 + (i - 1) * 2 + 1 > dend then
									break
								end
								local setOff = u16(d, so + 6 + (i - 1) * 2)
								local first = cov.list[i]
								local sb = so + setOff
								if first and setOff > 0 and sb + 1 <= dend then
									local nL = u16(d, sb)
									if nL >= 1 and nL <= 64 then
										for k = 0, nL - 1 do
											if sb + 2 + k * 2 + 1 > dend then
												break
											end
											local ligOff = u16(d, sb + 2 + k * 2)
											local lb = sb + ligOff
											if ligOff > 0 and lb + 3 <= dend then
												local lig, nComp = u16(d, lb), u16(d, lb + 2)
												if nComp >= 2 and nComp <= 16 then
													local comps = {}
													for c = 0, nComp - 2 do
														if lb + 4 + c * 2 + 1 > dend then
															break
														end
														comps[#comps + 1] = u16(d, lb + 4 + c * 2)
													end
													if #comps == nComp - 1 then
														gsub.ligs[first] = gsub.ligs[first] or {}
														gsub.ligs[first][#gsub.ligs[first] + 1] =
															{ lig = lig, comps = comps, n = nComp }
														gsub.hasLig = true
													end
												end
											end
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
	if gsub.hasLig then
		for _, sets in pairs(gsub.ligs) do
			table.sort(sets, function(a, b)
				return a.n > b.n
			end)
		end
	end
	if not gsub.hasSingle and not gsub.hasMulti and not gsub.hasLig then
		return nil
	end
	return gsub
end

local function applyGSUB(font, gids, clusters)
	local gs = font._gsub
	if not gs then
		return gids, clusters
	end
	local n = #gids
	local g2, c2 = {}, {}
	for i = 1, n do
		local g = gids[i]
		local s = gs.single[g]
		if s ~= nil then
			g = s
		end
		local m = gs.multi[g]
		if m then
			for _, sg in ipairs(m) do
				g2[#g2 + 1] = sg
				c2[#c2 + 1] = clusters[i]
			end
		else
			g2[#g2 + 1] = g
			c2[#c2 + 1] = clusters[i]
		end
	end
	if gs.hasLig then
		local g3, c3 = {}, {}
		local i = 1
		while i <= #g2 do
			local sets = gs.ligs[g2[i]]
			local matched = nil
			local mlen = 0
			if sets then
				for _, L in ipairs(sets) do
					local ok = true
					for k = 1, #L.comps do
						if g2[i + k] ~= L.comps[k] then
							ok = false
							break
						end
					end
					if ok then
						matched, mlen = L, L.n
						break
					end
				end
			end
			if matched then
				g3[#g3 + 1] = matched.lig
				c3[#c3 + 1] = c2[i]
				i = i + mlen
			else
				g3[#g3 + 1] = g2[i]
				c3[#c3 + 1] = c2[i]
				i = i + 1
			end
		end
		return g3, c3
	end
	return g2, c2
end

local function isMarkCP(cp)
	return (cp >= 0x300 and cp <= 0x36F)
		or (cp >= 0x1AB0 and cp <= 0x1AFF)
		or (cp >= 0x1DC0 and cp <= 0x1DFF)
		or (cp >= 0x20D0 and cp <= 0x20FF)
		or (cp >= 0xFE00 and cp <= 0xFE0F)
		or (cp >= 0xFE20 and cp <= 0xFE2F)
		or cp == 0x200D
		or cp == 0x200C
end

local CFF_STANDARD_STRINGS = {
	".notdef",
	"space",
	"exclam",
	"quotedbl",
	"numbersign",
	"dollar",
	"percent",
	"ampersand",
	"quoteright",
	"parenleft",
	"parenright",
	"asterisk",
	"plus",
	"comma",
	"hyphen",
	"period",
	"slash",
	"zero",
	"one",
	"two",
	"three",
	"four",
	"five",
	"six",
	"seven",
	"eight",
	"nine",
	"colon",
	"semicolon",
	"less",
	"equal",
	"greater",
	"question",
	"at",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"bracketleft",
	"backslash",
	"bracketright",
	"asciicircum",
	"underscore",
	"quoteleft",
	"a",
	"b",
	"c",
	"d",
	"e",
	"f",
	"g",
	"h",
	"i",
	"j",
	"k",
	"l",
	"m",
	"n",
	"o",
	"p",
	"q",
	"r",
	"s",
	"t",
	"u",
	"v",
	"w",
	"x",
	"y",
	"z",
	"braceleft",
	"bar",
	"braceright",
	"asciitilde",
	"exclamdown",
	"cent",
	"sterling",
	"fraction",
	"yen",
	"florin",
	"section",
	"currency",
	"quotesingle",
	"quotedblleft",
	"guillemotleft",
	"guilsinglleft",
	"guilsinglright",
	"fi",
	"fl",
	"endash",
	"dagger",
	"daggerdbl",
	"periodcentered",
	"paragraph",
	"bullet",
	"quotesinglbase",
	"quotedblbase",
	"quotedblright",
	"guillemotright",
	"ellipsis",
	"perthousand",
	"questiondown",
	"grave",
	"acute",
	"circumflex",
	"tilde",
	"macron",
	"breve",
	"dotaccent",
	"dieresis",
	"ring",
	"cedilla",
	"hungarumlaut",
	"ogonek",
	"caron",
	"emdash",
	"AE",
	"ordfeminine",
	"Lslash",
	"Oslash",
	"OE",
	"ordmasculine",
	"ae",
	"dotlessi",
	"lslash",
	"oslash",
	"oe",
	"germandbls",
	"onesuperior",
	"logicalnot",
	"mu",
	"trademark",
	"Eth",
	"onehalf",
	"plusminus",
	"Thorn",
	"onequarter",
	"divide",
	"brokenbar",
	"degree",
	"thorn",
	"threequarters",
	"twosuperior",
	"registered",
	"minus",
	"eth",
	"multiply",
	"threesuperior",
	"copyright",
	"Aacute",
	"Acircumflex",
	"Adieresis",
	"Agrave",
	"Aring",
	"Atilde",
	"Ccedilla",
	"Eacute",
	"Ecircumflex",
	"Edieresis",
	"Egrave",
	"Iacute",
	"Icircumflex",
	"Idieresis",
	"Igrave",
	"Ntilde",
	"Oacute",
	"Ocircumflex",
	"Odieresis",
	"Ograve",
	"Otilde",
	"Scaron",
	"Uacute",
	"Ucircumflex",
	"Udieresis",
	"Ugrave",
	"Yacute",
	"Ydieresis",
	"Zcaron",
	"aacute",
	"acircumflex",
	"adieresis",
	"agrave",
	"aring",
	"atilde",
	"ccedilla",
	"eacute",
	"ecircumflex",
	"edieresis",
	"egrave",
	"iacute",
	"icircumflex",
	"idieresis",
	"igrave",
	"ntilde",
	"oacute",
	"ocircumflex",
	"odieresis",
	"ograve",
	"otilde",
	"scaron",
	"uacute",
	"ucircumflex",
	"udieresis",
	"ugrave",
	"yacute",
	"ydieresis",
	"zcaron",
	"exclamsmall",
	"Hungarumlautsmall",
	"dollaroldstyle",
	"dollarsuperior",
	"ampersandsmall",
	"Acutesmall",
	"parenleftsuperior",
	"parenrightsuperior",
	"twodotenleader",
	"onedotenleader",
	"zerooldstyle",
	"oneoldstyle",
	"twooldstyle",
	"threeoldstyle",
	"fouroldstyle",
	"fiveoldstyle",
	"sixoldstyle",
	"sevenoldstyle",
	"eightoldstyle",
	"nineoldstyle",
	"commasuperior",
	"threequartersemdash",
	"periodsuperior",
	"questionsmall",
	"asuperior",
	"bsuperior",
	"centsuperior",
	"dsuperior",
	"esuperior",
	"isuperior",
	"lsuperior",
	"msuperior",
	"nsuperior",
	"osuperior",
	"rsuperior",
	"ssuperior",
	"tsuperior",
	"ff",
	"ffi",
	"ffl",
	"parenleftinferior",
	"parenrightinferior",
	"Circumflexsmall",
	"hyphensuperior",
	"Gravesmall",
	"Asmall",
	"Bsmall",
	"Csmall",
	"Dsmall",
	"Esmall",
	"Fsmall",
	"Gsmall",
	"Hsmall",
	"Ismall",
	"Jsmall",
	"Ksmall",
	"Lsmall",
	"Msmall",
	"Nsmall",
	"Osmall",
	"Psmall",
	"Qsmall",
	"Rsmall",
	"Ssmall",
	"Tsmall",
	"Usmall",
	"Vsmall",
	"Wsmall",
	"Xsmall",
	"Ysmall",
	"Zsmall",
	"colonmonetary",
	"onefitted",
	"rupiah",
	"Tildesmall",
	"exclamdownsmall",
	"centoldstyle",
	"Lslashsmall",
	"Scaronsmall",
	"Zcaronsmall",
	"Dieresissmall",
	"Brevesmall",
	"Caronsmall",
	"Dotaccentsmall",
	"Macronsmall",
	"figuredash",
	"hypheninferior",
	"Ogoneksmall",
	"Ringsmall",
	"Cedillasmall",
	"questiondownsmall",
	"oneeighth",
	"threeeighths",
	"fiveeighths",
	"seveneighths",
	"onethird",
	"twothirds",
	"zerosuperior",
	"foursuperior",
	"fivesuperior",
	"sixsuperior",
	"sevensuperior",
	"eightsuperior",
	"ninesuperior",
	"zeroinferior",
	"oneinferior",
	"twoinferior",
	"threeinferior",
	"fourinferior",
	"fiveinferior",
	"sixinferior",
	"seveninferior",
	"eightinferior",
	"nineinferior",
	"centinferior",
	"dollarinferior",
	"periodinferior",
	"commainferior",
	"Agravesmall",
	"Aacutesmall",
	"Acircumflexsmall",
	"Atildesmall",
	"Adieresissmall",
	"Aringsmall",
	"AEsmall",
	"Ccedillasmall",
	"Egravesmall",
	"Eacutesmall",
	"Ecircumflexsmall",
	"Edieresissmall",
	"Igravesmall",
	"Iacutesmall",
	"Icircumflexsmall",
	"Idieresissmall",
	"Ethsmall",
	"Ntildesmall",
	"Ogravesmall",
	"Oacutesmall",
	"Ocircumflexsmall",
	"Otildesmall",
	"Odieresissmall",
	"OEsmall",
	"Oslashsmall",
	"Ugravesmall",
	"Uacutesmall",
	"Ucircumflexsmall",
	"Udieresissmall",
	"Yacutesmall",
	"Thornsmall",
	"Ydieresissmall",
	"001.000",
	"001.001",
	"001.002",
	"001.003",
	"Black",
	"Bold",
	"Book",
	"Light",
	"Medium",
	"Regular",
	"Roman",
	"Semibold",
}

local CFF_STANDARD_ENCODING = {
	[0] = ".notdef",
	[1] = ".notdef",
	[2] = ".notdef",
	[3] = ".notdef",
	[4] = ".notdef",
	[5] = ".notdef",
	[6] = ".notdef",
	[7] = ".notdef",
	[8] = ".notdef",
	[9] = ".notdef",
	[10] = ".notdef",
	[11] = ".notdef",
	[12] = ".notdef",
	[13] = ".notdef",
	[14] = ".notdef",
	[15] = ".notdef",
	[16] = ".notdef",
	[17] = ".notdef",
	[18] = ".notdef",
	[19] = ".notdef",
	[20] = ".notdef",
	[21] = ".notdef",
	[22] = ".notdef",
	[23] = ".notdef",
	[24] = ".notdef",
	[25] = ".notdef",
	[26] = ".notdef",
	[27] = ".notdef",
	[28] = ".notdef",
	[29] = ".notdef",
	[30] = ".notdef",
	[31] = ".notdef",
	[32] = "space",
	[33] = "exclam",
	[34] = "quotedbl",
	[35] = "numbersign",
	[36] = "dollar",
	[37] = "percent",
	[38] = "ampersand",
	[39] = "quoteright",
	[40] = "parenleft",
	[41] = "parenright",
	[42] = "asterisk",
	[43] = "plus",
	[44] = "comma",
	[45] = "hyphen",
	[46] = "period",
	[47] = "slash",
	[48] = "zero",
	[49] = "one",
	[50] = "two",
	[51] = "three",
	[52] = "four",
	[53] = "five",
	[54] = "six",
	[55] = "seven",
	[56] = "eight",
	[57] = "nine",
	[58] = "colon",
	[59] = "semicolon",
	[60] = "less",
	[61] = "equal",
	[62] = "greater",
	[63] = "question",
	[64] = "at",
	[65] = "A",
	[66] = "B",
	[67] = "C",
	[68] = "D",
	[69] = "E",
	[70] = "F",
	[71] = "G",
	[72] = "H",
	[73] = "I",
	[74] = "J",
	[75] = "K",
	[76] = "L",
	[77] = "M",
	[78] = "N",
	[79] = "O",
	[80] = "P",
	[81] = "Q",
	[82] = "R",
	[83] = "S",
	[84] = "T",
	[85] = "U",
	[86] = "V",
	[87] = "W",
	[88] = "X",
	[89] = "Y",
	[90] = "Z",
	[91] = "bracketleft",
	[92] = "backslash",
	[93] = "bracketright",
	[94] = "asciicircum",
	[95] = "underscore",
	[96] = "quoteleft",
	[97] = "a",
	[98] = "b",
	[99] = "c",
	[100] = "d",
	[101] = "e",
	[102] = "f",
	[103] = "g",
	[104] = "h",
	[105] = "i",
	[106] = "j",
	[107] = "k",
	[108] = "l",
	[109] = "m",
	[110] = "n",
	[111] = "o",
	[112] = "p",
	[113] = "q",
	[114] = "r",
	[115] = "s",
	[116] = "t",
	[117] = "u",
	[118] = "v",
	[119] = "w",
	[120] = "x",
	[121] = "y",
	[122] = "z",
	[123] = "braceleft",
	[124] = "bar",
	[125] = "braceright",
	[126] = "asciitilde",
	[127] = ".notdef",
	[128] = ".notdef",
	[129] = ".notdef",
	[130] = ".notdef",
	[131] = ".notdef",
	[132] = ".notdef",
	[133] = ".notdef",
	[134] = ".notdef",
	[135] = ".notdef",
	[136] = ".notdef",
	[137] = ".notdef",
	[138] = ".notdef",
	[139] = ".notdef",
	[140] = ".notdef",
	[141] = ".notdef",
	[142] = ".notdef",
	[143] = ".notdef",
	[144] = ".notdef",
	[145] = ".notdef",
	[146] = ".notdef",
	[147] = ".notdef",
	[148] = ".notdef",
	[149] = ".notdef",
	[150] = ".notdef",
	[151] = ".notdef",
	[152] = ".notdef",
	[153] = ".notdef",
	[154] = ".notdef",
	[155] = ".notdef",
	[156] = ".notdef",
	[157] = ".notdef",
	[158] = ".notdef",
	[159] = ".notdef",
	[160] = ".notdef",
	[161] = "exclamdown",
	[162] = "cent",
	[163] = "sterling",
	[164] = "fraction",
	[165] = "yen",
	[166] = "florin",
	[167] = "section",
	[168] = "currency",
	[169] = "quotesingle",
	[170] = "quotedblleft",
	[171] = "guillemotleft",
	[172] = "guilsinglleft",
	[173] = "guilsinglright",
	[174] = "fi",
	[175] = "fl",
	[176] = ".notdef",
	[177] = "endash",
	[178] = "dagger",
	[179] = "daggerdbl",
	[180] = "periodcentered",
	[181] = ".notdef",
	[182] = "paragraph",
	[183] = "bullet",
	[184] = "quotesinglbase",
	[185] = "quotedblbase",
	[186] = "quotedblright",
	[187] = "guillemotright",
	[188] = "ellipsis",
	[189] = "perthousand",
	[190] = ".notdef",
	[191] = "questiondown",
	[192] = ".notdef",
	[193] = "grave",
	[194] = "acute",
	[195] = "circumflex",
	[196] = "tilde",
	[197] = "macron",
	[198] = "breve",
	[199] = "dotaccent",
	[200] = "dieresis",
	[201] = ".notdef",
	[202] = "ring",
	[203] = "cedilla",
	[204] = ".notdef",
	[205] = "hungarumlaut",
	[206] = "ogonek",
	[207] = "caron",
	[208] = "emdash",
	[209] = ".notdef",
	[210] = ".notdef",
	[211] = ".notdef",
	[212] = ".notdef",
	[213] = ".notdef",
	[214] = ".notdef",
	[215] = ".notdef",
	[216] = ".notdef",
	[217] = ".notdef",
	[218] = ".notdef",
	[219] = ".notdef",
	[220] = ".notdef",
	[221] = ".notdef",
	[222] = ".notdef",
	[223] = ".notdef",
	[224] = ".notdef",
	[225] = "AE",
	[226] = ".notdef",
	[227] = "ordfeminine",
	[228] = ".notdef",
	[229] = ".notdef",
	[230] = ".notdef",
	[231] = ".notdef",
	[232] = "Lslash",
	[233] = "Oslash",
	[234] = "OE",
	[235] = "ordmasculine",
	[236] = ".notdef",
	[237] = ".notdef",
	[238] = ".notdef",
	[239] = ".notdef",
	[240] = ".notdef",
	[241] = "ae",
	[242] = ".notdef",
	[243] = ".notdef",
	[244] = ".notdef",
	[245] = "dotlessi",
	[246] = ".notdef",
	[247] = ".notdef",
	[248] = "lslash",
	[249] = "oslash",
	[250] = "oe",
	[251] = "germandbls",
	[252] = ".notdef",
	[253] = ".notdef",
	[254] = ".notdef",
	[255] = ".notdef",
}

local function readCFFIndex(d, pos, what)
	if pos < 1 or pos + 1 > #d then
		return nil, ("CFF %s: INDEX header past end of data"):format(what)
	end
	local count = u16(d, pos)
	if count == 0 then
		return { count = 0, items = {}, next = pos + 2 }
	end
	if count > 65535 then
		return nil, ("CFF %s: bad INDEX count"):format(what)
	end
	local offSize = u8(d, pos + 2)
	if offSize < 1 or offSize > 4 then
		return nil, ("CFF %s: bad INDEX offSize %d"):format(what, offSize)
	end
	local function getOff(i)
		local o = pos + 3 + (i - 1) * offSize
		if offSize == 1 then
			return u8(d, o)
		elseif offSize == 2 then
			return u16(d, o)
		elseif offSize == 3 then
			return u8(d, o) * 65536 + u16(d, o + 1)
		else
			return u32(d, o)
		end
	end
	local base = pos + 3 + (count + 1) * offSize
	local last = getOff(count + 1)
	if last < 1 or base + last - 2 > #d + 1 then
		return nil, ("CFF %s: INDEX data past end of table"):format(what)
	end
	local items = {}
	local prev = getOff(1)
	if prev < 1 then
		return nil, ("CFF %s: bad INDEX offset"):format(what)
	end
	for i = 1, count do
		local cur = getOff(i + 1)
		if cur < prev then
			return nil, ("CFF %s: bad INDEX offsets"):format(what)
		end
		items[i] = { pos = base + prev - 1, len = cur - prev }
		prev = cur
	end
	return { count = count, items = items, next = base + last - 1 }
end

local function cffNumber(d, pos, fin, realOk)
	if pos > fin then
		return nil
	end
	local b = u8(d, pos)
	if b >= 32 and b <= 246 then
		return b - 139, pos + 1
	elseif b >= 247 and b <= 250 then
		if pos + 1 > fin then
			return nil
		end
		return (b - 247) * 256 + u8(d, pos + 1) + 108, pos + 2
	elseif b >= 251 and b <= 254 then
		if pos + 1 > fin then
			return nil
		end
		return -(b - 251) * 256 - u8(d, pos + 1) - 108, pos + 2
	elseif b == 28 then
		if pos + 2 > fin then
			return nil
		end
		return i16(d, pos + 1), pos + 3
	elseif b == 29 then
		if not realOk then
			return nil
		end
		if pos + 4 > fin then
			return nil
		end
		return i32(d, pos + 1), pos + 5
	elseif b == 30 then
		if not realOk then
			return nil
		end
		local chars = {}
		local p = pos + 1
		local done = false
		while p <= fin and not done do
			local by = u8(d, p)
			p = p + 1
			for _, nib in ipairs({ math.floor(by / 16), by % 16 }) do
				if nib == 0xF then
					done = true
					break
				elseif nib <= 9 then
					chars[#chars + 1] = string.char(48 + nib)
				elseif nib == 0xA then
					chars[#chars + 1] = "."
				elseif nib == 0xB then
					chars[#chars + 1] = "e"
				elseif nib == 0xC then
					chars[#chars + 1] = "e-"
				elseif nib == 0xE then
					chars[#chars + 1] = "-"
				else
					return nil
				end
			end
		end
		if not done then
			return nil
		end
		return tonumber(table.concat(chars)) or 0, p
	end
	return nil
end

local function parseCFFDict(d, pos, fin, what, cff2)
	local dict = {}
	local args = {}
	local p = pos
	while p <= fin do
		local b = u8(d, p)
		if b == 12 then
			if p + 1 > fin then
				return nil, ("CFF %s: truncated escape op"):format(what)
			end
			dict[12 * 256 + u8(d, p + 1)] = args
			args = {}
			p = p + 2
		elseif b <= 21 or (cff2 and (b == 22 or b == 24 or b == 25)) then
			dict[b] = args
			args = {}
			p = p + 1
		else
			local v, np = cffNumber(d, p, fin, true)
			if not v then
				return nil, ("CFF %s: bad DICT number"):format(what)
			end
			args[#args + 1] = v
			p = np
		end
	end
	return dict
end

local function cffSID(cff, sid)
	if sid < 0 then
		return nil
	end
	if sid < 391 then
		return CFF_STANDARD_STRINGS[sid + 1]
	end
	local extra = cff.strings
	if extra then
		local it = extra.items[sid - 391 + 1]
		if it then
			return string.sub(cff.data, it.pos, it.pos + it.len - 1)
		end
	end
	return nil
end

local function parseCFFCharset(d, cffStart, cffOff, cffLen, numGlyphs, isCID)
	local fin = cffStart + cffLen - 1
	local pos = cffStart + cffOff
	if pos < cffStart or pos > fin then
		return nil, "CFF charset out of range"
	end
	local fmt = u8(d, pos)
	local vals = { [0] = 0 }
	local gid = 1
	if fmt == 0 then
		if pos + 1 + (numGlyphs - 1) * 2 > fin + 1 then
			return nil, "CFF charset out of range"
		end
		for i = 1, numGlyphs - 1 do
			vals[gid] = u16(d, pos + 1 + (i - 1) * 2)
			gid = gid + 1
		end
	elseif fmt == 1 or fmt == 2 then
		local p = pos + 1
		local rangeSize = (fmt == 1) and 3 or 5
		while gid < numGlyphs do
			if p + rangeSize - 1 > fin + 1 then
				return nil, "CFF charset out of range"
			end
			local first = u16(d, p)
			local nLeft = (fmt == 1) and u8(d, p + 2) or u16(d, p + 2)
			for k = 0, nLeft do
				if gid >= numGlyphs then
					break
				end
				vals[gid] = first + k
				gid = gid + 1
			end
			p = p + rangeSize
		end
	else
		return nil, ("unsupported CFF charset format %d"):format(fmt)
	end
	return { vals = vals, isCID = isCID }
end

local function parseFDSelect(d, pos, fin, numGlyphs)
	if pos > fin then
		return nil, "CFF FDSelect out of range"
	end
	local fmt = u8(d, pos)
	local fd = {}
	if fmt == 0 then
		if pos + 1 + numGlyphs - 1 > fin + 1 then
			return nil, "CFF FDSelect out of range"
		end
		for gid = 0, numGlyphs - 1 do
			fd[gid] = u8(d, pos + 1 + gid)
		end
	elseif fmt == 3 or fmt == 4 then
		local w = (fmt == 3) and 2 or 4
		if pos + 2 > fin + 1 then
			return nil, "CFF FDSelect out of range"
		end
		local nRanges = u16(d, pos + 1)
		if nRanges < 1 or nRanges > numGlyphs + 1 then
			return nil, "bad CFF FDSelect range count"
		end
		local p = pos + 3
		local recSize = w + 1
		if p + nRanges * recSize + w - 1 > fin + 1 then
			return nil, "CFF FDSelect out of range"
		end
		for r = 0, nRanges - 1 do
			local first = (w == 2) and u16(d, p) or u32(d, p)
			local fdi = u8(d, p + w)
			local nxt
			if r + 1 < nRanges then
				nxt = (w == 2) and u16(d, p + recSize) or u32(d, p + recSize)
			else
				nxt = (w == 2) and u16(d, p + recSize) or u32(d, p + recSize)
			end
			for gid = first, nxt - 1 do
				if gid >= 0 and gid < numGlyphs then
					fd[gid] = fdi
				end
			end
			p = p + recSize
		end
	else
		return nil, ("unsupported CFF FDSelect format %d"):format(fmt)
	end
	for gid = 0, numGlyphs - 1 do
		if fd[gid] == nil then
			return nil, "CFF FDSelect has gaps"
		end
	end
	return fd
end

local function checkCFFMatrix(fm)
	if not fm then
		return 0.001
	end
	if #fm < 6 or not fm[1] or fm[1] == 0 or fm[1] ~= fm[4] or (fm[2] or 0) ~= 0 or (fm[3] or 0) ~= 0 then
		return nil
	end
	return fm[1]
end

local function readCFF2Index(d, pos, what)
	if pos < 1 or pos + 3 > #d then
		return nil, ("CFF2 %s: INDEX header past end of data"):format(what)
	end
	local count = u32(d, pos)
	if count == 0 then
		return { count = 0, items = {}, next = pos + 4 }
	end
	if count > 65535 then
		return nil, ("CFF2 %s: bad INDEX count"):format(what)
	end
	local offSize = u8(d, pos + 4)
	if offSize < 1 or offSize > 4 then
		return nil, ("CFF2 %s: bad INDEX offSize %d"):format(what, offSize)
	end
	local function getOff(i)
		local o = pos + 5 + (i - 1) * offSize
		if offSize == 1 then
			return u8(d, o)
		elseif offSize == 2 then
			return u16(d, o)
		elseif offSize == 3 then
			return u8(d, o) * 65536 + u16(d, o + 1)
		else
			return u32(d, o)
		end
	end
	local base = pos + 5 + (count + 1) * offSize
	local last = getOff(count + 1)
	if last < 1 or base + last - 2 > #d + 1 then
		return nil, ("CFF2 %s: INDEX data past end of table"):format(what)
	end
	local items = {}
	local prev = getOff(1)
	if prev < 1 then
		return nil, ("CFF2 %s: bad INDEX offset"):format(what)
	end
	for i = 1, count do
		local cur = getOff(i + 1)
		if cur < prev then
			return nil, ("CFF2 %s: bad INDEX offsets"):format(what)
		end
		items[i] = { pos = base + prev - 1, len = cur - prev }
		prev = cur
	end
	return { count = count, items = items, next = base + last - 1 }
end

local function parseCFF(d, cffStart, cffLen, numGlyphs)
	local fin = cffStart + cffLen - 1
	if cffLen < 4 or fin > #d then
		return nil, "CFF table out of range"
	end
	local major, minor = u8(d, cffStart), u8(d, cffStart + 1)
	if major == 2 then
		return nil, "CFF2 (variable) outlines are not supported yet"
	end
	if major ~= 1 then
		return nil, ("unsupported CFF version %d.%d"):format(major, minor)
	end
	local hdrSize = u8(d, cffStart + 2)
	if hdrSize < 4 then
		return nil, "bad CFF header size"
	end
	local p = cffStart + hdrSize
	local nameIdx, err = readCFFIndex(d, p, "name")
	if not nameIdx then
		return nil, err
	end
	local fontName
	if nameIdx.count >= 1 then
		local it = nameIdx.items[1]
		fontName = string.sub(d, it.pos, it.pos + it.len - 1)
	end
	local topIdx, err2 = readCFFIndex(d, nameIdx.next, "top dict")
	if not topIdx then
		return nil, err2
	end
	if topIdx.count < 1 then
		return nil, "CFF has no Top DICT"
	end
	local strIdx, err3 = readCFFIndex(d, topIdx.next, "string")
	if not strIdx then
		return nil, err3
	end
	local gsubrIdx, err4 = readCFFIndex(d, strIdx.next, "global subrs")
	if not gsubrIdx then
		return nil, err4
	end
	local tit = topIdx.items[1]
	local top, err5 = parseCFFDict(d, tit.pos, tit.pos + tit.len - 1, "top")
	if not top then
		return nil, err5
	end
	local ros = top[12 * 256 + 30]
	local fdArrD = top[12 * 256 + 36]
	local isCID = ros ~= nil
	if not isCID and fdArrD then
		return nil, "CFF FDArray without ROS; unsupported"
	end
	local cst = top[12 * 256 + 6]
	if cst and cst[1] ~= 2 then
		return nil, ("unsupported CharstringType %d"):format(cst[1] or -1)
	end
	local csOff = top[17]
	if not csOff then
		return nil, "CFF Top DICT has no CharStrings"
	end
	local csIdx, err6 = readCFFIndex(d, cffStart + csOff[1], "charstrings")
	if not csIdx then
		return nil, err6
	end
	if csIdx.count ~= numGlyphs then
		return nil, ("CFF glyph count %d != maxp numGlyphs %d"):format(csIdx.count, numGlyphs)
	end
	local fontMatrix = checkCFFMatrix(top[12 * 256 + 7])
	if not fontMatrix then
		return nil, "unsupported CFF FontMatrix"
	end
	local function parsePrivateAt(pstart, psize, what)
		if psize < 0 or pstart < cffStart or pstart + psize - 1 > fin then
			return nil, ("CFF %s DICT out of range"):format(what)
		end
		local pd, errP = parseCFFDict(d, pstart, pstart + psize - 1, what)
		if not pd then
			return nil, errP
		end
		local subrs = nil
		if pd[19] then
			if #pd[19] < 1 then
				return nil, ("bad CFF %s Subrs entry"):format(what)
			end
			local sIdx, errS = readCFFIndex(d, pstart + pd[19][1], "local subrs")
			if not sIdx then
				return nil, errS
			end
			subrs = sIdx
		end
		return {
			dict = pd,
			start = pstart,
			subrs = subrs,
			defaultWidthX = (pd[20] and pd[20][1]) or 0,
			nominalWidthX = (pd[21] and pd[21][1]) or 0,
		}
	end
	local cff = {
		start = cffStart,
		name = fontName,
		data = d,
		strings = strIdx,
		charstrings = csIdx,
		globalSubrs = gsubrIdx,
		private = nil,
		fontMatrix = fontMatrix,
		isCID = isCID,
	}
	if not isCID then
		local priv = nil
		local privD = top[18]
		if privD then
			if #privD < 2 then
				return nil, "bad CFF Private entry"
			end
			local perr
			priv, perr = parsePrivateAt(cffStart + privD[2], privD[1], "private")
			if not priv then
				return nil, perr
			end
		end
		cff.private = priv
		cff.scale = fontMatrix
	else
		if #ros < 3 then
			return nil, "bad CFF ROS entry"
		end
		if not fdArrD or #fdArrD < 1 then
			return nil, "CFF CID font has no FDArray"
		end
		local fdSelD = top[12 * 256 + 37]
		if not fdSelD or #fdSelD < 1 then
			return nil, "CFF CID font has no FDSelect"
		end
		local fdIdx, ferr = readCFFIndex(d, cffStart + fdArrD[1], "FDArray")
		if not fdIdx then
			return nil, ferr
		end
		if fdIdx.count < 1 or fdIdx.count > 256 then
			return nil, "bad CFF FDArray count"
		end
		local fds = {}
		for i = 1, fdIdx.count do
			local it = fdIdx.items[i]
			local fd, ferr2 = parseCFFDict(d, it.pos, it.pos + it.len - 1, "FD")
			if not fd then
				return nil, ferr2
			end
			local fpriv = nil
			if fd[18] then
				if #fd[18] < 2 then
					return nil, "bad CFF FD Private entry"
				end
				local perr
				fpriv, perr = parsePrivateAt(cffStart + fd[18][2], fd[18][1], "FD private")
				if not fpriv then
					return nil, perr
				end
			end
			local fscale
			if fd[12 * 256 + 7] then
				fscale = checkCFFMatrix(fd[12 * 256 + 7])
				if not fscale then
					return nil, "unsupported CFF FD FontMatrix"
				end
			else
				fscale = fontMatrix
			end
			local fname = nil
			local fnD = fd[12 * 256 + 38]
			if fnD and fnD[1] then
				local it2 = strIdx.items[fnD[1] - 391 + 1]
				if it2 then
					fname = string.sub(d, it2.pos, it2.pos + it2.len - 1)
				end
				if not fname and fnD[1] < 391 then
					fname = CFF_STANDARD_STRINGS[fnD[1] + 1]
				end
			end
			fds[i - 1] = { priv = fpriv, scale = fscale, name = fname }
		end
		local fdOf, ferr3 = parseFDSelect(d, cffStart + fdSelD[1], fin, numGlyphs)
		if not fdOf then
			return nil, ferr3
		end
		for gid = 0, numGlyphs - 1 do
			if not fds[fdOf[gid]] then
				return nil, "CFF FDSelect references missing FD"
			end
		end
		cff.fds = fds
		cff.fdOf = fdOf
	end
	local csD = top[15]
	if csD and #csD >= 1 then
		local cs, cerr = parseCFFCharset(d, cffStart, csD[1], cffLen, numGlyphs, isCID)
		if not cs then
			return nil, cerr
		end
		cff.charset = cs
		local names, sidMap = {}, {}
		names[0] = ".notdef"
		if not isCID then
			sidMap[".notdef"] = 0
		end
		for gid = 1, numGlyphs - 1 do
			local v = cs.vals[gid]
			if v ~= nil then
				if isCID then
					names[gid] = ("cid%05d"):format(v)
				else
					local nm = cffSID(cff, v)
					names[gid] = nm
					if nm then
						sidMap[nm] = gid
					end
				end
			end
		end
		cff.charsetNames = names
		cff.sidToGid = sidMap
	end
	if isCID and ros then
		cff.ros = {
			registry = cffSID(cff, ros[1]),
			ordering = cffSID(cff, ros[2]),
			supplement = ros[3],
		}
	end
	return cff
end

local function parseCFF2Regions(d, vsStart, fin)
	if vsStart + 7 > fin + 1 then
		return nil, "CFF2 VariationStore out of range"
	end
	if u16(d, vsStart) ~= 1 then
		return nil, "unsupported CFF2 VariationStore version"
	end
	local rlOff = u32(d, vsStart + 2)
	local rl = vsStart + rlOff
	if rl + 3 > fin + 1 then
		return nil, "CFF2 region list out of range"
	end
	local nRegions = u16(d, rl + 2)
	if nRegions > 64 then
		return nil, "bad CFF2 region count"
	end
	return nRegions
end

local function parseCFF2(d, cffStart, cffLen, numGlyphs)
	local fin = cffStart + cffLen - 1
	if cffLen < 5 or fin > #d then
		return nil, "CFF2 table out of range"
	end
	if u8(d, cffStart) ~= 2 then
		return nil, "not a CFF2 table"
	end
	local hdrSize = u8(d, cffStart + 2)
	if hdrSize < 5 then
		return nil, "bad CFF2 header size"
	end
	local topLen = u16(d, cffStart + 3)
	local topPos = cffStart + hdrSize
	if topLen < 1 or topPos + topLen - 1 > fin + 1 then
		return nil, "bad CFF2 Top DICT"
	end
	local top, err = parseCFFDict(d, topPos, topPos + topLen - 1, "CFF2 top", true)
	if not top then
		return nil, err
	end
	local gsubrIdx, err2 = readCFF2Index(d, topPos + topLen, "global subrs")
	if not gsubrIdx then
		return nil, err2
	end
	local csD = top[17]
	if not csD or #csD < 1 then
		return nil, "CFF2 Top DICT has no CharStrings"
	end
	local csIdx, err3 = readCFF2Index(d, cffStart + csD[1], "charstrings")
	if not csIdx then
		return nil, err3
	end
	if csIdx.count ~= numGlyphs then
		return nil, ("CFF2 glyph count %d != maxp numGlyphs %d"):format(csIdx.count, numGlyphs)
	end
	local fontMatrix = checkCFFMatrix(top[12 * 256 + 7])
	if not fontMatrix then
		return nil, "unsupported CFF2 FontMatrix"
	end
	local cff = {
		start = cffStart,
		data = d,
		strings = nil,
		charstrings = csIdx,
		globalSubrs = gsubrIdx,
		private = nil,
		fontMatrix = fontMatrix,
		scale = fontMatrix,
		isCID = false,
		isCFF2 = true,
		numRegions = 0,
	}
	local fdArrD = top[12 * 256 + 36]
	if fdArrD then
		if #fdArrD < 1 then
			return nil, "bad CFF2 FDArray entry"
		end
		local fdIdx, ferr = readCFF2Index(d, cffStart + fdArrD[1], "FDArray")
		if not fdIdx then
			return nil, ferr
		end
		if fdIdx.count < 1 or fdIdx.count > 256 then
			return nil, "bad CFF2 FDArray count"
		end
		local fds = {}
		for i = 1, fdIdx.count do
			local it = fdIdx.items[i]
			local fd, ferr2 = parseCFFDict(d, it.pos, it.pos + it.len - 1, "CFF2 FD", true)
			if not fd then
				return nil, ferr2
			end
			local fpriv = nil
			if fd[18] then
				if #fd[18] < 2 then
					return nil, "bad CFF2 FD Private entry"
				end
				local pstart, psize = cffStart + fd[18][2], fd[18][1]
				if psize < 0 or pstart < cffStart or pstart + psize - 1 > fin then
					return nil, "CFF2 Private DICT out of range"
				end
				local pd, perr = parseCFFDict(d, pstart, pstart + psize - 1, "CFF2 private", true)
				if not pd then
					return nil, perr
				end
				local subrs = nil
				if pd[19] then
					if #pd[19] < 1 then
						return nil, "bad CFF2 Subrs entry"
					end
					local sIdx, serr = readCFF2Index(d, pstart + pd[19][1], "local subrs")
					if not sIdx then
						return nil, serr
					end
					subrs = sIdx
				end
				fpriv = {
					dict = pd,
					start = pstart,
					subrs = subrs,
					defaultWidthX = 0,
					nominalWidthX = 0,
				}
			end
			local fscale
			if fd[12 * 256 + 7] then
				fscale = checkCFFMatrix(fd[12 * 256 + 7])
				if not fscale then
					return nil, "unsupported CFF2 FD FontMatrix"
				end
			else
				fscale = fontMatrix
			end
			fds[i - 1] = { priv = fpriv, scale = fscale }
		end
		local fdOf
		local fdSelD = top[12 * 256 + 37]
		if fdSelD then
			if #fdSelD < 1 then
				return nil, "bad CFF2 FDSelect entry"
			end
			local ferr3
			fdOf, ferr3 = parseFDSelect(d, cffStart + fdSelD[1], fin, numGlyphs)
			if not fdOf then
				return nil, ferr3
			end
		elseif fdIdx.count == 1 then
			fdOf = {}
			for gid = 0, numGlyphs - 1 do
				fdOf[gid] = 0
			end
		else
			return nil, "CFF2 multi-FD font has no FDSelect"
		end
		for gid = 0, numGlyphs - 1 do
			if not fds[fdOf[gid]] then
				return nil, "CFF2 FDSelect references missing FD"
			end
		end
		cff.fds = fds
		cff.fdOf = fdOf
		cff.isCID = true
	end
	local vsD = top[24]
	if vsD then
		if #vsD < 1 then
			return nil, "bad CFF2 VariationStore entry"
		end
		local nr, nerr = parseCFF2Regions(d, cffStart + vsD[1], fin)
		if nr == nil then
			return nil, nerr
		end
		cff.numRegions = nr
	end
	return cff
end

local function cffBias(n)
	if n < 1240 then
		return 107
	end
	if n < 33900 then
		return 1131
	end
	return 32768
end

local interpCharstring
local function doSeac(d, st, cff, args)
	if cff.isCID then
		return "seac is not supported in CID-keyed fonts"
	end
	if (st.seacDepth or 0) >= 4 then
		return "seac nesting too deep"
	end
	local adx, ady = args[1], args[2]
	local bName = CFF_STANDARD_ENCODING[math.floor(args[3] or -1)]
	local aName = CFF_STANDARD_ENCODING[math.floor(args[4] or -1)]
	if not bName or not aName then
		return "bad seac character code"
	end
	local sidMap = cff.sidToGid or {}
	local bGid, aGid = sidMap[bName], sidMap[aName]
	if bGid == nil or aGid == nil then
		return ("seac component '%s'/'%s' missing from charset"):format(bName, aName)
	end
	local ox, oy = st.x, st.y
	st.seacDepth = (st.seacDepth or 0) + 1
	local bit = cff.charstrings.items[bGid + 1]
	local ait = cff.charstrings.items[aGid + 1]
	if not bit or not ait then
		st.seacDepth = st.seacDepth - 1
		return "seac component out of range"
	end
	local _, err = interpCharstring(d, bit.pos, bit.pos + bit.len - 1, st, cff)
	if not err then
		st.x, st.y = ox + adx, oy + ady
		_, err = interpCharstring(d, ait.pos, ait.pos + ait.len - 1, st, cff)
	end
	st.seacDepth = st.seacDepth - 1
	st.x, st.y = ox, oy
	return err
end

interpCharstring = function(d, pos, fin, st, cff)
	local stack = st.stack
	while pos <= fin do
		local b = u8(d, pos)
		pos = pos + 1
		if b == 12 then
			if pos > fin then
				return nil, "truncated charstring escape"
			end
			local b2 = u8(d, pos)
			pos = pos + 1
			local n = st.n
			if b2 == 0 then
				st.n = 0
			elseif b2 == 3 then
				if n < 2 then
					return nil, "charstring stack underflow (and)"
				end
				stack[n - 1] = (stack[n - 1] ~= 0 and stack[n] ~= 0) and 1 or 0
				st.n = n - 1
			elseif b2 == 4 then
				if n < 2 then
					return nil, "charstring stack underflow (or)"
				end
				stack[n - 1] = (stack[n - 1] ~= 0 or stack[n] ~= 0) and 1 or 0
				st.n = n - 1
			elseif b2 == 5 then
				if n < 1 then
					return nil, "charstring stack underflow (not)"
				end
				stack[n] = (stack[n] == 0) and 1 or 0
			elseif b2 == 9 then
				if n < 1 then
					return nil, "charstring stack underflow (abs)"
				end
				stack[n] = math.abs(stack[n])
			elseif b2 == 10 or b2 == 11 or b2 == 24 then
				if n < 2 then
					return nil, "charstring stack underflow (arith)"
				end
				local y, x = stack[n], stack[n - 1]
				if b2 == 10 then
					stack[n - 1] = x + y
				elseif b2 == 11 then
					stack[n - 1] = x - y
				else
					stack[n - 1] = x * y
				end
				st.n = n - 1
			elseif b2 == 12 then
				if n < 2 then
					return nil, "charstring stack underflow (div)"
				end
				local y, x = stack[n], stack[n - 1]
				stack[n - 1] = (y == 0) and 0 or (x / y)
				st.n = n - 1
			elseif b2 == 14 then
				if n < 1 then
					return nil, "charstring stack underflow (neg)"
				end
				stack[n] = -stack[n]
			elseif b2 == 15 then
				if n < 2 then
					return nil, "charstring stack underflow (eq)"
				end
				stack[n - 1] = (stack[n - 1] == stack[n]) and 1 or 0
				st.n = n - 1
			elseif b2 == 18 then
				if n < 1 then
					return nil, "charstring stack underflow (drop)"
				end
				st.n = n - 1
			elseif b2 == 20 or b2 == 21 then
				if b2 == 20 then
					if n < 2 then
						return nil, "charstring stack underflow (put)"
					end
					local v, i = stack[n - 1], math.floor(stack[n])
					if i >= 0 and i < 32 then
						st.transient[i] = v
					end
					st.n = n - 2
				else
					if n < 1 then
						return nil, "charstring stack underflow (get)"
					end
					local i = math.floor(stack[n])
					stack[n] = (i >= 0 and i < 32) and (st.transient[i] or 0) or 0
				end
			elseif b2 == 22 then
				if n < 4 then
					return nil, "charstring stack underflow (ifelse)"
				end
				stack[n - 3] = (stack[n - 1] <= stack[n]) and stack[n - 3] or stack[n - 2]
				st.n = n - 3
			elseif b2 == 23 then
				stack[n + 1] = math.random()
				st.n = n + 1
			elseif b2 == 26 then
				if n < 1 then
					return nil, "charstring stack underflow (sqrt)"
				end
				stack[n] = (stack[n] < 0) and 0 or math.sqrt(stack[n])
			elseif b2 == 27 then
				if n < 1 then
					return nil, "charstring stack underflow (dup)"
				end
				stack[n + 1] = stack[n]
				st.n = n + 1
			elseif b2 == 28 then
				if n < 2 then
					return nil, "charstring stack underflow (exch)"
				end
				stack[n - 1], stack[n] = stack[n], stack[n - 1]
			elseif b2 == 29 then
				if n < 1 then
					return nil, "charstring stack underflow (index)"
				end
				local i = math.floor(stack[n])
				if i < 0 then
					return nil, "charstring index out of range"
				end
				stack[n] = (i >= n) and 0 or stack[n - 1 - i]
			elseif b2 == 30 then
				if n < 2 then
					return nil, "charstring stack underflow (roll)"
				end
				local cnt = math.floor(stack[n - 1])
				local amt = math.floor(stack[n])
				st.n = n - 2
				if cnt < 0 or cnt > st.n then
					return nil, "charstring roll out of range"
				end
				if cnt > 0 then
					local r = ((amt % cnt) + cnt) % cnt
					if r ~= 0 then
						local base = st.n - cnt
						local tmp = {}
						for i = 1, cnt do
							tmp[i] = stack[base + ((i - 1 - r) % cnt) + 1]
						end
						for i = 1, cnt do
							stack[base + i] = tmp[i]
						end
					end
				end
			elseif b2 == 34 then
				if n < 7 then
					return nil, "charstring stack underflow (hflex)"
				end
				local a =
					{ stack[n - 6], stack[n - 5], stack[n - 4], stack[n - 3], stack[n - 2], stack[n - 1], stack[n] }
				st.n = 0
				st.cubic(st, a[1], 0, a[2], a[3], a[4], 0)
				st.cubic(st, a[5], 0, a[6], -a[3], a[7], 0)
			elseif b2 == 35 then
				if n < 13 then
					return nil, "charstring stack underflow (flex)"
				end
				local a = {}
				for i = 0, 11 do
					a[i + 1] = stack[n - 12 + i]
				end
				st.n = 0
				st.cubic(st, a[1], a[2], a[3], a[4], a[5], a[6])
				st.cubic(st, a[7], a[8], a[9], a[10], a[11], a[12])
			elseif b2 == 36 then
				if n < 9 then
					return nil, "charstring stack underflow (hflex1)"
				end
				local a = {}
				for i = 0, 8 do
					a[i + 1] = stack[n - 8 + i]
				end
				st.n = 0
				local dy6 = -(a[2] + a[4] + a[5] + a[8])
				st.cubic(st, a[1], a[2], a[3], a[4], a[5], 0)
				st.cubic(st, a[6], 0, a[7], a[8], a[9], dy6)
			elseif b2 == 37 then
				if n < 11 then
					return nil, "charstring stack underflow (flex1)"
				end
				local a = {}
				for i = 0, 10 do
					a[i + 1] = stack[n - 10 + i]
				end
				st.n = 0
				local dx, dy = 0, 0
				for i = 1, 5 do
					dx, dy = dx + a[2 * i - 1], dy + a[2 * i]
				end
				local dx6, dy6
				if math.abs(dx) > math.abs(dy) then
					dx6, dy6 = a[11], -dy
				else
					dx6, dy6 = -dx, a[11]
				end
				st.cubic(st, a[1], a[2], a[3], a[4], a[5], a[6])
				st.cubic(st, a[7], a[8], a[9], a[10], dx6, dy6)
			else
				return nil, ("unsupported charstring op 12 %d"):format(b2)
			end
		elseif b <= 27 or b == 29 or b == 30 or b == 31 then
			if b == 1 or b == 3 or b == 18 or b == 23 then
				local n = st.n
				if not st.widthSet and not st.noWidth then
					st.widthSet = true
					if n % 2 == 1 then
						st.width = stack[1]
						for i = 1, n - 1 do
							stack[i] = stack[i + 1]
						end
						n = n - 1
					end
				end
				if st.noWidth and n % 2 == 1 then
					return nil, "CFF2 stem arguments must be even (no width)"
				end
				st.stems = st.stems + math.floor(n / 2)
				st.n = 0
			elseif b == 19 or b == 20 then
				local n = st.n
				if not st.widthSet and not st.noWidth then
					st.widthSet = true
					if n % 2 == 1 then
						st.width = stack[1]
						for i = 1, n - 1 do
							stack[i] = stack[i + 1]
						end
						n = n - 1
					end
				end
				if st.noWidth and n % 2 == 1 then
					return nil, "CFF2 stem arguments must be even (no width)"
				end
				st.stems = st.stems + math.floor(n / 2)
				st.n = 0
				pos = pos + math.ceil(st.stems / 8)
				if pos - 1 > fin + 1 then
					return nil, "truncated hint mask"
				end
			elseif b == 4 or b == 21 or b == 22 then
				local need = (b == 21) and 2 or 1
				local n = st.n
				if n < need then
					return nil, "charstring stack underflow (moveto)"
				end
				if not st.widthSet and not st.noWidth then
					st.widthSet = true
					if (n - need) % 2 == 1 then
						st.width = stack[1]
						for i = 1, n - 1 do
							stack[i] = stack[i + 1]
						end
						n = n - 1
					end
				end
				if st.noWidth and n ~= need then
					return nil, "CFF2 moveto takes exact arguments (no width)"
				end
				local dx, dy = 0, 0
				if b == 21 then
					dx, dy = stack[n - 1], stack[n]
				elseif b == 22 then
					dx = stack[n]
				else
					dy = stack[n]
				end
				st.n = 0
				st.moveTo(st, dx, dy)
			elseif b == 5 or b == 6 or b == 7 then
				local n = st.n
				if b == 5 then
					if n < 2 or n % 2 == 1 then
						return nil, "charstring stack underflow (rlineto)"
					end
					local i = 1
					while i <= n do
						st.lineTo(st, stack[i], stack[i + 1])
						i = i + 2
					end
				else
					if n < 1 then
						return nil, "charstring stack underflow (lineto)"
					end
					local horiz = (b == 6)
					for i = 1, n do
						if horiz then
							st.lineTo(st, stack[i], 0)
						else
							st.lineTo(st, 0, stack[i])
						end
						horiz = not horiz
					end
				end
				st.n = 0
			elseif b == 8 then
				local n = st.n
				if n < 6 or n % 6 ~= 0 then
					return nil, "charstring stack underflow (rrcurveto)"
				end
				local i = 1
				while i <= n do
					st.cubic(st, stack[i], stack[i + 1], stack[i + 2], stack[i + 3], stack[i + 4], stack[i + 5])
					i = i + 6
				end
				st.n = 0
			elseif b == 24 then
				local n = st.n
				if n < 8 or (n - 2) % 6 ~= 0 then
					return nil, "charstring stack underflow (rcurveline)"
				end
				local i = 1
				while i <= n - 2 do
					st.cubic(st, stack[i], stack[i + 1], stack[i + 2], stack[i + 3], stack[i + 4], stack[i + 5])
					i = i + 6
				end
				st.lineTo(st, stack[n - 1], stack[n])
				st.n = 0
			elseif b == 25 then
				local n = st.n
				if n < 8 or (n - 6) % 2 ~= 0 then
					return nil, "charstring stack underflow (rlinecurve)"
				end
				local i = 1
				while i <= n - 6 do
					st.lineTo(st, stack[i], stack[i + 1])
					i = i + 2
				end
				st.cubic(st, stack[n - 5], stack[n - 4], stack[n - 3], stack[n - 2], stack[n - 1], stack[n])
				st.n = 0
			elseif b == 26 then
				local n = st.n
				local args, dx1 = {}, 0
				if n % 2 == 1 then
					if n < 1 then
						return nil, "charstring stack underflow (vvcurveto)"
					end
					dx1 = stack[1]
					for i = 2, n do
						args[#args + 1] = stack[i]
					end
				else
					for i = 1, n do
						args[#args + 1] = stack[i]
					end
				end
				st.n = 0
				local i = 1
				while i <= #args do
					if i + 3 > #args then
						return nil, "charstring stack underflow (vvcurveto)"
					end
					st.cubic(st, dx1, args[i], args[i + 1], args[i + 2], 0, args[i + 3])
					dx1 = 0
					i = i + 4
				end
			elseif b == 27 then
				local n = st.n
				local args, dy1 = {}, 0
				if n % 2 == 1 then
					if n < 1 then
						return nil, "charstring stack underflow (hhcurveto)"
					end
					dy1 = stack[1]
					for i = 2, n do
						args[#args + 1] = stack[i]
					end
				else
					for i = 1, n do
						args[#args + 1] = stack[i]
					end
				end
				st.n = 0
				local i = 1
				while i <= #args do
					if i + 3 > #args then
						return nil, "charstring stack underflow (hhcurveto)"
					end
					st.cubic(st, args[i], dy1, args[i + 1], args[i + 2], args[i + 3], 0)
					dy1 = 0
					i = i + 4
				end
			elseif b == 30 or b == 31 then
				local n = st.n
				if n < 4 then
					return nil, "charstring stack underflow (vh/hvcurveto)"
				end
				local args = {}
				for i = 1, n do
					args[i] = stack[i]
				end
				st.n = 0
				local vert = (b == 30)
				while #args > 0 do
					if vert then
						if #args < 4 then
							return nil, "charstring stack underflow (vhcurveto)"
						end
						if #args == 5 then
							st.cubic(st, 0, args[1], args[2], args[3], args[4], args[5])
							args = {}
						else
							st.cubic(st, 0, args[1], args[2], args[3], args[4], 0)
							local rest = {}
							for i = 5, #args do
								rest[#rest + 1] = args[i]
							end
							args = rest
						end
					else
						if #args < 4 then
							return nil, "charstring stack underflow (hvcurveto)"
						end
						if #args == 5 then
							st.cubic(st, args[1], 0, args[2], args[3], args[5], args[4])
							args = {}
						else
							st.cubic(st, args[1], 0, args[2], args[3], 0, args[4])
							local rest = {}
							for i = 5, #args do
								rest[#rest + 1] = args[i]
							end
							args = rest
						end
					end
					vert = not vert
				end
			elseif b == 10 or b == 29 then
				if st.n < 1 then
					return nil, "charstring stack underflow (callsubr)"
				end
				local num = stack[st.n]
				st.n = st.n - 1
				local idx
				if b == 10 then
					local sub = st.priv and st.priv.subrs
					if not sub then
						return nil, "charstring calls missing local subrs"
					end
					idx = math.floor(num) + cffBias(sub.count)
					if idx < 0 or idx >= sub.count then
						return nil, "charstring local subr out of range"
					end
					if st.depth >= 10 then
						return nil, "charstring subr nesting too deep"
					end
					st.depth = st.depth + 1
					local it = sub.items[idx + 1]
					local _, err = interpCharstring(d, it.pos, it.pos + it.len - 1, st, cff)
					st.depth = st.depth - 1
					if err then
						return nil, err
					end
				else
					local sub = cff.globalSubrs
					idx = math.floor(num) + cffBias(sub.count)
					if idx < 0 or idx >= sub.count then
						return nil, "charstring global subr out of range"
					end
					if st.depth >= 10 then
						return nil, "charstring subr nesting too deep"
					end
					st.depth = st.depth + 1
					local it = sub.items[idx + 1]
					local _, err = interpCharstring(d, it.pos, it.pos + it.len - 1, st, cff)
					st.depth = st.depth - 1
					if err then
						return nil, err
					end
				end
			elseif b == 11 then
				if st.depth == 0 then
					return nil, "charstring return outside subr"
				end
				return pos, nil
			elseif b == 14 then
				local n = st.n
				local seacArgs = nil
				if st.noWidth then
					if n ~= 0 then
						return nil, "bad CFF2 endchar argument count"
					end
				elseif not st.widthSet and n == 5 then
					st.width = stack[1]
					st.widthSet = true
					seacArgs = { stack[2], stack[3], stack[4], stack[5] }
					n = 4
				elseif not st.widthSet and n == 1 then
					st.width = stack[1]
					st.widthSet = true
				elseif n == 4 then
					seacArgs = { stack[1], stack[2], stack[3], stack[4] }
				end
				st.n = 0
				if seacArgs then
					local err = doSeac(d, st, cff, seacArgs)
					if err then
						return nil, err
					end
					st.close(st)
					return pos, nil
				end
				if n ~= 0 and n ~= 1 then
					return nil, "bad endchar argument count"
				end
				st.close(st)
				return pos, nil
			elseif b == 15 or b == 16 then
				if not st.noWidth then
					return nil, "variable (CFF2) charstrings are not supported"
				end
				if b == 15 then
					if st.n < 1 then
						return nil, "charstring stack underflow (vsindex)"
					end
					st.vsindex = stack[st.n]
					st.n = st.n - 1
				else
					if st.n < 1 then
						return nil, "charstring stack underflow (blend)"
					end
					local nb = math.floor(stack[st.n])
					st.n = st.n - 1
					if nb < 1 or nb > 96 then
						return nil, "bad blend count"
					end
					local drop = nb * (st.numRegions or 0)
					if drop > st.n - nb then
						return nil, "charstring stack underflow (blend)"
					end
					st.n = st.n - drop
				end
			else
				return nil, ("unsupported charstring op %d"):format(b)
			end
		elseif b == 28 then
			if pos + 1 > fin then
				return nil, "truncated charstring number"
			end
			st.n = st.n + 1
			stack[st.n] = i16(d, pos)
			pos = pos + 2
		elseif b >= 32 and b <= 246 then
			st.n = st.n + 1
			stack[st.n] = b - 139
		elseif b >= 247 and b <= 250 then
			if pos > fin then
				return nil, "truncated charstring number"
			end
			st.n = st.n + 1
			stack[st.n] = (b - 247) * 256 + u8(d, pos) + 108
			pos = pos + 1
		elseif b >= 251 and b <= 254 then
			if pos > fin then
				return nil, "truncated charstring number"
			end
			st.n = st.n + 1
			stack[st.n] = -(b - 251) * 256 - u8(d, pos) - 108
			pos = pos + 1
		else
			if pos + 3 > fin then
				return nil, "truncated charstring number"
			end
			st.n = st.n + 1
			stack[st.n] = i32(d, pos) / 65536
			pos = pos + 4
		end
		if st.n > 96 then
			return nil, "charstring stack overflow"
		end
	end
	return pos, nil
end

local function cffGlyphOutline(font, gid)
	local cff = font._cff
	local d = font._data
	local it = cff.charstrings.items[gid + 1]
	if not it then
		return nil, "glyph id out of range"
	end
	local priv, scale
	if cff.isCID then
		local fd = cff.fds[cff.fdOf[gid]]
		if not fd then
			return nil, "glyph has no CID font dictionary"
		end
		priv, scale = fd.priv, fd.scale
	else
		priv, scale = cff.private, cff.scale
	end
	local st = {
		stack = {},
		n = 0,
		x = 0,
		y = 0,
		contours = {},
		cur = nil,
		stems = 0,
		width = 0,
		widthSet = false,
		transient = {},
		depth = 0,
		priv = priv,
		noWidth = cff.isCFF2 == true,
		numRegions = cff.numRegions or 0,
	}
	function st.moveTo(s, dx, dy)
		if s.cur and #s.cur > 0 then
			s.contours[#s.contours + 1] = s.cur
		end
		s.x, s.y = s.x + dx, s.y + dy
		s.cur = { { x = s.x, y = s.y, k = "on" } }
	end

	function st.lineTo(s, dx, dy)
		if not s.cur then
			s.cur = { { x = s.x, y = s.y, k = "on" } }
		end
		s.x, s.y = s.x + dx, s.y + dy
		s.cur[#s.cur + 1] = { x = s.x, y = s.y, k = "on" }
	end

	function st.cubic(s, dx1, dy1, dx2, dy2, dx3, dy3)
		if not s.cur then
			s.cur = { { x = s.x, y = s.y, k = "on" } }
		end
		s.x, s.y = s.x + dx1, s.y + dy1
		s.cur[#s.cur + 1] = { x = s.x, y = s.y, k = "c" }
		s.x, s.y = s.x + dx2, s.y + dy2
		s.cur[#s.cur + 1] = { x = s.x, y = s.y, k = "c" }
		s.x, s.y = s.x + dx3, s.y + dy3
		s.cur[#s.cur + 1] = { x = s.x, y = s.y, k = "on" }
	end

	function st.close(s)
		if s.cur and #s.cur > 0 then
			s.contours[#s.contours + 1] = s.cur
		end
		s.cur = nil
	end

	local _, err = interpCharstring(d, it.pos, it.pos + it.len - 1, st, cff)
	if err then
		return nil, err
	end
	st.close(st)
	if #st.contours == 0 then
		return {
			contours = {},
			xMin = 0,
			yMin = 0,
			xMax = 0,
			yMax = 0,
			advance = font._advances[gid] or 0,
			lsb = font._lsbs[gid] or 0,
			empty = true,
		}
	end
	local xMin, yMin, xMax, yMax
	for _, contour in ipairs(st.contours) do
		for _, p in ipairs(contour) do
			p.x, p.y = p.x * scale, p.y * scale
			if not xMin or p.x < xMin then
				xMin = p.x
			end
			if not xMax or p.x > xMax then
				xMax = p.x
			end
			if not yMin or p.y < yMin then
				yMin = p.y
			end
			if not yMax or p.y > yMax then
				yMax = p.y
			end
		end
	end
	return {
		contours = st.contours,
		xMin = xMin,
		yMin = yMin,
		xMax = xMax,
		yMax = yMax,
		advance = font._advances[gid] or 0,
		lsb = font._lsbs[gid] or 0,
	}
end

local function parseSimpleGlyph(d, go, nContours, limit)
	limit = limit or #d
	local xMin, yMin, xMax, yMax = i16(d, go + 2), i16(d, go + 4), i16(d, go + 6), i16(d, go + 8)
	local empty = { contours = {}, xMin = xMin, yMin = yMin, xMax = xMax, yMax = yMax, empty = true }
	if nContours <= 0 or go + 10 + nContours * 2 > limit then
		return empty
	end
	local o = go + 10
	local endPts = {}
	for i = 1, nContours do
		endPts[i] = u16(d, o)
		o = o + 2
	end
	local nPoints = (endPts[nContours] or -1) + 1
	if nPoints <= 0 or nPoints > 32767 then
		return empty
	end
	local instrLen = u16(d, o)
	o = o + 2 + instrLen
	if o > limit then
		return empty
	end
	local flags = {}
	local i = 1
	while i <= nPoints do
		if o > limit then
			break
		end
		local f = u8(d, o)
		o = o + 1
		flags[i] = f
		i = i + 1
		if f % 16 >= 8 then
			local rep = u8(d, o)
			o = o + 1
			for _ = 1, rep do
				if i > nPoints then
					break
				end
				flags[i] = f
				i = i + 1
			end
		end
	end
	local shortX, sameX, shortY, sameY, isOn = {}, {}, {}, {}, {}
	for k = 1, nPoints do
		local f = flags[k] or 0
		shortX[k] = (f % 4) >= 2
		isOn[k] = (f % 2) == 1
		sameX[k] = (f % 32) >= 16
		shortY[k] = (f % 8) >= 4
		sameY[k] = (f % 64) >= 32
	end
	local xs, ys = {}, {}
	do
		local prev = 0
		for k = 1, nPoints do
			if shortX[k] then
				local v = u8(d, o)
				o = o + 1
				if sameX[k] then
					prev = prev + v
				else
					prev = prev - v
				end
			elseif not sameX[k] then
				prev = prev + i16(d, o)
				o = o + 2
			end
			xs[k] = prev
		end
	end
	do
		local prev = 0
		for k = 1, nPoints do
			if shortY[k] then
				local v = u8(d, o)
				o = o + 1
				if sameY[k] then
					prev = prev + v
				else
					prev = prev - v
				end
			elseif not sameY[k] then
				prev = prev + i16(d, o)
				o = o + 2
			end
			ys[k] = prev
		end
	end
	local contours = {}
	local start = 1
	for c = 1, nContours do
		local last = endPts[c] + 1
		if last > nPoints then
			last = nPoints
		end
		if last < start then
			last = start - 1
		end
		local pts = {}
		local np = 0
		for k = start, last do
			np = np + 1
			pts[np] = { x = xs[k], y = ys[k], k = isOn[k] and "on" or "q" }
		end
		contours[#contours + 1] = pts
		start = last + 1
	end
	return { contours = contours, xMin = xMin, yMin = yMin, xMax = xMax, yMax = yMax }
end

local ARG_WORDS = 1
local ARGS_XY = 2
local ROUND_XY = 4
local HAVE_SCALE = 8
local MORE_COMPONENTS = 32
local HAVE_XY_SCALE = 64
local HAVE_2X2 = 128
local HAVE_INSTR = 256
local USE_MY_METRICS = 512

local function parseGlyphRaw(font, gid, depth)
	local d = font._data
	local loc = font._loca
	local gbase = font._glyfOff
	if gid < 0 or gid >= font.numGlyphs then
		return nil, "glyph id out of range"
	end
	local o0, o1 = loc[gid], loc[gid + 1]
	if not o0 or not o1 or o1 <= o0 then
		return {
			contours = {},
			xMin = 0,
			yMin = 0,
			xMax = 0,
			yMax = 0,
			advance = font._advances[gid] or 0,
			lsb = font._lsbs[gid] or 0,
			empty = true,
		}
	end
	local go = gbase + o0
	local glimit = gbase + o1 - 1
	if go < 1 or go + 9 > #d or go + 9 > glimit then
		return {
			contours = {},
			xMin = 0,
			yMin = 0,
			xMax = 0,
			yMax = 0,
			advance = font._advances[gid] or 0,
			lsb = font._lsbs[gid] or 0,
			empty = true,
		}
	end
	local nContours = i16(d, go)
	if nContours >= 0 then
		local gl = parseSimpleGlyph(d, go, nContours, glimit)
		gl.advance = font._advances[gid] or 0
		gl.lsb = font._lsbs[gid] or 0
		return gl
	end
	if (depth or 0) > 8 then
		return nil, "composite glyph nesting too deep"
	end
	local xMin, yMin, xMax, yMax = i16(d, go + 2), i16(d, go + 4), i16(d, go + 6), i16(d, go + 8)
	local o = go + 10
	local contours = {}
	local useMyMetrics = false
	local adv, lsb = font._advances[gid], font._lsbs[gid]
	while true do
		if o + 4 > glimit then
			break
		end
		local flags = u16(d, o)
		local comp = u16(d, o + 2)
		o = o + 4
		local arg1, arg2
		if flags % 2 == 1 then
			arg1, arg2 = i16(d, o), i16(d, o + 2)
			o = o + 4
		else
			arg1 = u8(d, o)
			arg2 = u8(d, o + 1)
			o = o + 2
			if arg1 >= 128 then
				arg1 = arg1 - 256
			end
			if arg2 >= 128 then
				arg2 = arg2 - 256
			end
		end
		local mxx, mxy, myx, myy = 1, 0, 0, 1
		if (flags % 16) >= HAVE_SCALE then
			mxx = i16(d, o) / 16384
			myy = mxx
			o = o + 2
		elseif (flags % 128) >= HAVE_XY_SCALE then
			mxx = i16(d, o) / 16384
			myy = i16(d, o + 2) / 16384
			o = o + 4
		elseif (flags % 256) >= HAVE_2X2 then
			mxx = i16(d, o) / 16384
			myx = i16(d, o + 2) / 16384
			mxy = i16(d, o + 4) / 16384
			myy = i16(d, o + 6) / 16384
			o = o + 8
		end
		local dx, dy = 0, 0
		if (flags % 4) >= ARGS_XY then
			dx, dy = arg1, arg2
		end
		local my_metrics = false
		if (flags % 1024) >= USE_MY_METRICS and not useMyMetrics then
			useMyMetrics = true
			my_metrics = true
		end
		local sub, err = parseGlyphRaw(font, comp, (depth or 0) + 1)
		if not sub then
			return nil, err
		end
		if my_metrics then
			adv, lsb = sub.advance, sub.lsb
		end
		for _, contour in ipairs(sub.contours) do
			local nc = {}
			for _, p in ipairs(contour) do
				nc[#nc + 1] = {
					x = p.x * mxx + p.y * mxy + dx,
					y = p.x * myx + p.y * myy + dy,
					k = p.k,
				}
			end
			contours[#contours + 1] = nc
		end
		if (flags % 512) >= HAVE_INSTR then
			local n = u16(d, o)
			o = o + 2 + n
		end
		if (flags % 64) < MORE_COMPONENTS then
			break
		end
	end
	return {
		contours = contours,
		xMin = xMin,
		yMin = yMin,
		xMax = xMax,
		yMax = yMax,
		advance = adv or 0,
		lsb = lsb or 0,
	}
end

local function flattenContour(pts, scale, ox, oy, slant)
	local n = #pts
	if n == 0 then
		return nil
	end
	if n == 1 then
		return nil
	end
	local mabs, mfloor = math.abs, math.floor
	local hasSlant = slant and slant ~= 0
	local scaleSlant = hasSlant and (scale * slant) or 0
	local exp = {}
	local nexp = 0
	for i = 1, n do
		local cur = pts[i]
		local prev = pts[(i - 2) % n + 1]
		if cur.k == "q" and prev.k == "q" then
			nexp = nexp + 1
			exp[nexp] = { x = (prev.x + cur.x) / 2, y = (prev.y + cur.y) / 2, k = "on" }
		end
		nexp = nexp + 1
		exp[nexp] = cur
	end
	local m = nexp
	local ons = {}
	local nons = 0
	for i = 1, m do
		if exp[i].k == "on" then
			nons = nons + 1
			ons[nons] = i
		end
	end
	local poly = {}
	local npoly = 0
	if nons == 0 then
		for i = 1, m do
			local pt = exp[i]
			local x = (pt.x - ox) * scale
			if hasSlant then
				x = x + pt.y * scaleSlant
			end
			npoly = npoly + 1
			poly[npoly] = { x = x, y = (oy - pt.y) * scale }
		end
		if npoly < 3 then
			return nil
		end
		return poly
	end
	for oi = 1, nons do
		local a = ons[oi]
		local b = ons[oi % nons + 1]
		local pa, pb = exp[a], exp[b]
		local p0x = (pa.x - ox) * scale
		if hasSlant then
			p0x = p0x + pa.y * scaleSlant
		end
		local p0y = (oy - pa.y) * scale
		local p1x = (pb.x - ox) * scale
		if hasSlant then
			p1x = p1x + pb.y * scaleSlant
		end
		local p1y = (oy - pb.y) * scale
		local nb = b - a - 1
		if nb < 0 then
			nb = nb + m
		end
		if nb == 0 then
			if not (p0x == p1x and p0y == p1y) then
				npoly = npoly + 1
				poly[npoly] = { x = p1x, y = p1y }
			end
		else
			local i1 = a % m + 1
			local q1 = exp[i1]
			if nb == 1 and q1.k == "q" then
				local cx = (q1.x - ox) * scale
				if hasSlant then
					cx = cx + q1.y * scaleSlant
				end
				local cy = (oy - q1.y) * scale
				local approx = (mabs(cx - p0x) + mabs(cy - p0y) + mabs(p1x - cx) + mabs(p1y - cy)) / 2
				local segs = mfloor(approx) + 1
				if segs < 2 then
					segs = 2
				end
				if segs > 24 then
					segs = 24
				end
				for s = 1, segs do
					local t = s / segs
					local mt = 1 - t
					npoly = npoly + 1
					poly[npoly] = {
						x = mt * mt * p0x + 2 * mt * t * cx + t * t * p1x,
						y = mt * mt * p0y + 2 * mt * t * cy + t * t * p1y,
					}
				end
			else
				local i2 = i1 % m + 1
				local q2 = exp[i2]
				if nb == 2 and q1.k == "c" and q2.k == "c" then
					local c1x = (q1.x - ox) * scale
					if hasSlant then
						c1x = c1x + q1.y * scaleSlant
					end
					local c1y = (oy - q1.y) * scale
					local c2x = (q2.x - ox) * scale
					if hasSlant then
						c2x = c2x + q2.y * scaleSlant
					end
					local c2y = (oy - q2.y) * scale
					local approx = (
						mabs(c1x - p0x)
						+ mabs(c1y - p0y)
						+ mabs(c2x - c1x)
						+ mabs(c2y - c1y)
						+ mabs(p1x - c2x)
						+ mabs(p1y - c2y)
					) / 2
					local segs = mfloor(approx) + 1
					if segs < 2 then
						segs = 2
					end
					if segs > 32 then
						segs = 32
					end
					for s = 1, segs do
						local t = s / segs
						local mt = 1 - t
						local aa = mt * mt * mt
						local bb = 3 * mt * mt * t
						local cc = 3 * mt * t * t
						local ee = t * t * t
						npoly = npoly + 1
						poly[npoly] = {
							x = aa * p0x + bb * c1x + cc * c2x + ee * p1x,
							y = aa * p0y + bb * c1y + cc * c2y + ee * p1y,
						}
					end
				else
					local i = i1
					for _ = 1, nb do
						local q = exp[i]
						local qx = (q.x - ox) * scale
						if hasSlant then
							qx = qx + q.y * scaleSlant
						end
						npoly = npoly + 1
						poly[npoly] = { x = qx, y = (oy - q.y) * scale }
						i = i % m + 1
					end
					npoly = npoly + 1
					poly[npoly] = { x = p1x, y = p1y }
				end
			end
		end
	end
	if npoly < 3 then
		return nil
	end
	return poly
end

local function rasterizeOutline(outline, px, ss, slant)
	slant = slant or 0
	local upm = outline._upm
	local scale = px / upm
	local glyphs = outline.contours
	if #glyphs == 0 or outline.empty then
		return nil
	end
	local shMin, shMax = 0, 0
	if slant ~= 0 then
		local a, b = outline.yMin * slant, outline.yMax * slant
		if a < b then
			shMin, shMax = a, b
		else
			shMin, shMax = b, a
		end
	end
	local x0f = math.floor((outline.xMin + shMin) * scale)
	local x1f = math.ceil((outline.xMax + shMax) * scale)
	local yTop = math.ceil(outline.yMax * scale)
	local yBot = math.floor(outline.yMin * scale)
	local W = x1f - x0f
	local H = yTop - yBot
	if W <= 0 or H <= 0 then
		return nil
	end
	if W > 1024 or H > 1024 then
		return nil, "glyph bitmap too large"
	end
	local oy = yTop / scale
	local ox = x0f / scale
	local polys = {}
	for _, c in ipairs(glyphs) do
		local p = flattenContour(c, scale, ox, oy, slant)
		if p then
			polys[#polys + 1] = p
		end
	end
	if #polys == 0 then
		return nil
	end
	local ex1, ey1, ex2, ey2 = {}, {}, {}, {}
	local ne = 0
	for _, poly in ipairs(polys) do
		local np = #poly
		if np >= 2 then
			local prev = poly[np]
			for i = 1, np do
				local cur = poly[i]
				if prev.y ~= cur.y then
					ne = ne + 1
					ex1[ne], ey1[ne], ex2[ne], ey2[ne] = prev.x, prev.y, cur.x, cur.y
				end
				prev = cur
			end
		end
	end
	local cov = {}
	for i = 1, W * H do
		cov[i] = 0
	end
	local xs = {}
	local Hss = H * ss
	local mfloor, mceil = math.floor, math.ceil
	local inv = {}
	for e = 1, ne do
		local dy = ey2[e] - ey1[e]
		inv[e] = 1 / dy
		xs[e] = 0
	end
	local ssInv = 1 / ss
	for sy = 0, Hss - 1 do
		local y = (sy + 0.5) / ss
		local nx = 0
		for e = 1, ne do
			local y1, y2 = ey1[e], ey2[e]
			if (y1 <= y) ~= (y2 <= y) then
				nx = nx + 1
				xs[nx] = ex1[e] + (y - y1) * inv[e] * (ex2[e] - ex1[e])
			end
		end
		if nx >= 2 then
			for i = 2, nx do
				local v = xs[i]
				local j = i - 1
				while j >= 1 and xs[j] > v do
					xs[j + 1] = xs[j]
					j = j - 1
				end
				xs[j + 1] = v
			end
			local row = mfloor(sy * ssInv)
			local rowBase = row * W
			local k = 1
			while k < nx do
				local xa, xb = xs[k], xs[k + 1]
				if xb > xa then
					local sx0 = mfloor(xa * ss - 0.5) + 1
					if sx0 < 0 then
						sx0 = 0
					end
					local sx1 = mceil(xb * ss - 0.5) - 1
					local maxSx = W * ss - 1
					if sx1 > maxSx then
						sx1 = maxSx
					end
					if sx0 <= sx1 then
						local c0 = mfloor(sx0 * ssInv)
						local c1 = mfloor(sx1 * ssInv)
						if c0 == c1 then
							cov[rowBase + c0 + 1] = cov[rowBase + c0 + 1] + (sx1 - sx0 + 1)
						else
							local leftEnd = (c0 + 1) * ss - 1
							cov[rowBase + c0 + 1] = cov[rowBase + c0 + 1] + (leftEnd - sx0 + 1)
							for col = c0 + 1, c1 - 1 do
								cov[rowBase + col + 1] = cov[rowBase + col + 1] + ss
							end
							local rightStart = c1 * ss
							cov[rowBase + c1 + 1] = cov[rowBase + c1 + 1] + (sx1 - rightStart + 1)
						end
					end
				end
				k = k + 2
			end
		end
	end
	local div = ss * ss
	local divInv = 255 / div
	local alpha = {}
	for i = 1, W * H do
		local c = cov[i]
		if c > div then
			c = div
		end
		alpha[i] = mfloor(c * divInv + 0.5)
	end
	return {
		width = W,
		height = H,
		bearingX = x0f,
		bearingY = yTop,
		coverage = alpha,
	}
end

local Font = {}
Font.__index = Font

function Font:glyphIndex(cp)
	if type(cp) ~= "number" then
		return nil, "codepoint must be a number"
	end
	cp = math.floor(cp)
	local cached = self._gidCache[cp]
	if cached ~= nil then
		return cached
	end
	local gid = cmapLookupFull(self, cp)
	if gid >= self.numGlyphs then
		gid = 0
	end
	self._gidCache[cp] = gid
	return gid
end

function Font:charIndex(ch)
	local cps = fntp.decodeUTF8(ch)
	return self:glyphIndex(cps[1] or 0xFFFD)
end

function Font:hmetrics(gid)
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	return self._advances[gid] or 0, self._lsbs[gid] or 0
end

function Font:metrics(px)
	local s = px / self.unitsPerEm
	local asc = math.floor(self.ascender * s + 0.5)
	local desc = math.floor(self.descender * s + 0.5)
	local gap = math.floor(self.lineGap * s + 0.5)
	return { scale = s, ascent = asc, descent = desc, lineGap = gap, height = asc - desc + gap }
end

function Font:kerning(leftGid, rightGid)
	if type(leftGid) ~= "number" or type(rightGid) ~= "number" then
		return nil, "glyph ids must be numbers"
	end
	leftGid, rightGid = math.floor(leftGid), math.floor(rightGid)
	if self._gpos then
		local p = gposPairAt(self, leftGid, rightGid)
		if p and p.adv ~= 0 then
			return p.adv
		end
	end
	local k = self._kern and self._kern[leftGid * 65536 + rightGid]
	if k then
		return k
	end
	return 0
end

function Font:adjust(gid)
	local s = self._gpos and self._gpos.singles[gid]
	if s then
		return s.dx or 0, s.dy or 0, s.adv or 0
	end
	return 0, 0, 0
end

function Font:hasKerning()
	if self._kern and next(self._kern) ~= nil then
		return true
	end
	return self._gpos ~= nil and self._gpos.hasPairs == true
end

function Font:hasShaping()
	return self._gsub ~= nil
		or self:hasKerning()
		or (self._gpos ~= nil and (self._gpos.hasSingles or self._gpos.hasMarks))
end

function Font:glyphName(gid)
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	if self.post and self.post.names and self.post.names[gid] then
		return self.post.names[gid]
	end
	if self._cff and self._cff.charsetNames and self._cff.charsetNames[gid] then
		return self._cff.charsetNames[gid]
	end
	return nil
end

function Font:names()
	return self._names
end

function Font:vmetrics(gid)
	if not self._vAdv then
		return nil, "font has no vertical metrics"
	end
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	return self._vAdv[gid] or 0, self._vTsb[gid] or 0
end

function Font:vorigin(gid)
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	if self._vorg then
		return self._vorg.rec[gid] or self._vorg.defaultY
	end
	return self.unitsPerEm
end

function Font:underline(px)
	local s = px / self.unitsPerEm
	local pos, thick
	if self.underlineMetrics then
		pos, thick = self.underlineMetrics.pos, self.underlineMetrics.thick
	else
		pos, thick = self.descender, math.max(1, math.floor(self.unitsPerEm / 14))
	end
	return { pos = math.floor(pos * s + 0.5), thick = math.max(1, math.floor(thick * s + 0.5)) }
end

function Font:strikeout(px)
	local s = px / self.unitsPerEm
	local pos, thick
	if self.strikeoutMetrics then
		pos, thick = self.strikeoutMetrics.pos, self.strikeoutMetrics.size
	elseif self.os2 and self.os2.xHeight then
		pos, thick = math.floor(self.os2.xHeight / 2), math.max(1, math.floor(self.unitsPerEm / 14))
	else
		pos, thick = math.floor(self.unitsPerEm * 0.28), math.max(1, math.floor(self.unitsPerEm / 14))
	end
	return { pos = math.floor(pos * s + 0.5), thick = math.max(1, math.floor(thick * s + 0.5)) }
end

local shapeCps
function Font:shape(text, opts)
	opts = opts or {}
	if type(text) ~= "string" then
		return nil, "text must be a string"
	end
	return shapeCps(self, fntp.decodeUTF8(text), opts.kerning ~= false, opts.ligatures ~= false, opts.marks ~= false)
end

shapeCps = function(font, cps, doKern, doLig, doMark)
	if font.isBitmap then
		local items, width = {}, 0
		for i, cp in ipairs(cps) do
			local g = font:glyphIndex(cp)
			if g >= font.numGlyphs then
				g = 0
			end
			local mark = doMark and isMarkCP(cp)
			local adv = mark and 0 or (font._advances[g] or 0)
			items[i] = {
				gid = g,
				cp = cp,
				cluster = i,
				adv = adv,
				dx = 0,
				dy = 0,
				mark = mark,
			}
			width = width + adv
		end
		return { items = items, width = width }
	end
	local gids, clusters = {}, {}
	local gidCache = font._gidCache
	local numGlyphs = font.numGlyphs
	for i, cp in ipairs(cps) do
		local g = gidCache[cp]
		if g == nil then
			g = cmapLookupFull(font, cp)
			if g >= numGlyphs then
				g = 0
			end
			gidCache[cp] = g
		end
		gids[i] = g
		clusters[i] = i
	end
	if doLig and font._gsub then
		gids, clusters = applyGSUB(font, gids, clusters)
	end
	local items = {}
	local width = 0
	local prev = nil
	local n = #gids
	for i = 1, n do
		local g = gids[i]
		local cp = cps[clusters[i]] or 0
		local mark = doMark and isMarkCP(cp)
		local adv = mark and 0 or (font._advances[g] or 0)
		local dx, dy = 0, 0
		if font._gpos and font._gpos.singles[g] then
			local s = font._gpos.singles[g]
			dx, dy = s.dx or 0, s.dy or 0
			if not mark then
				adv = adv + (s.adv or 0)
			end
		end
		items[i] = {
			gid = g,
			cp = cp,
			cluster = clusters[i],
			adv = adv,
			dx = dx,
			dy = dy,
			mark = mark,
		}
	end
	local lastBase = nil
	for i = 1, n do
		local it = items[i]
		if it.mark then
			if lastBase and font._gpos and font._gpos.hasMarks then
				local mm = font._gpos.marks[it.gid]
				local base = items[lastBase]
				if mm and mm.mark then
					local ba = font._gpos.marks["b" .. base.gid .. ":" .. (mm.class or 0)]
					if ba then
						it.dx = it.dx + (ba.x - mm.mark.x)
						it.dy = it.dy + (ba.y - mm.mark.y)
					else
						it.dx = it.dx + math.floor((font._advances[base.gid] or 0) / 2)
					end
				else
					it.dx = it.dx + math.floor((font._advances[items[lastBase].gid] or 0) / 2)
				end
			elseif lastBase then
				it.dx = it.dx + math.floor((font._advances[items[lastBase].gid] or 0) / 2)
			end
		else
			if doKern and prev then
				local k = 0
				if font._gpos then
					local p = gposPairAt(font, items[prev].gid, it.gid)
					if p and p.adv ~= 0 then
						k = p.adv
					end
				end
				if k == 0 and font._kern then
					k = font._kern[items[prev].gid * 65536 + it.gid] or 0
				end
				if k ~= 0 then
					width = width + k
					it.kern = k
				end
			end
			prev = i
			lastBase = i
		end
		width = width + it.adv
	end
	return { items = items, width = width }
end

function Font:clearCache()
	local o, g = 0, 0
	for _ in pairs(self._outlineCache) do
		o = o + 1
	end
	for _ in pairs(self._glyphCache) do
		g = g + 1
	end
	self._outlineCache, self._glyphCache, self._gidCache = {}, {}, {}
	return { outlines = o, glyphs = g }
end

function Font:cacheInfo()
	local o, g = 0, 0
	for _ in pairs(self._outlineCache) do
		o = o + 1
	end
	for _ in pairs(self._glyphCache) do
		g = g + 1
	end
	return { outlines = o, glyphs = g }
end

function Font:getOutline(gid)
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	local cached = self._outlineCache[gid]
	if cached ~= nil then
		return cached
	end
	local gl, err
	if self.outlines == "cff" then
		gl, err = cffGlyphOutline(self, gid)
	else
		gl, err = parseGlyphRaw(self, gid, 0)
	end
	if not gl then
		return nil, err
	end
	gl._upm = self.unitsPerEm
	if self._cacheOutlines then
		self._outlineCache[gid] = gl
	end
	return gl
end

local function clampByte(v)
	v = math.floor(v or 0)
	if v < 0 then
		return 0
	end
	if v > 255 then
		return 255
	end
	return v
end

local rasterizeGid
function Font:rasterize(what, px, opts)
	opts = opts or {}
	if type(px) ~= "number" or px < 1 or px > 1024 then
		return nil, "pixel size must be in 1..1024"
	end
	px = math.floor(px)
	local cp
	if type(what) == "number" then
		cp = math.floor(what)
	elseif type(what) == "string" then
		local cps = fntp.decodeUTF8(what)
		cp = cps[1] or 0xFFFD
	else
		return nil, "glyph must be a codepoint or character"
	end
	local ss = opts.supersample or 2
	if ss ~= 1 and ss ~= 2 and ss ~= 4 then
		return nil, "supersample must be 1, 2 or 4"
	end
	local r, g, b, a =
		clampByte(opts.r == nil and 255 or opts.r),
		clampByte(opts.g == nil and 255 or opts.g),
		clampByte(opts.b == nil and 255 or opts.b),
		clampByte(opts.a == nil and 255 or opts.a)
	local gid = self:glyphIndex(cp)
	return rasterizeGid(self, gid, cp, px, r, g, b, a, ss, opts)
end

rasterizeGid = function(font, gid, cp, px, r, g, b, a, ss, fx)
	fx = fx or {}
	local gamma = fx.gamma or 1
	local slant = fx.slant or fx.italic or 0
	if slant == true then
		slant = 0.2
	end
	local embolden = fx.embolden or fx.bold or 0
	if embolden == true then
		embolden = 1
	end
	local keyFx = ""
	if gamma ~= 1 then
		keyFx = keyFx .. "g" .. gamma
	end
	if slant ~= 0 then
		keyFx = keyFx .. "s" .. slant
	end
	if embolden ~= 0 then
		keyFx = keyFx .. "b" .. embolden
	end
	local cacheKey = gid .. ":" .. px .. ":" .. ss .. ":" .. r .. "," .. g .. "," .. b .. "," .. a .. keyFx
	if font._cacheGlyphs then
		local hit = font._glyphCache[cacheKey]
		if hit then
			return hit
		end
	end
	if font.isBitmap then
		return bmpRaster(font, gid, cp, px, r, g, b, a, ss, fx, cacheKey)
	end
	local outline, err = font:getOutline(gid)
	if not outline then
		return nil, err
	end
	local scale = px / font.unitsPerEm
	local advance = math.floor((outline.advance or 0) * scale + 0.5)
	if outline.empty or #outline.contours == 0 then
		local gl0 = {
			buffer = "",
			width = 0,
			height = 0,
			bearingX = 0,
			bearingY = 0,
			advance = advance,
			px = px,
			codepoint = cp,
			gid = gid,
			blank = true,
		}
		if font._cacheGlyphs then
			font._glyphCache[cacheKey] = gl0
		end
		return gl0
	end
	local rast, rerr = rasterizeOutline(outline, px, ss, slant)
	if not rast then
		if rerr then
			return nil, rerr
		end
		local gl0 = {
			buffer = "",
			width = 0,
			height = 0,
			bearingX = 0,
			bearingY = 0,
			advance = advance,
			px = px,
			codepoint = cp,
			gid = gid,
			blank = true,
		}
		if font._cacheGlyphs then
			font._glyphCache[cacheKey] = gl0
		end
		return gl0
	end
	local W, H = rast.width, rast.height
	local cov = rast.coverage
	if embolden ~= 0 then
		local rad = math.floor(embolden + 0.5)
		if rad < 1 then
			rad = 1
		end
		if rad > 2 then
			rad = 2
		end
		local tmp = {}
		for y = 0, H - 1 do
			local base = y * W
			for x = 0, W - 1 do
				local best = 0
				local x0 = x - rad
				if x0 < 0 then
					x0 = 0
				end
				local x1 = x + rad
				if x1 >= W then
					x1 = W - 1
				end
				for xx = x0, x1 do
					local v = cov[base + xx + 1]
					if v > best then
						best = v
						if best == 255 then
							break
						end
					end
				end
				tmp[base + x + 1] = best
			end
		end
		local dst = {}
		for y = 0, H - 1 do
			for x = 0, W - 1 do
				local best = 0
				local y0 = y - rad
				if y0 < 0 then
					y0 = 0
				end
				local y1 = y + rad
				if y1 >= H then
					y1 = H - 1
				end
				for yy = y0, y1 do
					local v = tmp[yy * W + x + 1]
					if v > best then
						best = v
						if best == 255 then
							break
						end
					end
				end
				dst[y * W + x + 1] = best
			end
		end
		cov = dst
	end
	local chunks = {}
	local n = 0
	local schar = string.char
	if gamma ~= 1 then
		local gexp = 1 / gamma
		local aScale = a / 255
		local lut = {}
		for cc = 0, 255 do
			local c = 255 * ((cc / 255) ^ gexp)
			lut[cc] = schar(r, g, b, math.floor(c * aScale + 0.5))
		end
		for i = 1, W * H do
			n = n + 1
			chunks[n] = lut[cov[i]]
		end
	elseif a == 255 then
		local lut = {}
		for cc = 0, 255 do
			lut[cc] = schar(r, g, b, cc)
		end
		for i = 1, W * H do
			n = n + 1
			chunks[n] = lut[cov[i]]
		end
	else
		local aScale = a / 255
		local lut = {}
		for cc = 0, 255 do
			lut[cc] = schar(r, g, b, math.floor(cc * aScale + 0.5))
		end
		for i = 1, W * H do
			n = n + 1
			chunks[n] = lut[cov[i]]
		end
	end
	local gl = {
		buffer = table.concat(chunks),
		width = W,
		height = H,
		bearingX = rast.bearingX,
		bearingY = rast.bearingY,
		advance = advance,
		px = px,
		codepoint = cp,
		gid = gid,
	}
	if font._cacheGlyphs then
		font._glyphCache[cacheKey] = gl
	end
	return gl
end

function Font:decode(glyph)
	if not glyph or (glyph.width > 0 and (not glyph.buffer or #glyph.buffer == 0)) then
		return nil, "not a rasterized glyph"
	end
	local rows = {}
	local buf = glyph.buffer
	for y = 0, glyph.height - 1 do
		local row = {}
		for x = 0, glyph.width - 1 do
			row[x + 1] = string.byte(buf, (y * glyph.width + x) * 4 + 4)
		end
		rows[y + 1] = row
	end
	return {
		width = glyph.width,
		height = glyph.height,
		rows = rows,
		bearingX = glyph.bearingX,
		bearingY = glyph.bearingY,
		advance = glyph.advance,
	}
end

function Font:sdf(what, px, spread, opts)
	opts = opts or {}
	if type(px) ~= "number" or px < 1 or px > 1024 then
		return nil, "pixel size must be in 1..1024"
	end
	px = math.floor(px)
	spread = spread or 4
	if type(spread) ~= "number" or spread < 1 or spread > 64 then
		return nil, "spread must be in 1..64"
	end
	local cp
	if type(what) == "number" then
		cp = math.floor(what)
	elseif type(what) == "string" then
		cp = fntp.decodeUTF8(what)[1] or 0xFFFD
	else
		return nil, "glyph must be a codepoint or character"
	end
	if self.isBitmap then
		return bmpSdf(self, cp, px, spread)
	end
	local gid = self:glyphIndex(cp)
	local outline, err = self:getOutline(gid)
	if not outline then
		return nil, err
	end
	local scale = px / self.unitsPerEm
	local advance = math.floor((outline.advance or 0) * scale + 0.5)
	if outline.empty or #outline.contours == 0 then
		return {
			width = 0,
			height = 0,
			rows = {},
			advance = advance,
			spread = spread,
			bearingX = 0,
			bearingY = 0,
			blank = true,
		}
	end
	local rast, rerr = rasterizeOutline(outline, px, 2)
	if not rast then
		if rerr then
			return nil, rerr
		end
		return {
			width = 0,
			height = 0,
			rows = {},
			advance = advance,
			spread = spread,
			bearingX = 0,
			bearingY = 0,
			blank = true,
		}
	end
	local W, H = rast.width, rast.height
	local inside = {}
	for i = 1, W * H do
		inside[i] = rast.coverage[i] >= 128
	end
	local function chamfer(seedOutside)
		local INF = (W + H) * 3 + 10
		local d = {}
		for i = 1, W * H do
			local isIn = inside[i]
			d[i] = ((isIn and not seedOutside) or (not isIn and seedOutside)) and 0 or INF
		end
		for y = 0, H - 1 do
			for x = 0, W - 1 do
				local i = y * W + x + 1
				local best = d[i]
				if x > 0 and d[i - 1] + 3 < best then
					best = d[i - 1] + 3
				end
				if y > 0 then
					if d[i - W] + 3 < best then
						best = d[i - W] + 3
					end
					if x > 0 and d[i - W - 1] + 4 < best then
						best = d[i - W - 1] + 4
					end
					if x < W - 1 and d[i - W + 1] + 4 < best then
						best = d[i - W + 1] + 4
					end
				end
				d[i] = best
			end
		end
		for y = H - 1, 0, -1 do
			for x = W - 1, 0, -1 do
				local i = y * W + x + 1
				local best = d[i]
				if x < W - 1 and d[i + 1] + 3 < best then
					best = d[i + 1] + 3
				end
				if y < H - 1 then
					if d[i + W] + 3 < best then
						best = d[i + W] + 3
					end
					if x < W - 1 and d[i + W + 1] + 4 < best then
						best = d[i + W + 1] + 4
					end
					if x > 0 and d[i + W - 1] + 4 < best then
						best = d[i + W - 1] + 4
					end
				end
				d[i] = best
			end
		end
		return d
	end
	local dIn = chamfer(false)
	local dOut = chamfer(true)
	local rows = {}
	for y = 0, H - 1 do
		local row = {}
		for x = 0, W - 1 do
			local i = y * W + x + 1
			local v = (dOut[i] - dIn[i]) / 3
			if v > spread then
				v = spread
			end
			if v < -spread then
				v = -spread
			end
			row[x + 1] = v
		end
		rows[y + 1] = row
	end
	return {
		width = W,
		height = H,
		rows = rows,
		spread = spread,
		bearingX = rast.bearingX,
		bearingY = rast.bearingY,
		advance = advance,
	}
end

function Font:atlas(px, chars, opts)
	opts = opts or {}
	if type(px) ~= "number" or px < 1 or px > 256 then
		return nil, "atlas pixel size must be in 1..256"
	end
	px = math.floor(px)
	local cps
	if type(chars) == "string" then
		cps = fntp.decodeUTF8(chars)
	elseif type(chars) == "table" then
		cps = chars
	else
		return nil, "chars must be a string or codepoint array"
	end
	local maxW = opts.maxWidth or 512
	if maxW < 16 or maxW > 2048 then
		return nil, "maxWidth must be in 16..2048"
	end
	local ropts = {
		r = opts.r,
		g = opts.g,
		b = opts.b,
		a = opts.a,
		supersample = opts.supersample or 2,
		embolden = opts.embolden or opts.bold,
		slant = opts.slant or opts.italic,
		gamma = opts.gamma,
	}
	local glyphs, order = {}, {}
	for _, cp in ipairs(cps) do
		if glyphs[cp] == nil then
			local gl, err = self:rasterize(cp, px, ropts)
			if not gl then
				return nil, err
			end
			glyphs[cp] = gl
			order[#order + 1] = cp
		end
	end
	local uv = {}
	local ax, ay, rowH = 0, 0, 0
	local totalH = 0
	for _, cp in ipairs(order) do
		local gl = glyphs[cp]
		local w, h = gl.width, gl.height
		if w == 0 then
			w = 1
		end
		if h == 0 then
			h = 1
		end
		if ax + w > maxW then
			ax, ay, rowH = 0, ay + rowH, 0
		end
		uv[cp] = {
			x = ax,
			y = ay,
			w = gl.width,
			h = gl.height,
			advance = gl.advance,
			bx = gl.bearingX,
			by = gl.bearingY,
		}
		ax = ax + w + 1
		if h + 1 > rowH then
			rowH = h + 1
		end
		if ay + rowH > totalH then
			totalH = ay + rowH
		end
	end
	if totalH < 1 then
		totalH = 1
	end
	local blank = string.rep("\0", maxW * 4)
	local rows = {}
	for y = 1, totalH do
		rows[y] = blank
	end
	for _, cp in ipairs(order) do
		local gl = glyphs[cp]
		local u = uv[cp]
		if gl.width > 0 and gl.height > 0 then
			for row = 0, gl.height - 1 do
				local ry = u.y + row + 1
				local grow = string.sub(gl.buffer, row * gl.width * 4 + 1, (row + 1) * gl.width * 4)
				local base = rows[ry]
				local x0 = u.x * 4
				rows[ry] = string.sub(base, 1, x0) .. grow .. string.sub(base, x0 + gl.width * 4 + 1)
			end
		end
	end
	return {
		buffer = table.concat(rows),
		width = maxW,
		height = totalH,
		uv = uv,
		px = px,
	}
end

local function surfaceSize(surface)
	if type(surface) == "table" and type(surface.getSize) == "function" then
		local w, h = surface.getSize()
		if type(w) == "number" and type(h) == "number" then
			return w, h
		end
	end
	return 800, 600
end

local function blitClipped(surface, x, y, buffer, w)
	local h = math.floor(#buffer / 4 / w)
	if h <= 0 then
		return 0
	end
	local sw, sh = surfaceSize(surface)
	local x0, y0 = x, y
	local x1, y1 = x + w - 1, y + h - 1
	if x1 < 0 or y1 < 0 or x0 >= sw or y0 >= sh then
		return 0
	end
	local cx0 = x0 < 0 and 0 or x0
	local cy0 = y0 < 0 and 0 or y0
	local cx1 = x1 >= sw and sw - 1 or x1
	local cy1 = y1 >= sh and sh - 1 or y1
	local cw = cx1 - cx0 + 1
	if cw == w and (cy1 - cy0 + 1) == h and cx0 == x0 and cy0 == y0 then
		surface.writeData(cx0, cy0, buffer, w)
		return cw * h
	end
	local parts = {}
	for row = cy0 - y, cy1 - y do
		local s = row * w * 4 + (cx0 - x) * 4 + 1
		parts[#parts + 1] = string.sub(buffer, s, s + cw * 4 - 1)
	end
	surface.writeData(cx0, cy0, table.concat(parts), cw)
	return cw * (cy1 - cy0 + 1)
end

local function strokeSilhouette(gl, rad, r, g, b, a)
	local W, H = gl.width, gl.height
	local NW, NH = W + rad * 2, H + rad * 2
	local src = gl.buffer
	local sbyte, schar, mfloor = string.byte, string.char, math.floor
	local cov = {}
	for i = 1, W * H do
		cov[i] = sbyte(src, (i - 1) * 4 + 4)
	end
	local aScale = a / 255
	local lut = {}
	for cc = 0, 255 do
		lut[cc] = schar(r, g, b, mfloor(cc * aScale + 0.5))
	end
	local parts = {}
	local n = 0
	for y = 0, NH - 1 do
		for x = 0, NW - 1 do
			local best = 0
			for oy = -rad, rad do
				local sy = y - rad + oy
				if sy >= 0 and sy < H then
					local base = sy * W
					for ox = -rad, rad do
						local sx = x - rad + ox
						if sx >= 0 and sx < W then
							local v = cov[base + sx + 1]
							if v > best then
								best = v
								if best == 255 then
									break
								end
							end
						end
					end
					if best == 255 then
						break
					end
				end
			end
			n = n + 1
			parts[n] = lut[best]
		end
	end
	return table.concat(parts), NW
end

local function fillRect(surface, x, y, w, h, r, g, b, a, canWrite)
	x, y, w, h = math.floor(x), math.floor(y), math.floor(w), math.floor(h)
	if w <= 0 or h <= 0 then
		return 0
	end
	if canWrite then
		local row = string.rep(string.char(r, g, b, a), w)
		local parts = {}
		for _ = 1, h do
			parts[#parts + 1] = row
		end
		return blitClipped(surface, x, y, table.concat(parts), w)
	end
	if type(surface.writePixel) ~= "function" then
		return 0
	end
	local sw, sh = surfaceSize(surface)
	local done = 0
	for yy = y, y + h - 1 do
		if yy >= 0 and yy < sh then
			for xx = x, x + w - 1 do
				if xx >= 0 and xx < sw then
					surface.writePixel(xx, yy, r, g, b, a)
					done = done + 1
				end
			end
		end
	end
	return done
end

local function blitPixels(surface, x, y, glyph, r, g, b)
	if glyph.width == 0 or glyph.height == 0 then
		return 0
	end
	local sw, sh = surfaceSize(surface)
	local buf = glyph.buffer
	local done = 0
	for row = 0, glyph.height - 1 do
		local py = y + row
		if py >= 0 and py < sh then
			for col = 0, glyph.width - 1 do
				local px0 = x + col
				if px0 >= 0 and px0 < sw then
					local alpha = string.byte(buf, (row * glyph.width + col) * 4 + 4)
					if alpha > 0 then
						surface.writePixel(px0, py, r, g, b, alpha)
						done = done + 1
					end
				end
			end
		end
	end
	return done
end

local function isCJK(cp)
	return (cp >= 0x2E80 and cp <= 0x9FFF)
		or (cp >= 0xAC00 and cp <= 0xD7FF)
		or (cp >= 0xF900 and cp <= 0xFAFF)
		or (cp >= 0xFE30 and cp <= 0xFE4F)
		or (cp >= 0xFF00 and cp <= 0xFFEF)
		or (cp >= 0x20000 and cp <= 0x3FFFF)
end

local function noBreakBefore(cp)
	return cp == 0x21
		or cp == 0x22
		or cp == 0x29
		or cp == 0x2C
		or cp == 0x2E
		or cp == 0x3A
		or cp == 0x3B
		or cp == 0x3F
		or cp == 0x5D
		or cp == 0x7D
		or (cp >= 0x3001 and cp <= 0x3011)
		or (cp >= 0x3014 and cp <= 0x301F)
		or cp == 0xFF01
		or cp == 0xFF09
		or cp == 0xFF0C
		or cp == 0xFF0E
		or cp == 0xFF1A
		or cp == 0xFF1B
		or cp == 0xFF1F
		or cp == 0xFF3D
		or cp == 0xFF5D
		or cp == 0xFF61
		or cp == 0xFF64
end

local function layoutText(font, cps, px, opts)
	local letterSpacing = opts.letterSpacing or 0
	local wrapWidth = opts.wrapWidth
	local tabWidth = opts.tabWidth or 4
	local shaping = opts.shaping ~= false
	local doKern = opts.kerning ~= false
	local doLig = opts.ligatures ~= false
	local doMark = opts.marks ~= false
	local fallbacks = opts.fallback
	local breakCJK = opts.breakCJK ~= false
	local m = font:metrics(px)
	local scale = px / font.unitsPerEm
	local r, g, b, a =
		clampByte(opts.r == nil and 255 or opts.r),
		clampByte(opts.g == nil and 255 or opts.g),
		clampByte(opts.b == nil and 255 or opts.b),
		clampByte(opts.a == nil and 255 or opts.a)
	local ss = opts.supersample or 2
	local spaceAdv = math.floor((font._advances[font:glyphIndex(32)] or font.unitsPerEm / 4) * scale + 0.5)
	local lines = {}
	local cur, curW = {}, 0
	local function newline()
		lines[#lines + 1] = { items = cur, width = curW }
		cur, curW = {}, 0
	end
	local wordBuf, wordW = {}, 0
	local function flushWord()
		for _, it in ipairs(wordBuf) do
			cur[#cur + 1] = it
			curW = curW + it.advance + letterSpacing
		end
		wordBuf, wordW = {}, 0
	end
	local function resolve(cp)
		local gid = font:glyphIndex(cp)
		if gid ~= 0 or not fallbacks then
			return font, gid
		end
		for _, fb in ipairs(fallbacks) do
			if type(fb) == "table" and fb.unitsPerEm then
				local fg = fb:glyphIndex(cp)
				if fg ~= 0 then
					return fb, fg
				end
			end
		end
		return font, 0
	end
	local runFont, runGids, runCps = nil, {}, {}
	local layoutNextCp = nil
	local noRaster = opts.noRaster == true
	local function pushRunItem(wordItems, sh, fnt)
		local fscale = px / fnt.unitsPerEm
		for _, it in ipairs(sh.items) do
			local advPx = math.floor((it.adv + (it.kern or 0)) * fscale + 0.5)
			local ox = math.floor((it.dx or 0) * fscale + 0.5)
			local oy = math.floor((it.dy or 0) * fscale + 0.5)
			if noRaster then
				wordItems[#wordItems + 1] = {
					glyph = {
						buffer = "",
						width = 0,
						height = 0,
						bearingX = 0,
						bearingY = 0,
						advance = advPx,
						px = px,
						codepoint = it.cp,
						gid = it.gid,
						blank = true,
					},
					advance = advPx,
					ox = ox,
					oy = oy,
					cp = it.cp,
				}
			else
				local gl, err = rasterizeGid(fnt, it.gid, it.cp, px, r, g, b, a, ss, opts)
				if not gl then
					return nil, err
				end
				gl.advance = advPx
				wordItems[#wordItems + 1] = {
					glyph = gl,
					advance = advPx,
					ox = ox,
					oy = oy,
					cp = it.cp,
				}
			end
		end
		return true
	end
	local function flushRun()
		if #runCps == 0 or not runFont then
			return true
		end
		local fnt = runFont
		local items = {}
		if shaping and (fnt:hasShaping() or doKern) then
			local sh = shapeCps(fnt, runCps, doKern, doLig, doMark)
			local ok, err = pushRunItem(items, sh, fnt)
			if not ok then
				return nil, err
			end
		else
			local fscale = px / fnt.unitsPerEm
			for i, cp in ipairs(runCps) do
				local gid = runGids[i]
				if noRaster then
					local advPx = math.floor((fnt._advances[gid] or 0) * fscale + 0.5)
					items[#items + 1] = {
						glyph = {
							buffer = "",
							width = 0,
							height = 0,
							bearingX = 0,
							bearingY = 0,
							advance = advPx,
							px = px,
							codepoint = cp,
							gid = gid,
							blank = true,
						},
						advance = advPx,
						ox = 0,
						oy = 0,
						cp = cp,
					}
				else
					local gl, err = rasterizeGid(fnt, gid, cp, px, r, g, b, a, ss, opts)
					if not gl then
						return nil, err
					end
					items[#items + 1] = { glyph = gl, advance = gl.advance, ox = 0, oy = 0, cp = cp }
				end
			end
		end
		for _, item in ipairs(items) do
			if wrapWidth then
				if curW + wordW + item.advance > wrapWidth and (curW > 0 or wordW > 0) then
					if #cur == 0 then
						flushWord()
						newline()
					else
						newline()
					end
					wordBuf, wordW = {}, 0
				end
				wordBuf[#wordBuf + 1] = item
				wordW = wordW + item.advance + letterSpacing
				if breakCJK and isCJK(item.cp or 0) then
					if layoutNextCp == nil or (not noBreakBefore(layoutNextCp) and not isMarkCP(layoutNextCp)) then
						flushWord()
					end
				end
			else
				cur[#cur + 1] = item
				curW = curW + item.advance + letterSpacing
			end
		end
		runFont, runGids, runCps = nil, {}, {}
		return true
	end
	local i = 1
	while i <= #cps do
		local cp = cps[i]
		layoutNextCp = cps[i + 1]
		if cp == 10 then
			local ok, err = flushRun()
			if not ok then
				return nil, err
			end
			flushWord()
			newline()
		elseif cp == 32 or cp == 9 then
			local ok, err = flushRun()
			if not ok then
				return nil, err
			end
			flushWord()
			local adv = cp == 32 and spaceAdv or spaceAdv * tabWidth
			if wrapWidth and curW + adv > wrapWidth and curW > 0 then
				newline()
			else
				cur[#cur + 1] = { space = true, advance = adv }
				curW = curW + adv + letterSpacing
			end
		else
			local fnt, gid = resolve(cp)
			if runFont ~= fnt then
				local ok, err = flushRun()
				if not ok then
					return nil, err
				end
				runFont = fnt
			end
			runCps[#runCps + 1] = cp
			runGids[#runGids + 1] = gid
		end
		i = i + 1
	end
	layoutNextCp = nil
	local ok, err = flushRun()
	if not ok then
		return nil, err
	end
	flushWord()
	newline()
	return lines, m
end

function Font:measure(text, px, opts)
	opts = opts or {}
	if type(text) ~= "string" then
		return nil, "text must be a string"
	end
	if type(px) ~= "number" or px < 1 or px > 1024 then
		return nil, "pixel size must be in 1..1024"
	end
	px = math.floor(px)
	local mopts = {}
	for k, v in pairs(opts) do
		mopts[k] = v
	end
	mopts.noRaster = true
	mopts.r, mopts.g, mopts.b, mopts.a = 255, 255, 255, 255
	local lines, m = layoutText(self, fntp.decodeUTF8(text), px, mopts)
	if not lines or not m then
		return nil, m
	end
	local lh = math.floor(m.height * (opts.lineHeight or 1.0) + 0.5)
	local w = 0
	for _, ln in ipairs(lines) do
		if ln.width > w then
			w = ln.width
		end
	end
	return {
		width = w,
		height = lh * #lines,
		ascent = m.ascent,
		descent = m.descent,
		lineCount = #lines,
		lineHeight = lh,
	}
end

function Font:render(surface, x, y, text, px, r, g, b, opts)
	opts = opts or {}
	if type(surface) ~= "table" then
		return nil, "surface must be a table"
	end
	if type(text) ~= "string" then
		return nil, "text must be a string"
	end
	if type(px) ~= "number" or px < 1 or px > 1024 then
		return nil, "pixel size must be in 1..1024"
	end
	px = math.floor(px)
	r, g, b = clampByte(r), clampByte(g), clampByte(b)
	local alpha = clampByte(opts.a == nil and 255 or opts.a)
	x, y = math.floor(x), math.floor(y)
	local lines, m = layoutText(self, fntp.decodeUTF8(text), px, {
		letterSpacing = opts.letterSpacing or 0,
		wrapWidth = opts.wrapWidth,
		tabWidth = opts.tabWidth or 4,
		supersample = opts.supersample or 2,
		shaping = opts.shaping,
		kerning = opts.kerning,
		ligatures = opts.ligatures,
		marks = opts.marks,
		fallback = opts.fallback,
		breakCJK = opts.breakCJK,
		embolden = opts.embolden or opts.bold,
		slant = opts.slant or opts.italic,
		gamma = opts.gamma,
		r = r,
		g = g,
		b = b,
		a = alpha,
	})
	if not lines or not m then
		return nil, m
	end
	local lh = math.floor(m.height * (opts.lineHeight or 1.0) + 0.5)
	local align = opts.align or "left"
	local canWrite = type(surface.writeData) == "function"
	local canPixel = type(surface.writePixel) == "function"
	if not canWrite and not canPixel then
		return nil, "surface needs writeData or writePixel"
	end
	local strokeR = math.floor((opts.strokeWidth or 0) + 0.5)
	local sr, sg, sb, sa =
		clampByte(opts.sr == nil and r or opts.sr),
		clampByte(opts.sg == nil and g or opts.sg),
		clampByte(opts.sb == nil and b or opts.sb),
		clampByte(opts.sa == nil and alpha or opts.sa)
	if strokeR < 0 then
		strokeR = 0
	end
	if strokeR > 8 then
		strokeR = 8
	end
	if not canWrite then
		strokeR = 0
	end
	local ul, so
	if opts.underline then
		ul = self:underline(px)
	end
	if opts.strike then
		so = self:strikeout(px)
	end
	local maxW = 0
	for _, ln in ipairs(lines) do
		if ln.width > maxW then
			maxW = ln.width
		end
	end
	for li, ln in ipairs(lines) do
		local penX = x
		if align == "center" then
			penX = x + math.floor((maxW - ln.width) / 2)
		elseif align == "right" then
			penX = x + (maxW - ln.width)
		end
		local baseline = y + (li - 1) * lh + m.ascent
		local lineX0 = penX
		for _, item in ipairs(ln.items) do
			if item.space then
				penX = penX + item.advance + (opts.letterSpacing or 0)
			else
				local gl = item.glyph
				if not gl.blank and gl.width > 0 and gl.height > 0 then
					local gx = penX + gl.bearingX + (item.ox or 0)
					local gy = baseline - gl.bearingY - (item.oy or 0)
					if canWrite then
						if strokeR > 0 then
							local sbuf, sw = strokeSilhouette(gl, strokeR, sr, sg, sb, sa)
							blitClipped(surface, gx - strokeR, gy - strokeR, sbuf, sw)
						end
						blitClipped(surface, gx, gy, gl.buffer, gl.width)
					else
						blitPixels(surface, gx, gy, gl, r, g, b)
					end
				end
				penX = penX + item.advance + (opts.letterSpacing or 0)
			end
		end
		local lineW = penX - lineX0 - (opts.letterSpacing or 0)
		if lineW < 0 then
			lineW = 0
		end
		if ul and lineW > 0 then
			fillRect(surface, lineX0, baseline - ul.pos, lineW, ul.thick, r, g, b, alpha, canWrite)
		end
		if so and lineW > 0 then
			fillRect(surface, lineX0, baseline - so.pos, lineW, so.thick, r, g, b, alpha, canWrite)
		end
	end
	return { x = x + maxW, y = y, width = maxW, height = lh * #lines, lines = #lines }
end

function Font:renderGlyph(surface, x, y, what, px, r, g, b, opts)
	opts = opts or {}
	local gl, err = self:rasterize(what, px, {
		r = r,
		g = g,
		b = b,
		a = opts.a,
		supersample = opts.supersample or 2,
	})
	if not gl then
		return nil, err
	end
	if not gl.blank and gl.width > 0 and gl.height > 0 then
		if type(surface.writeData) == "function" then
			blitClipped(surface, math.floor(x), math.floor(y), gl.buffer, gl.width)
		elseif type(surface.writePixel) == "function" then
			blitPixels(surface, math.floor(x), math.floor(y), gl, clampByte(r), clampByte(g), clampByte(b))
		else
			return nil, "surface needs writeData or writePixel"
		end
	end
	return gl.advance
end

local POW2 = {}
for _powi = 0, 31 do
	POW2[_powi] = 2 ^ _powi
end

local CP1252_MAP = {
	[0x80] = 0x20AC,
	[0x82] = 0x201A,
	[0x83] = 0x0192,
	[0x84] = 0x201E,
	[0x85] = 0x2026,
	[0x86] = 0x2020,
	[0x87] = 0x2021,
	[0x88] = 0x02C6,
	[0x89] = 0x2030,
	[0x8A] = 0x0160,
	[0x8B] = 0x2039,
	[0x8C] = 0x0152,
	[0x8E] = 0x017D,
	[0x91] = 0x2018,
	[0x92] = 0x2019,
	[0x93] = 0x201C,
	[0x94] = 0x201D,
	[0x95] = 0x2022,
	[0x96] = 0x2013,
	[0x97] = 0x2014,
	[0x98] = 0x02DC,
	[0x99] = 0x2122,
	[0x9A] = 0x0161,
	[0x9B] = 0x203A,
	[0x9C] = 0x0153,
	[0x9E] = 0x017E,
	[0x9F] = 0x0178,
}

local function readAsciiz(data, off0)
	local p = off0 + 1
	if p < 1 or p > #data then
		return ""
	end
	local e = p
	while e <= #data and string.byte(data, e) ~= 0 do
		e = e + 1
	end
	return string.sub(data, p, e - 1)
end

bmpDetect = function(data)
	local n = #data
	if n >= 4 then
		local a, b, c, e = string.byte(data, 1, 4)
		if a == 0x01 and b == 0x66 and c == 0x63 and e == 0x70 then
			return "pcf"
		end
		if a == 0x72 and b == 0xB5 and c == 0x4A and e == 0x86 then
			return "psf"
		end
		if a == 0x36 and b == 0x04 then
			return "psf"
		end
	end
	if n >= 9 and string.sub(data, 1, 9) == "STARTFONT" then
		return "bdf"
	end
	if n >= 64 and string.sub(data, 1, 2) == "MZ" then
		local el = le32(data, 0x3D)
		if el >= 0 and el + 6 <= n then
			if string.sub(data, el + 1, el + 2) == "NE" then
				return "fon"
			end
			if string.sub(data, el + 1, el + 4) == "PE\0\0" then
				return "fon"
			end
		end
	end
	if n >= 118 then
		local v = le16(data, 1)
		if v == 0x200 or v == 0x300 then
			local pixH = le16(data, 89)
			local first = string.byte(data, 96)
			local last = string.byte(data, 97)
			local bits = le32(data, 114)
			if pixH >= 1 and pixH <= 256 and first <= last and (last - first) <= 255 and bits < n then
				return "fnt"
			end
		end
	end
	return nil
end

local BFont = {}
BFont.__index = BFont
setmetatable(BFont, { __index = Font })

function BFont:glyphIndex(cp)
	if type(cp) ~= "number" then
		return nil, "codepoint must be a number"
	end
	cp = math.floor(cp)
	local hit = self._gidCache[cp]
	if hit ~= nil then
		return hit
	end
	local g = self._cmap[cp]
	if g == nil then
		g = 0
	end
	if g < 0 or g >= self.numGlyphs then
		g = 0
	end
	self._gidCache[cp] = g
	return g
end

function BFont:getOutline(gid)
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	return nil, "bitmap font has no outlines (use rasterize)"
end

function BFont:glyphName(gid)
	if gid < 0 or gid >= self.numGlyphs then
		return nil, "glyph id out of range"
	end
	if self._glyphNames then
		return self._glyphNames[gid]
	end
	return nil
end

local function makeBitmapFont(spec, useCache)
	local adv, lsb = {}, {}
	for gid = 0, spec.ng - 1 do
		adv[gid] = spec.glyphs[gid].adv or 0
		lsb[gid] = spec.glyphs[gid].bx or 0
	end
	local upm = spec.upm
	local uthick = math.max(1, math.floor(upm / 14))
	return setmetatable({
		_cmap = spec.cmap,
		_bitmaps = spec.glyphs,
		_advances = adv,
		_lsbs = lsb,
		_kern = {},
		_gpos = nil,
		_gsub = nil,
		_vAdv = nil,
		_vTsb = nil,
		_vorg = nil,
		_gidCache = {},
		_outlineCache = {},
		_glyphCache = {},
		_cacheGlyphs = useCache,
		_cacheOutlines = false,
		isBitmap = true,
		format = "bitmap",
		outlines = "bitmap",
		kind = spec.kind,
		index = spec.index or 1,
		count = spec.count or 1,
		name = spec.name,
		_names = { [1] = spec.name, [4] = spec.name },
		unitsPerEm = upm,
		numGlyphs = spec.ng,
		ascender = spec.asc,
		descender = spec.desc,
		lineGap = spec.gap or 0,
		bbox = {
			xMin = 0,
			yMin = spec.desc,
			xMax = spec.cellW or 0,
			yMax = spec.asc,
		},
		cellW = spec.cellW,
		cellH = spec.cellH,
		underlineMetrics = {
			pos = -math.max(1, math.floor(upm / 12)),
			thick = uthick,
		},
		strikeoutMetrics = { pos = math.floor(upm * 0.3), size = uthick },
		weight = spec.weight,
		italicAngle = 0,
		isFixedPitch = spec.fixedPitch,
		_glyphNames = spec.glyphNames,
	}, BFont)
end

bmpRaster = function(font, gid, cp, px, r, g, b, a, ss, fx, cacheKey)
	fx = fx or {}
	if gid < 0 or gid >= font.numGlyphs then
		return nil, "glyph id out of range"
	end
	local gl0 = font._bitmaps[gid]
	local upm = font.unitsPerEm
	local scale = px / upm
	local advance = math.floor((font._advances[gid] or 0) * scale + 0.5)
	local function blank()
		local gl = {
			buffer = "",
			width = 0,
			height = 0,
			bearingX = 0,
			bearingY = 0,
			advance = advance,
			px = px,
			codepoint = cp,
			gid = gid,
			blank = true,
		}
		if cacheKey and font._cacheGlyphs then
			font._glyphCache[cacheKey] = gl
		end
		return gl
	end
	if gl0 == nil or gl0.w <= 0 or gl0.h <= 0 then
		return blank()
	end
	local w0, h0 = gl0.w, gl0.h
	local W = math.floor(w0 * scale + 0.5)
	local H = math.floor(h0 * scale + 0.5)
	if W < 1 or H < 1 then
		return blank()
	end
	if W > 1024 or H > 1024 then
		return nil, "glyph bitmap too large"
	end
	local raw, stride, covm = gl0.raw, gl0.stride, gl0.cov
	local function src(sx, sy)
		if covm then
			return covm[sy * w0 + sx + 1] or 0
		end
		local byte = string.byte(raw, sy * stride + math.floor(sx / 8) + 1) or 0
		return math.floor(byte / POW2[7 - (sx % 8)]) % 2
	end
	local cov = {}
	local any = false
	for ty = 0, H - 1 do
		local sy = math.floor(ty * h0 / H)
		if sy >= h0 then
			sy = h0 - 1
		end
		for tx = 0, W - 1 do
			local sx = math.floor(tx * w0 / W)
			if sx >= w0 then
				sx = w0 - 1
			end
			if src(sx, sy) == 1 then
				cov[ty * W + tx + 1] = 255
				any = true
			else
				cov[ty * W + tx + 1] = 0
			end
		end
	end
	if not any then
		return blank()
	end
	local bx = math.floor((gl0.bx or 0) * scale + 0.5)
	local by = math.floor((gl0.by or 0) * scale + 0.5)
	local slant = fx.slant or fx.italic or 0
	if slant == true then
		slant = 0.2
	end
	if slant ~= 0 then
		if type(slant) ~= "number" then
			return nil, "slant must be a number"
		end
		local shifts = {}
		local mn, mx = 0, 0
		for ty = 0, H - 1 do
			local dx = math.floor(slant * (H - 1 - ty) + 0.5)
			shifts[ty + 1] = dx
			if dx < mn then
				mn = dx
			end
			if dx > mx then
				mx = dx
			end
		end
		local NW = W + (mx - mn)
		if NW < 1 or NW > 1024 then
			return nil, "glyph bitmap too large"
		end
		local sh = {}
		for i = 1, NW * H do
			sh[i] = 0
		end
		for ty = 0, H - 1 do
			local dx = shifts[ty + 1] - mn
			for tx = 0, W - 1 do
				sh[ty * NW + tx + dx + 1] = cov[ty * W + tx + 1]
			end
		end
		cov, W, bx = sh, NW, bx + mn
	end
	local embolden = fx.embolden or fx.bold or 0
	if embolden == true then
		embolden = 1
	end
	if embolden ~= 0 then
		local rad = math.floor(embolden + 0.5)
		if rad < 1 then
			rad = 1
		end
		if rad > 2 then
			rad = 2
		end
		local dst = {}
		for y = 0, H - 1 do
			for x = 0, W - 1 do
				local best = 0
				for oy = -rad, rad do
					local yy = y + oy
					if yy >= 0 and yy < H then
						for ox = -rad, rad do
							local xx = x + ox
							if xx >= 0 and xx < W then
								local v = cov[yy * W + xx + 1]
								if v > best then
									best = v
								end
							end
						end
					end
				end
				dst[y * W + x + 1] = best
			end
		end
		cov = dst
	end
	local gamma = fx.gamma or 1
	local chunks = {}
	local n = 0
	for i = 1, W * H do
		local c = cov[i]
		if gamma ~= 1 then
			c = 255 * ((c / 255) ^ (1 / gamma))
		end
		n = n + 1
		chunks[n] = string.char(r, g, b, math.floor(c * a / 255 + 0.5))
	end
	local gl = {
		buffer = table.concat(chunks),
		width = W,
		height = H,
		bearingX = bx,
		bearingY = by,
		advance = advance,
		px = px,
		codepoint = cp,
		gid = gid,
	}
	if cacheKey and font._cacheGlyphs then
		font._glyphCache[cacheKey] = gl
	end
	return gl
end

bmpSdf = function(font, cp, px, spread)
	local gid = font:glyphIndex(cp)
	local gl, gerr = bmpRaster(font, gid, cp, px, 255, 255, 255, 255, 2, {}, nil)
	if not gl then
		return nil, gerr
	end
	if gl.blank or gl.width == 0 or gl.height == 0 then
		return {
			width = 0,
			height = 0,
			rows = {},
			advance = gl.advance,
			spread = spread,
			bearingX = 0,
			bearingY = 0,
			blank = true,
		}
	end
	local W, H = gl.width, gl.height
	local inside = {}
	for i = 1, W * H do
		inside[i] = string.byte(gl.buffer, (i - 1) * 4 + 4) >= 128
	end
	local function chamfer(seedOutside)
		local INF = (W + H) * 3 + 10
		local d = {}
		for i = 1, W * H do
			local isIn = inside[i]
			d[i] = ((isIn and not seedOutside) or (not isIn and seedOutside)) and 0 or INF
		end
		for y = 0, H - 1 do
			for x = 0, W - 1 do
				local i = y * W + x + 1
				local best = d[i]
				if x > 0 and d[i - 1] + 3 < best then
					best = d[i - 1] + 3
				end
				if y > 0 then
					if d[i - W] + 3 < best then
						best = d[i - W] + 3
					end
					if x > 0 and d[i - W - 1] + 4 < best then
						best = d[i - W - 1] + 4
					end
					if x < W - 1 and d[i - W + 1] + 4 < best then
						best = d[i - W + 1] + 4
					end
				end
				d[i] = best
			end
		end
		for y = H - 1, 0, -1 do
			for x = W - 1, 0, -1 do
				local i = y * W + x + 1
				local best = d[i]
				if x < W - 1 and d[i + 1] + 3 < best then
					best = d[i + 1] + 3
				end
				if y < H - 1 then
					if d[i + W] + 3 < best then
						best = d[i + W] + 3
					end
					if x < W - 1 and d[i + W + 1] + 4 < best then
						best = d[i + W + 1] + 4
					end
					if x > 0 and d[i + W - 1] + 4 < best then
						best = d[i + W - 1] + 4
					end
				end
				d[i] = best
			end
		end
		return d
	end
	local dIn = chamfer(false)
	local dOut = chamfer(true)
	local rows = {}
	for y = 0, H - 1 do
		local row = {}
		for x = 0, W - 1 do
			local i = y * W + x + 1
			local v = (dOut[i] - dIn[i]) / 3
			if v > spread then
				v = spread
			end
			if v < -spread then
				v = -spread
			end
			row[x + 1] = v
		end
		rows[y + 1] = row
	end
	return {
		width = W,
		height = H,
		rows = rows,
		spread = spread,
		bearingX = gl.bearingX,
		bearingY = gl.bearingY,
		advance = gl.advance,
	}
end

local function bmpParsePSF1(data)
	local mode = string.byte(data, 3)
	local chsize = string.byte(data, 4)
	if chsize < 1 or chsize > 128 then
		return nil, "bad PSF1 character size"
	end
	if mode > 5 then
		return nil, "bad PSF1 mode"
	end
	local ng = (mode % 2 == 1) and 512 or 256
	local hastab = math.floor(mode / 2) % 2 == 1
	local w, h = 8, chsize
	if 4 + ng * chsize > #data then
		return nil, "PSF1 bitmaps truncated"
	end
	local glyphs = {}
	for gi = 0, ng - 1 do
		local base = 5 + gi * chsize
		glyphs[gi] = {
			w = w,
			h = h,
			bx = 0,
			by = h,
			adv = w,
			raw = string.sub(data, base, base + chsize - 1),
			stride = 1,
		}
	end
	local cmap = {}
	if hastab then
		local p = 5 + ng * chsize
		local gi = 0
		local inSeq = false
		while p + 1 <= #data and gi < ng do
			local v = le16(data, p)
			p = p + 2
			if v == 0xFFFF then
				gi = gi + 1
				inSeq = false
			elseif v == 0xFFFE then
				inSeq = true
			elseif not inSeq then
				if cmap[v] == nil then
					cmap[v] = gi
				end
			end
		end
		for cp = 0, 255 do
			if cmap[cp] == nil and cp < ng then
				cmap[cp] = cp
			end
		end
	else
		for cp = 0, ng - 1 do
			cmap[cp] = cp
		end
	end
	return {
		kind = "psf",
		name = ("PSF1 %dx%d"):format(w, h),
		upm = h,
		ng = ng,
		asc = h,
		desc = 0,
		gap = 0,
		glyphs = glyphs,
		cmap = cmap,
		cellW = w,
		cellH = h,
		fixedPitch = true,
	}
end

local function bmpParsePSF2(data)
	if #data < 32 then
		return nil, "PSF2 data too short"
	end
	local ver = le32(data, 5)
	local hdrsize = le32(data, 9)
	local flags = le32(data, 13)
	local ng = le32(data, 17)
	local chsize = le32(data, 21)
	local h = le32(data, 25)
	local w = le32(data, 29)
	if ver ~= 0 then
		return nil, "unsupported PSF2 version"
	end
	if hdrsize < 32 or hdrsize > 4096 then
		return nil, "bad PSF2 header size"
	end
	if ng < 1 or ng > 8192 then
		return nil, "bad PSF2 glyph count"
	end
	if h < 1 or h > 512 or w < 1 or w > 128 then
		return nil, "bad PSF2 dimensions"
	end
	local stride = math.floor((w + 7) / 8)
	if chsize ~= h * stride then
		return nil, "bad PSF2 character size"
	end
	local bbase = hdrsize + 1
	if bbase + ng * chsize - 1 > #data then
		return nil, "PSF2 bitmaps truncated"
	end
	local glyphs = {}
	for gi = 0, ng - 1 do
		glyphs[gi] = {
			w = w,
			h = h,
			bx = 0,
			by = h,
			adv = w,
			raw = string.sub(data, bbase + gi * chsize, bbase + (gi + 1) * chsize - 1),
			stride = stride,
		}
	end
	local cmap = {}
	if flags % 2 == 1 then
		local tail = string.sub(data, bbase + ng * chsize)
		local segs = {}
		local start = 1
		for k = 1, #tail do
			if string.byte(tail, k) == 0xFF then
				segs[#segs + 1] = string.sub(tail, start, k - 1)
				start = k + 1
			end
		end
		for gi = 0, math.min(#segs, ng) - 1 do
			local seg = segs[gi + 1]
			local fe = string.find(seg, "\254", 1, true)
			local singles = fe and string.sub(seg, 1, fe - 1) or seg
			for _, cp in ipairs(fntp.decodeUTF8(singles)) do
				if cmap[cp] == nil then
					cmap[cp] = gi
				end
			end
		end
		for cp = 0, 255 do
			if cmap[cp] == nil and cp < ng then
				cmap[cp] = cp
			end
		end
	else
		for cp = 0, ng - 1 do
			cmap[cp] = cp
		end
	end
	return {
		kind = "psf",
		name = ("PSF2 %dx%d"):format(w, h),
		upm = h,
		ng = ng,
		asc = h,
		desc = 0,
		gap = 0,
		glyphs = glyphs,
		cmap = cmap,
		cellW = w,
		cellH = h,
		fixedPitch = true,
	}
end

local function bmpParsePSF(data)
	local a, b = string.byte(data, 1, 2)
	if a == 0x72 and b == 0xB5 then
		return bmpParsePSF2(data)
	end
	return bmpParsePSF1(data)
end

local function pcfReaders(fmt)
	if (fmt % 8) >= 4 then
		return u16, u32
	end
	return le16, le32
end

local function pcfTables(data)
	if #data < 8 then
		return nil, "PCF data too short"
	end
	local ntab = le32(data, 5)
	if ntab < 1 or ntab > 32 then
		return nil, "bad PCF table count"
	end
	if 8 + ntab * 16 > #data then
		return nil, "PCF directory truncated"
	end
	local tabs = {}
	for i = 0, ntab - 1 do
		local o = 9 + i * 16
		tabs[le32(data, o)] = {
			fmt = le32(data, o + 4),
			size = le32(data, o + 8),
			off = le32(data, o + 12),
		}
	end
	return tabs
end

local function pcfRangeOk(data, e)
	return e.off >= 0 and e.size >= 0 and e.off + e.size <= #data
end

local function pcfProperties(data, e)
	local o = e.off + 1
	if o + 7 > #data then
		return nil, "PCF properties truncated"
	end
	local _, R32 = pcfReaders(e.fmt)
	local nprops = R32(data, o + 4)
	if nprops > 512 then
		return nil, "bad PCF property count"
	end
	local recs = {}
	for i = 1, nprops do
		local ro = o + 8 + (i - 1) * 9
		if ro + 8 > #data then
			return nil, "PCF properties truncated"
		end
		recs[i] = {
			nm = R32(data, ro),
			isStr = string.byte(data, ro + 4),
			val = R32(data, ro + 5),
		}
	end
	local q = o + 8 + nprops * 9
	q = q + ((4 - (nprops * 9) % 4) % 4)
	if q + 3 > #data then
		return nil, "PCF properties truncated"
	end
	local ssize = R32(data, q)
	if ssize < 0 or ssize > 65536 then
		return nil, "bad PCF string table"
	end
	q = q + 4
	if ssize > 0 and q + ssize - 1 > #data then
		return nil, "PCF properties truncated"
	end
	local function gstr(off)
		if off < 0 or off >= ssize then
			return ""
		end
		local epos = off
		while epos < ssize and string.byte(data, q + epos) ~= 0 do
			epos = epos + 1
		end
		return string.sub(data, q + off, q + epos - 1)
	end
	local props = {}
	for _, rec in ipairs(recs) do
		local name = gstr(rec.nm)
		if name ~= "" then
			props[name] = (rec.isStr == 1) and gstr(rec.val) or rec.val
		end
	end
	return props
end

local function pcfAccelerators(data, e)
	if not e or not pcfRangeOk(data, e) then
		return nil
	end
	local o = e.off + 1
	if o + 19 > #data then
		return nil
	end
	local _, R32 = pcfReaders(e.fmt)
	local asc, desc = R32(data, o + 12), R32(data, o + 16)
	if asc < 1 or asc > 1024 or desc < 0 or desc > 1024 then
		return nil
	end
	return { ascent = asc, descent = desc }
end

local function pcfS16(R16, data, o)
	local v = R16(data, o)
	if v >= 32768 then
		return v - 65536
	end
	return v
end

local function pcfMetrics(data, e)
	local o = e.off + 1
	if o + 5 > #data then
		return nil, "PCF metrics truncated"
	end
	local R16 = pcfReaders(e.fmt)
	local compressed = math.floor(e.fmt / 256) % 2 == 1
	local mets = {}
	if compressed then
		local n = R16(data, o + 4)
		if n < 1 or n > 65536 then
			return nil, "bad PCF metric count"
		end
		local p = o + 6
		if p + n * 5 - 1 > #data then
			return nil, "PCF metrics truncated"
		end
		for i = 1, n do
			local b1, b2, b3, b4, b5 = string.byte(data, p, p + 4)
			mets[i] = {
				lb = b1 - 128,
				rb = b2 - 128,
				wd = b3 - 128,
				asc = b4 - 128,
				desc = b5 - 128,
			}
			p = p + 5
		end
	else
		local n = R16(data, o + 4)
		if n < 1 or n > 65536 then
			return nil, "bad PCF metric count"
		end
		local p = o + 6
		if p + n * 12 - 1 > #data then
			return nil, "PCF metrics truncated"
		end
		for i = 1, n do
			mets[i] = {
				lb = pcfS16(R16, data, p),
				rb = pcfS16(R16, data, p + 2),
				wd = pcfS16(R16, data, p + 4),
				asc = pcfS16(R16, data, p + 6),
				desc = pcfS16(R16, data, p + 8),
			}
			p = p + 12
		end
	end
	return mets
end

local function pcfBitmaps(data, e)
	local o = e.off + 1
	if o + 7 > #data then
		return nil, "PCF bitmaps truncated"
	end
	local R16, R32 = pcfReaders(e.fmt)
	local ng = R32(data, o + 4)
	if ng < 1 or ng > 65536 then
		return nil, "bad PCF bitmap count"
	end
	local po = o + 8
	if po + ng * 4 + 15 > #data then
		return nil, "PCF bitmaps truncated"
	end
	local offs = {}
	for i = 1, ng do
		offs[i] = R32(data, po + (i - 1) * 4)
	end
	local so = po + ng * 4
	local sizes = {}
	for i = 1, 4 do
		sizes[i] = R32(data, so + (i - 1) * 4)
	end
	local padIdx = (e.fmt % 4) + 1
	local datasize = sizes[padIdx]
	if datasize < 0 or datasize > 8000000 then
		return nil, "bad PCF bitmap size"
	end
	local dbase = so + 16
	if dbase + datasize - 1 > #data then
		return nil, "PCF bitmaps truncated"
	end
	return {
		ng = ng,
		offs = offs,
		dbase = dbase,
		datasize = datasize,
		msbByte = ((e.fmt % 8) >= 4),
		bitMSB = (math.floor(e.fmt / 8) % 2 == 1),
		pad = POW2[e.fmt % 4],
		unit = POW2[math.floor(e.fmt / 16) % 4],
	}
end

local function pcfEncodings(data, e)
	local o = e.off + 1
	if o + 13 > #data then
		return nil, "PCF encodings truncated"
	end
	local R16 = pcfReaders(e.fmt)
	local fc, lc, fr, lr = R16(data, o + 4), R16(data, o + 6), R16(data, o + 8), R16(data, o + 10)
	if lc < fc or lr < fr then
		return nil, "bad PCF encoding range"
	end
	local cols, rows = lc - fc + 1, lr - fr + 1
	if cols > 256 or rows > 256 or cols * rows > 65536 then
		return nil, "bad PCF encoding range"
	end
	local n = cols * rows
	local p = o + 14
	if p + n * 2 - 1 > #data then
		return nil, "PCF encodings truncated"
	end
	local map = {}
	for i = 0, n - 1 do
		local gv = R16(data, p + i * 2)
		if gv ~= 0xFFFF then
			local code
			if rows == 1 then
				code = fc + i
			else
				code = (fr + math.floor(i / cols)) * 256 + (fc + (i % cols))
			end
			map[code] = gv
		end
	end
	return map
end

local function bmpParsePCF(data)
	local tabs, terr = pcfTables(data)
	if not tabs then
		return nil, terr
	end
	if not (tabs[4] and tabs[8] and tabs[32]) then
		return nil, "PCF missing metrics/bitmaps/encodings tables"
	end
	if not (pcfRangeOk(data, tabs[4]) and pcfRangeOk(data, tabs[8]) and pcfRangeOk(data, tabs[32])) then
		return nil, "PCF table out of range"
	end
	local props = {}
	if tabs[1] and pcfRangeOk(data, tabs[1]) then
		local pr, perr = pcfProperties(data, tabs[1])
		if not pr then
			return nil, perr
		end
		props = pr
	end
	local mets, merr = pcfMetrics(data, tabs[4])
	if not mets then
		return nil, merr
	end
	local B, berr = pcfBitmaps(data, tabs[8])
	if not B then
		return nil, berr
	end
	if B.ng ~= #mets then
		return nil, "PCF bitmap/metric count mismatch"
	end
	local enc, eerr = pcfEncodings(data, tabs[32])
	if not enc then
		return nil, eerr
	end
	local accel = pcfAccelerators(data, tabs[2]) or pcfAccelerators(data, tabs[256])
	local asc, desc
	if accel then
		asc, desc = accel.ascent, accel.descent
	else
		asc, desc = 0, 0
		for _, m in ipairs(mets) do
			if m.asc > asc then
				asc = m.asc
			end
			if m.desc > desc then
				desc = m.desc
			end
		end
		if asc < 1 then
			return nil, "bad PCF metrics"
		end
	end
	local upm = asc + desc
	if upm < 1 or upm > 2048 then
		return nil, "bad PCF metrics"
	end
	local glyphs = {}
	local cellW = 0
	for gi = 1, #mets do
		local m = mets[gi]
		local w, h = m.rb - m.lb, m.asc + m.desc
		local gl
		if w <= 0 or h <= 0 then
			gl = { w = 0, h = 0, bx = 0, by = 0, adv = m.wd }
		else
			local rowBytes = math.floor((w + 7) / 8)
			local stride = math.floor((rowBytes + B.pad - 1) / B.pad) * B.pad
			local goff = B.offs[gi]
			local blob = nil
			if goff >= 0 and goff + h * stride <= B.datasize then
				if B.unit == 1 and B.bitMSB then
					local parts = {}
					for y = 0, h - 1 do
						local pos = B.dbase + goff + y * stride
						parts[y + 1] = string.sub(data, pos, pos + rowBytes - 1)
					end
					blob = table.concat(parts)
				else
					local parts = {}
					for y = 0, h - 1 do
						local row = {}
						for k = 0, rowBytes - 1 do
							local phys = k
							if B.unit > 1 and (B.bitMSB ~= B.msbByte) then
								local grp = math.floor(k / B.unit)
								phys = grp * B.unit + (B.unit - 1 - (k % B.unit))
							end
							local byte = string.byte(data, B.dbase + goff + y * stride + phys) or 0
							if not B.bitMSB then
								local mb = 0
								for bb = 0, 7 do
									mb = mb + (math.floor(byte / POW2[bb]) % 2) * POW2[7 - bb]
								end
								byte = mb
							end
							row[k + 1] = string.char(byte)
						end
						parts[y + 1] = table.concat(row)
					end
					blob = table.concat(parts)
				end
			end
			if blob then
				gl = {
					w = w,
					h = h,
					bx = m.lb,
					by = m.asc,
					adv = m.wd,
					raw = blob,
					stride = rowBytes,
				}
			else
				gl = { w = 0, h = 0, bx = 0, by = 0, adv = m.wd }
			end
		end
		glyphs[gi - 1] = gl
		if m.wd > cellW then
			cellW = m.wd
		end
	end
	local cmap = {}
	for code, gv in pairs(enc) do
		if gv >= 0 and gv < #mets and cmap[code] == nil then
			cmap[code] = gv
		end
	end
	local name = props.FULL_NAME or props.FAMILY_NAME or "PCF bitmap font"
	if type(name) ~= "string" or name == "" then
		name = "PCF bitmap font"
	end
	if props.FAMILY_NAME and props.PIXEL_SIZE and not props.FULL_NAME then
		name = props.FAMILY_NAME .. " " .. tostring(props.PIXEL_SIZE)
	end
	local fixed = nil
	if props.SPACING == "P" then
		fixed = false
	elseif props.SPACING == "M" or props.SPACING == "C" then
		fixed = true
	end
	return {
		kind = "pcf",
		name = name,
		upm = upm,
		ng = #mets,
		asc = asc,
		desc = -desc,
		gap = 0,
		glyphs = glyphs,
		cmap = cmap,
		cellW = cellW,
		cellH = upm,
		fixedPitch = fixed,
	}
end

local function bdfHexVal(b)
	if b >= 48 and b <= 57 then
		return b - 48
	end
	if b >= 65 and b <= 70 then
		return b - 55
	end
	if b >= 97 and b <= 102 then
		return b - 87
	end
	return nil
end

local function bmpParseBDF(data)
	local lines = {}
	local p = 1
	while p <= #data do
		local nl = string.find(data, "\n", p, true)
		local line
		if nl then
			line = string.sub(data, p, nl - 1)
			p = nl + 1
		else
			line = string.sub(data, p)
			p = #data + 1
		end
		if #line > 0 and string.byte(line, #line) == 13 then
			line = string.sub(line, 1, #line - 1)
		end
		lines[#lines + 1] = line
	end
	if #lines < 4 or lines[1]:sub(1, 9) ~= "STARTFONT" then
		return nil, "bad BDF header"
	end
	local fontName, bbx, nchars
	local props = {}
	local i = 2
	local function words(line)
		local out = {}
		for w in line:gmatch("%S+") do
			out[#out + 1] = w
		end
		return out
	end
	while i <= #lines do
		local W = words(lines[i])
		if W[1] == "FONT" and not fontName then
			fontName = lines[i]:sub(6):match("^%s*(.-)%s*$")
		elseif W[1] == "FONTBOUNDINGBOX" then
			bbx = {
				w = tonumber(W[2]),
				h = tonumber(W[3]),
				x = tonumber(W[4]),
				y = tonumber(W[5]),
			}
		elseif W[1] == "STARTPROPERTIES" then
			i = i + 1
			while i <= #lines and lines[i]:sub(1, 13) ~= "ENDPROPERTIES" do
				local k, v = lines[i]:match("^(%S+)%s+(.-)%s*$")
				if k then
					if v:sub(1, 1) == '"' then
						props[k] = v:sub(2, -2)
					else
						props[k] = tonumber(v) or v
					end
				end
				i = i + 1
			end
		elseif W[1] == "CHARS" then
			nchars = tonumber(W[2])
			i = i + 1
			break
		end
		i = i + 1
	end
	if not bbx or not bbx.w or not bbx.h then
		return nil, "BDF missing FONTBOUNDINGBOX"
	end
	if bbx.w < 1 or bbx.w > 256 or bbx.h < 1 or bbx.h > 512 then
		return nil, "bad BDF bounding box"
	end
	if not nchars or nchars < 1 or nchars > 65535 then
		return nil, "bad BDF character count"
	end
	local glyphs, cmap, gnames = {}, {}, {}
	local ng = 0
	local totalPx = 0
	while i <= #lines do
		if lines[i]:sub(1, 9) == "STARTCHAR" then
			local gname = lines[i]:sub(10):match("^%s*(.-)%s*$") or ""
			local enc, dwx, gw, gh, gx, gy, rows
			enc, dwx = -1, nil
			i = i + 1
			while i <= #lines do
				local L = lines[i]
				if L:sub(1, 8) == "ENCODING" then
					enc = tonumber(L:match("(-?%d+)")) or -1
					i = i + 1
				elseif L:sub(1, 6) == "DWIDTH" then
					local a = L:match("DWIDTH%s+(-?%d+)")
					dwx = tonumber(a)
					i = i + 1
				elseif L:sub(1, 3) == "BBX" then
					local a, b, c, d = L:match("BBX%s+(-?%d+)%s+(-?%d+)%s+" .. "(-?%d+)%s+(-?%d+)")
					gw, gh, gx, gy = tonumber(a), tonumber(b), tonumber(c), tonumber(d)
					i = i + 1
				elseif L == "BITMAP" then
					rows = {}
					i = i + 1
					while i <= #lines and lines[i] ~= "ENDCHAR" do
						rows[#rows + 1] = lines[i]
						i = i + 1
					end
				elseif L == "ENDCHAR" then
					break
				else
					i = i + 1
				end
			end
			if gw and gh and dwx then
				if gw < 0 or gw > 256 or gh < 0 or gh > 512 then
					return nil, "bad BDF glyph metrics"
				end
				totalPx = totalPx + gw * gh
				if totalPx > 4000000 then
					return nil, "BDF font too large"
				end
				local cov = {}
				if gw > 0 and gh > 0 then
					local stride = math.floor((gw + 7) / 8)
					for y = 0, gh - 1 do
						local row = (rows and rows[y + 1]) or ""
						for x = 0, gw - 1 do
							local hx = math.floor(x / 8) * 2
							local hi = bdfHexVal(string.byte(row, hx + 1) or 48) or 0
							local lo = bdfHexVal(string.byte(row, hx + 2) or 48) or 0
							cov[y * gw + x + 1] = math.floor((hi * 16 + lo) / POW2[7 - (x % 8)]) % 2
						end
					end
				end
				glyphs[ng] = {
					w = gw,
					h = gh,
					bx = gx or 0,
					by = (gy or 0) + gh,
					adv = dwx,
					cov = cov,
				}
				gnames[ng] = (gname ~= "") and gname or nil
				local cp = nil
				if enc >= 0 then
					cp = enc
				elseif gname ~= "" then
					if #gname == 1 then
						cp = string.byte(gname, 1)
					else
						local uni = gname:match("^uni(%x%x%x%x)$") or gname:match("^u(%x%x%x%x%x?)$")
						if uni then
							cp = tonumber(uni, 16)
						end
					end
				end
				if cp and cmap[cp] == nil then
					cmap[cp] = ng
				end
				ng = ng + 1
				if ng > 65535 then
					return nil, "too many BDF glyphs"
				end
			end
		elseif lines[i] == "ENDFONT" then
			break
		end
		i = i + 1
	end
	if ng == 0 then
		return nil, "BDF has no glyphs"
	end
	local asc = tonumber(props.FONT_ASCENT)
	local desc = tonumber(props.FONT_DESCENT)
	if not asc then
		asc = bbx.y + bbx.h
	end
	if not desc then
		desc = (bbx.y < 0) and -bbx.y or 0
	end
	if asc < 1 or asc > 1024 or desc < 0 or desc > 1024 then
		return nil, "bad BDF metrics"
	end
	local cellW = 0
	for gid = 0, ng - 1 do
		if glyphs[gid].adv > cellW then
			cellW = glyphs[gid].adv
		end
	end
	local fixed = nil
	if props.SPACING == "P" then
		fixed = false
	elseif props.SPACING == "M" or props.SPACING == "C" then
		fixed = true
	end
	local name = fontName or props.FAMILY_NAME or "BDF bitmap font"
	return {
		kind = "bdf",
		name = name,
		upm = asc + desc,
		ng = ng,
		asc = asc,
		desc = -desc,
		gap = 0,
		glyphs = glyphs,
		cmap = cmap,
		glyphNames = gnames,
		cellW = cellW,
		cellH = asc + desc,
		fixedPitch = fixed,
	}
end

local function fntCharToCp(code, charset)
	if charset == 2 then
		return 0xF000 + code
	end
	if code >= 0x80 and code <= 0x9F then
		return CP1252_MAP[code] or code
	end
	return code
end

local function bmpParseFNT(data)
	if #data < 118 then
		return nil, "FNT data too short"
	end
	local ver = le16(data, 1)
	if ver ~= 0x200 and ver ~= 0x300 then
		return nil, "bad FNT version"
	end
	local v3 = (ver == 0x300)
	local hsize = v3 and 148 or 118
	if #data < hsize then
		return nil, "FNT data too short"
	end
	local ftype = le16(data, 67)
	if ftype % 2 == 1 then
		return nil, "vector FNT fonts are not supported (raster only)"
	end
	local ascent = le16(data, 75)
	local extLead = le16(data, 79)
	local weight = le16(data, 84)
	local charset = string.byte(data, 86)
	local pixW = le16(data, 87)
	local pixH = le16(data, 89)
	local avgW = le16(data, 92)
	local maxW = le16(data, 94)
	local first = string.byte(data, 96)
	local last = string.byte(data, 97)
	local bits0 = le32(data, 114)
	if pixH < 1 or pixH > 256 then
		return nil, "bad FNT height"
	end
	if first > last then
		return nil, "bad FNT character range"
	end
	if last - first > 255 then
		return nil, "bad FNT character range"
	end
	if maxW < 1 or maxW > 256 then
		return nil, "bad FNT width"
	end
	if bits0 >= #data then
		return nil, "FNT bitmaps out of range"
	end
	local face = readAsciiz(data, le32(data, 106))
	local nEnt = (last - first) + 2
	if pixH * maxW * nEnt > 4000000 then
		return nil, "FNT font too large"
	end
	local es = v3 and 6 or 4
	local ctab = hsize + 1
	if ctab + nEnt * es - 1 > #data then
		return nil, "FNT character table truncated"
	end
	local widths, offs = {}, {}
	for k = 0, nEnt - 1 do
		local q = ctab + k * es
		widths[k] = le16(data, q)
		offs[k] = v3 and le32(data, q + 2) or le16(data, q + 2)
		if widths[k] > 256 then
			return nil, "bad FNT glyph width"
		end
	end
	if ascent < 1 or ascent > pixH then
		ascent = pixH
	end
	local glyphs, cmap = {}, {}
	for k = 0, nEnt - 2 do
		local wdt = (pixW ~= 0) and pixW or widths[k]
		local goff = offs[k]
		local gnext = offs[k + 1]
		local cov = {}
		if wdt > 0 then
			local stripes = math.floor((wdt + 7) / 8)
			for s = 0, stripes - 1 do
				for y = 0, pixH - 1 do
					local pos = goff + 1 + s * pixH + y
					local byte = (pos >= 1 and pos <= #data) and string.byte(data, pos) or 0
					for b = 0, 7 do
						local x = s * 8 + b
						if x < wdt then
							cov[y * wdt + x + 1] = math.floor(byte / POW2[7 - b]) % 2
						end
					end
				end
			end
			if gnext < goff then
				return nil, "bad FNT glyph offsets"
			end
		end
		glyphs[k] = {
			w = wdt,
			h = (wdt > 0) and pixH or 0,
			bx = 0,
			by = ascent,
			adv = wdt,
			cov = cov,
		}
		local code = first + k
		cmap[fntCharToCp(code, charset)] = k
	end
	local name = (face ~= "") and face or "FNT bitmap font"
	return {
		kind = "fnt",
		name = name,
		upm = pixH,
		ng = nEnt - 1,
		asc = ascent,
		desc = ascent - pixH,
		gap = extLead,
		glyphs = glyphs,
		cmap = cmap,
		cellW = (pixW ~= 0) and pixW or maxW,
		cellH = pixH,
		weight = weight,
		fixedPitch = (pixW ~= 0),
		avgWidth = avgW,
	}
end

local function fonFontsNE(data, el)
	local ne = el + 1
	if ne + 63 > #data then
		return nil, "FON NE header truncated"
	end
	if string.sub(data, ne, ne + 1) ~= "NE" then
		return nil, "not an NE executable"
	end
	local rtabOff = le16(data, ne + 0x24)
	local rpos = el + rtabOff + 1
	if rpos < 1 or rpos + 1 > #data then
		return nil, "FON resource table out of range"
	end
	local align = le16(data, rpos)
	if align > 16 then
		return nil, "bad FON alignment shift"
	end
	local mult = 2 ^ align
	local p = rpos + 2
	local out = {}
	while true do
		if p + 7 > #data then
			return nil, "FON resource table truncated"
		end
		local tid = le16(data, p)
		local count = le16(data, p + 2)
		p = p + 8
		if tid == 0 then
			break
		end
		if count < 1 or count > 256 then
			return nil, "bad FON resource count"
		end
		if p + count * 12 - 1 > #data then
			return nil, "FON resource table truncated"
		end
		if tid == 0x8008 or tid == 8 then
			for j = 0, count - 1 do
				local q = p + j * 12
				local ro = le16(data, q)
				local rl = le16(data, q + 2)
				if ro ~= 0 and rl ~= 0 then
					local off0 = ro * mult
					local got = nil
					local cands = { rl, rl * mult }
					for _, ln in ipairs(cands) do
						if ln >= 118 and off0 + ln <= #data then
							local chunk = string.sub(data, off0 + 1, off0 + ln)
							local v = le16(chunk, 1)
							if v == 0x200 or v == 0x300 then
								got = chunk
								break
							end
						end
					end
					if got then
						out[#out + 1] = got
					end
				end
			end
		end
		p = p + count * 12
		if #out > 64 then
			return nil, "too many FON font resources"
		end
	end
	if #out == 0 then
		return nil, "FON contains no FONT resources"
	end
	return out
end

local function fonFontsPE(data, el)
	local pe = el + 1
	if pe + 27 > #data then
		return nil, "FON PE header truncated"
	end
	if string.sub(data, pe, pe + 3) ~= "PE\0\0" then
		return nil, "not a PE executable"
	end
	local nsec = le16(data, pe + 6)
	local optsz = le16(data, pe + 20)
	if nsec < 1 or nsec > 64 then
		return nil, "bad FON section count"
	end
	local stab = pe + 24 + optsz
	if stab + nsec * 40 - 1 > #data then
		return nil, "FON section table truncated"
	end
	local secs = {}
	for k = 0, nsec - 1 do
		local q = stab + k * 40
		secs[k + 1] = {
			name = string.sub(data, q, q + 7),
			vsize = le32(data, q + 8),
			vaddr = le32(data, q + 12),
			rawsz = le32(data, q + 16),
			rawptr = le32(data, q + 20),
		}
	end
	local function rva2off(rva)
		for _, s in ipairs(secs) do
			local span = math.max(s.vsize, s.rawsz)
			if s.rawptr ~= 0 and rva >= s.vaddr and rva < s.vaddr + span then
				local o = s.rawptr + (rva - s.vaddr) + 1
				if o >= 1 and o <= #data then
					return o
				end
			end
		end
		return nil
	end
	local rsrc = nil
	for _, s in ipairs(secs) do
		if s.name:sub(1, 5) == ".rsrc" then
			rsrc = s
			break
		end
	end
	if not rsrc then
		return nil, "FON has no resource section"
	end
	local root = rva2off(rsrc.vaddr)
	if not root then
		return nil, "FON resource section out of range"
	end
	local function dirEntries(dpos)
		if dpos + 15 > #data then
			return nil, "FON resource tree truncated"
		end
		local total = le16(data, dpos + 12) + le16(data, dpos + 14)
		if total > 256 then
			return nil, "bad FON resource directory"
		end
		local list = {}
		for k = 0, total - 1 do
			local epos = dpos + 16 + k * 8
			if epos + 7 > #data then
				return nil, "FON resource tree truncated"
			end
			list[k + 1] = { id = le32(data, epos), off = le32(data, epos + 4) }
		end
		return list
	end
	local l0, lerr = dirEntries(root)
	if not l0 then
		return nil, lerr
	end
	local out = {}
	for _, e0 in ipairs(l0) do
		if e0.id < 0x80000000 and (e0.id % 0x10000) == 8 and e0.off >= 0x80000000 then
			local l1, e1 = dirEntries(root + (e0.off % 0x80000000))
			if not l1 then
				return nil, e1
			end
			for _, e1e in ipairs(l1) do
				if e1e.off >= 0x80000000 then
					local l2, e2 = dirEntries(root + (e1e.off % 0x80000000))
					if not l2 then
						return nil, e2
					end
					for _, e2e in ipairs(l2) do
						if e2e.off < 0x80000000 then
							local dent = root + e2e.off
							if dent + 15 <= #data then
								local drva, dsize = le32(data, dent), le32(data, dent + 4)
								local doff = rva2off(drva)
								if doff and dsize >= 118 and doff + dsize - 1 <= #data then
									local chunk = string.sub(data, doff, doff + dsize - 1)
									local v = le16(chunk, 1)
									if v == 0x200 or v == 0x300 then
										out[#out + 1] = chunk
									end
								end
							end
						end
					end
				end
			end
		end
	end
	if #out == 0 then
		return nil, "FON contains no FONT resources"
	end
	return out
end

local function fonFonts(data)
	if #data < 64 or string.sub(data, 1, 2) ~= "MZ" then
		return nil, "not a FON executable"
	end
	local el = le32(data, 0x3D)
	if el < 0 or el + 6 > #data then
		return nil, "bad FON executable header"
	end
	if string.sub(data, el + 1, el + 2) == "NE" then
		return fonFontsNE(data, el)
	end
	if string.sub(data, el + 1, el + 4) == "PE\0\0" then
		return fonFontsPE(data, el)
	end
	return nil, "FON must be an NE or PE executable with FONT resources"
end

bmpCount = function(data, kind)
	if kind == "fon" then
		local fonts, ferr = fonFonts(data)
		if not fonts then
			return nil, ferr
		end
		return #fonts
	end
	return 1
end

bmpLoad = function(data, kind, opts)
	opts = opts or {}
	local index = opts.index or 1
	if type(index) ~= "number" or index < 1 or math.floor(index) ~= index then
		return nil, "index must be a positive integer"
	end
	local useCache = opts.cache ~= false
	if kind == "fon" then
		local fonts, ferr = fonFonts(data)
		if not fonts then
			return nil, ferr
		end
		if index > #fonts then
			return nil, ("FON index %d out of range (1..%d)"):format(index, #fonts)
		end
		local spec, serr = bmpParseFNT(fonts[index])
		if not spec then
			return nil, serr
		end
		spec.kind = "fon"
		spec.count = #fonts
		spec.index = index
		if #fonts > 1 then
			spec.name = spec.name .. " #" .. index
		end
		return makeBitmapFont(spec, useCache)
	end
	if index ~= 1 then
		return nil, "index > 1 requires a .ttc or .fon collection"
	end
	local spec, serr
	if kind == "pcf" then
		spec, serr = bmpParsePCF(data)
	elseif kind == "psf" then
		spec, serr = bmpParsePSF(data)
	elseif kind == "bdf" then
		spec, serr = bmpParseBDF(data)
	elseif kind == "fnt" then
		spec, serr = bmpParseFNT(data)
	else
		return nil, ("unsupported bitmap kind '%s'"):format(tostring(kind))
	end
	if not spec then
		return nil, serr
	end
	spec.count = 1
	spec.index = 1
	return makeBitmapFont(spec, useCache)
end

local REQUIRED_TTF = { "cmap", "glyf", "head", "hhea", "hmtx", "loca", "maxp" }
local REQUIRED_OTF = { "CFF ", "cmap", "head", "hhea", "hmtx", "maxp" }

local function loadFont(data, opts)
	opts = opts or {}
	if type(data) ~= "string" then
		return nil, "font data must be a string"
	end
	if #data < 12 then
		return nil, "font data too short"
	end
	local magic0 = tag(data, 1)
	if magic0 == "wOF2" then
		return nil, "WOFF2 fonts are not supported (needs Brotli); use WOFF 1.0 or raw TTF/OTF"
	end
	if magic0 == "wOFF" then
		local raw, werr = woffUnpack(data)
		if not raw then
			return nil, werr
		end
		data = raw
	end
	do
		local bk = bmpDetect(data)
		if bk then
			return bmpLoad(data, bk, opts)
		end
	end
	local index = opts.index or 1
	if type(index) ~= "number" or index < 1 or math.floor(index) ~= index then
		return nil, "index must be a positive integer"
	end
	local base = 1
	local count = 1
	local magic = tag(data, 1)
	if magic == "ttcf" then
		local version = u32(data, 5)
		if version ~= 0x00010000 and version ~= 0x00020000 then
			return nil, ("unsupported TTC version 0x%08X"):format(version)
		end
		count = u32(data, 9)
		if count < 1 or count > 256 then
			return nil, "bad TTC font count"
		end
		if index > count then
			return nil, ("TTC index %d out of range (1..%d)"):format(index, count)
		end
		base = u32(data, 9 + index * 4) + 1
		if base < 1 or base + 11 > #data then
			return nil, "bad TTC font offset"
		end
	elseif index ~= 1 then
		return nil, "index > 1 requires a .ttc collection"
	end
	local tables, version, derr = readDirectory(data, base)
	if not tables then
		return nil, derr
	end
	local isCFF = (version == 0x4F54544F)
	if not isCFF and (version ~= 0x00010000 and version ~= 0x74727565) then
		return nil, ("unsupported sfnt version 0x%08X"):format(version)
	end
	if tables["CFF2"] and not tables["CFF "] then
		isCFF = true
	end
	if not isCFF and tables["CFF "] then
		return nil, "font has both TrueType and CFF outlines; unsupported"
	end
	local needTables = isCFF and REQUIRED_OTF or REQUIRED_TTF
	for _, t in ipairs(needTables) do
		if t == "CFF " and tables["CFF2"] then
		elseif not tables[t] then
			return nil, ("missing required table '%s'"):format(t)
		end
	end
	local function slice(t)
		local e = tables[t]
		if e.offset + 1 < 1 or e.offset + e.length > #data then
			return nil
		end
		return e.offset + 1
	end
	local headOff = slice("head")
	local maxpOff = slice("maxp")
	local hheaOff = slice("hhea")
	local hmtxOff = slice("hmtx")
	local cmapOff = slice("cmap")
	local locaOff, glyfOff
	if not isCFF then
		locaOff = slice("loca")
		glyfOff = slice("glyf")
	end
	if not (headOff and maxpOff and hheaOff and hmtxOff and cmapOff) or (not isCFF and not (locaOff and glyfOff)) then
		return nil, "font table extends past end of data"
	end
	if tables["head"].length < 54 then
		return nil, "truncated head table"
	end
	if tables["maxp"].length < 6 then
		return nil, "truncated maxp table"
	end
	if tables["hhea"].length < 36 then
		return nil, "truncated hhea table"
	end
	local head = parseHead(data, headOff)
	if head.unitsPerEm < 16 or head.unitsPerEm > 16384 then
		return nil, ("bad unitsPerEm %d"):format(head.unitsPerEm)
	end
	if head.indexToLocFormat ~= 0 and head.indexToLocFormat ~= 1 then
		return nil, "bad indexToLocFormat"
	end
	local maxp = parseMaxp(data, maxpOff)
	if maxp.numGlyphs < 1 or maxp.numGlyphs > 65535 then
		return nil, "bad numGlyphs"
	end
	local hhea = parseHhea(data, hheaOff)
	if hhea.numberOfHMetrics < 1 or hhea.numberOfHMetrics > maxp.numGlyphs then
		return nil, "bad numberOfHMetrics"
	end
	do
		local needH = hhea.numberOfHMetrics * 4 + (maxp.numGlyphs - hhea.numberOfHMetrics) * 2
		if tables["hmtx"].length < needH then
			return nil, "truncated hmtx table"
		end
	end
	local advances, lsbs = parseHmtx(data, hmtxOff, maxp.numGlyphs, hhea.numberOfHMetrics)
	local loca, cff
	if isCFF then
		if tables["CFF2"] and not tables["CFF "] then
			local cff2Off = tables["CFF2"].offset + 1
			cff, derr = parseCFF2(data, cff2Off, tables["CFF2"].length, maxp.numGlyphs)
			if not cff then
				return nil, derr
			end
			if cff.fds then
				for _, fd in pairs(cff.fds) do
					fd.scale = fd.scale * head.unitsPerEm
				end
			else
				cff.scale = cff.fontMatrix * head.unitsPerEm
			end
		else
			local cffOff = tables["CFF "].offset + 1
			cff, derr = parseCFF(data, cffOff, tables["CFF "].length, maxp.numGlyphs)
			if not cff then
				return nil, derr
			end
			if cff.isCID then
				for _, fd in pairs(cff.fds) do
					fd.scale = fd.scale * head.unitsPerEm
				end
			else
				cff.scale = cff.fontMatrix * head.unitsPerEm
			end
		end
	else
		local needLoca = (maxp.numGlyphs + 1) * (head.indexToLocFormat == 0 and 2 or 4)
		if tables["loca"].length < needLoca then
			return nil, "truncated loca table"
		end
		loca = parseLoca(data, locaOff, maxp.numGlyphs, head.indexToLocFormat)
		local glyfLen = tables["glyf"].length
		local prev = 0
		for i = 0, maxp.numGlyphs do
			local v = loca[i]
			if not v or v < prev or v > glyfLen then
				return nil, "bad loca entry"
			end
			prev = v
		end
	end
	local cmap, cerr = parseCmap(data, cmapOff, tables["cmap"].length)
	if not cmap then
		return nil, cerr
	end
	local name
	local namesFull = {}
	if tables["name"] then
		local noff = tables["name"].offset + 1
		if noff + tables["name"].length - 1 <= #data then
			name = parseName(data, noff, tables["name"].length)
			namesFull = parseNameFull(data, noff, tables["name"].length)
		end
	end
	local kernMap = {}
	if tables["kern"] then
		local koff = tables["kern"].offset + 1
		if koff + tables["kern"].length - 1 <= #data then
			kernMap = parseKern(data, koff, tables["kern"].length)
		end
	end
	local os2
	if tables["OS/2"] then
		local ooff = tables["OS/2"].offset + 1
		if ooff + tables["OS/2"].length - 1 <= #data then
			os2 = parseOS2(data, ooff, tables["OS/2"].length)
		end
	end
	local post
	if tables["post"] then
		local poff = tables["post"].offset + 1
		if poff + tables["post"].length - 1 <= #data then
			post = parsePost(data, poff, tables["post"].length)
		end
	end
	local vAdv, vTsb, vhea
	if tables["vhea"] and tables["vmtx"] then
		local voff = tables["vhea"].offset + 1
		local moff = tables["vmtx"].offset + 1
		if voff + tables["vhea"].length - 1 <= #data and moff + tables["vmtx"].length - 1 <= #data then
			vhea = parseVhea(data, voff)
			if vhea.numVerMetrics >= 1 and vhea.numVerMetrics <= maxp.numGlyphs then
				local needV = vhea.numVerMetrics * 4 + (maxp.numGlyphs - vhea.numVerMetrics) * 2
				if tables["vmtx"].length >= needV then
					vAdv, vTsb = parseVmtx(data, moff, maxp.numGlyphs, vhea.numVerMetrics)
				else
					vhea = nil
				end
			else
				vhea = nil
			end
		end
	end
	local gpos, gsub
	if tables["GPOS"] then
		local goff = tables["GPOS"].offset + 1
		if goff + tables["GPOS"].length - 1 <= #data then
			gpos = parseGPOS(data, goff, tables["GPOS"].length)
		end
	end
	if tables["GSUB"] then
		local goff = tables["GSUB"].offset + 1
		if goff + tables["GSUB"].length - 1 <= #data then
			gsub = parseGSUB(data, goff, tables["GSUB"].length)
		end
	end
	local vorg
	if tables["VORG"] then
		local voff = tables["VORG"].offset + 1
		if voff + tables["VORG"].length - 1 <= #data then
			vorg = parseVorg(data, voff, tables["VORG"].length)
		end
	end
	local useCache = opts.cache ~= false
	local font = setmetatable({
		_data = data,
		_tables = tables,
		_glyfOff = glyfOff,
		_glyfEnd = glyfOff and tables["glyf"] and (glyfOff + tables["glyf"].length - 1) or nil,
		_loca = loca,
		_cff = cff,
		_cmap = cmap,
		_advances = advances,
		_lsbs = lsbs,
		_kern = kernMap,
		_gpos = gpos,
		_gsub = gsub,
		_vAdv = vAdv,
		_vTsb = vTsb,
		_vorg = vorg,
		_gidCache = {},
		_outlineCache = {},
		_glyphCache = {},
		_cacheGlyphs = useCache,
		_cacheOutlines = useCache,
		format = isCFF and "otf" or "ttf",
		outlines = isCFF and "cff" or "glyf",
		kind = magic == "ttcf" and "ttc" or (isCFF and "otf" or "ttf"),
		index = index,
		count = count,
		name = name,
		_names = namesFull,
		os2 = os2,
		post = post,
		unitsPerEm = head.unitsPerEm,
		numGlyphs = maxp.numGlyphs,
		ascender = hhea.ascender,
		descender = hhea.descender,
		lineGap = hhea.lineGap,
		bbox = { xMin = head.xMin, yMin = head.yMin, xMax = head.xMax, yMax = head.yMax },
	}, Font)
	if os2 then
		font.weight = os2.weightClass
		font.widthClass = os2.widthClass
		font.vendor = os2.vendor
		font.typo = {
			ascender = os2.typoAscender,
			descender = os2.typoDescender,
			lineGap = os2.typoLineGap,
		}
		font.win = { ascent = os2.winAscent, descent = os2.winDescent }
		font.xHeight = os2.xHeight
		font.capHeight = os2.capHeight
		font.strikeoutMetrics = { pos = os2.strikeoutPos, size = os2.strikeoutSize }
	end
	if post then
		font.italicAngle = post.italicAngle
		font.underlineMetrics = { pos = post.underlinePos, thick = post.underlineThick }
		font.isFixedPitch = post.isFixedPitch
	end
	if vhea then
		font.vert = {
			ascender = vhea.ascender,
			descender = vhea.descender,
			lineGap = vhea.lineGap,
		}
	end
	return font
end

function fntp.load(data, opts)
	local ok, font, err = pcall(loadFont, data, opts)
	if not ok then
		return nil, "bad font: " .. tostring(font)
	end
	return font, err
end

function fntp.list(data)
	local info, err = fntp.inspect(data)
	if not info then
		return nil, err
	end
	local out = {}
	for i = 1, info.count do
		local f, ferr = fntp.load(data, { index = i, cache = false })
		out[i] = { index = i, name = f and f.name or nil, error = ferr }
	end
	return out
end

function fntp.chain(fonts)
	if type(fonts) ~= "table" or #fonts < 1 then
		return nil, "chain needs a non-empty font array"
	end
	local primary = fonts[1]
	local rest = {}
	for i = 2, #fonts do
		rest[#rest + 1] = fonts[i]
	end
	local ch = {
		_fonts = fonts,
		name = primary.name,
		unitsPerEm = primary.unitsPerEm,
		numGlyphs = primary.numGlyphs,
		format = primary.format,
		outlines = primary.outlines,
		kind = "chain",
	}
	function ch:glyphIndex(cp)
		for _, f in ipairs(fonts) do
			local gid = f:glyphIndex(cp)
			if gid ~= 0 then
				return gid
			end
		end
		return 0
	end

	function ch:charIndex(s)
		return self:glyphIndex(fntp.decodeUTF8(s)[1] or 0xFFFD)
	end

	function ch:hmetrics(gid)
		return primary:hmetrics(gid)
	end

	function ch:metrics(px)
		return primary:metrics(px)
	end

	function ch:kerning(l, r)
		return primary:kerning(l, r)
	end

	function ch:shape(text, opts)
		return primary:shape(text, opts)
	end

	function ch:rasterize(what, px, opts)
		local cp
		if type(what) == "number" then
			cp = math.floor(what)
		elseif type(what) == "string" then
			cp = fntp.decodeUTF8(what)[1] or 0xFFFD
		else
			return nil, "glyph must be a codepoint or character"
		end
		for _, f in ipairs(fonts) do
			if f:glyphIndex(cp) ~= 0 then
				return f:rasterize(what, px, opts)
			end
		end
		return primary:rasterize(what, px, opts)
	end

	function ch:decode(glyph)
		return primary:decode(glyph)
	end

	local function withFallback(opts)
		opts = opts or {}
		if opts.fallback == nil then
			local o2 = {}
			for k, v in pairs(opts) do
				o2[k] = v
			end
			o2.fallback = rest
			return o2
		end
		return opts
	end
	function ch:measure(text, px, opts)
		return primary:measure(text, px, withFallback(opts))
	end

	function ch:render(surface, x, y, text, px, r, g, b, opts)
		return primary:render(surface, x, y, text, px, r, g, b, withFallback(opts))
	end

	function ch:renderGlyph(surface, x, y, what, px, r, g, b, opts)
		local cp
		if type(what) == "number" then
			cp = math.floor(what)
		elseif type(what) == "string" then
			cp = fntp.decodeUTF8(what)[1] or 0xFFFD
		else
			return nil, "glyph must be a codepoint or character"
		end
		for _, f in ipairs(fonts) do
			if f:glyphIndex(cp) ~= 0 then
				return f:renderGlyph(surface, x, y, what, px, r, g, b, opts)
			end
		end
		return primary:renderGlyph(surface, x, y, what, px, r, g, b, opts)
	end

	function ch:underline(px)
		return primary:underline(px)
	end

	function ch:strikeout(px)
		return primary:strikeout(px)
	end

	function ch:clearCache()
		local o, g = 0, 0
		for _, f in ipairs(fonts) do
			local c = f:clearCache()
			o, g = o + c.outlines, g + c.glyphs
		end
		return { outlines = o, glyphs = g }
	end

	return ch
end

return fntp
