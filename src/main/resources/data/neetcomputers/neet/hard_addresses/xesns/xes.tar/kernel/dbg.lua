local K = ...

local rawdebug = debug
local rawcreate = coroutine.create
local rawstatus = coroutine.status
local rawclose = coroutine.close
local rawrunning = coroutine.running
local rawyield = coroutine.yield
local rawisyieldable = coroutine.isyieldable
local rawequal = rawequal

local argerr, argint = K.argcheck.err, K.argcheck.int

local states = setmetatable({}, { __mode = "k" })
local owner = setmetatable({}, { __mode = "k" })

local function needroot()
	if K.current.uid ~= 0 then
		return nil, "EACCES", "debug requires root"
	end
	return true
end

local function needco(co)
	if type(co) ~= "thread" then
		return nil, "EINVAL", "thread expected"
	end
	local st = states[co]
	if not st then
		return nil, "EINVAL", "not a debuggee"
	end
	if owner[co] ~= K.current.pid then
		return nil, "EACCES", "not your debuggee"
	end
	return st
end

local function kfunc(fn)
	if type(fn) ~= "function" then
		return false
	end
	for i = 1, 256 do
		local _, v = rawdebug.getupvalue(fn, i)
		if v == nil then
			break
		end
		if rawequal(v, K) then
			return true
		end
	end
	return false
end

local kfuncCache = setmetatable({}, { __mode = "k" })
local function iskfunc(fn)
	if type(fn) ~= "function" then
		return false
	end
	local v = kfuncCache[fn]
	if v == nil then
		v = kfunc(fn)
		kfuncCache[fn] = v
	end
	return v
end

local INFO_ALLOW = {
	source = true,
	short_src = true,
	currentline = true,
	linedefined = true,
	lastlinedefined = true,
	what = true,
	name = true,
	namewhat = true,
	nups = true,
	nparams = true,
	isvararg = true,
}

local MAXFRAMES = 256

local DBG_SRC = (rawdebug.getinfo(1, "S") or {}).source

local function frameInfo(level)
	local i = rawdebug.getinfo(level, "Sfn")
	if type(i) ~= "table" then
		return nil
	end
	local out = {}
	for k in pairs(INFO_ALLOW) do
		out[k] = i[k]
	end
	local f = i.func
	if type(f) == "function" then
		local fs = rawdebug.getinfo(f, "S")
		if type(fs) == "table" then
			out.linedefined = fs.linedefined
			out.lastlinedefined = fs.lastlinedefined
			out.nups = fs.nups
			out.nparams = fs.nparams
			out.isvararg = fs.isvararg
			if out.source == nil then
				out.source = fs.source
			end
			if out.short_src == nil then
				out.short_src = fs.short_src
			end
		end
	end
	out.kernel = (out.what ~= "Lua" and out.what ~= "main") or iskfunc(f)
	return out
end

local function snapshot()
	local snap = {}
	local started = false
	for level = 1, MAXFRAMES do
		local fi = frameInfo(level)
		if not fi then
			break
		end
		if started or fi.source ~= DBG_SRC then
			started = true
			snap[#snap + 1] = fi
		end
	end
	return snap
end

local function hookfn(event)
	local p = K.current
	if not p or p.critical > 0 then
		return
	end
	if p.dying then
		error(K.EXIT, 0)
	end
	if event == "count" then
		if rawisyieldable() then
			rawyield(K.PREEMPT)
		end
		return
	end
	local co = rawrunning()
	local st = states[co]
	if not st then
		return
	end
	if event == "call" then
		st.depth = st.depth + 1
		return
	elseif event == "return" then
		st.depth = st.depth - 1
		return
	elseif event == "tail call" then
		return
	elseif event ~= "line" then
		return
	end
	local info = rawdebug.getinfo(2, "Sl")
	if not info then
		return
	end
	local cur = info.currentline
	if cur == nil or cur < 1 then
		return
	end
	local stop, why = false, nil
	if st.mode == "step" then
		stop, why = true, "step"
	elseif st.mode == "next" then
		if st.depth <= st.depth0 then
			stop, why = true, "next"
		end
	elseif st.mode == "out" then
		if st.depth < st.depth0 then
			stop, why = true, "out"
		end
	end
	if not stop and cur ~= nil and st.breaks[cur] and (st.src == nil or info.source == st.src) then
		stop, why = true, "break"
	end
	if stop then
		st.stopped, st.why, st.line, st.stopdepth = true, why, cur, st.depth
		st.snap = snapshot()
		if rawisyieldable() then
			rawyield()
		end
	end
end

local api = {}

function api.create(fn)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	if type(fn) ~= "function" then
		argerr(1, "create", "function", fn)
	end
	local co = rawcreate(fn)
	local src = nil
	local si = rawdebug.getinfo(fn, "S")
	if type(si) == "table" then
		src = si.source
	end
	states[co] = {
		mode = "run",
		depth = 0,
		depth0 = 0,
		breaks = {},
		src = src,
		stopped = false,
		why = nil,
		line = nil,
		stopdepth = 0,
		snap = nil,
	}
	owner[co] = K.current.pid
	rawdebug.sethook(co, hookfn, "lcr", K.quantum)
	return co
end

function api.resume(co, ...)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	st.stopped, st.why, st.line = false, nil, nil
	st.snap = nil
	return K.usercoroutine.resume(co, ...)
end

function api.state(co)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	return st.stopped, st.why, st.line, st.stopdepth
end

function api.mode(co, m)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	if m ~= "run" and m ~= "step" and m ~= "next" and m ~= "out" then
		return nil, "EINVAL", "mode must be run, step, next or out"
	end
	st.mode = m
	if m == "next" or m == "out" then
		st.depth0 = st.stopdepth
	end
	return true
end

function api.addbreak(co, line)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	line = argint(line, 2, "addbreak")
	if line < 1 then
		return nil, "EINVAL", "bad line number"
	end
	st.breaks[line] = true
	return true
end

function api.delbreak(co, line)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	line = argint(line, 2, "delbreak")
	st.breaks[line] = nil
	return true
end

function api.clearbreaks(co)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	st.breaks = {}
	return true
end

function api.listbreaks(co)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	local out = {}
	for line in pairs(st.breaks) do
		out[#out + 1] = line
	end
	table.sort(out)
	return out
end

function api.info(co, level, what)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	level = argint(level, 2, "info")
	if level < 0 then
		return nil, "EINVAL", "bad level"
	end
	if what ~= nil and type(what) ~= "string" then
		what = tostring(what)
	end
	local r = st.snap and st.snap[level + 1]
	if r == nil then
		return nil
	end
	local out = {}
	for k in pairs(INFO_ALLOW) do
		out[k] = r[k]
	end
	out.kernel = r.kernel
	return out
end

function api.locals(co, level)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	level = argint(level, 2, "locals")
	if level < 0 then
		return nil, "EINVAL", "bad level"
	end
	local fr = st.snap and st.snap[level + 1]
	if fr == nil then
		return nil, "EINVAL", "bad level"
	end
	if fr.what ~= "Lua" and fr.what ~= "main" then
		return nil, "EACCES", "not a Lua frame"
	end
	if fr.kernel then
		return nil, "EACCES", "kernel frame"
	end
	local out = {}
	for i = 1, 256 do
		local ok, name, val = pcall(rawdebug.getlocal, co, level, i)
		if not ok or name == nil then
			break
		end
		out[#out + 1] = { name = name, value = val }
	end
	return out
end

function api.setlocal(co, level, idx, val)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	level = argint(level, 2, "setlocal")
	idx = argint(idx, 3, "setlocal")
	if level < 0 or idx < 1 then
		return nil, "EINVAL", "bad level or index"
	end
	local fr = st.snap and st.snap[level + 1]
	if fr == nil then
		return nil, "EINVAL", "bad level"
	end
	if fr.what ~= "Lua" and fr.what ~= "main" then
		return nil, "EACCES", "not a Lua frame"
	end
	if fr.kernel then
		return nil, "EACCES", "kernel frame"
	end
	local ok, name = pcall(rawdebug.setlocal, co, level, idx, val)
	if not ok or name == nil then
		return nil, "EINVAL", "cannot write locals on this VM (debug.setlocal is not implemented)"
	end
	return name
end

function api.traceback(co, msg, level)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	if level ~= nil then
		level = argint(level, 3, "traceback")
	end
	local tb = rawdebug.traceback(co, msg, level)
	if type(tb) ~= "string" then
		return ""
	end
	local out = {}
	for line in (tb .. "\n"):gmatch("([^\n]*)\n") do
		if not line:find("/kernel/", 1, true) then
			out[#out + 1] = line
		end
	end
	return table.concat(out, "\n")
end

function api.status(co)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	return rawstatus(co)
end

function api.close(co)
	local rok, rc, rm = needroot()
	if not rok then
		return nil, rc, rm
	end
	local st, ec, em = needco(co)
	if not st then
		return nil, ec, em
	end
	pcall(rawdebug.sethook, co)
	states[co] = nil
	owner[co] = nil
	pcall(rawclose, co)
	return true
end

function K.dbg_release(p)
	local dead = {}
	for co, pid in pairs(owner) do
		if pid == p.pid then
			dead[#dead + 1] = co
		end
	end
	for _, co in ipairs(dead) do
		pcall(rawdebug.sethook, co)
		states[co] = nil
		owner[co] = nil
		pcall(rawclose, co)
	end
end

function K.dbgapi()
	local t = {}
	for k, v in pairs(api) do
		t[k] = v
	end
	return t
end

K.extensions["x.xesns.dbg"] = 1
