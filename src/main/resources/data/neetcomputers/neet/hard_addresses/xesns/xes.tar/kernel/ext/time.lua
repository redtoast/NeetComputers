local K, API, X = ...
local T = {}

function T.wallPrecise(p)
	return K.wallnow()
end

T.__ext = { ["x.xesns.time"] = 1 }

return T
