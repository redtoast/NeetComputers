return {
    extensions = { "conf", "ini", "cfg", "rc" },
    words = {
        ["yes"] = "constant", ["no"] = "constant", ["on"] = "constant",
        ["off"] = "constant", ["true"] = "constant", ["false"] = "constant",
        ["none"] = "constant", ["default"] = "constant",
    },
    rules = {
        { "comment", "[#;].*" },
        { "type", "^%[.-%]" },
        { "keyword", "^[%w_%.%-]+%s*=" },
        { "string", '"[^"]*"', "'[^']*'" },
        { "number", "%f[%d]%d+" },
        { "variable", "%$%b{}", "%$[%w_]+" },
    },
}
