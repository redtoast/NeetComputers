local u = require("util")

local M = {}

function M.norm(p)
	local segs = {}
	for seg in tostring(p or ""):gmatch("[^/]+") do
		if seg == "." then
		elseif seg == ".." then
			if #segs > 0 then
				segs[#segs] = nil
			end
		else
			segs[#segs + 1] = seg
		end
	end
	return "/" .. table.concat(segs, "/")
end

function M.getcwd()
	local c = u.resolve(".")
	if type(c) ~= "string" or c == "" then
		c = u.getenv("PWD")
	end
	if type(c) ~= "string" or c == "" then
		return "/"
	end
	c = u.pretty(c)
	if c:sub(1, 1) ~= "/" then
		c = "/" .. c
	end
	return c
end

function M.join(dir, name)
	if dir == "/" or dir == "" or dir == nil then
		return "/" .. tostring(name)
	end
	return dir .. "/" .. tostring(name)
end

function M.abspath(p, base)
	p = (p or ""):gsub("^%s+", ""):gsub("%s+$", "")
	if p == "" then
		return nil
	end
	if p:sub(1, 1) ~= "/" then
		base = base or M.getcwd()
		if base == "/" then
			base = ""
		end
		p = base .. "/" .. p
	end
	return M.norm(p)
end

function M.canonical(path, depth)
	depth = depth or 0
	if depth > 32 then
		return nil, "too many levels of symbolic links"
	end
	local abs = M.abspath(path)
	if not abs then
		return nil, "invalid path"
	end
	local parts = {}
	for seg in abs:gmatch("[^/]+") do
		parts[#parts + 1] = seg
	end
	local cur = "/"
	local i = 1
	while i <= #parts do
		local nextp = M.join(cur, parts[i])
		local st, serr = u.lstat(nextp)
		if not st then
			if serr and serr ~= "no such file or directory" and serr ~= "not a directory" then
				return nil, serr
			end
			local rest = table.concat(parts, "/", i)
			if cur == "/" then
				return "/" .. rest
			end
			return cur .. "/" .. rest
		end
		if st.type == "link" then
			local tgt = st.link
			if tgt == nil then
				tgt = u.readlink(nextp)
			end
			if type(tgt) ~= "string" or tgt == "" then
				return nil, "cannot read symbolic link " .. nextp
			end
			local base
			if tgt:sub(1, 1) == "/" then
				base = M.norm(tgt)
			else
				base = M.norm(M.join(cur, tgt))
			end
			local rest = table.concat(parts, "/", i + 1)
			local full = base
			if rest ~= "" then
				full = (base == "/" and "" or base) .. "/" .. rest
			end
			if full == "" then
				full = "/"
			end
			return M.canonical(full, depth + 1)
		end
		cur = nextp
		i = i + 1
	end
	return cur
end

function M.entries(dir, max)
	local names, rerr = u.readdir(dir)
	local out = {}
	if dir ~= "/" then
		local parent = dir:match("^(.*)/[^/]*$")
		if not parent or parent == "" then
			parent = "/"
		end
		out[1] = { name = "..", full = parent, dir = true, kind = "dir" }
	end
	if not names then
		return out, rerr or "cannot read directory"
	end
	local unknown = 0
	local seen = 0
	for _, n in ipairs(names) do
		if n:sub(1, 1) ~= "." then
			local full = M.join(dir, n)
			if max and seen >= max then
				unknown = unknown + 1
				out[#out + 1] = {
					name = n,
					full = full,
					kind = "unknown",
					dir = false,
					link = false,
				}
			else
				seen = seen + 1
				local st = u.lstat(full)
				out[#out + 1] = {
					name = n,
					full = full,
					kind = st and st.type or "missing",
					dir = st ~= nil and st.type == "dir",
					link = st ~= nil and st.type == "link",
					target = st and st.link,
					size = st and st.size,
				}
			end
		end
	end
	table.sort(out, function(a, b)
		if a.name == ".." then
			return b.name ~= ".."
		end
		if b.name == ".." then
			return false
		end
		local adir, bdir = not not a.dir, not not b.dir
		if adir ~= bdir then
			return adir
		end
		return a.name < b.name
	end)
	return out, nil, unknown
end

function M.label(e)
	if e.link then
		return e.name .. " -> " .. tostring(e.target or "?")
	end
	return e.name .. (e.dir and "/" or "")
end

function M.remove(e)
	if not e or type(e.full) ~= "string" then
		return nil, "no such entry"
	end
	if e.full == "/" then
		return nil, "refusing to delete /"
	end
	local st, serr = u.lstat(e.full)
	if not st then
		return nil, serr or "no such file or directory"
	end
	if st.type == "dir" then
		return u.rmtree(e.full)
	end
	return u.unlink(e.full)
end

function M.paste(src, dest)
	local sst, serr = u.lstat(src)
	if not sst then
		return nil, serr or "no such file or directory"
	end
	if M.norm(src) == M.norm(dest) then
		return nil, "source and destination are the same"
	end
	if sst.type == "dir" then
		local rs, re = M.canonical(src)
		if not rs then
			return nil, re
		end
		local rd, de = M.canonical(dest)
		if not rd then
			return nil, de
		end
		if rd == rs or (rs ~= "/" and rd:sub(1, #rs + 1) == rs .. "/") then
			return nil, "cannot copy a folder into itself"
		end
	end
	return u.copyTree(src, dest, {})
end

function M.check_save_dest(p)
	if type(p) ~= "string" or p == "" then
		return nil, "no file selected"
	end
	if p:sub(1, 1) ~= "/" then
		return nil, "path is not absolute"
	end
	local st = u.lstat(p)
	if st then
		if st.type == "dir" then
			return nil, "is a directory"
		end
		if st.type == "link" then
			return nil, "is a symbolic link"
		end
		if st.type ~= "file" then
			return nil, "not a regular file"
		end
	end
	local parent = p:match("^(.*)/[^/]*$") or "/"
	if parent == "" then
		parent = "/"
	end
	local pst = u.stat(parent)
	if not pst or pst.type ~= "dir" then
		return nil, "no such directory: " .. parent
	end
	return true
end

return M
