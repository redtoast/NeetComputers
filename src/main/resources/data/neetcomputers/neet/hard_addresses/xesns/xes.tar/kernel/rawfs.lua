local K = ...

local R = {}
K.rawfs = R

local files = files

local function msgOf(e)
    e = tostring(e)
    return (e:gsub("^[^:]*:%d+:%s*", ""))
end

function R.disks()
    local out = {}
    local ok, raw = pcall(files.getDisks)
    if not ok or type(raw) ~= "table" then return out end
    for _, d in ipairs(raw) do
        local slot = type(d) == "table" and (d.slot or d[1]) or d
        local okid, id = pcall(files.getDiskID, slot)
        if not okid or type(id) ~= "string" or id == "" then id = "disk" .. tostring(slot) end
        out[#out + 1] = { slot = slot, id = id }
    end
    table.sort(out, function(a, b) return a.slot < b.slot end)
    return out
end

function R.diskByRef(ref)
    for _, d in ipairs(R.disks()) do
        if d.id == ref or (type(ref) == "number" and d.slot == ref)
            or (type(ref) == "string" and ref:match("^%d+$") and d.slot == tonumber(ref)) then
            return d
        end
    end
end

function R.partitions(slot)
    local ok, parts = pcall(files.getPartitions, slot)
    if not ok or type(parts) ~= "table" then return nil, msgOf(parts) end

    if type(parts[1]) == "table" and parts[1].name == nil and #parts == 1 then parts = parts[1] end
    local out = {}
    for _, p in ipairs(parts) do out[#out + 1] = type(p) == "table" and p.name or p end
    table.sort(out)
    return out
end

function R.hasPartition(slot, name)
    local parts = R.partitions(slot)
    if not parts then return false end
    for _, p in ipairs(parts) do if p == name then return true end end
    return false
end

local function rp(part, path) return part .. ":" .. path end

function R.exists(slot, part, path)
    local ok, r = pcall(files.exists, rp(part, path), slot)
    return ok and r == true
end

function R.isDir(slot, part, path)
    if path == "/" then return R.hasPartition(slot, part) end
    local ok, r = pcall(files.isDir, rp(part, path), slot)
    return ok and r == true
end

function R.isFile(slot, part, path)
    local ok, r = pcall(files.isFile, rp(part, path), slot)
    return ok and r == true
end

function R.list(slot, part, path)
    local ok, r = pcall(files.getChildren, rp(part, path), slot)
    if not ok then return nil, msgOf(r) end
    local out = {}
    for _, n in ipairs(r or {}) do out[#out + 1] = n end
    return out
end

function R.mkdir(slot, part, path)
    local ok, r = pcall(files.makeDir, rp(part, path), slot)
    if not ok then return nil, msgOf(r) end
    if r == false then return nil, "cannot create directory" end
    return true
end

function R.remove(slot, part, path)
    local ok, r = pcall(files.delete, rp(part, path), slot)
    if not ok then return nil, msgOf(r) end
    if r == false then return nil, "cannot delete (not empty?)" end
    return true
end

function R.open(slot, part, path, mode)
    local ok, h = pcall(files.open, rp(part, path), mode, slot)
    if not ok or not h then return nil, msgOf(h) end
    return h
end

function R.readAll(slot, part, path)
    local h, err = R.open(slot, part, path, "r")
    if not h then return nil, err end
    local ok, data = pcall(h.read, "a")
    pcall(h.close)
    if not ok then return nil, msgOf(data) end
    return data or ""
end

function R.writeAll(slot, part, path, data)
    local h, err = R.open(slot, part, path, "w")
    if not h then return nil, err end
    local ok, e = pcall(function()
        if #data > 0 then h.write(data) end
        h.flush()
    end)
    pcall(h.close)
    if not ok then return nil, msgOf(e) end
    return true
end
