local M = {}

local MONTHS = { jan = 1, feb = 2, mar = 3, apr = 4, may = 5, jun = 6,
    jul = 7, aug = 8, sep = 9, oct = 10, nov = 11, dec = 12 }
local DAYS = { sun = 0, mon = 1, tue = 2, wed = 3, thu = 4, fri = 5, sat = 6 }

local FIELDS = {
    { name = "minute", lo = 0, hi = 59 },
    { name = "hour", lo = 0, hi = 23 },
    { name = "dom", lo = 1, hi = 31 },
    { name = "month", lo = 1, hi = 12, names = MONTHS },
    { name = "dow", lo = 0, hi = 7, names = DAYS },
}

local MACROS = {
    ["@reboot"] = "reboot",
    ["@yearly"] = "0 0 1 1 *",
    ["@annually"] = "0 0 1 1 *",
    ["@monthly"] = "0 0 1 * *",
    ["@weekly"] = "0 0 * * 0",
    ["@daily"] = "0 0 * * *",
    ["@midnight"] = "0 0 * * *",
    ["@hourly"] = "0 * * * *",
}

local function copy(t)
    local o = {}
    for k, v in pairs(t) do o[k] = v end
    return o
end

local function resolve(tok, names)
    local n = tonumber(tok)
    if n then return n end
    if names then return names[tok:lower()] end
end

local function parseField(text, lo, hi, names)
    local set = {}
    for part in (text .. ","):gmatch("([^,]*),") do
        if part == "" then return nil, "empty list element" end
        local base, step = part:match("^([^/]+)/(%d+)$")
        if base then
            step = tonumber(step)
            if step < 1 then return nil, "bad step in '" .. part .. "'" end
        else
            base, step = part, 1
        end
        local a, b
        if base == "*" then
            a, b = lo, hi
        else
            local ra, rb = base:match("^(.-)%-(.+)$")
            if ra and ra ~= "" then
                a, b = resolve(ra, names), resolve(rb, names)
                if not a or not b then return nil, "bad range '" .. part .. "'" end
            else
                a = resolve(base, names)
                if not a then return nil, "bad value '" .. part .. "'" end
                b = a
            end
        end
        if a < lo or b > hi or a > b then return nil, "out of range '" .. part .. "'" end
        for v = a, b, step do set[v] = true end
    end
    if set[7] then
        set[7] = nil
        set[0] = true
    end
    return { set = set, star = (text == "*") }
end

local function splitWords(line, count)
    local words, i, n = {}, 1, #line
    for _ = 1, count do
        while i <= n and line:sub(i, i):match("%s") do i = i + 1 end
        local j = i
        while j <= n and not line:sub(j, j):match("%s") do j = j + 1 end
        if j == i then break end
        words[#words + 1] = line:sub(i, j - 1)
        i = j
    end
    while i <= n and line:sub(i, i):match("%s") do i = i + 1 end
    return words, line:sub(i)
end

local function buildJob(words, command, spec)
    if command == "" then return nil, "missing command" end
    local job = { command = command, env = copy(spec.env), source = spec.source, line = spec.line, user = spec.user }
    for i, f in ipairs(FIELDS) do
        local parsed, err = parseField(words[i], f.lo, f.hi, f.names)
        if not parsed then return nil, f.name .. ": " .. tostring(err) end
        job[f.name] = parsed
    end
    return job
end

function M.parseLine(line, spec)
    line = line:gsub("%s+$", "")
    if line == "" or line:sub(1, 1) == "#" then return nil end
    local name, value = line:match("^%s*([%a_][%w_]*)%s*=%s*(.*)$")
    if name then
        value = value:gsub('^"(.*)"$', "%1"):gsub("^'(.*)'$", "%1")
        return "env", name, value
    end
    if line:sub(1, 1) == "@" then
        local macro, rest = line:match("^(%S+)%s+(.*)$")
        if not macro then return nil, "bad macro line" end
        local expansion = MACROS[macro:lower()]
        if not expansion then return nil, "unknown macro '" .. macro .. "'" end
        if expansion == "reboot" then
            local user, cmd
            if spec.system then
                user, cmd = rest:match("^(%S+)%s+(.*)$")
                if not user then return nil, "missing user" end
            else
                user, cmd = spec.user, rest
            end
            if not cmd or cmd == "" then return nil, "missing command" end
            return { command = cmd, env = copy(spec.env), source = spec.source, line = spec.line, user = user, reboot = true }
        end
        line = expansion .. " " .. rest
    end
    local need = spec.system and 6 or 5
    local words, command = splitWords(line, need)
    if #words < need then return nil, "not enough fields" end
    local user = spec.system and words[6] or spec.user
    return buildJob(words, command, { env = spec.env, source = spec.source, line = spec.line, user = user })
end

function M.parseTab(data, spec)
    local jobs, errors, env = {}, {}, {}
    local lineno = 0
    for raw in (data .. "\n"):gmatch("([^\n]*)\n") do
        lineno = lineno + 1
        local line = raw:gsub("^%s+", "")
        if line ~= "" and line:sub(1, 1) ~= "#" then
            local res, a, b = M.parseLine(line, {
                system = spec.system, user = spec.user, source = spec.source, line = lineno, env = env,
            })
            if res == "env" then
                env[a] = b
            elseif type(res) == "table" then
                jobs[#jobs + 1] = res
            elseif res == nil and a then
                errors[#errors + 1] = { line = lineno, msg = a }
            end
        end
    end
    return jobs, errors
end

function M.match(job, d)
    if job.reboot then return false end
    if not job.minute.set[d.min] then return false end
    if not job.hour.set[d.hour] then return false end
    if not job.month.set[d.month] then return false end
    local domMatch = job.dom.star or job.dom.set[d.day] == true
    local dowMatch = job.dow.star or job.dow.set[d.wday] == true
    if job.dom.star or job.dow.star then return domMatch and dowMatch end
    return domMatch or dowMatch
end

M.FIELDS = FIELDS
M.MACROS = MACROS

return M
