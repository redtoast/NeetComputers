return {
    extensions = { "makefile", "mk" },
    words = {
        ["ifeq"] = "keyword", ["ifneq"] = "keyword", ["ifdef"] = "keyword",
        ["ifndef"] = "keyword", ["else"] = "keyword", ["endif"] = "keyword",
        ["include"] = "keyword", ["define"] = "keyword", ["endef"] = "keyword",
        ["export"] = "keyword", ["override"] = "keyword",
    },
    rules = {
        { "comment", "#.*" },
        { "string", '"[^"]*"', "'[^']*'" },
        { "variable", "%$%b()", "%$%b{}", "%$[%w_]+" },
        { "function", "^[%w_][%w_%.%-]*%s*:" },
        { "type", "^[%w_%.%-]+%s*[:+?]?=" },
    },
}
