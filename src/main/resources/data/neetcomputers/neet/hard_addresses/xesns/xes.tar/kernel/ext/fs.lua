local K, API, X = ...
local T = {}

local V, P = K.vfs, K.path

local CODES = {
	{ "no such file", "ENOENT" },
	{ "no such directory", "ENOENT" },
	{ "does not exist", "ENOENT" },
	{ "not a file", "ENOENT" },
	{ "not a directory", "ENOTDIR" },
	{ "is a directory", "EISDIR" },
	{ "not a symbolic link", "EINVAL" },
	{ "permission denied", "EACCES" },
	{ "access denied", "EACCES" },
	{ "operation not permitted", "EROFS" },
	{ "read-only", "EROFS" },
	{ "read only", "EROFS" },
	{ "virtual file system", "EROFS" },
	{ "operation not supported", "ENOTSUP" },
	{ "not supported", "ENOTSUP" },
	{ "file exists", "EEXIST" },
	{ "already exists", "EEXIST" },
	{ "not empty", "ENOTEMPTY" },
	{ "too many levels", "EIO" },
	{ "no space", "ENOSPC" },
	{ "file too large", "EFBIG" },
	{ "too large", "EFBIG" },
	{ "too big", "EFBIG" },
	{ "bad file descriptor", "EBADF" },
	{ "not open for", "EBADF" },
	{ "closed file", "EBADF" },
	{ "illegal seek", "ESPIPE" },
	{ "no such process", "ESRCH" },
	{ "too long", "ENAMETOOLONG" },
	{ "in use", "EBUSY" },
	{ "busy", "EBUSY" },
	{ "no such device", "ENODEV" },
	{ "invalid", "EINVAL" },
	{ "illegal", "EINVAL" },
}

local function codeOf(msg)
	local e = tostring(msg):lower()
	for i = 1, #CODES do
		if e:find(CODES[i][1], 1, true) then
			return CODES[i][2]
		end
	end
	return "EIO"
end

local function fail(msg)
	local text = tostring(msg)
	return nil, codeOf(text), text
end

local function rpath(p, path, fname)
	if type(path) ~= "string" then
		K.argcheck.err(1, fname, "string", path)
	end
	return P.resolve(path, p.cwd or p.launchcwd, 3)
end

local function unwrap(handle)
	if type(handle) ~= "table" then
		K.argcheck.err(1, "handle", "handle", handle)
	end
	local entry = K.neatoEntries[handle]
	if not entry or not entry.h then
		return nil, "EBADF", "bad file descriptor"
	end
	return entry.h
end

local KNOWN_TYPES = { file = true, dir = true, link = true, fifo = true, device = true }

local function typed(info, full)
	if not info then
		return info
	end
	if info.type == "file" and full then
		local _, _, fp = P.split(full)
		if fp and (fp == "/dev" or fp:sub(1, 5) == "/dev/") then
			info.type = "device"
		end
	end
	if not KNOWN_TYPES[info.type] then
		info.type = "other"
	end
	return info
end

function T.open(p, path, mode, opts)
	if mode == nil then
		mode = "r"
	end
	if type(mode) ~= "string" then
		K.argcheck.err(2, "open", "string", mode)
	end
	local m = V.normMode(mode)
	if not m then
		return nil, "EINVAL", "invalid open mode '" .. tostring(mode) .. "'"
	end
	if opts ~= nil and type(opts) ~= "table" then
		K.argcheck.err(3, "open", "table", opts)
	end
	opts = opts or {}
	local createMode = opts.createMode
	if createMode ~= nil and (math.type(createMode) ~= "integer" or createMode < 0 or createMode > 1023) then
		return nil, "EINVAL", "createMode must be an integer from 0 to 1023"
	end
	local full, perr = rpath(p, path, "open")
	if not full then
		return fail(perr)
	end
	local h, oerr = V.open(p, full, m, createMode, opts)
	if not h then
		return fail(oerr)
	end
	return K.wrapHandle(p, h, m)
end

function T.statx(p, path, opts)
	if opts ~= nil and type(opts) ~= "table" then
		K.argcheck.err(2, "statx", "table", opts)
	end
	opts = opts or {}
	local full, perr = rpath(p, path, "statx")
	if not full then
		return fail(perr)
	end
	local nofollow = opts.follow == false or opts.nofollow == true or opts.noFollow == true
	local info, serr
	if nofollow then
		info, serr = V.lstatx(p, full)
	else
		info, serr = V.statx(p, full)
		if info then
			info.link = nil
		end
	end
	if not info then
		return fail(serr)
	end
	return typed(info, full)
end

function T.lstat(p, path)
	return T.statx(p, path, { follow = false })
end

function T.statHandle(p, handle)
	local h, code, msg = unwrap(handle)
	if not h then
		return nil, code, msg
	end
	local info, serr = V.statHandle(p, h)
	if not info then
		return fail(serr)
	end
	return typed(info, h.loc and h.loc.full)
end

function T.truncate(p, path, size)
	if math.type(size) ~= "integer" then
		return nil, "EINVAL", "size must be an integer"
	end
	local full, perr = rpath(p, path, "truncate")
	if not full then
		return fail(perr)
	end
	local ok, err = V.truncate(p, full, size)
	if not ok then
		return fail(err)
	end
	return true
end

function T.truncateHandle(p, handle, size)
	local h, code, msg = unwrap(handle)
	if not h then
		return nil, code, msg
	end
	if math.type(size) ~= "integer" then
		return nil, "EINVAL", "size must be an integer"
	end
	local ok, err = V.truncateHandle(p, h, size)
	if not ok then
		return fail(err)
	end
	return true
end

function T.symlink(p, target, linkPath)
	if type(target) ~= "string" then
		K.argcheck.err(1, "symlink", "string", target)
	end
	local full, perr = rpath(p, linkPath, "symlink")
	if not full then
		return fail(perr)
	end
	local ok, err = V.symlink(p, target, full)
	if not ok then
		return fail(err)
	end
	return true
end

function T.readlink(p, path)
	local full, perr = rpath(p, path, "readlink")
	if not full then
		return fail(perr)
	end
	local tgt, err = V.readlink(p, full)
	if not tgt then
		return fail(err)
	end
	return tgt
end

function T.statfs(p, path)
	local full, perr = rpath(p, path, "statfs")
	if not full then
		return fail(perr)
	end
	local info, serr = V.statfs(p, full)
	if not info then
		return fail(serr)
	end
	return info
end

function T.utimes(p, path, mtime, atime)
	if type(mtime) ~= "number" then
		K.argcheck.err(2, "utimes", "number", mtime)
	end
	if atime ~= nil and type(atime) ~= "number" then
		K.argcheck.err(3, "utimes", "number", atime)
	end
	local full, perr = rpath(p, path, "utimes")
	if not full then
		return fail(perr)
	end
	local ok, err = V.utime(p, full, math.floor(mtime), atime ~= nil and math.floor(atime) or nil)
	if not ok then
		return fail(err)
	end
	return true
end

function T.sync(p, handle)
	if handle ~= nil then
		local h, code, msg = unwrap(handle)
		if not h then
			return nil, code, msg
		end
		if h.loc and h.loc.raw and type(h.loc.raw.flush) == "function" then
			local ok, err = pcall(h.loc.raw.flush)
			if not ok then
				return fail(err)
			end
		end
		return true
	end
	for _, entry in pairs(K.neatoEntries) do
		local h = entry.h
		if h and h.loc and h.loc.raw and type(h.loc.raw.flush) == "function" then
			pcall(h.loc.raw.flush)
		end
	end
	return true
end

T.__ext = {
	["ext.symlink"] = 1,
	["ext.statfs"] = 1,
	["ext.statx"] = 1,
	["ext.truncate"] = 1,
	["ext.sync"] = 1,
}

return T
