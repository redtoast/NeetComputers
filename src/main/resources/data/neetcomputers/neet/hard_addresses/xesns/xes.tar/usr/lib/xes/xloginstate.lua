local u = require("util")

local M = {}

M.LOCKDOWN = "/var/run/xesd.lockdown"
M.SESSION = "/var/run/xesd.session"
M.OWNER_KEY = "greeter"

function M.set_paths(lockdown, session)
	M.LOCKDOWN = lockdown or M.LOCKDOWN
	M.SESSION = session or M.SESSION
end

local function say(msg)
	u.writeErr("xlogin: " .. tostring(msg) .. "\n")
end

function M.pid_alive(pid)
	if type(pid) ~= "number" then
		return false
	end
	local ok, ps = pcall(proc.info)
	if not ok or type(ps) ~= "table" then
		return false
	end
	for _, p in ipairs(ps) do
		if p.pid == pid and p.state ~= "Z" then
			return true
		end
	end
	return false
end

function M.read_session()
	local data = u.readFile(M.SESSION)
	if type(data) ~= "string" then
		return nil
	end
	local c = {}
	for k, v in data:gmatch("([a-z_]+)=([^%s]+)") do
		c[k] = v
	end
	return c
end

function M.drop_session()
	local data = u.readFile(M.SESSION)
	if type(data) ~= "string" then
		return true
	end
	local owner = tonumber(data:match(M.OWNER_KEY .. "=(%d+)"))
	if owner ~= nil and owner ~= u.getpid() and M.pid_alive(owner) then
		return nil, "session credentials owned by live greeter " .. owner
	end
	local ok, err = u.unlink(M.SESSION)
	if ok then
		return true
	end
	if not u.exists(M.SESSION) then
		return true
	end
	return nil, err or ("cannot remove " .. M.SESSION)
end

function M.release()
	local ok, werr = u.writeFile(M.LOCKDOWN, "locked\n")
	if not ok then
		local dok, derr = M.drop_session()
		local extra = dok and " (session credentials removed)"
			or ("; cannot remove " .. M.SESSION .. ": " .. tostring(derr))
		return nil, "cannot write " .. M.LOCKDOWN .. ": " .. tostring(werr) .. extra
	end
	local locked = u.readFile(M.LOCKDOWN)
	if type(locked) ~= "string" or locked == "" then
		local dok, derr = M.drop_session()
		local extra = dok and " (session credentials removed)"
			or ("; cannot remove " .. M.SESSION .. ": " .. tostring(derr))
		return nil, "cannot confirm " .. M.LOCKDOWN .. extra
	end
	local dok, derr = M.drop_session()
	if not dok then
		say(derr)
	end
	return true
end

function M.claim(user)
	if type(user) ~= "table" or type(user.name) ~= "string" then
		return nil, "no account"
	end
	local text = table.concat({
		"uid=" .. tostring(user.uid),
		"gid=" .. tostring(user.gid),
		"user=" .. user.name,
		"home=" .. tostring(user.home or "/"),
		"shell=" .. tostring(user.shell or "/bin/sh"),
		M.OWNER_KEY .. "=" .. tostring(u.getpid()),
	}, "\n") .. "\n"
	local ok, werr = u.writeFile(M.SESSION, text)
	if not ok then
		u.unlink(M.SESSION)
		u.writeFile(M.LOCKDOWN, "locked\n")
		return nil, "cannot write " .. M.SESSION .. ": " .. tostring(werr)
	end
	local back = u.readFile(M.SESSION)
	if
		type(back) ~= "string"
		or not back:find("user=" .. user.name, 1, true)
		or not back:find(M.OWNER_KEY .. "=" .. tostring(u.getpid()), 1, true)
	then
		u.unlink(M.SESSION)
		u.writeFile(M.LOCKDOWN, "locked\n")
		return nil, "session credentials did not persist (" .. M.SESSION .. ")"
	end
	if u.exists(M.LOCKDOWN) then
		local uok, uerr = u.unlink(M.LOCKDOWN)
		if not uok then
			u.unlink(M.SESSION)
			u.writeFile(M.LOCKDOWN, "locked\n")
			return nil, "cannot remove " .. M.LOCKDOWN .. ": " .. tostring(uerr)
		end
	end
	return true
end

function M.sweep(uid, sid)
	local keep = { [1] = true, [u.getpid()] = true }
	for _, f in ipairs(u.readdir("/var/run") or {}) do
		if tostring(f):match("%.pid$") and f ~= "xeswm.pid" then
			local pid = tonumber(u.readFile("/var/run/" .. f) or "")
			if pid then
				keep[pid] = true
			end
		end
	end
	local ok, procs = pcall(proc.info)
	if not ok or type(procs) ~= "table" then
		return
	end
	if sid == nil or uid == nil then
		return
	end
	local kill = {}
	for _, p in ipairs(procs) do
		if p.sid == sid then
			kill[p.pid] = true
		end
	end
	local changed = true
	while changed do
		changed = false
		for _, p in ipairs(procs) do
			if not kill[p.pid] and kill[p.ppid] then
				kill[p.pid] = true
				changed = true
			end
		end
	end
	for _, p in ipairs(procs) do
		if
			kill[p.pid]
			and p.state ~= "Z"
			and not keep[p.pid]
			and p.name ~= "getty"
			and p.name ~= "init"
			and p.name ~= "xesd"
		then
			proc.kill(p.pid, "kill")
		end
	end
end

return M
