-- The one copy of libfntp lives with the kernel: /kernel is immutable at securelevel 1,
-- and the kernel needs it before any program can run.  Programs load it by name.
local chunk, err = loadfile("/kernel/fntp.lua")
if not chunk then
	return nil, err
end
return chunk()
