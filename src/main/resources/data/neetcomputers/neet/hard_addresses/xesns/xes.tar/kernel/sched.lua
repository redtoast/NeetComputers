local K = ...

K.quantum = 20000
K.maxrounds = 48
K.tickbudget = 0.03

local PREEMPT, BLOCK, EXIT = K.PREEMPT, K.BLOCK, K.EXIT
local sethook, isyieldable, yield = debug.sethook, coroutine.isyieldable, coroutine.yield
local rawresume, rawcreate, rawfork = coroutine.resume, coroutine.create, coroutine.fork
local rawstatus = coroutine.status

local EXITSIG = setmetatable({}, {
	__tostring = function()
		return "<exit>"
	end,
})
K.EXITSIG = EXITSIG

local function halt()
	if isyieldable() then
		yield(EXITSIG)
	end
	error(EXIT, 0)
end
K.halt = halt

-- The count hook yields PREEMPT only while p.critical == 0: K.sys raises p.critical around the
-- kernel entry points it wraps, so a process is never preempted in the middle of a syscall.
local function hook()
	local p = K.current
	if not p or p.critical > 0 then
		return
	end
	if p.dying then
		halt()
	end
	if isyieldable() then
		yield(PREEMPT)
	end
end

function K.hookthread(co)
	sethook(co, hook, "", K.quantum)
	return co
end

function K.setquantum(q)
	K.quantum = q
	for _, p in pairs(K.procs) do
		if p.co and rawstatus(p.co) ~= "dead" then
			pcall(sethook, p.co, hook, "", q)
		end
	end
end

-- PREEMPT/BLOCK/EXITSIG yielded inside a user coroutine are relayed outward, never consumed here:
-- only the kernel's own yield() at the end of K.run reaches the emulator, and that app yield is
-- what feeds its watchdog; a process that kept resuming its coroutine here would starve it.
local function xresume(co, ...)
	local r = table.pack(rawresume(co, ...))
	while r[1] and (r[2] == PREEMPT or r[2] == BLOCK or r[2] == EXITSIG) and rawstatus(co) == "suspended" do
		if r[2] == EXITSIG then
			halt()
		end
		if isyieldable() then
			yield(r[2])
		elseif r[2] == BLOCK then
			return false, "attempt to block in a non-yieldable context"
		end
		r = table.pack(rawresume(co))
	end
	return table.unpack(r, 1, r.n)
end

local function xcreate(f)
	return K.hookthread(rawcreate(f))
end

local function xwrap(f)
	local co = xcreate(f)
	return function(...)
		local r = table.pack(xresume(co, ...))
		if not r[1] then
			error(r[2], 0)
		end
		return table.unpack(r, 2, r.n)
	end
end

local function xfork()
	local t = rawfork()
	if t then
		K.hookthread(t)
	end
	return t
end

do
	local c = {}
	for k, v in pairs(coroutine) do
		c[k] = v
	end
	c.create, c.resume, c.wrap, c.fork = xcreate, xresume, xwrap, xfork
	K.usercoroutine = c
end

local function mainfn(p, chunk, args)
	local r = chunk(table.unpack(args, 1, args.n or #args))
	p.exitcode = (math.tointeger(tonumber(r)) or 0) % 256
end

local function badExec(msg)
	return nil, "exec format error: " .. msg
end

local function u16(s, off)
	local a, b = s:byte(off + 1, off + 2)
	if not a or not b then
		return nil
	end
	return a | (b << 8)
end

local function u64lo(s, off)
	local a, b, c, d = s:byte(off + 1, off + 4)
	if not a or not b or not c or not d then
		return nil
	end
	return a | (b << 8) | (c << 16) | (d << 24)
end

local function isElf(src)
	return src:sub(1, 4) == "\127ELF"
end

local function launchWith(p, path, launcher, arg0)
	local lsrc, lerr = K.vfs.readFile(launcher)
	if not lsrc then
		local em = tostring(lerr or ""):lower()
		if em:find("permission", 1, true) then
			return nil, "permission denied"
		end
		return nil, "no such file or directory"
	end
	local env = K.makeEnv(p)
	local lchunk, cerr = load(lsrc, "=" .. launcher, "t", env)
	if not lchunk then
		return nil, "exec format error: launcher: " .. tostring(cerr)
	end
	p.envtbl = env
	p.execpath = path
	return function(...)
		return lchunk(arg0, ...)
	end
end

local function loadElf(p, path, src)
	if #src < 64 then
		return badExec("truncated ELF header")
	end
	if src:byte(5) ~= 2 then
		return badExec("unsupported ELF class (need 64-bit)")
	end
	if src:byte(6) ~= 1 then
		return badExec("unsupported ELF data encoding (need little-endian)")
	end
	local machine = u16(src, 18)
	if machine ~= 243 then
		return badExec("unsupported ELF machine " .. tostring(machine) .. " (need RISC-V)")
	end
	local entryLo, entryHi = u64lo(src, 24), u64lo(src, 28)
	if (entryLo or 0) == 0 and (entryHi or 0) == 0 then
		return badExec("invalid ELF entry point")
	end
	local phoff = u64lo(src, 32) or 0
	local phentsize, phnum = u16(src, 54) or 0, u16(src, 56) or 0
	if phnum > 0 then
		if phentsize < 56 or phoff == 0 then
			return badExec("invalid ELF program header table")
		end
		if phoff + phnum * phentsize > #src then
			return badExec("truncated ELF program header table")
		end
	elseif #src < 64 then
		return badExec("truncated ELF image")
	end

	local launcher = K.binfmtLauncher or (K.rootdir .. "bin/xmre")
	local thunk, lerr = launchWith(p, path, launcher, path)
	if not thunk then
		return nil, lerr
	end
	if K.extensions then
		K.extensions["x.xesns.binfmt"] = 1
	end
	if K.authlog then
		K.authlog("BINFMT pid=%d uid=%d image=%s", p.pid, p.uid, path)
	end
	return thunk
end

local function loadScript(p, path, src)
	local interp = K.trim(src:match("^#!([^\n]*)") or "")
	local words = {}
	for w in interp:gmatch("%S+") do
		words[#words + 1] = w
	end
	if not words[1] then
		return badExec("no interpreter in #! line")
	end
	local sh = #words <= 2 and (words[1] == "/bin/sh" or (words[1] == "/usr/bin/env" and words[2] == "sh"))
	if not sh then
		return badExec("unsupported interpreter " .. interp)
	end
	return launchWith(p, path, K.rootdir .. "bin/sh", K.path.pretty(path))
end

function K.loadprog(p, path)
	local acc, aerr = K.vfs.access(p, path, "exec")
	if acc ~= true then
		return nil, aerr or "permission denied"
	end
	local st = K.vfs.stat(path)
	if not st then
		return nil, "no such file or directory"
	end

	if st ~= "file" and st ~= "link" then
		return nil, "not a regular file"
	end
	local src, err = K.vfs.readFile(path)
	if not src then
		return nil, err
	end
	if isElf(src) then
		return loadElf(p, path, src)
	end
	if src:sub(1, 2) == "#!" then
		return loadScript(p, path, src)
	end
	local env = K.makeEnv(p)
	local chunk, cerr = load(src, "=" .. path, "t", env)
	if not chunk then
		return nil, "exec format error: " .. tostring(cerr)
	end
	p.envtbl = env
	return chunk
end

local function startImage(p, chunk, args)
	p.args = args
	p.co = K.hookthread(rawcreate(function()
		mainfn(p, chunk, args)
	end))
	p.state, p.dying, p.critical = "R", false, 0
	p.waitfn, p.deadline = nil, nil
end

local function stdStream(p, n)
	local o = { kind = "std", refs = 1, fd = n }
	local busy = false
	local function get()
		local fd = p.fds[n]
		if not fd then
			return nil, "bad file descriptor"
		end
		return fd
	end
	function o:read(fmt)
		local fd, err = get()
		if not fd then
			return nil, err
		end
		if not fd.read then
			return nil, "not open for reading"
		end
		return fd:read(fmt)
	end

	function o:write(s)
		local fd, err = get()
		if not fd then
			return nil, err
		end
		if not fd.write then
			return nil, "not open for writing"
		end
		if busy then
			return nil, "invalid argument"
		end
		busy = true
		local r, e = fd:write(s)
		busy = false
		return r, e
	end

	function o:seek(whence, off)
		local fd, err = get()
		if not fd then
			return nil, err
		end
		if not fd.seek then
			return nil, "illegal seek"
		end
		return fd:seek(whence, off)
	end

	function o:isatty()
		local fd = p.fds[n]
		return fd ~= nil and fd.isatty ~= nil and fd:isatty() or false
	end

	return o
end

function K.stdstreams(p)
	p.stdin, p.stdout, p.stderr = stdStream(p, 0), stdStream(p, 1), stdStream(p, 2)
end

function K.spawn(parent, path, args, opts)
	opts = opts or {}
	args = args or {}
	if not K.procLimitOk(opts.uid or (parent and parent.uid) or 0) then
		return nil, "too many processes"
	end
	local p = K.newproc(parent, opts.name or K.path.basename(path))
	if opts.uid then
		p.uid, p.gid = opts.uid, opts.gid or opts.uid
		p.groups = opts.groups or {}
	end
	if opts.home then
		p.home = opts.home
	end
	if opts.cwd then
		p.cwd = opts.cwd
	end
	p.launchcwd = p.cwd
	if opts.env then
		p.env = {}
		for k, v in pairs(opts.env) do
			p.env[k] = tostring(v)
		end
	end
	if opts.tty then
		p.tty = opts.tty
	end
	if opts.setsid then
		p.sid, p.pgid = p.pid, p.pid
		if opts.tty and p.tty ~= K.nulltty then
			p.tty.session, p.tty.fgpgid = p.pid, p.pid
		end
	elseif opts.newpgrp then
		p.pgid = p.pid
		if opts.foreground and p.tty ~= K.nulltty then
			p.tty.fgpgid = p.pid
		end
	elseif opts.pgid then
		p.pgid = opts.pgid
	end
	if opts.nice then
		p.nice = opts.nice
	end

	local ttyobj
	for n = 0, 2 do
		local src = opts.fds and opts.fds[n]
		local obj
		if type(src) == "number" and parent then
			obj = parent.fds[src]
		elseif type(src) == "table" then
			obj = src
		elseif opts.tty then
			ttyobj = ttyobj or K.ttyfd(p.tty)
			obj = ttyobj
		elseif parent then
			obj = parent.fds[n]
		end
		if obj then
			p.fds[n] = K.fdref(obj)
		end
	end
	if opts.fds then
		for n, src in pairs(opts.fds) do
			if n > 2 then
				local obj = type(src) == "number" and parent and parent.fds[src] or (type(src) == "table" and src)
				if obj then
					p.fds[n] = K.fdref(obj)
				end
			end
		end
	end
	if not p.fds[0] and not parent then
		ttyobj = ttyobj or K.ttyfd(p.tty)
		for n = 0, 2 do
			p.fds[n] = K.fdref(ttyobj)
		end
	end
	if ttyobj then
		K.fdclose(ttyobj)
	end
	K.stdstreams(p)

	local chunk, err = K.loadprog(p, path)
	if not chunk then
		K.releaseProc(p)
		K.procs[p.pid] = nil
		if parent then
			parent.children[p.pid] = nil
		end
		return nil, err
	end
	startImage(p, chunk, args)
	return p
end

local function inheritNeatoHandles(parent, child)
	child.inheritedHandles = {}
	for h in pairs(parent.handles or {}) do
		child.handles[h] = true
		child.inheritedHandles[h] = true
		local entry = K.neatoEntries and K.neatoEntries[h]
		if entry then
			if entry.pipe and entry.st then
				if entry.read then
					entry.st.readers = entry.st.readers + 1
				else
					entry.st.writers = entry.st.writers + 1
				end
			elseif entry.refs then
				entry.refs = entry.refs + 1
			end
		end
	end
	for h in pairs(parent.ports or {}) do
		child.ports[h] = true
	end
	for h in pairs(parent.sppHandles or {}) do
		child.sppHandles[h] = true
		h.forkrefs = (h.forkrefs or 1) + 1
	end
end

function K.fork()
	local parent = K.current
	if not K.procLimitOk(parent.uid) then
		return nil, "too many processes"
	end
	local th = rawfork()
	if not th then
		return 0
	end
	local c = K.newproc(parent, parent.name)
	c.home, c.launchcwd, c.fg, c.bg = parent.home, parent.launchcwd, parent.fg, parent.bg
	c.args = {}
	for i = 1, (parent.args.n or #parent.args) do
		c.args[i] = parent.args[i]
	end
	c.args.n = parent.args.n
	c.envtbl = parent.envtbl and K.copy(parent.envtbl) or nil
	c.libs = parent.libs and K.copy(parent.libs) or nil
	c.groups = K.copy(parent.groups or {})
	c.umask = parent.umask
	c.inbuf = nil
	c.sigevents = parent.sigevents
	c.termGrace = parent.termGrace
	c.memcap = parent.memcap
	c.limits = K.copy(parent.limits or K.defaultLimits)
	for n, o in pairs(parent.fds) do
		c.fds[n] = K.fdref(o)
	end
	inheritNeatoHandles(parent, c)
	K.stdstreams(c)
	c.co = K.hookthread(th)
	return c.pid
end

function K.exec(p, path, args, env)
	p.launchcwd = p.cwd
	local chunk, err = K.loadprog(p, path)
	if not chunk then
		return nil, err
	end
	p.execchunk, p.execargs, p.execname = chunk, args or {}, K.path.basename(path)
	if env then
		p.env = {}
		for k, v in pairs(env) do
			p.env[k] = tostring(v)
		end
	end
	p.libs = {}
	p.inbuf = nil
	p.dying = true
	halt()
end

function K.exit(p, code)
	p.exitcode = (math.tointeger(tonumber(code)) or 0) % 256
	p.dying = true
	halt()
end

local function zombie(p)
	p.state = "Z"
	p.waitfn, p.deadline = nil, nil
	K.releaseProc(p)
	if p.pid == 1 then
		K.panic("init exited (status " .. tostring(p.exitcode) .. ")")
	end
end

function K.terminate(p, code)
	if p.co and rawstatus(p.co) ~= "running" then
		pcall(coroutine.close, p.co)
	end
	p.exitcode = p.killed or code or 1
	zombie(p)
end

local function finish(p, ok, err)
	if not ok and err ~= EXIT then
		local msg = type(err) == "string" and err or tostring(err)
		K.klog("pid %d (%s) crashed: %s", p.pid, p.name, msg)
		local fd = p.fds[2]
		if fd and (fd.kind == "tty" or fd.kind == "file") then
			K.current = p
			pcall(fd.write, fd, p.name .. ": " .. msg .. "\n")
			K.current = nil
		end
		if K.debug then
			local tb = debug.traceback(p.co, nil, 0)
			if tb then
				K.klog("%s", tb)
			end
		end
		p.exitcode = 1
	end
	if p.killed then
		p.exitcode = p.killed
	end
	if p.execchunk and not p.killed then
		local chunk, args = p.execchunk, p.execargs
		p.execchunk, p.execargs = nil, nil
		p.name = p.execname
		p.launchcwd = p.cwd
		for h in pairs(p.handles) do
			pcall(h.close, h)
		end
		p.handles = {}
		startImage(p, chunk, args)
		return
	end
	zombie(p)
end

local function waitMatches(p, pid, c)
	if pid == nil or pid == -1 then
		return true
	end
	if pid == 0 then
		return c.pgid == p.pgid
	end
	if pid < -1 then
		return c.pgid == -pid
	end
	return c.pid == pid
end

local function findChild(p, pid)
	local any = false
	for cpid in pairs(p.children) do
		local c = K.procs[cpid]
		if c and waitMatches(p, pid, c) then
			any = true
			if c.state == "Z" then
				return c, any
			end
		end
	end
	return nil, any
end

local function reap(p, pid, nohang)
	while true do
		local found, any = findChild(p, pid)
		if found then
			K.procs[found.pid] = nil
			p.children[found.pid] = nil
			local sig = found.killed and (found.killed - 128) or 0
			return found.pid, found.exitcode, sig, found.core == true
		end
		if not any then
			return nil, "no child processes"
		end
		if nohang then
			return 0
		end
		K.block(p, function()
			local z = findChild(p, pid)
			return z ~= nil
		end)
	end
end

function K.wait(p, pid, nohang)
	local cpid, status, sig, core = reap(p, pid, nohang)
	if cpid == nil then
		return nil, status
	end
	if cpid == 0 then
		return 0
	end
	return cpid, status, sig, core
end

function K.wait4(p, pid, nohang)
	return reap(p, pid, nohang)
end

local function runnable(p, now)
	if p.state == "R" then
		return true
	end
	if p.state ~= "S" then
		return false
	end
	if p.wakeup then
		p.wakeup = nil
		return true
	end
	if p.deadline and now >= p.deadline then
		return true
	end
	if p.waitfn and p.waitfn() then
		return true
	end
	return false
end

function K.runslice(p)
	K.current = p
	K.lastrun = p
	p.state = "R"
	local t0 = K.monotonic()
	local ok, v = rawresume(p.co)
	p.cputime = p.cputime + (K.monotonic() - t0)
	p.slices = p.slices + 1
	K.current = nil
	if not ok then
		finish(p, false, v)
	elseif v == EXITSIG then
		finish(p, true)
	elseif rawstatus(p.co) == "dead" then
		finish(p, true)
	else
		return v == PREEMPT
	end
	return false
end

-- TERM/INT/HUP/QUIT only ask: if the process does not pull the event within p.termGrace (1.5 s,
-- 10 s for sigevents) p.killed is set and the next round ends it like SIGKILL, status 128+sig.
local function escalate(now)
	for _, p in pairs(K.procs) do
		local grace = p.termGrace or 1.5
		if p.termAsked and p.state ~= "Z" and now - p.termAsked > grace then
			p.killed = 128 + (p.termSig or 15)
			p.termAsked = nil
		end
	end
end

function K.schedule_round(round)
	local now = K.monotonic()
	escalate(now)
	local pids = {}
	for pid in pairs(K.procs) do
		pids[#pids + 1] = pid
	end
	table.sort(pids)
	local full = false
	for _, pid in ipairs(pids) do
		local p = K.procs[pid]
		if p and p.state ~= "Z" then
			if p.killed then
				K.terminate(p, p.killed)
			elseif (p.nice <= 0 or round % (p.nice + 1) == 0) and runnable(p, now) then
				if K.runslice(p) then
					full = true
				end
			end
		end
	end
	return full
end

local oomArmed, oomLimit, oomQuiet = true, nil, false

local function oomUsed()
	local c = rawget(_G, "chip")
	if type(c) ~= "table" then
		c = chip
	end
	if type(c) ~= "table" or type(c.getMemory) ~= "function" then
		return nil
	end
	local ok, m = pcall(c.getMemory)
	if not ok or type(m) ~= "table" then
		return nil
	end
	return tonumber(m.used)
end

-- Policy: kill the most recently run process, else the highest pid; never init, a zombie or a
-- process inside a syscall (p.critical > 0).  If the last-run process already exited, only log.
local function oomCandidate(p)
	return p ~= nil and p.state ~= "Z" and p.pid ~= 1 and (p.critical or 0) <= 0
end

function K.oomCheck()
	local limit = K.memlimit
	if limit ~= oomLimit then
		oomLimit, oomArmed, oomQuiet = limit, true, false
	end
	local used = oomUsed()
	if not used or not limit or used <= limit then
		if used then
			oomArmed, oomQuiet = true, false
		end
		return
	end
	if not oomArmed then
		return
	end
	local victim = K.lastrun
	if victim and victim.state == "Z" then
		if not oomQuiet then
			oomQuiet = true
			K.klog("kernel: out of memory: pid %d (%s) already exited: rss %d > limit %d",
				victim.pid, tostring(victim.name), used, limit)
		end
		oomArmed = false
		return
	end
	if not oomCandidate(victim) then
		victim = nil
		local best = 0
		for pid, p in pairs(K.procs) do
			if oomCandidate(p) and pid > best then
				best, victim = pid, p
			end
		end
	end
	if not victim then
		if not oomQuiet then
			oomQuiet = true
			K.klog("kernel: out of memory: rss %d > limit %d, no killable process", used, limit)
		end
		return
	end
	oomArmed, oomQuiet = false, false
	K.klog("kernel: out of memory: killed pid %d (%s): rss %d > limit %d",
		victim.pid, tostring(victim.name), used, limit)
	K.signal(victim, K.SIG.KILL)
end

-- One iteration is one scheduler pass ending in a yield to the emulator (one host tick, unless
-- the emulator's instruction budget suspends it).  Rounds continue while some process used its
-- full slice, bounded by K.maxrounds and K.tickbudget; sleepers are woken only by polling in runnable.
function K.run()
	while true do
		K.ticks = K.ticks + 1
		K.kbd.pump()
		local t0 = K.monotonic()
		local round = 0
		repeat
			round = round + 1
			local full = K.schedule_round(round)
			K.oomCheck()
		until not full or round >= K.maxrounds or (K.monotonic() - t0) > K.tickbudget
		K.sampleLoad()
		if K.ticks % 32 == 0 then
			K.crypto.entropy_add("tick", K.ticks)
		end
		K.tty_flush()
		if K.shutdownRequested then
			K.doShutdown(K.shutdownRequested)
		end
		yield()
	end
end
