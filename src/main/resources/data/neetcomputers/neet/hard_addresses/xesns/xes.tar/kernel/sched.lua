local K = ...

K.quantum = 20000
K.maxrounds = 48
K.tickbudget = 0.03

local PREEMPT, BLOCK, EXIT = K.PREEMPT, K.BLOCK, K.EXIT
local sethook, isyieldable, yield = debug.sethook, coroutine.isyieldable, coroutine.yield
local rawresume, rawcreate, rawfork = coroutine.resume, coroutine.create, coroutine.fork
local rawstatus = coroutine.status

local function hook()
    local p = K.current
    if not p or p.critical > 0 then return end
    if p.dying then error(EXIT, 0) end
    if isyieldable() then yield(PREEMPT) end
end

function K.hookthread(co)
    sethook(co, hook, "", K.quantum)
    return co
end

local function xresume(co, ...)
    local r = table.pack(rawresume(co, ...))
    while r[1] and (r[2] == PREEMPT or r[2] == BLOCK) and rawstatus(co) == "suspended" do
        if isyieldable() then
            yield(r[2])
        elseif r[2] == BLOCK then
            return false, "attempt to block in a non-yieldable context"
        end
        r = table.pack(rawresume(co))
    end
    return table.unpack(r, 1, r.n)
end

local function xcreate(f) return K.hookthread(rawcreate(f)) end

local function xwrap(f)
    local co = xcreate(f)
    return function(...)
        local r = table.pack(xresume(co, ...))
        if not r[1] then error(r[2], 0) end
        return table.unpack(r, 2, r.n)
    end
end

local function xfork()
    local t = rawfork()
    if t then K.hookthread(t) end
    return t
end

do
    local c = {}
    for k, v in pairs(coroutine) do c[k] = v end
    c.create, c.resume, c.wrap, c.fork = xcreate, xresume, xwrap, xfork
    K.usercoroutine = c
end

local function mainfn(p, chunk, args)
    local r = chunk(table.unpack(args, 1, args.n or #args))
    p.exitcode = math.tointeger(tonumber(r)) or 0
end

function K.loadprog(p, path)
    local acc, aerr = K.vfs.access(p, path, "exec")
    if acc ~= true then return nil, aerr or "permission denied" end
    local st = K.vfs.stat(path)
    if not st then return nil, "no such file or directory" end

    if st ~= "file" and st ~= "link" then return nil, "not a regular file" end
    local src, err = K.vfs.readFile(path)
    if not src then return nil, err end
    src = src:gsub("^#![^\n]*", "--", 1)
    local env = K.makeEnv(p)
    local chunk, cerr = load(src, "=" .. path, "t", env)
    if not chunk then return nil, "exec format error: " .. tostring(cerr) end
    p.envtbl = env
    return chunk
end

local function startImage(p, chunk, args)
    p.args = args
    p.co = K.hookthread(rawcreate(function() mainfn(p, chunk, args) end))
    p.state, p.dying, p.critical = "R", false, 0
    p.waitfn, p.deadline = nil, nil
end

function K.spawn(parent, path, args, opts)
    opts = opts or {}
    args = args or {}
    if not K.procLimitOk(opts.uid or (parent and parent.uid) or 0) then return nil, "too many processes" end
    local p = K.newproc(parent, opts.name or K.path.basename(path))
    if opts.uid then
        p.uid, p.gid = opts.uid, opts.gid or opts.uid
        p.groups = opts.groups or {}
    end
    if opts.home then p.home = opts.home end
    if opts.cwd then p.cwd = opts.cwd end
    p.launchcwd = p.cwd
    if opts.env then
        p.env = {}
        for k, v in pairs(opts.env) do p.env[k] = tostring(v) end
    end
    if opts.tty then p.tty = opts.tty end
    if opts.setsid then
        p.sid, p.pgid = p.pid, p.pid
        p.tty.session, p.tty.fgpgid = p.pid, p.pid
    elseif opts.newpgrp then
        p.pgid = p.pid
        if opts.foreground then p.tty.fgpgid = p.pid end
    elseif opts.pgid then
        p.pgid = opts.pgid
    end
    if opts.nice then p.nice = opts.nice end

    local ttyobj
    for n = 0, 2 do
        local src = opts.fds and opts.fds[n]
        local obj
        if type(src) == "number" and parent then
            obj = parent.fds[src]
        elseif type(src) == "table" then
            obj = src
        elseif opts.tty then
            ttyobj = ttyobj or K.ttyfd(p.tty)
            obj = ttyobj
        elseif parent then
            obj = parent.fds[n]
        end
        if obj then p.fds[n] = K.fdref(obj) end
    end
    if opts.fds then
        for n, src in pairs(opts.fds) do
            if n > 2 then
                local obj = type(src) == "number" and parent and parent.fds[src] or (type(src) == "table" and src)
                if obj then p.fds[n] = K.fdref(obj) end
            end
        end
    end
    if not p.fds[0] and not parent then
        ttyobj = ttyobj or K.ttyfd(p.tty)
        for n = 0, 2 do p.fds[n] = K.fdref(ttyobj) end
    end
    if ttyobj then K.fdclose(ttyobj) end

    local chunk, err = K.loadprog(p, path)
    if not chunk then
        K.releaseProc(p)
        K.procs[p.pid] = nil
        if parent then parent.children[p.pid] = nil end
        return nil, err
    end
    startImage(p, chunk, args)
    return p
end

function K.fork()
    local parent = K.current
    if not K.procLimitOk(parent.uid) then return nil, "too many processes" end
    local th = rawfork()
    if not th then return 0 end
    local c = K.newproc(parent, parent.name)
    c.args, c.home, c.launchcwd, c.fg, c.bg = parent.args, parent.home, parent.launchcwd, parent.fg, parent.bg
    for n, o in pairs(parent.fds) do c.fds[n] = K.fdref(o) end
    c.co = K.hookthread(th)
    return c.pid
end

function K.exec(p, path, args, env)
    p.launchcwd = p.cwd
    local chunk, err = K.loadprog(p, path)
    if not chunk then return nil, err end
    p.execchunk, p.execargs, p.execname = chunk, args or {}, K.path.basename(path)
    if env then
        p.env = {}
        for k, v in pairs(env) do p.env[k] = tostring(v) end
    end
    p.dying = true
    error(EXIT, 0)
end

function K.exit(p, code)
    p.exitcode = math.tointeger(tonumber(code)) or 0
    p.dying = true
    error(EXIT, 0)
end

local function zombie(p)
    p.state = "Z"
    p.waitfn, p.deadline = nil, nil
    K.releaseProc(p)
    if p.pid == 1 then K.panic("init exited (status " .. tostring(p.exitcode) .. ")") end
end

function K.terminate(p, code)
    if p.co and rawstatus(p.co) ~= "running" then pcall(coroutine.close, p.co) end
    p.exitcode = p.killed or code or 1
    zombie(p)
end

local function finish(p, ok, err)
    if not ok and err ~= EXIT then
        local msg = type(err) == "string" and err or tostring(err)
        K.klog("pid %d (%s) crashed: %s", p.pid, p.name, msg)
        local fd = p.fds[2]
        if fd and (fd.kind == "tty" or fd.kind == "file") then
            K.current = p
            pcall(fd.write, fd, p.name .. ": " .. msg .. "\n")
            K.current = nil
        end
        if K.debug then
            local tb = debug.traceback(p.co, nil, 0)
            if tb then K.klog("%s", tb) end
        end
        p.exitcode = 1
    end
    if p.killed then p.exitcode = p.killed end
    if p.execchunk and not p.killed then
        local chunk, args = p.execchunk, p.execargs
        p.execchunk, p.execargs = nil, nil
        p.name = p.execname
        p.launchcwd = p.cwd
        for h in pairs(p.handles) do pcall(h.close, h) end
        p.handles = {}
        startImage(p, chunk, args)
        return
    end
    zombie(p)
end

function K.wait(p, pid, nohang)
    while true do
        local found, any
        for cpid in pairs(p.children) do
            local c = K.procs[cpid]
            if c and (pid == -1 or pid == cpid or (pid == 0 and c.pgid == p.pgid)) then
                any = true
                if c.state == "Z" then
                    found = c
                    break
                end
            end
        end
        if found then
            K.procs[found.pid] = nil
            p.children[found.pid] = nil
            return found.pid, found.exitcode, found.killed and (found.killed - 128) or 0
        end
        if not any then return nil, "no child processes" end
        if nohang then return 0 end
        K.block(p, function()
            for cpid in pairs(p.children) do
                local c = K.procs[cpid]
                if c and c.state == "Z" then return true end
            end
            return false
        end)
    end
end

local function runnable(p, now)
    if p.state == "R" then return true end
    if p.state ~= "S" then return false end
    if p.wakeup then
        p.wakeup = nil
        return true
    end
    if p.deadline and now >= p.deadline then return true end
    if p.waitfn and p.waitfn() then return true end
    return false
end

function K.runslice(p)
    K.current = p
    p.state = "R"
    local t0 = K.now()
    local ok, v = rawresume(p.co)
    p.cputime = p.cputime + (K.now() - t0)
    p.slices = p.slices + 1
    K.current = nil
    if not ok then
        finish(p, false, v)
    elseif rawstatus(p.co) == "dead" then
        finish(p, true)
    else
        return v == PREEMPT
    end
    return false
end

local function escalate(now)
    for _, p in pairs(K.procs) do
        if p.termAsked and p.state ~= "Z" and now - p.termAsked > 1.5 then
            p.killed = 128 + (p.termSig or 15)
            p.termAsked = nil
        end
    end
end

function K.schedule_round(round)
    local now = K.now()
    escalate(now)
    local pids = {}
    for pid in pairs(K.procs) do pids[#pids + 1] = pid end
    table.sort(pids)
    local full = false
    for _, pid in ipairs(pids) do
        local p = K.procs[pid]
        if p and p.state ~= "Z" then
            if p.killed then
                K.terminate(p, p.killed)
            elseif (p.nice <= 0 or round % (p.nice + 1) == 0) and runnable(p, now) then
                if K.runslice(p) then full = true end
            end
        end
    end
    return full
end

function K.run()
    while true do
        K.ticks = K.ticks + 1
        K.kbd.pump()
        local t0 = K.now()
        local round = 0
        repeat
            round = round + 1
            local full = K.schedule_round(round)
        until not full or round >= K.maxrounds or (K.now() - t0) > K.tickbudget
        K.sampleLoad()
        if K.ticks % 32 == 0 then K.crypto.entropy_add("tick", K.ticks) end
        K.tty_flush()
        if K.shutdownRequested then K.doShutdown(K.shutdownRequested) end
        yield()
    end
end
