local K = ...
local API = K.neato or {}

local X = { version = 1 }
K.ext = X

local AREAS = {
	"fs",
	"proc",
	"job",
	"time",
	"system",
	"tty",
	"poll",
	"shm",
	"screen",
	"headsup",
	"peripherals",
	"internet",
	"compat",
	"mouse",
	"rpp",
	"sppremote",
}

local TOP = {}
local HOOKS = {}
K.extensionHooks = HOOKS

local function loadArea(name)
	local path = "/kernel/ext/" .. name .. ".lua"
	local src, rerr = K.rawRead(path)
	if not src then
		return nil, rerr
	end
	local chunk, cerr = load(src, "=" .. path, "t", _G)
	if not chunk then
		return nil, cerr
	end
	local ok, mod = pcall(chunk, K, API, X)
	if not ok then
		return nil, mod
	end
	if type(mod) ~= "table" then
		return nil, "submodule did not return a table"
	end
	return mod
end

local function declareExt(map)
	if type(map) ~= "table" then
		return
	end
	for k, v in pairs(map) do
		if type(k) == "number" then
			K.extensions[v] = 1
		else
			K.extensions[k] = v
		end
	end
end

for _, name in ipairs(AREAS) do
	local mod, err = loadArea(name)
	if mod then
		X[name] = mod
		declareExt(mod.__ext)
		if type(mod.__top) == "table" then
			for n, f in pairs(mod.__top) do
				TOP[n] = f
			end
		end
		if type(mod.__hooks) == "table" then
			for n, f in pairs(mod.__hooks) do
				HOOKS[n] = f
			end
		end
	else
		if err and not tostring(err):find("cannot open", 1, true) then
			K.klog("kernel: ext area '%s' unavailable: %s", name, tostring(err))
		end
	end
end

K.extensions["x.xesns.kernel"] = X.version

function K.extbind(p)
	local out = {}
	local function self()
		return K.current or p
	end
	local function bind(tbl)
		local bound = {}
		for name, fn in pairs(tbl) do
			if type(fn) == "function" then
				bound[name] = function(...)
					return fn(self(), ...)
				end
			elseif name ~= "__top" and name ~= "__ext" and name ~= "__hooks"
				and name ~= "__eventonly" and name ~= "__global" then
				bound[name] = fn
			end
		end
		return bound
	end
	for area, mod in pairs(X) do
		if area ~= "version" and type(mod) == "table" and not mod.__eventonly then
			out[mod.__global or area] = bind(mod)
		end
	end
	for name, fn in pairs(TOP) do
		if type(fn) == "function" then
			out[name] = function(...)
				return fn(self(), ...)
			end
		else
			out[name] = fn
		end
	end
	return out
end
