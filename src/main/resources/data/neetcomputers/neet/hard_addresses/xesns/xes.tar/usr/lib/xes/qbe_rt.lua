local __penv = _ENV or _G

local function __runtime()
local mtype, floor, ceil, ult = math.type, math.floor, math.ceil, math.ult
local spack, sunpack, schar = string.pack, string.unpack, string.char
local MININT = math.mininteger

local M = {}
M.__index = M

local LO = 0x10000

function M.new(opts)
  opts = opts or {}
  local memsize = opts.memsize or (32 << 20)
  local stacksize = opts.stacksize or (1 << 20)
  local datasize = opts.datasize or (2 << 20)
  local R = setmetatable({}, M)
  local m, fm = {}, {}
  R.m, R.fm = m, fm
  R.F, R.FI = {}, {}

  R.globals = opts.globals == nil and _G or opts.globals
  if R.globals then
    setmetatable(R.F, { __index = function(_, name) return R.globals[name] end })
  end
  R.lo, R.hi = LO, LO + memsize
  R.dbump = LO
  R.dend = LO + datasize
  R.brk = R.dend
  R.slimit = R.hi - stacksize
  R.sp = R.hi
  R.env = 0
  R.nextfn = 16
  R.out = opts.out or io.stdout
  R.out:setvbuf("full")
  R.hostdata = {}
  local S = setmetatable({}, {
    __index = function(t, name)
      local f = R.F[name]
      if f then
        local h = R.nextfn
        R.nextfn = h + 16
        R.FI[h] = f
        rawset(t, name, h)
        return h
      end
      local d = R.hostdata[name]
      if d then
        rawset(t, name, d)
        return d
      end
      error("undefined symbol: " .. tostring(name), 2)
    end})
  R.S = S

  local lo, hi = R.lo, R.hi

  local function f32(x)
    local t = x * 536870913.0
    local r = t - (t - x)
    if r ~= r or r > 3.4028234663852886e38 or r < -3.4028234663852886e38
       or (x ~= 0 and x < 1.1754943508222875e-38 and x > -1.1754943508222875e-38) then
      return (sunpack("<f", spack("<f", x)))
    end
    return r
  end
  local function f2b32(x) return (sunpack("<I4", spack("<f", x))) end
  local function b2f32(b) return (sunpack("<f", spack("<I4", b & 0xFFFFFFFF))) end
  local function d2b(x) return (sunpack("<i8", spack("<d", x))) end
  local function b2d(b) return (sunpack("<d", spack("<i8", b))) end
  R.f32, R.f2b32, R.b2f32, R.d2b, R.b2d = f32, f2b32, b2f32, d2b, b2d

  local function ftoi(x)
    if x ~= x or x >= 9223372036854775808.0 or x < -9223372036854775808.0 then
      return MININT
    end
    if x >= 0 then return floor(x) else return ceil(x) end
  end
  R.ftoi = ftoi
  function R.ftoi32(x)
    local r = ftoi(x)
    if r > 2147483647 or r < -2147483648 then return -2147483648 end
    return r
  end
  function R.ftou(x)
    if x >= 9223372036854775808.0 and x < 18446744073709551616.0 then
      return ftoi(x - 9223372036854775808.0) | MININT
    end
    return ftoi(x)
  end
  function R.u2f(a)
    if a >= 0 then return a + 0.0 end
    return (((a >> 1) | (a & 1)) + 0.0) * 2.0
  end

  function R.idiv(a, b)
    local q = a // b
    if q < 0 and q * b ~= a then q = q + 1 end
    return q
  end
  local function udiv(a, b)
    if b < 0 then return ult(a, b) and 0 or 1 end
    if a >= 0 then return a // b end
    local q = ((a >> 1) // b) << 1
    local r = a - q * b
    if not ult(r, b) then q = q + 1 end
    return q
  end
  R.udiv = udiv
  function R.urem(a, b) return a - udiv(a, b) * b end
  function R.sar64(a, n)
    return (a >> n) | (-(a >> 63) << (63 - n) << 1)
  end

  local function oob(p)
    error(string.format("segmentation fault: bad address 0x%x", p), 0)
  end

  local function ld64(p)
    local q = p >> 3
    local v = m[q]
    if v ~= nil then return v end
    v = fm[q]
    if v ~= nil then return d2b(v) end
    if p < lo or p >= hi then oob(p) end
    return 0
  end
  local function ldd(p)
    local q = p >> 3
    local x = fm[q]
    if x ~= nil then return x end
    local b = m[q]
    if b ~= nil then
      x = b2d(b)
      fm[q] = x; m[q] = nil
      return x
    end
    if p < lo or p >= hi then oob(p) end
    return 0.0
  end
  R.ld64, R.ldd = ld64, ldd

  local function ldb(p)
    return ((m[p >> 3] or ld64(p)) >> ((p & 7) << 3)) & 0xFF
  end
  local function stb(p, v)
    local q, s = p >> 3, (p & 7) << 3
    m[q] = ((m[q] or ld64(p)) & ~(0xFF << s)) | ((v & 0xFF) << s)
    fm[q] = nil
  end
  R.ldb, R.stb = ldb, stb

  local function ldNu(p, n)
    local s = (p & 7) << 3
    local w0 = m[p >> 3] or ld64(p)
    if s == 0 then
      if n == 8 then return w0 end
      return w0 & ((1 << (n << 3)) - 1)
    end
    local v = w0 >> s
    if s + (n << 3) > 64 then
      v = v | ((m[(p >> 3) + 1] or ld64(p + 8)) << (64 - s))
    end
    if n == 8 then return v end
    return v & ((1 << (n << 3)) - 1)
  end
  local function ld64u(p) return ldNu(p, 8) end
  R.ld64u = ld64u
  R.ld32u = function(p) return ldNu(p, 4) end
  R.ld16u = function(p) return ldNu(p, 2) end
  R.lddu = function(p)
    if p & 7 == 0 then return ldd(p) end
    return b2d(ldNu(p, 8))
  end
  local function stN(p, n, v)
    if n == 8 and p & 7 == 0 then
      m[p >> 3] = v; fm[p >> 3] = nil
      return
    end
    for i = 0, n - 1 do stb(p + i, v >> (8 * i)) end
  end
  R.stN = stN
  local function st64u(p, v) return stN(p, 8, v) end
  R.st64u = st64u

  local function zero(p, n)
    local q = p >> 3
    for i = q, q + (n >> 3) - 1 do m[i] = 0; fm[i] = nil end
  end

  local function memcpy(d, s, n)
    if n <= 0 then return end
    if (d | s) & 7 == 0 then
      local dq, sq = d >> 3, s >> 3
      for i = 0, (n >> 3) - 1 do
        local v = m[sq + i]
        if v == nil then
          v = fm[sq + i]
          if v == nil then v = ld64((sq + i) << 3); m[dq + i] = v; fm[dq + i] = nil
          else fm[dq + i] = v; m[dq + i] = nil end
        else
          m[dq + i] = v; fm[dq + i] = nil
        end
      end
      for i = (n & ~7), n - 1 do stb(d + i, ldb(s + i)) end
    else
      for i = 0, n - 1 do stb(d + i, ldb(s + i)) end
    end
  end
  R.blit = memcpy

  local function memmove(d, s, n)
    if d <= s or d >= s + n then return memcpy(d, s, n) end
    for i = n - 1, 0, -1 do stb(d + i, ldb(s + i)) end
  end

  function R.alloc(size, align)
    align = align > 8 and align or 8
    local a = (R.dbump + align - 1) & -align
    local e = (a + size + 7) & -8
    if e > R.dend then error("out of static data space", 0) end
    R.dbump = e
    zero(a, e - a)
    return a
  end
  function R.dwrite(a, s)
    local i, n = 1, #s
    while i <= n and (a + i - 1) & 7 ~= 0 do
      stb(a + i - 1, s:byte(i)); i = i + 1
    end
    while i + 7 <= n do
      local q = (a + i - 1) >> 3
      m[q] = sunpack("<i8", s, i); fm[q] = nil
      i = i + 8
    end
    while i <= n do stb(a + i - 1, s:byte(i)); i = i + 1 end
  end

  function R.bawrite(t, s)
    for i = 1, #s do
      local b = s:byte(i)
      if b ~= 0 then t[i-1] = b end
    end
  end
  function R.dptr(a, size, v) stN(a, size, v) end

  R.pending = {}
  function R.later(fn) R.pending[#R.pending + 1] = fn end

  function R.vastore(va, ...)
    local n = select("#", ...)
    local q = va >> 3
    for i = 1, n do
      local v = select(i, ...)
      if mtype(v) == "float" then m[q + i - 1] = nil; fm[q + i - 1] = v
      else m[q + i - 1] = v; fm[q + i - 1] = nil end
    end
  end
  function R.stkovf() error("stack overflow", 0) end
  function R.hlt() error("halt", 0) end

  local function cstr(p)
    local t, n = {}, 0
    while true do
      local w = m[p >> 3] or ld64(p)
      local sh = (p & 7) << 3
      for s = sh, 56, 8 do
        local c = (w >> s) & 0xFF
        if c == 0 then return table.concat(t) end
        n = n + 1; t[n] = schar(c)
      end
      p = (p & ~7) + 8
    end
  end
  R.cstr = cstr
  local function putstr(p, s)
    for i = 1, #s do stb(p + i - 1, s:byte(i)) end
    stb(p + #s, 0)
    return p
  end
  R.putstr = putstr
  local function rawstr(p, n)
    local t = {}
    for i = 0, n - 1 do t[#t + 1] = schar(ldb(p + i)) end
    return table.concat(t)
  end
  R.rawstr = rawstr

  local freelist = {}
  local function malloc(n)
    n = (n + 15) & -16
    if n == 0 then n = 16 end
    local l = freelist[n]
    if l and #l > 0 then
      local p = l[#l]; l[#l] = nil
      return p
    end
    local p = R.brk + 16
    if p + n >= R.slimit then return 0 end
    R.brk = p + n
    m[(p - 8) >> 3] = n; fm[(p - 8) >> 3] = nil
    zero(p, n)
    return p
  end
  local function free(p)
    if p == 0 then return end
    local n = m[(p - 8) >> 3]
    local l = freelist[n]
    if not l then l = {}; freelist[n] = l end
    l[#l + 1] = p
  end

  local F = R.F
  local out = R.out

  F.malloc = function(n) return malloc(n) end
  F.free = free
  F.calloc = function(a, b)
    local p = malloc(a * b)
    if p ~= 0 then zero(p, (a * b + 15) & -16) end
    return p
  end
  F.realloc = function(p, n)
    if p == 0 then return malloc(n) end
    local old = m[(p - 8) >> 3]
    if n <= old then return p end
    local q = malloc(n)
    if q == 0 then return 0 end
    memcpy(q, p, old)
    free(p)
    return q
  end
  F.memcpy = function(d, s, n) memcpy(d, s, n); return d end
  F.memmove = function(d, s, n) memmove(d, s, n); return d end
  F.memset = function(d, c, n)
    c = c & 0xFF
    for i = 0, n - 1 do stb(d + i, c) end
    return d
  end
  F.memcmp = function(a, b, n)
    for i = 0, n - 1 do
      local x, y = ldb(a + i), ldb(b + i)
      if x ~= y then return x < y and -1 or 1 end
    end
    return 0
  end
  F.strlen = function(p)
    local n = 0
    while ldb(p + n) ~= 0 do n = n + 1 end
    return n
  end
  F.strcmp = function(a, b)
    while true do
      local x, y = ldb(a), ldb(b)
      if x ~= y then return x < y and -1 or 1 end
      if x == 0 then return 0 end
      a, b = a + 1, b + 1
    end
  end
  F.strncmp = function(a, b, n)
    for i = 0, n - 1 do
      local x, y = ldb(a + i), ldb(b + i)
      if x ~= y then return x < y and -1 or 1 end
      if x == 0 then return 0 end
    end
    return 0
  end
  F.strcpy = function(d, s)
    local i = 0
    repeat local c = ldb(s + i); stb(d + i, c); i = i + 1 until c == 0
    return d
  end
  F.strncpy = function(d, s, n)
    local i, z = 0, false
    while i < n do
      local c = z and 0 or ldb(s + i)
      if c == 0 then z = true end
      stb(d + i, c); i = i + 1
    end
    return d
  end
  F.strcat = function(d, s)
    F.strcpy(d + F.strlen(d), s)
    return d
  end
  F.strchr = function(s, c)
    c = c & 0xFF
    while true do
      local x = ldb(s)
      if x == c then return s end
      if x == 0 then return 0 end
      s = s + 1
    end
  end
  F.strrchr = function(s, c)
    c = c & 0xFF
    local r = 0
    while true do
      local x = ldb(s)
      if x == c then r = s end
      if x == 0 then return r end
      s = s + 1
    end
  end
  F.strstr = function(h, n)
    local hs, ns = cstr(h), cstr(n)
    local i = hs:find(ns, 1, true)
    return i and h + i - 1 or 0
  end
  F.atoi = function(p)
    local n = tonumber(cstr(p):match("^%s*([+-]?%d+)")) or 0
    return ((n & 0xFFFFFFFF) ~ 0x80000000) - 0x80000000
  end
  F.atol = function(p) return math.tointeger(tonumber(cstr(p):match("^%s*([+-]?%d+)"))) or 0 end
  F.abs = function(x) return x < 0 and -x or x end
  F.labs = F.abs
  F.toupper = function(c) if c >= 97 and c <= 122 then return c - 32 end return c end
  F.tolower = function(c) if c >= 65 and c <= 90 then return c + 32 end return c end
  F.isdigit = function(c) return (c >= 48 and c <= 57) and 1 or 0 end
  F.isalpha = function(c) return ((c >= 65 and c <= 90) or (c >= 97 and c <= 122)) and 1 or 0 end
  F.isspace = function(c) return (c == 32 or (c >= 9 and c <= 13)) and 1 or 0 end

  F.putchar = function(c) out:write(schar(c & 0xFF)); return c & 0xFF end
  F.puts = function(p) out:write(cstr(p), "\n"); return 1 end
  F.exit = function(c) error(setmetatable({ code = c }, { __tostring = function() return "exit" end }), 0) end
  F.abort = function() error("abort", 0) end

  for _, n in ipairs { "sqrt", "sin", "cos", "tan", "exp", "log", "floor", "ceil", "fabs", "atan" } do
    local f = math[n == "fabs" and "abs" or n]
    F[n] = function(x) if mtype(x) == "integer" then x = x + 0.0 end return f(x) end
  end
  F.pow = function(a, b) if mtype(a) == "integer" then a = a + 0.0 end return a ^ b end
  F.fmod = function(a, b) return math.fmod(a, b) end

  local function sfmt(fp, nextarg)
    local f = cstr(fp)
    local res, pos = {}, 1
    while pos <= #f do
      local s, e = f:find("%", pos, true)
      if not s then res[#res + 1] = f:sub(pos); break end
      res[#res + 1] = f:sub(pos, s - 1)
      local flags, width, prec, len, conv
      local i = s + 1
      flags = f:match("^[-+ #0]*", i); i = i + #flags
      width = f:match("^%*", i)
      if width then width = tostring(nextarg("i")); i = i + 1
      else width = f:match("^%d*", i); i = i + #width end
      prec = nil
      if f:sub(i, i) == "." then
        i = i + 1
        if f:sub(i, i) == "*" then prec = tostring(nextarg("i")); i = i + 1
        else prec = f:match("^%d*", i); i = i + #prec; if prec == "" then prec = "0" end end
      end
      len = f:match("^[hlLqjzt]*", i); i = i + #len
      conv = f:sub(i, i)
      pos = i + 1
      if flags:find("-", 1, true) == nil and width:sub(1, 1) == "-" then
        flags = flags .. "-"; width = width:sub(2)
      end
      local spec = "%" .. flags .. width .. (prec and ("." .. prec) or "")
      local long = (len == "l" or len == "ll" or len == "j" or len == "z" or len == "t" or len == "q")
      if conv == "%" then
        res[#res + 1] = "%"
      elseif conv == "d" or conv == "i" then
        local v = nextarg()
        if not long then v = ((v & 0xFFFFFFFF) ~ 0x80000000) - 0x80000000 end
        res[#res + 1] = string.format(spec .. "d", v)
      elseif conv == "u" or conv == "x" or conv == "X" or conv == "o" then
        local v = nextarg()
        if not long then v = v & 0xFFFFFFFF end
        if conv == "u" then
          local str
          if v >= 0 then str = tostring(v)
          else
            local q = udiv(v, 10); str = tostring(q) .. tostring(v - q * 10)
          end
          res[#res + 1] = string.format("%" .. flags:gsub("[+ #0]", "") .. width .. "s", str)
        else
          res[#res + 1] = string.format(spec .. conv, v)
        end
      elseif conv == "c" then
        res[#res + 1] = string.format("%" .. flags:gsub("[+ #0]", "") .. width .. "s", schar(nextarg() & 0xFF))
      elseif conv == "s" then
        local p = nextarg()
        local str = p == 0 and "(null)" or cstr(p)
        if prec then str = str:sub(1, tonumber(prec)) end
        res[#res + 1] = string.format("%" .. flags:gsub("[+ #0]", "") .. width .. "s", str)
      elseif conv == "p" then
        local v = nextarg()
        res[#res + 1] = string.format("%" .. flags:gsub("[+ #0]", "") .. width .. "s", v == 0 and "(nil)" or string.format("0x%x", v))
      elseif conv:match("[feEgGaA]") then
        local v = nextarg("f")
        if mtype(v) == "integer" then v = v + 0.0 end
        res[#res + 1] = string.format(spec .. conv, v)
      else
        res[#res + 1] = "%" .. conv
      end
    end
    return table.concat(res)
  end

  local function listargs(...)
    local args, ai = { ... }, 1
    return function() local v = args[ai]; ai = ai + 1; return v end
  end
  local function memargs(ap)
    return function(kind)
      local v
      if kind == "f" then v = ldd(ap) else v = ld64u(ap) end
      ap = ap + 8
      return v
    end
  end
  F.printf = function(fp, ...)
    local s = sfmt(fp, listargs(...))
    out:write(s)
    return #s
  end
  F.sprintf = function(d, fp, ...)
    local s = sfmt(fp, listargs(...))
    putstr(d, s)
    return #s
  end
  F.snprintf = function(d, n, fp, ...)
    local s = sfmt(fp, listargs(...))
    if n > 0 then putstr(d, s:sub(1, n - 1)) end
    return #s
  end
  F.vprintf = function(fp, ap)
    local s = sfmt(fp, memargs(ap))
    out:write(s)
    return #s
  end
  F.vsprintf = function(d, fp, ap)
    local s = sfmt(fp, memargs(ap))
    putstr(d, s)
    return #s
  end
  F.vsnprintf = function(d, n, fp, ap)
    local s = sfmt(fp, memargs(ap))
    if n > 0 then putstr(d, s:sub(1, n - 1)) end
    return #s
  end
  F.qsort = function(base, n, size, cmp)
    local f = R.FI[cmp]
    local tmp = malloc(size)

    for i = 1, n - 1 do
      memcpy(tmp, base + i * size, size)
      local j = i - 1
      while j >= 0 and f(base + j * size, tmp) > 0 do
        memcpy(base + (j + 1) * size, base + j * size, size)
        j = j - 1
      end
      memcpy(base + (j + 1) * size, tmp, size)
    end
    free(tmp)
  end

  return R
end

function M:extern(spec)
  local t
  if type(spec) == "string" then
    local f = loadfile(spec)
    if f then
      spec = f
    else
      local ok, m = pcall(require, spec)
      if not ok then error(m, 0) end
      spec = m
    end
  end
  t = type(spec) == "function" and spec(self) or spec
  if type(t) ~= "table" then
    error("extern: expected a table of bindings", 2)
  end
  for name, v in pairs(t) do
    if type(v) == "string" then
      local g = self.globals
      for part in v:gmatch("[^.]+") do
        g = g and g[part]
      end
      v = g
    end
    if type(v) ~= "function" then
      error("extern: bad binding for '" .. tostring(name) .. "'", 2)
    end
    self.F[name] = v
  end
  return self
end

function M:load(src, name)
  local fn, err
  if src:find("\n", 1, true) == nil and not src:find("^%-%-") then
    local fh = assert(io.open(src, "rb")); src = fh:read("a"); fh:close()
  end
  fn, err = load(src, name or "=qbe", "t")
  if not fn then error(err, 0) end
  local r = fn(self)
  self:link(false)
  return r
end

function M:link(final)
  local left = {}
  for _, fn in ipairs(self.pending) do
    local ok, err = pcall(fn)
    if not ok then
      if final then error(err, 0) end
      left[#left + 1] = fn
    end
  end
  self.pending = left
end

function M:run(args)
  args = args or { "a.out" }
  self:link(true)
  local argv = self.alloc(8 * (#args + 1), 8)
  for i, a in ipairs(args) do
    local p = self.alloc(#a + 1, 8)
    self.putstr(p, a)
    self.st64u(argv + 8 * (i - 1), p)
  end
  local ok, res = pcall(self.F.main, #args, argv)
  self.out:flush()
  if ok then return res or 0 end
  if type(res) == "table" and res.code then return res.code end
  io.stderr:write("qbe-lua: ", tostring(res), "\n")
  return 134
end

return M

end

local function __host(...)
local R = ...

local G = R.globals or _G
local P = G.posix
if not P then
  error("extern/host.lua: no XesNS `posix` table in the environment " ..
    "(run with extern/xesns.lua installed, or embed with globals = xesns_env)", 2)
end
local T, S, E = G.term, G.sys, G.event
local FST, DPP, SPP = G.fs, G.dpp, G.spp

local function cstr(p)
  if p == nil or p == 0 then return nil end
  return R.cstr(p)
end

local function toint(v)
  if type(v) ~= "number" then return 0 end
  if math.type(v) == "integer" then return v end
  return R.ftoi(v)
end

local function newstr(s)
  if s == nil then return 0 end
  s = tostring(s)
  local p = R.F.malloc(#s + 1)
  R.putstr(p, s)
  return p
end

local function copyout(dst, cap, s)
  if dst == 0 then return #s end
  if not cap or cap <= 0 then return 0 end
  local n = #s
  if n > cap - 1 then n = cap - 1 end
  R.dwrite(dst, s:sub(1, n))
  R.stb(dst + n, 0)
  return n
end

local function copyoutlist(dst, cap, list)
  if not list then return -1 end
  local off = 0
  for i = 1, #list do
    local n = #list[i]
    if dst ~= 0 and off + n + 1 <= cap then
      R.dwrite(dst + off, list[i]); R.stb(dst + off + n, 0)
    end
    off = off + n + 1
  end
  return #list
end

local function pcallr(f, ...)
  local ok, a, b, c = pcall(f, ...)
  if not ok then return nil, tostring(a) end
  return a, b, c
end

local F = {}

F.posix_write = function(fd, buf, n)
  if not n or n < 0 then return -1 end
  local ok, err = pcallr(P.write, fd, R.rawstr(buf, n))
  if ok == nil then return -1 end
  return n
end

F.posix_read = function(fd, buf, n)
  if not n or n <= 0 then return 0 end
  local s, err = pcallr(P.read, fd, n)
  if s == nil then return (err == nil and 0 or -1) end
  if type(s) ~= "string" then return 0 end
  if #s > n then s = s:sub(1, n) end
  R.dwrite(buf, s)
  return #s
end

local OPEN_MODE = { [0] = "r", [1] = "w", [2] = "a" }
F.posix_open = function(path, mode)
  local fd, err = pcallr(P.open, cstr(path), OPEN_MODE[mode] or "r")
  if fd == nil then return -1 end
  return fd
end

F.posix_close = function(fd)
  local ok = pcallr(P.close, fd)
  return ok and 0 or -1
end

F.posix_seek = function(fd, whence, off)
  local W = ({ "set", "cur", "end" })[(whence or 0) + 1]
  if not W then return -1 end
  local pos, err = pcallr(P.seek, fd, W, off or 0)
  if pos == nil then return -1 end
  return toint(pos)
end

F.posix_dup = function(fd)
  local nfd, err = pcallr(P.dup, fd)
  if nfd == nil then return -1 end
  return nfd
end

F.posix_dup2 = function(oldfd, newfd)
  local nfd, err = pcallr(P.dup2, oldfd, newfd)
  if nfd == nil then return -1 end
  return nfd
end

F.posix_pipe = function(fds)
  local r, w = pcallr(P.pipe)
  if r == nil then return -1 end
  R.stN(fds + 0, 4, toint(r))
  R.stN(fds + 4, 4, toint(w))
  return 0
end

F.posix_getpid  = function() return toint(P.getpid()) end
F.posix_getppid = function() return toint(P.getppid()) end
F.posix_getpgrp = function() return toint(P.getpgrp()) end
F.posix_getuid  = function() return toint(P.getuid()) end
F.posix_geteuid = function()
  local g = P.geteuid or P.getuid
  return toint(g())
end
F.posix_getgid = function() return toint(P.getgid()) end
F.posix_isatty  = function(fd) return P.isatty(fd) and 1 or 0 end

F.posix_getgroups = function(buf, cap)
  local gs = P.getgroups and P.getgroups() or {}
  if buf == 0 then return #gs end
  local n = #gs
  if cap and n > cap // 4 then n = cap // 4 end
  for i = 1, n do R.stN(buf + 4 * (i - 1), 4, toint(gs[i])) end
  return #gs
end

F.posix_umask = function(mask)
  if not P.umask then return -1 end
  return toint(P.umask(mask))
end

F.posix_gethostname = function(buf, cap)
  return copyout(buf, cap, P.gethostname() or "")
end

F.posix_uname = function(up)
  local u, err = pcallr(P.uname)
  if not u then return -1 end
  local fields = {
    { 0, u.sysname, 32 }, { 32, u.nodename, 32 }, { 64, u.release, 32 },
    { 96, u.version, 64 }, { 160, u.machine, 32 },
  }
  for _, f in ipairs(fields) do copyout(up + f[1], f[3], f[2] or "") end
  return 0
end

F.posix_getenv = function(name) return newstr(P.getenv(cstr(name) or "")) end
F.posix_setenv = function(name, value)
  local ok = pcallr(P.setenv, cstr(name), cstr(value))
  return ok and 0 or -1
end
F.posix_unsetenv = function(name)
  local ok = pcallr(P.unsetenv, cstr(name))
  return ok and 0 or -1
end

F.posix_chdir = function(path)
  local ok = pcallr(P.chdir, cstr(path))
  return ok and 0 or -1
end
F.posix_getcwd = function(buf, cap)
  local d = (P.pwd and P.pwd()) or P.getcwd() or ""
  return copyout(buf, cap, d)
end

F.posix_readfile = function(path, buf, cap)
  local d, err = pcallr(P.readfile, cstr(path))
  if type(d) ~= "string" then return -1 end
  if not cap or cap <= 0 then return #d end
  copyout(buf, cap, d)
  return #d
end

F.posix_writefile = function(path, buf, n, append)
  if not n or n < 0 then return -1 end
  local ok, err = pcallr(P.writefile, cstr(path), R.rawstr(buf, n), append ~= 0)
  return ok and 0 or -1
end

F.posix_readdir = function(path, buf, cap)
  local list = pcallr(P.readdir, cstr(path))
  if not list then return -1 end
  return copyoutlist(buf, cap, list)
end

F.posix_glob = function(pattern, buf, cap)
  local list = pcallr(P.glob, cstr(pattern))
  if not list then return -1 end
  return copyoutlist(buf, cap, list)
end

local STYPE = { dir = 1, file = 2, link = 3, fifo = 4, chr = 5, blk = 6, sock = 7 }
F.posix_stat = function(path, sp)
  local st = pcallr(P.stat, cstr(path))
  if not st then return -1 end

  R.stN(sp +  0, 8, toint(st.size))
  R.stN(sp +  8, 8, toint(st.mtime))
  R.stN(sp + 16, 8, toint(STYPE[st.type]))
  R.stN(sp + 24, 8, toint(st.mode))
  R.stN(sp + 32, 8, toint(st.uid))
  R.stN(sp + 40, 8, toint(st.gid))
  return 0
end

F.posix_mkdir  = function(path)
  local ok = pcallr(P.mkdir, cstr(path))
  return ok and 0 or -1
end
F.posix_unlink = function(path)
  local ok = pcallr(P.unlink, cstr(path))
  return ok and 0 or -1
end
F.posix_rename = function(a, b)
  local ok = pcallr(P.rename, cstr(a), cstr(b))
  return ok and 0 or -1
end
F.posix_access = function(path, mode)
  local ok = pcallr(P.access, cstr(path), mode)
  return ok and 0 or -1
end
F.posix_chmod  = function(path, mode)
  local ok = pcallr(P.chmod, cstr(path), mode)
  return ok and 0 or -1
end
F.posix_chown = function(path, uid, gid)
  if not P.chown then return -1 end
  local ok = pcallr(P.chown, cstr(path), uid, gid)
  return ok and 0 or -1
end

F.posix_symlink = function(target, linkpath)
  if not P.symlink then return -1 end
  local ok = pcallr(P.symlink, cstr(target), cstr(linkpath))
  return ok and 0 or -1
end
F.posix_readlink = function(path, buf, cap)
  if not P.readlink then return -1 end
  local s = pcallr(P.readlink, cstr(path))
  if type(s) ~= "string" then return -1 end
  return copyout(buf, cap, s)
end
F.posix_mkfifo = function(path)
  if not P.mkfifo then return -1 end
  local ok = pcallr(P.mkfifo, cstr(path))
  return ok and 0 or -1
end
F.posix_mknod = function(path, kind)
  if not P.mknod then return -1 end
  local kinds = { [4] = "p" }
  local ok = pcallr(P.mknod, cstr(path), kinds[kind] or "p")
  return ok and 0 or -1
end
F.posix_utime = function(path, mtime)
  if not P.utime then return -1 end
  local mt = mtime
  if mt ~= nil and mt < 0 then mt = nil end
  local ok = pcallr(P.utime, cstr(path), mt)
  return ok and 0 or -1
end
F.posix_mount = function(mp, device)
  if not P.mount then return -1 end
  local ok = pcallr(P.mount, cstr(mp), cstr(device))
  return ok and 0 or -1
end
F.posix_unmount = function(mp)
  if not P.unmount then return -1 end
  local ok = pcallr(P.unmount, cstr(mp))
  return ok and 0 or -1
end
F.posix_mounts = function(buf, cap)
  if not P.mounts then return -1 end
  local ms = pcallr(P.mounts)
  if not ms then return -1 end
  local list = {}
  for _, m in ipairs(ms) do
    list[#list + 1] = tostring(m.mountpoint or "?") .. " " ..
      tostring(m.disk or "?") .. ":" .. tostring(m.partition or "?")
  end
  return copyoutlist(buf, cap, list)
end

local function copyin_passwd(dst, pw)
  if not pw then return -1 end
  copyout(dst + 0, 64, pw.name or "")
  R.stN(dst + 64, 4, toint(pw.uid))
  R.stN(dst + 68, 4, toint(pw.gid))
  copyout(dst + 72, 128, pw.gecos or "")
  copyout(dst + 200, 128, pw.home or "")
  copyout(dst + 328, 64, pw.shell or "")
  return 0
end
F.posix_getpwnam = function(name, pw)
  if not P.getpwnam then return -1 end
  local u = pcallr(P.getpwnam, cstr(name))
  return copyin_passwd(pw, u)
end
F.posix_getpwuid = function(uid, pw)
  if not P.getpwuid then return -1 end
  local u = pcallr(P.getpwuid, uid)
  return copyin_passwd(pw, u)
end
F.posix_getusers = function(buf, cap)
  if not P.getusers then return -1 end
  local us = pcallr(P.getusers)
  if not us then return -1 end
  local list = {}
  for _, u in ipairs(us) do list[#list + 1] = tostring(u.name or "?") end
  return copyoutlist(buf, cap, list)
end
F.posix_authenticate = function(name, pass)
  if not P.authenticate then return -1 end
  local u = pcallr(P.authenticate, cstr(name), cstr(pass) or "")
  return u and 0 or -1
end
F.posix_passwd = function(name, old, newpass)
  if not P.passwd then return -1 end
  local ok = pcallr(P.passwd, cstr(name), cstr(old) or "", cstr(newpass) or "")
  return ok and 0 or -1
end

F.posix_date = function()
  if P.date then
    local ok, d = pcall(P.date)
    if ok and type(d) == "number" then return toint(d) end
  end
  return toint(P.time())
end
F.posix_datestring = function(buf, cap, ts)
  local ds = P.dateString or P.date
  if not ds then return -1 end
  local s = ds(ts)
  if type(s) ~= "string" then return -1 end
  return copyout(buf, cap, s)
end
F.posix_loadavg = function(lav)
  if not P.loadavg then return -1 end
  local a, b, c = P.loadavg()
  if a == nil then return -1 end
  local function std(o, v)
    R.stN(lav + o, 8, R.d2b(tonumber(v) or 0))
  end
  std(0, a); std(8, b); std(16, c)
  return 0
end
F.posix_dmesg = function(buf, cap)
  if not P.dmesg then return -1 end
  local lines = pcallr(P.dmesg)
  if not lines then return -1 end
  local s = table.concat(lines, "\n")
  if buf == 0 then return #s end
  copyout(buf, cap, s)
  return #s
end
F.posix_ps = function(buf, cap)
  if not P.ps then return -1 end
  local ps = pcallr(P.ps)
  if not ps then return -1 end
  local list = {}
  for _, p in ipairs(ps) do
    list[#list + 1] = string.format("%d %d %s", toint(p.pid), toint(p.uid),
      tostring(p.name or "?"))
  end
  return copyoutlist(buf, cap, list)
end
F.posix_meminfo = function(gcp, prp, npp)
  if not P.meminfo then return -1 end
  local m = pcallr(P.meminfo)
  if not m then return -1 end
  R.stN(gcp, 8, toint(m.gc_bytes))
  R.stN(prp, 8, toint(m.procs_bytes))
  R.stN(npp, 8, toint(m.nprocs))
  return 0
end
F.posix_sysctl = function(key, buf, cap)
  if not P.sysctl then return -1 end
  local v = pcallr(P.sysctl, cstr(key))
  if v == nil then return -1 end
  return copyout(buf, cap, tostring(v))
end
F.posix_sysctl_set = function(key, value)
  if not P.sysctl then return -1 end
  local v = pcallr(P.sysctl, cstr(key), cstr(value))
  return v == nil and -1 or 0
end
F.posix_reboot = function()
  if not P.reboot then return -1 end
  local ok = pcallr(P.reboot)
  return ok and 0 or -1
end
F.posix_halt = function()
  if not P.halt then return -1 end
  local ok = pcallr(P.halt)
  return ok and 0 or -1
end

F.posix_loadlib = function(name)
  if not P.loadlib then return -1 end
  local ok, lib = pcallr(P.loadlib, cstr(name))
  return (ok ~= nil or lib ~= nil) and 0 or -1
end
F.posix_unloadlib = function(name)
  if not P.unloadlib then return -1 end
  local ok = pcallr(P.unloadlib, cstr(name))
  return ok and 0 or -1
end
F.posix_reloadlib = function(name)
  if not P.reloadlib then return -1 end
  local ok, lib = pcallr(P.reloadlib, cstr(name))
  return (ok ~= nil or lib ~= nil) and 0 or -1
end
F.posix_listlibs = function(buf, cap)
  if not P.listlibs then return -1 end
  local list = pcallr(P.listlibs)
  if not list then return -1 end
  return copyoutlist(buf, cap, list)
end
F.posix_readline = function(buf, cap)
  if not P.readline then return -1 end
  local s = pcallr(P.readline, {})
  if s == nil then return 0 end
  if type(s) ~= "string" then return -1 end
  copyout(buf, cap, s)
  return #s
end

F.posix_fork = function()
  if not P.fork then return -1 end
  local pid, err = pcallr(P.fork)
  if pid == nil then return -1 end
  return toint(pid)
end

F.posix_exec = function(path, argc, argv)
  local args = {}
  for i = 1, (argc or 0) - 1 do
    args[#args + 1] = cstr(R.ld64u(argv + 8 * i))
  end
  local _, err = pcallr(P.exec, cstr(path), args)
  return -1
end

local function spawn_common(path, argc, argv, cwd)
  local args = {}
  for i = 1, (argc or 0) - 1 do
    args[#args + 1] = cstr(R.ld64u(argv + 8 * i))
  end
  local opts = cwd and { cwd = cwd } or nil
  local pid = pcallr(P.spawn, cstr(path), args, opts)
  if pid == nil then return -1 end
  return pid
end

F.posix_spawn = function(path, argc, argv)
  return spawn_common(path, argc, argv, nil)
end

F.posix_spawn_at = function(path, argc, argv, cwd)
  return spawn_common(path, argc, argv, cstr(cwd))
end

local function wait_common(pid, sp, nohang)
  local got, code = pcallr(P.wait, pid, nohang)
  if got == nil then return -1 end
  if got == 0 then return 0 end
  if sp ~= 0 then R.stN(sp, 4, toint(code)) end
  return toint(got)
end

F.posix_wait = function(pid, sp)
  return wait_common(pid, sp, nil)
end

F.posix_waitpid = function(pid, sp, nohang)
  return wait_common(pid, sp, nohang ~= 0 and true or nil)
end

F.posix_kill = function(pid, sig)
  if not P.kill then return -1 end
  local ok = pcallr(P.kill, pid, sig)
  return ok and 0 or -1
end
F.posix_setpgid = function(pid, pgid)
  if not P.setpgid then return -1 end
  local ok = pcallr(P.setpgid, pid, pgid)
  return ok and 0 or -1
end
F.posix_setsid = function()
  if not P.setsid then return -1 end
  local id = pcallr(P.setsid)
  if id == nil then return -1 end
  return toint(id)
end
F.posix_tcsetpgrp = function(pgid)
  if not P.tcsetpgrp then return -1 end
  local ok = pcallr(P.tcsetpgrp, pgid)
  return ok and 0 or -1
end
F.posix_tcgetpgrp = function()
  if not P.tcgetpgrp then return -1 end
  local id = pcallr(P.tcgetpgrp)
  if id == nil then return -1 end
  return toint(id)
end
F.posix_nice = function(n)
  if not P.nice then return -1 end
  local v = pcallr(P.nice, n)
  if v == nil then return -1 end
  return toint(v)
end

F.posix_exit = function(code) return R.F.exit(toint(code)) end
F.posix_time = function() return toint(P.time()) end
F.posix_uptime = function() return toint(P.uptime()) end

local function sleep_common(seconds)
  local f = (S and S.sleep) or (P.sleep)
  if not f then return -1 end
  local ok, err = pcall(f, toint(seconds))
  if not ok then return -1 end
  return 0
end
F.posix_sleep = function(seconds) return sleep_common(seconds) end
F.sys_sleep = F.posix_sleep

F.posix_ttyname = function()
  local n = P.ttyname and pcallr(P.ttyname) or nil
  return newstr(n)
end

local function needterm()
  if not T then error("extern/host.lua: no XesNS `term` table in the environment", 2) end
end

F.term_write   = function(s) needterm(); pcallr(T.write, cstr(s)); return 0 end
F.term_clear   = function() needterm(); pcallr(T.clear); return 0 end
F.term_clearline = function()
  needterm()
  if not T.clearLine then return -1 end
  pcallr(T.clearLine)
  return 0
end
F.term_scroll  = function(n) needterm(); pcallr(T.scroll, n); return 0 end
F.term_setansi = function(on) needterm(); pcallr(T.setAnsi, on ~= 0); return 0 end
F.term_getsize = function(wp, hp)
  needterm()
  local w, h = T.getSize()
  R.stN(wp, 8, toint(w)); R.stN(hp, 8, toint(h))
  return 0
end
F.term_getcursor = function(xp, yp)
  needterm()
  local x, y = T.getCursorPos()
  R.stN(xp, 8, toint(x)); R.stN(yp, 8, toint(y))
  return 0
end
F.term_setcursor = function(x, y) needterm(); pcallr(T.setCursorPos, toint(x), toint(y)); return 0 end
F.term_setcolor = function(r, g, b) needterm(); T.setTextColor(toint(r), toint(g), toint(b)); return 0 end
F.term_setbgcolor = function(r, g, b) needterm(); T.setBackgroundColor(toint(r), toint(g), toint(b)); return 0 end
F.term_getcolor = function(rp, gp, bp)
  needterm()
  local r, g, b = T.getTextColor()
  R.stN(rp, 8, toint(r)); R.stN(gp, 8, toint(g)); R.stN(bp, 8, toint(b))
  return 0
end
F.term_getbgcolor = function(rp, gp, bp)
  needterm()
  if not T.getBackgroundColor then return -1 end
  local r, g, b = T.getBackgroundColor()
  R.stN(rp, 8, toint(r)); R.stN(gp, 8, toint(g)); R.stN(bp, 8, toint(b))
  return 0
end
F.term_scrollview = function(n)
  needterm()
  if not T.scrollView then return -1 end
  local v = pcallr(T.scrollView, toint(n))
  if v == nil then return -1 end
  return toint(v)
end
F.term_getscrollview = function()
  needterm()
  if not T.getScrollView then return -1 end
  return toint(T.getScrollView())
end
F.term_scrollback = function(buf, cap, n)
  needterm()
  if not T.scrollback then return -1 end
  local lines = pcallr(T.scrollback, toint(n))
  if not lines then return -1 end
  if type(lines) == "string" then lines = { lines } end
  return copyoutlist(buf, cap, lines)
end

local function event_vals(ev)
  if ev == nil then return 0 end
  if type(ev) == "string" then return newstr(ev) end
  if type(ev) == "table" then return newstr(tostring(ev[1])) end
  return 0
end

F.event_pull = function(filter, timeout)
  if not E then return 0 end
  local a = pcallr(E.pull, cstr(filter), timeout)
  return event_vals(a)
end
F.event_poll = function()
  if not E then return 0 end
  local a = pcallr(E.poll)
  return event_vals(a)
end
F.event_push = function(name)
  if not E then return -1 end
  local ok = pcallr(E.push, cstr(name))
  return ok ~= nil and 0 or -1
end
F.event_clear = function()
  if not E or not E.clear then return -1 end
  pcallr(E.clear)
  return 0
end

F.sys_getosname = function()
  if not S or not S.getOSName then return 0 end
  return newstr(S.getOSName())
end
F.sys_getosversion = function()
  if not S or not S.getOSVersion then return 0 end
  return newstr(S.getOSVersion())
end
F.sys_hasextension = function(name)
  if not S or not S.hasExtension then return 0 end
  return S.hasExtension(cstr(name)) and 1 or 0
end
F.sys_getextensions = function(buf, cap)
  if not S or not S.getExtensions then return -1 end
  local exts = S.getExtensions()
  local list = {}
  if type(exts) == "table" then
    for k in pairs(exts) do list[#list + 1] = tostring(k) end
    table.sort(list)
  end
  return copyoutlist(buf, cap, list)
end

local function needfs()
  if not FST then error("extern/host.lua: no XesNS `fs` table in the environment", 2) end
end

F.fs_exists = function(path) needfs(); return FST.exists(cstr(path)) and 1 or 0 end
F.fs_isfile = function(path) needfs(); return FST.isFile(cstr(path)) and 1 or 0 end
F.fs_isdir  = function(path) needfs(); return FST.isDir(cstr(path)) and 1 or 0 end
F.fs_list = function(path, buf, cap)
  needfs()
  local list = pcallr(FST.list, cstr(path))
  if not list then return -1 end
  return copyoutlist(buf, cap, list)
end
F.fs_makedir = function(path)
  needfs()
  local ok = pcallr(FST.makeDir, cstr(path))
  return ok and 0 or -1
end
F.fs_delete = function(path)
  needfs()
  local ok = pcallr(FST.delete, cstr(path))
  return ok and 0 or -1
end
F.fs_resolve = function(path, buf, cap)
  needfs()
  local s = pcallr(FST.resolve, cstr(path))
  if type(s) ~= "string" then return -1 end
  return copyout(buf, cap, s)
end
F.fs_getdisks = function(buf, cap)
  needfs()
  if not FST.getDisks then return -1 end
  local ds = pcallr(FST.getDisks)
  if not ds then return -1 end
  local list = {}
  for _, d in ipairs(ds) do
    if type(d) == "table" then list[#list + 1] = tostring(d.slot or d.id or "?")
    else list[#list + 1] = tostring(d) end
  end
  return copyoutlist(buf, cap, list)
end
F.fs_getpartitions = function(disk, buf, cap)
  needfs()
  if not FST.getPartitions then return -1 end
  local arg = tonumber(cstr(disk)) or cstr(disk)
  local ps = pcallr(FST.getPartitions, arg)
  if not ps then return -1 end
  local list = {}
  for _, p in ipairs(ps) do
    if type(p) == "table" then list[#list + 1] = tostring(p.name or p[1] or "?")
    else list[#list + 1] = tostring(p) end
  end
  return copyoutlist(buf, cap, list)
end

F.dpp_listen = function(port)
  if not DPP then return -1 end
  local ok = pcallr(DPP.listen, port)
  return ok and 0 or -1
end
F.dpp_unlisten = function(port)
  if not DPP then return -1 end
  local ok = pcallr(DPP.unlisten, port)
  return ok and 0 or -1
end
F.dpp_send = function(target, payload, source)
  if not DPP then return -1 end
  local ok = pcallr(DPP.send, target, cstr(payload) or "", source)
  return ok and 0 or -1
end

local spp_handles, spp_next = {}, 1
local function spp_reg(h)
  local id = spp_next
  spp_next = spp_next + 1
  spp_handles[id] = h
  return id
end
local function spp_get(id) return spp_handles[id] end
F.spp_listen = function(port)
  if not SPP then return -1 end
  local h = pcallr(SPP.listen, port)
  if h == nil then return -1 end
  if type(h) ~= "table" then return 0 end
  return spp_reg(h)
end
F.spp_connect = function(port)
  if not SPP then return -1 end
  local h = pcallr(SPP.connect, port)
  if type(h) ~= "table" then return -1 end
  return spp_reg(h)
end
F.spp_accept = function(listener, timeout)
  local l = spp_get(listener)
  if not l then return -1 end
  local h = pcallr(l.accept, l, timeout ~= 0 and timeout or nil)
  if type(h) ~= "table" then return -1 end
  return spp_reg(h)
end
F.spp_send = function(handle, payload, timeout)
  local h = spp_get(handle)
  if not h then return -1 end
  local ok = pcallr(h.send, h, cstr(payload) or "", timeout ~= 0 and timeout or nil)
  return ok and 0 or -1
end
F.spp_recv = function(handle, buf, cap, timeout)
  local h = spp_get(handle)
  if not h then return -1 end
  local s = pcallr(h.recv, h, (timeout ~= nil and timeout ~= 0) and timeout or nil)
  if s == nil then return 0 end
  if type(s) ~= "string" then return 0 end
  if not cap or cap <= 0 then return #s end
  copyout(buf, cap, s)
  return #s
end
F.spp_close = function(handle)
  local h = spp_get(handle)
  if not h then return -1 end
  spp_handles[handle] = nil
  pcallr(h.close, h)
  return 0
end

return F

end

local rt = __runtime()

local M = {}
M._VERSION = "1"
M.backend = "xesns"
M.libname = "qbe_rt"

function M.run(prog, args, penv, out)
  penv = penv or __penv
  assert(type(prog) == "function", "qbe_rt.run needs a program chunk")
  if out == nil then out = M.defaultout(penv) end
  local R = rt.new{ globals = penv, out = out }
  R:extern(__host)
  prog(R)
  return R:run(args)
end

function M.defaultout(penv)
  local P = penv.posix
  assert(P, "qbe_rt: no `posix` table in the program environment")
  return {
    setvbuf = function() end,
    flush = function() end,
    write = function(_, ...) P.write(1, table.concat({ ... })); return true end,
  }
end

return M
