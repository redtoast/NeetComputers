local K, API, X = ...

local T = {}

local hostEvent = rawget(_G, "event")
local PUMP = type(hostEvent) == "table" and type(hostEvent.getQueue) == "function"

local unpack = table.unpack

local OVERLAP = {
	key = true,
	key_up = true,
	char = true,
	paste = true,
}

local function singleChar(s)
	local lead = s:byte(1)
	if not lead then
		return false
	end
	local len
	if lead < 0x80 then
		len = 1
	elseif lead >= 0xC2 and lead <= 0xDF then
		len = 2
	elseif lead >= 0xE0 and lead <= 0xEF then
		len = 3
	elseif lead >= 0xF0 and lead <= 0xF4 then
		len = 4
	else
		return false
	end
	if #s ~= len then
		return false
	end
	for i = 2, len do
		local b = s:byte(i)
		if b < 0x80 or b > 0xBF then
			return false
		end
	end
	return true
end

local function onCompat(e)
	if not PUMP or type(e) ~= "table" then
		return
	end
	local name = e[1]
	if type(name) ~= "string" or name == "" then
		return
	end
	local n = #e

	if OVERLAP[name] then
		if name == "paste" then
			local text = e[2]
			if n == 2 and type(text) == "string" and singleChar(text) then
				K.input("char", text)
			end
		end
		return
	end

	K.input("compat_" .. name, unpack(e, 2, n))
end

T.__eventonly = true

if PUMP then
	T.__ext = { ["ext.compat"] = 1 }
	T.__hooks = { compatibility = onCompat }
end

return T
