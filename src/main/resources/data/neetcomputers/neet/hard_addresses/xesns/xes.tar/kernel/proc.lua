local K = ...

K.procs = {}
K.nextpid = 1
K.current = nil
K.rootdir = K.path.join(K.root.id, K.root.part, "/", true)

K.PREEMPT          = setmetatable({}, { __tostring = function() return "<preempt>" end })
K.BLOCK            = setmetatable({}, { __tostring = function() return "<block>" end })
K.EXIT             = setmetatable({}, { __tostring = function() return "<exit>" end })

local WHITE, BLACK = K.WHITE, K.BLACK
local EVQ_MAX      = 256

function K.nprocs()
    local n = 0
    for _ in pairs(K.procs) do n = n + 1 end
    return n
end

function K.nrunning()
    local n = 0
    for _, p in pairs(K.procs) do if p.state == "R" then n = n + 1 end end
    return n
end

K.maxproc = 512
K.maxprocperuid = 128
function K.procLimitOk(uid)
    local total, mine = 0, 0
    for _, q in pairs(K.procs) do
        if q.state ~= "Z" then
            total = total + 1
            if q.uid == uid then mine = mine + 1 end
        end
    end
    if total >= K.maxproc then return false end
    return uid == 0 or mine < K.maxprocperuid
end

function K.pgidAllowed(me, pgid)
    if me.uid == 0 then return true end
    for _, q in pairs(K.procs) do
        if q.pgid == pgid and q.state ~= "Z" and q.sid == me.sid and q.uid == me.uid then return true end
    end
    return false
end

function K.newproc(parent, name)
    local pid = K.nextpid
    K.nextpid = pid + 1
    local p = {
        pid = pid,
        ppid = parent and parent.pid or 0,
        pgid = parent and parent.pgid or pid,
        sid = parent and parent.sid or pid,
        uid = parent and parent.uid or 0,
        gid = parent and parent.gid or 0,
        groups = parent and parent.groups or {},
        name = name or "?",
        args = {},
        cwd = parent and parent.cwd or K.rootdir,
        launchcwd = parent and parent.cwd or K.rootdir,
        home = parent and parent.home or "/root",
        tty = parent and parent.tty or K.nulltty,
        state = "R",
        fds = {},
        handles = {},
        ports = {},
        env = {},
        children = {},
        evq = {},
        eh = 1,
        et = 0,
        nice = parent and parent.nice or 0,
        slices = 0,
        cputime = 0,
        started = K.now(),
        critical = 0,
        fg = WHITE,
        bg = BLACK,
        umask = parent and parent.umask or 18,
    }
    if parent then
        for k, v in pairs(parent.env) do p.env[k] = v end
        parent.children[pid] = true
    end
    K.procs[pid] = p
    return p
end

function K.pushEvent(p, name, ...)
    if p.state == "Z" then return false end
    if p.et - p.eh + 1 >= EVQ_MAX then return false end
    p.et = p.et + 1
    p.evq[p.et] = table.pack(name, ...)
    return true
end

function K.block(p, waitfn, deadline)
    if p.dying then error(K.EXIT, 0) end
    if not coroutine.isyieldable() then error("cannot block in this context", 2) end
    p.state, p.waitfn, p.deadline = "S", waitfn, deadline
    coroutine.yield(K.BLOCK)
    p.state, p.waitfn, p.deadline = "R", nil, nil
    if p.dying then error(K.EXIT, 0) end
end

local function scan(p, filter)
    p.critical = p.critical + 1
    local found
    while p.eh <= p.et do
        local e = p.evq[p.eh]
        p.evq[p.eh] = nil
        p.eh = p.eh + 1
        if not filter or e[1] == filter then
            if e[1] == "terminate" then p.termAsked = nil end
            found = e
            break
        end
    end
    if p.eh > p.et then p.eh, p.et = 1, 0 end
    p.critical = p.critical - 1
    return found
end

function K.evpull(p, filter, timeout)
    local deadline = timeout and (K.now() + timeout) or nil
    while true do
        local e = scan(p, filter)
        if e then return table.unpack(e, 1, e.n) end
        if deadline and K.now() >= deadline then return nil end
        K.block(p, function() return p.eh <= p.et end, deadline)
    end
end

function K.evpoll(p)
    local e = scan(p, nil)
    if not e then return nil end
    return table.unpack(e, 1, e.n)
end

function K.evclear(p)
    p.evq, p.eh, p.et = {}, 1, 0
    p.termAsked = nil
end

function K.tty_input(t, name, ...)
    if not t then return end
    if name == "key" then K.crypto.entropy_add("key", ...) end
    if not t.fgpgid then
        if name == "key" or name == "key_up" or name == "char" then
            t.pending = t.pending or {}
            if #t.pending < 512 then t.pending[#t.pending + 1] = table.pack(name, ...) end
        end
        return
    end
    for _, p in pairs(K.procs) do
        if p.pgid == t.fgpgid and p.tty == t and p.state ~= "Z" then
            K.pushEvent(p, name, ...)
        end
    end
end

function K.input(name, ...)
    K.tty_input(K.tty_active, name, ...)
end

K.SIG = {
    HUP = 1,
    INT = 2,
    QUIT = 3,
    KILL = 9,
    USR1 = 10,
    USR2 = 12,
    PIPE = 13,
    TERM = 15,
    CHLD = 20,
    CONT = 19,
    STOP = 17
}
K.SIGNAME = {}
for n, v in pairs(K.SIG) do K.SIGNAME[v] = n end

function K.signal(p, sig)
    if p.state == "Z" then return false end
    if sig == 0 then return true end
    if sig == K.SIG.KILL or sig == K.SIG.QUIT then
        p.killed = 128 + sig
        p.dying = true
        p.wakeup = true
    elseif sig == K.SIG.INT or sig == K.SIG.TERM or sig == K.SIG.HUP then
        K.pushEvent(p, "terminate")
        p.termAsked = p.termAsked or K.now()
        p.termSig = sig
    elseif sig == K.SIG.STOP then
        p.state, p.waitfn, p.deadline, p.wakeup = "T", nil, nil, nil
    elseif sig == K.SIG.CONT then
        if p.state == "T" then p.state = "R" end
        p.wakeup = true
        K.pushEvent(p, "x.signal", sig)
    elseif sig == K.SIG.CHLD then
        p.wakeup = true
    elseif sig == K.SIG.STOP then
        if p.state ~= "T" then p.state = "T" end
        p.waitfn, p.deadline, p.wakeup = nil, nil, nil
        K.pushEvent(p, "x.signal", sig)
    elseif sig == K.SIG.CONT then
        if p.state == "T" then p.state = "R" end
        p.wakeup = true
        K.pushEvent(p, "x.signal", sig)
    else
        K.pushEvent(p, "x.signal", sig)
    end
    return true
end

function K.tty_deliverPending(t)
    local keep = t.pending
    if not keep or #keep == 0 or not t.fgpgid then return end
    t.pending = {}
    for _, p in pairs(K.procs) do
        if p.pgid == t.fgpgid and p.tty == t and p.state ~= "Z" then
            for _, e in ipairs(keep) do K.pushEvent(p, table.unpack(e, 1, e.n)) end
        end
    end
end

function K.interrupt(quit)
    local t = K.tty_active
    if not t or not t.fgpgid then return end
    for _, p in pairs(K.procs) do
        if p.pgid == t.fgpgid and p.tty == t then
            K.signal(p, quit and K.SIG.QUIT or K.SIG.INT)
        end
    end
end

local function newfd(kind, t)
    t.kind, t.refs = kind, 1
    return t
end

function K.fdref(o)
    o.refs = o.refs + 1
    return o
end

function K.fdclose(o)
    o.refs = o.refs - 1
    if o.refs == 0 and o.onclose then o:onclose() end
end

function K.fdalloc(p, obj, min)
    local n = min or 0
    while p.fds[n] do n = n + 1 end
    p.fds[n] = obj
    return n
end

function K.fdget(p, n)
    local o = p.fds[n]
    if not o then return nil, "bad file descriptor" end
    return o
end

function K.fdcloseNum(p, n)
    local o = p.fds[n]
    if not o then return nil, "bad file descriptor" end
    p.fds[n] = nil
    K.fdclose(o)
    return true
end

function K.ttyfd(t)
    local o = newfd("tty", { tty = t })
    function o:read(fmt) return K.ttyread(self.tty, fmt) end

    function o:write(s)
        local p = K.current
        self.tty:printText(s, p and p.fg or WHITE, p and p.bg or BLACK, false)
        return true
    end

    function o:isatty() return true end

    return o
end

function K.filefd(h)
    local o = newfd("file", { h = h })
    function o:read(fmt) return self.h:read(fmt) end

    function o:write(s) return self.h:write(s) end

    function o:seek(w, off) return self.h:seek(w, off) end

    function o:isatty() return false end

    function o:onclose() self.h:close() end

    return o
end

local PIPE_LIMIT = 8192
function K.pipe()
    local st = { buf = "", off = 0, readers = 1, writers = 1 }
    local function avail() return #st.buf - st.off end
    local function take(n)
        local s = st.buf:sub(st.off + 1, st.off + n)
        st.off = st.off + #s
        if st.off > 4096 or st.off == #st.buf then
            st.buf, st.off = st.buf:sub(st.off + 1), 0
        end
        return s
    end
    local r = newfd("pipe", {})
    function r:read(fmt)
        local p = K.current
        fmt = fmt or "l"
        if type(fmt) == "number" then
            while avail() == 0 and st.writers > 0 do
                K.block(p, function() return avail() > 0 or st.writers == 0 end)
            end
            if avail() == 0 then return nil end
            return take(math.floor(fmt))
        elseif fmt == "a" then
            while st.writers > 0 do K.block(p, function() return st.writers == 0 end) end
            return take(avail())
        elseif fmt == "l" then
            while true do
                local nl = st.buf:find("\n", st.off + 1, true)
                if nl then
                    local line = st.buf:sub(st.off + 1, nl - 1)
                    st.off = nl
                    if st.off == #st.buf then st.buf, st.off = "", 0 end
                    return line
                end
                if st.writers == 0 then
                    if avail() == 0 then return nil end
                    return take(avail())
                end
                K.block(p, function() return st.writers == 0 or st.buf:find("\n", st.off + 1, true) ~= nil end)
            end
        end
        return nil, "invalid format"
    end

    function r:isatty() return false end

    function r:onclose() st.readers = st.readers - 1 end

    local w = newfd("pipe", {})
    function w:write(s)
        if st.readers == 0 then return nil, "broken pipe" end
        st.buf = st.buf .. s
        local p = K.current
        while avail() > PIPE_LIMIT and st.readers > 0 do
            K.block(p, function() return avail() <= PIPE_LIMIT or st.readers == 0 end)
        end
        return true
    end

    function w:isatty() return false end

    function w:onclose() st.writers = st.writers - 1 end

    return r, w
end

function K.releaseProc(p)
    if K.kbd and type(K.kbd.release) == "function" then K.kbd.release(p.pid) end
    if K.gfx == p then K.gfx, p.gfx = nil, nil; K.tty_dirty = true end
    if K.extrattys then
        for id, t in pairs(K.extrattys) do
            if t.owner == p.pid then K.extrattys[id] = nil end
        end
    end
    for n, o in pairs(p.fds) do
        p.fds[n] = nil; K.fdclose(o)
    end
    for h in pairs(p.handles) do pcall(h.close, h) end
    p.handles = {}
    if K.dpp_release then K.dpp_release(p) end
    if K.spp_release then K.spp_release(p) end

    for cpid in pairs(p.children) do
        local c = K.procs[cpid]
        if c then
            c.ppid = 1
            local init = K.procs[1]
            if init and init ~= p then init.children[cpid] = true end
        end
    end
    p.children = {}
    local t = p.tty
    if t and t.fgpgid == p.pgid then
        local alive = false
        for _, q in pairs(K.procs) do
            if q ~= p and q.pgid == p.pgid and q.state ~= "Z" then
                alive = true
                break
            end
        end
        if not alive then
            local keep = t.pending or {}
            for i = p.eh, p.et do
                local e = p.evq[i]
                if e and (e[1] == "key" or e[1] == "key_up" or e[1] == "char") and #keep < 512 then keep[#keep + 1] = e end
            end
            t.pending = keep
            t.fgpgid = nil
        end
    end
end

local avg = { 0, 0, 0 }
local lastSample = K.now()
function K.sampleLoad()
    local now = K.now()
    local dt = now - lastSample
    if dt < 1 then return end
    lastSample = now
    local n = K.nrunning()
    local f = { 60, 300, 900 }
    for i = 1, 3 do
        local e = math.exp(-dt / f[i])
        avg[i] = avg[i] * e + n * (1 - e)
    end
end

function K.loadavg() return avg[1], avg[2], avg[3] end
