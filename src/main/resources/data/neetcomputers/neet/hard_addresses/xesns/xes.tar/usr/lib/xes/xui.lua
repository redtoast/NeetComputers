local xd = posix.loadlib("xd")

local M = {}

M.gray = 0xB0B0B0
M.face = 0xB0B0B0
M.light = 0xE8E8E8
M.hi = 0xE8E8E8
M.lo = 0x606060
M.paper = 0xFFFFFF
M.sunken = 0xE8E8E8
M.ink = 0x000000
M.selbg = 0x3050A0
M.selfg = 0xFFFFFF

local App = {}
App.__index = App
M.App = App

local function bevel(c, win, x, y, w, h, face, hi, lo)
    c:fill(win, x, y, w, h, face)
    c:fill(win, x, y, w, 1, hi)
    c:fill(win, x, y, 1, h, hi)
    c:fill(win, x, y + h - 1, w, 1, lo)
    c:fill(win, x + w - 1, y, 1, h, lo)
end

M.bevel = bevel

local function parse_anchor(a)
    if a == nil then return { left = true, top = true } end
    if type(a) == "string" then
        if a == "all" then
            return { left = true, top = true, right = true, bottom = true }
        elseif a == "top" then
            return { left = true, top = true, right = true }
        elseif a == "bottom" then
            return { left = true, bottom = true, right = true }
        elseif a == "left" then
            return { left = true, top = true, bottom = true }
        elseif a == "right" then
            return { top = true, bottom = true, right = true }
        elseif a == "tl" then
            return { left = true, top = true }
        elseif a == "tr" then
            return { top = true, right = true }
        elseif a == "bl" then
            return { bottom = true, left = true }
        elseif a == "br" then
            return { bottom = true, right = true }
        else
            return { left = true, top = true }
        end
    end
    if type(a) == "table" then
        return {
            left = a.left and true or false,
            top = a.top and true or false,
            right = a.right and true or false,
            bottom = a.bottom and true or false,
        }
    end
    return { left = true, top = true }
end

M.parse_anchor = parse_anchor

local function track(app, w, opts)
    w._anchor = parse_anchor(opts and opts.anchor)
    w._l = w.x or 0
    w._t = w.y or 0
    w._r = app.W - ((w.x or 0) + (w.w or 0))
    w._b = app.H - ((w.y or 0) + (w.h or 0))
    return w
end

function M.App(opts)
    opts = opts or {}
    local client, err = xd.connect({ name = opts.name or "xui" })
    if not client then return nil, err end
    local win, werr = client:window({
        w = opts.w or 320,
        h = opts.h or 200,
        title = opts.title or opts.name or "xui",
        kind = opts.kind,
        x = opts.x,
        y = opts.y,
    })
    if not win then
        client:close()
        return nil, werr
    end
    local self = setmetatable({
        client = client,
        win = win,
        W = opts.w or 320,
        H = opts.h or 200,
        bg = opts.bg or M.gray,
        widgets = {},
        keyhandler = nil,
        quit = false,
        focus = nil,
        grab = nil,
        cw = client.font.w,
        ch = client.font.h,
    }, App)
    client:map(win)
    return self
end

function App:close()
    if self.client then
        pcall(function() self.client:close() end)
        self.client = nil
    end
end

function App:dirty(w)
    if w then
        w.dirty = true
    else
        for _, wid in ipairs(self.widgets) do wid.dirty = true end
        self.bgdirty = true
    end
end

function App:dirtyAll() self:dirty(nil) end

function App:set_anchor(w, anchor)
    w._anchor = parse_anchor(anchor)
    w._l = w.x or 0
    w._t = w.y or 0
    w._r = self.W - ((w.x or 0) + (w.w or 0))
    w._b = self.H - ((w.y or 0) + (w.h or 0))
end

function App:apply_anchors()
    for _, w in ipairs(self.widgets) do
        local a = w._anchor or { left = true, top = true }
        if w.x ~= nil and w.w ~= nil then
            local l, t, r, b = w._l or w.x, w._t or w.y,
                w._r or 0, w._b or 0
            if a.left and a.right then
                w.x = l
                w.w = math.max(4, self.W - l - r)
            elseif a.right and not a.left then
                w.x = self.W - r - w.w
            else
                w.x = l
            end
            if w.y ~= nil and w.h ~= nil then
                if a.top and a.bottom then
                    w.y = t
                    w.h = math.max(4, self.H - t - b)
                elseif a.bottom and not a.top then
                    w.y = self.H - b - (w.h or 0)
                else
                    w.y = t
                end
            end
            w.dirty = true
        end
    end
    self.bgdirty = true
end

function App:onresize(fn)
    self.resize_handler = fn
end

function App:handle_configure(m)
    if type(m) ~= "table" then return false end
    local w, h = m.w, m.h
    if type(w) ~= "number" or type(h) ~= "number" then return false end
    if w < 1 or h < 1 then return false end
    w, h = math.floor(w), math.floor(h)
    if w == self.W and h == self.H then return false end
    self.W, self.H = w, h
    self:apply_anchors()
    if self.resize_handler then
        pcall(self.resize_handler, w, h)
    end
    self:dirtyAll()
    return true
end

function App:label(opts)
    local w = {
        kind = "label",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 28,
        text = opts.text or "",
        align = opts.align or "left",
        fg = opts.fg or M.ink,
        bg = opts.bg or M.sunken,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:button(opts)
    local w = {
        kind = "button",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h,
        label = opts.label or "?",
        onpress = opts.onpress,
        pressed = false,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:textbox(opts)
    local w = {
        kind = "textbox",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 24,
        text = opts.text or "",
        cursor = #(opts.text or "") + 1,
        scroll = 1,
        onenter = opts.onenter,
        onchange = opts.onchange,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:checkbox(opts)
    local w = {
        kind = "checkbox",
        x = opts.x,
        y = opts.y,
        w = opts.w or ((#(opts.label or "") + 4) * 6 + 20),
        h = opts.h or 20,
        label = opts.label or "",
        value = opts.value and true or false,
        onchange = opts.onchange,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:listbox(opts)
    local w = {
        kind = "listbox",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h,
        items = opts.items or {},
        selected = opts.selected or 0,
        top = 1,
        onselect = opts.onselect,
        ondouble = opts.ondouble,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:slider(opts)
    local w = {
        kind = "slider",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 24,
        min = opts.min or 0,
        max = opts.max == nil and 100 or opts.max,
        value = opts.value or 0,
        onchange = opts.onchange,
        dirty = true,
    }
    if w.max < w.min then w.min, w.max = w.max, w.min end
    w.value = math.min(math.max(w.value, w.min), w.max)
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:progress(opts)
    local w = {
        kind = "progress",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 20,
        frac = math.min(math.max(opts.frac or 0, 0), 1),
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:frame(opts)
    local w = {
        kind = "frame",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h,
        title = opts.title or "",
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:separator(opts)
    local w = {
        kind = "separator",
        x = opts.x,
        y = opts.y,
        w = opts.w or 6,
        h = opts.h or 6,
        vertical = opts.vertical and true or false,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:radio(opts)
    local w = {
        kind = "radio",
        x = opts.x,
        y = opts.y,
        w = opts.w or ((#(opts.label or "") + 4) * self.cw + 20),
        h = opts.h or 20,
        label = opts.label or "",
        group = opts.group or "__default__",
        value = opts.value and true or false,
        onchange = opts.onchange,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:dropdown(opts)
    local w = {
        kind = "dropdown",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 24,
        items = opts.items or {},
        selected = opts.selected or 0,
        top = 1,
        open = false,
        onselect = opts.onselect,
        dirty = true,
    }
    if w.selected < 0 or w.selected > #w.items then w.selected = 0 end
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:menubutton(opts)
    local w = {
        kind = "menubutton",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 24,
        label = opts.label or "?",
        items = opts.items or {},
        selected = 0,
        top = 1,
        open = false,
        onselect = opts.onselect,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:menubar_layout(x, y, h, buttons)
    local cx = x
    for _, b in ipairs(buttons) do
        b.x, b.y, b.h = cx, y, h
        b.dirty = true
        cx = cx + (b.w or 0) + 2
    end
    return buttons
end

function App:spinbox(opts)
    local w = {
        kind = "spinbox",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h or 24,
        min = opts.min or 0,
        max = opts.max == nil and 100 or opts.max,
        step = opts.step or 1,
        value = opts.value or 0,
        onchange = opts.onchange,
        dirty = true,
    }
    if w.max < w.min then w.min, w.max = w.max, w.min end
    if w.step <= 0 then w.step = 1 end
    w.value = math.min(math.max(w.value, w.min), w.max)
    w.value = self:spin_round(w, w.value)
    w.text = self:spin_format(w, w.value)
    w.cursor = #w.text + 1
    w.scroll = 1
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:scrollbar(opts)
    local w = {
        kind = "scrollbar",
        x = opts.x,
        y = opts.y,
        w = opts.w or 16,
        h = opts.h,
        total = opts.total or 0,
        visible = opts.visible or 1,
        first = opts.first or 1,
        grab = nil,
        onchange = opts.onchange,
        dirty = true,
    }
    if w.visible < 1 then w.visible = 1 end
    if w.total < 0 then w.total = 0 end
    w.first = self:scroll_clamp(w, w.first)
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:canvas(opts)
    local w = {
        kind = "canvas",
        x = opts.x,
        y = opts.y,
        w = opts.w,
        h = opts.h,
        bg = opts.bg or M.paper,
        ondraw = opts.ondraw,
        onmouse = opts.onmouse,
        onscroll = opts.onscroll,
        dirty = true,
    }
    track(self, w, opts)
    self.widgets[#self.widgets + 1] = w
    return w
end

function App:settext(w, text)
    text = text or ""
    if w.text ~= text then
        w.text = text
        if w.kind == "textbox" then
            w.cursor = math.min(w.cursor, #text + 1)
            self:ensure_cursor(w)
        end
        w.dirty = true
    end
end

function App:set_checkbox(w, value)
    value = value and true or false
    if w.value ~= value then
        w.value = value
        w.dirty = true
        if w.onchange then w.onchange(w, value) end
    end
end

function App:setfrac(w, frac)
    frac = math.min(math.max(frac or 0, 0), 1)
    if w.frac ~= frac then
        w.frac = frac
        w.dirty = true
    end
end

function App:setitems(w, items)
    w.items = items or {}
    w.selected = 0
    w.top = 1
    w.dirty = true
end

function App:select(w, idx)
    idx = math.min(math.max(idx or 0, 0), #w.items)
    if w.selected ~= idx then
        w.selected = idx
        self:ensure_visible(w)
        w.dirty = true
        if idx > 0 and w.onselect then w.onselect(w, idx) end
    end
end

function App:set_slider(w, value)
    value = math.min(math.max(value, w.min), w.max)
    if w.min % 1 == 0 and w.max % 1 == 0 then value = math.floor(value + 0.5) end
    if w.value ~= value then
        w.value = value
        w.dirty = true
        if w.onchange then w.onchange(w, value) end
    end
end

function App:set_radio(w, value)
    value = value and true or false
    if value then
        for _, o in ipairs(self.widgets) do
            if o.kind == "radio" and o.group == w.group and o ~= w and o.value then
                o.value = false
                o.dirty = true
                if o.onchange then o.onchange(o, false) end
            end
        end
    end
    if w.value ~= value then
        w.value = value
        w.dirty = true
        if w.onchange then w.onchange(w, value) end
    end
end

function App:radio_step(w, dir)
    local group = {}
    for _, o in ipairs(self.widgets) do
        if o.kind == "radio" and o.group == w.group then group[#group + 1] = o end
    end
    if #group == 0 then return end
    local i = 1
    for k, o in ipairs(group) do
        if o == w then
            i = k; break
        end
    end
    i = (i - 1 + dir) % #group + 1
    self.focus = group[i]
    self:set_radio(group[i], true)
end

function App:spin_round(w, value)
    if w.min % 1 == 0 and w.max % 1 == 0 and w.step % 1 == 0 then
        value = math.floor(value + 0.5)
    end
    return math.min(math.max(value, w.min), w.max)
end

function App:spin_format(w, value)
    if w.min % 1 == 0 and w.max % 1 == 0 and w.step % 1 == 0 then
        return string.format("%d", value)
    end
    return string.format("%.10g", value)
end

function App:spin_commit(w)
    local v = tonumber(w.text)
    if v == nil then
        w.text = self:spin_format(w, w.value)
        w.cursor = #w.text + 1
        w.dirty = true
        return
    end
    v = self:spin_round(w, v)
    if v ~= w.value then
        w.value = v
        if w.onchange then w.onchange(w, v) end
    end
    w.text = self:spin_format(w, w.value)
    w.cursor = #w.text + 1
    w.dirty = true
end

function App:set_spin(w, value)
    value = self:spin_round(w, value)
    if w.value ~= value then
        w.value = value
        if w.onchange then w.onchange(w, value) end
    end
    local text = self:spin_format(w, w.value)
    if w.text ~= text then
        w.text = text
        w.cursor = #text + 1
    end
    w.dirty = true
end

function App:spin_step(w, dir)
    self:spin_commit(w)
    self:set_spin(w, w.value + dir * w.step)
end

function App:scroll_maxfirst(w)
    return math.max(1, w.total - w.visible + 1)
end

function App:scroll_clamp(w, first)
    return math.min(math.max(first or 1, 1), self:scroll_maxfirst(w))
end

function App:set_scroll(w, first, visible, total)
    if total ~= nil then w.total = math.max(0, total) end
    if visible ~= nil then w.visible = math.max(1, visible) end
    first = self:scroll_clamp(w, first)
    if w.first ~= first then
        w.first = first
        w.dirty = true
        if w.onchange then w.onchange(w, first) end
    else
        w.dirty = true
    end
end

function App:onkey(fn)
    self.keyhandler = fn
end

function App:onclose(fn)
    self.closehandler = fn
end

function App:onrightclick(fn)
    self.rightclick = fn
end

function App:ontick(secs, fn)
    self.tick_secs = (type(secs) == "number" and secs > 0) and secs or 2
    self.tick_fn = fn
    self.tick_last = nil
    self.tick_count = 0
end

function App:row_height() return self.ch + 4 end

function App:visible_rows(w)
    if w.kind == "dropdown" then return self:dropdown_prows(w) end
    if w.kind == "menubutton" then return self:menu_prows(w) end
    return math.max(1, (w.h - 4) // self:row_height())
end

function App:ensure_visible(w)
    if w.kind == "dropdown" then
        self:dropdown_top(w)
        return
    end
    if w.kind == "menubutton" then
        self:menu_top(w)
        return
    end
    local rows = self:visible_rows(w)
    if w.selected < w.top then w.top = w.selected end
    if w.selected > w.top + rows - 1 then w.top = w.selected - rows + 1 end
    if w.top < 1 then w.top = 1 end
end

function App:row_at(w, px, py)
    local y0 = w.y + 2
    if px < w.x or px >= w.x + w.w or py < y0 then return nil end
    local i = (py - y0) // self:row_height()
    if i < 0 or i >= self:visible_rows(w) then return nil end
    local idx = w.top + i
    if idx < 1 or idx > #w.items then return nil end
    return idx
end

function App:ensure_cursor(w)
    local maxn = math.max(1, (w.w - 10) // self.cw)
    if w.cursor < w.scroll then w.scroll = w.cursor end
    if w.cursor > w.scroll + maxn - 1 then w.scroll = w.cursor - maxn + 1 end
    if w.scroll < 1 then w.scroll = 1 end
    w.cursor = math.min(math.max(w.cursor, 1), #w.text + 1)
end

function App:ensure_spin_cursor(w)
    local maxn = math.max(1, (w.w - 2 * self:spin_btn() - 10) // self.cw)
    if w.cursor < w.scroll then w.scroll = w.cursor end
    if w.cursor > w.scroll + maxn - 1 then w.scroll = w.cursor - maxn + 1 end
    if w.scroll < 1 then w.scroll = 1 end
    w.cursor = math.min(math.max(w.cursor, 1), #w.text + 1)
end

function App:spin_btn() return 18 end

function App:drop_btn() return 18 end

function App:dropdown_prows(w)
    local below = (self.H - (w.y + w.h) - 2) // self:row_height()
    local above = (w.y - 2) // self:row_height()
    local room = math.max(below, above)
    return math.min(math.max(#w.items, 1), 8, math.max(room, 1))
end

function App:dropdown_popup(w)
    local rows = self:dropdown_prows(w)
    local h = rows * self:row_height() + 4
    local y = w.y + w.h + 1
    if y + h > self.H - 1 and w.y - 1 - h >= 0 then y = w.y - 1 - h end
    return w.x, y, w.w, h, rows
end

function App:dropdown_top(w)
    local _, _, _, _, rows = self:dropdown_popup(w)
    if w.selected > 0 then
        if w.selected < w.top then w.top = w.selected end
        if w.selected > w.top + rows - 1 then w.top = w.selected - rows + 1 end
    end
    if w.top < 1 then w.top = 1 end
    local maxfirst = math.max(1, #w.items - rows + 1)
    if w.top > maxfirst then w.top = maxfirst end
end

function App:dropdown_row_at(w, px, py)
    local x, y, pw, ph, rows = self:dropdown_popup(w)
    if px < x or px >= x + pw or py < y + 2 then return nil end
    local i = (py - (y + 2)) // self:row_height()
    if i < 0 or i >= rows then return nil end
    local idx = w.top + i
    if idx < 1 or idx > #w.items then return nil end
    return idx
end

function App:menu_prows(w)
    local below = (self.H - (w.y + w.h) - 2) // self:row_height()
    local above = (w.y - 2) // self:row_height()
    local room = math.max(below, above)
    return math.min(math.max(#w.items, 1), 8, math.max(room, 1))
end

function App:menu_popup(w)
    local rows = self:menu_prows(w)
    local h = rows * self:row_height() + 4
    local y = w.y + w.h + 1
    if y + h > self.H - 1 and w.y - 1 - h >= 0 then y = w.y - 1 - h end
    return w.x, y, w.w, h, rows
end

function App:menu_top(w)
    local _, _, _, _, rows = self:menu_popup(w)
    if w.selected > 0 then
        if w.selected < w.top then w.top = w.selected end
        if w.selected > w.top + rows - 1 then w.top = w.selected - rows + 1 end
    end
    if w.top < 1 then w.top = 1 end
    local maxfirst = math.max(1, #w.items - rows + 1)
    if w.top > maxfirst then w.top = maxfirst end
end

function App:menu_row_at(w, px, py)
    local x, y, pw, ph, rows = self:menu_popup(w)
    if px < x or px >= x + pw or py < y + 2 then return nil end
    local i = (py - (y + 2)) // self:row_height()
    if i < 0 or i >= rows then return nil end
    local idx = w.top + i
    if idx < 1 or idx > #w.items then return nil end
    return idx
end

function App:menu_highlight(w, idx)
    idx = math.min(math.max(idx or 0, 0), #w.items)
    if w.selected ~= idx then
        w.selected = idx
        self:menu_top(w)
        w.dirty = true
    end
end

function App:close_dropdowns(except)
    local closed = false
    for _, o in ipairs(self.widgets) do
        if (o.kind == "dropdown" or o.kind == "menubutton")
            and o.open and o ~= except then
            o.open = false
            closed = true
            if o.kind == "menubutton" then
                o.selected = 0
                o.top = 1
            end
        end
    end

    if closed then self:dirtyAll() end
end

function App:set_dropdown(w, open)
    open = open and true or false
    if w.open ~= open then
        w.open = open
        self:dirtyAll()
    else
        w.dirty = true
    end
end

function App:set_menu(w, open)
    open = open and true or false
    if w.open ~= open then
        w.open = open
        if open then
            w.selected = (#w.items > 0) and 1 or 0
            w.top = 1
            self:menu_top(w)
        else
            w.selected = 0
            w.top = 1
        end
        self:dirtyAll()
    else
        w.dirty = true
    end
end

function App:menu_step(w, dir)
    local bars = {}
    for _, o in ipairs(self.widgets) do
        if o.kind == "menubutton" then bars[#bars + 1] = o end
    end
    if #bars == 0 then return end
    local i = 1
    for k, o in ipairs(bars) do
        if o == w then
            i = k; break
        end
    end
    i = (i - 1 + dir) % #bars + 1
    self:close_dropdowns(bars[i])
    self.focus = bars[i]
    self:set_menu(bars[i], true)
end

function App:popup(items, x, y, onpick)
    items = items or {}
    local w = 40
    for _, it in ipairs(items) do
        w = math.max(w, utf8.len(tostring(it)) * self.cw + 12)
    end
    local rows = math.min(math.max(#items, 1), 8)
    local h = rows * self:row_height() + 4
    x = math.max(0, math.min(math.floor(x or 0), math.max(0, self.W - w)))
    y = math.max(0, math.min(math.floor(y or 0), math.max(0, self.H - h)))
    self:close_dropdowns(nil)
    self.pop = {
        items = items,
        x = x,
        y = y,
        w = w,
        h = h,
        rows = rows,
        selected = (#items > 0) and 1 or 0,
        top = 1,
        onpick = onpick
    }
    self.popdirty = true
    self:dirtyAll()
end

function App:close_popup()
    if self.pop then
        self.pop = nil
        self.popdirty = true
        self:dirtyAll()
    end
end

function App:validpop()
    local p = self.pop
    if type(p) == "table" and type(p.items) == "table" then return p end
    if p ~= nil then
        self.pop = nil
        self.popdirty = true
        self:dirtyAll()
    end
    return nil
end

function App:pop_top(p)
    if type(p) ~= "table" then return end
    if p.selected > 0 then
        if p.selected < p.top then p.top = p.selected end
        if p.selected > p.top + p.rows - 1 then
            p.top = p.selected - p.rows + 1
        end
    end
    if p.top < 1 then p.top = 1 end
    local maxfirst = math.max(1, #p.items - p.rows + 1)
    if p.top > maxfirst then p.top = maxfirst end
end

function App:pop_row_at(p, px, py)
    if type(p) ~= "table" then return nil end
    if px < p.x or px >= p.x + p.w or py < p.y + 2 then return nil end
    local i = (py - (p.y + 2)) // self:row_height()
    if i < 0 or i >= p.rows then return nil end
    local idx = p.top + i
    if idx < 1 or idx > #p.items then return nil end
    return idx
end

function App:pop_highlight(p, idx)
    if type(p) ~= "table" or type(p.items) ~= "table" then return end
    idx = math.min(math.max(idx or 0, 0), #p.items)
    if p.selected ~= idx then
        p.selected = idx
        self:pop_top(p)
        self.popdirty = true
    end
end

function App:scroll_geom(w)
    local b = math.min(w.w, 20)
    local up = { x = w.x, y = w.y, w = w.w, h = b }
    local down = { x = w.x, y = w.y + w.h - b, w = w.w, h = b }
    local tx, ty, th = w.x, w.y + b, w.h - 2 * b
    if th < 1 then th = 1 end
    local total = math.max(w.total, 1)
    local frac = math.min(w.visible, total) / total
    local kh = math.max(8, math.floor(th * frac + 0.5))
    if kh > th then kh = th end
    local maxfirst = self:scroll_maxfirst(w)
    local ky = ty
    if maxfirst > 1 then
        ky = ty + math.floor((th - kh) * (w.first - 1) / (maxfirst - 1) + 0.5)
    end
    return up, { x = tx, y = ty, w = w.w, h = th }, down, ky, kh
end

function App:scroll_drag_to(w, py)
    local _, track, _, _, kh = self:scroll_geom(w)
    local span = track.h - kh
    local maxfirst = self:scroll_maxfirst(w)
    if span < 1 or maxfirst <= 1 then return end
    local off = w.grab or 0
    local frac = (py - off - track.y) / span
    self:set_scroll(w, math.floor(frac * (maxfirst - 1) + 1.5))
end

function App:drawWidget(w)
    local c, win = self.client, self.win
    if w.kind == "button" then
        if w.pressed then
            bevel(c, win, w.x, w.y, w.w, w.h, self.bg, M.lo, M.hi)
        else
            bevel(c, win, w.x, w.y, w.w, w.h, self.bg, M.hi, M.lo)
        end
        local kw = utf8.len(w.label) * self.cw
        c:text(win, w.x + (w.w - kw) // 2, w.y + (w.h - self.ch) // 2,
            w.label, M.ink, self.bg)
    elseif w.kind == "label" then
        bevel(c, win, w.x, w.y, w.w, w.h, w.bg, M.lo, M.hi)
        local shown = w.text
        local maxn = (w.w - 10) // self.cw
        if utf8.len(shown) > maxn then
            if w.align == "right" then
                shown = shown:sub(utf8.offset(shown, utf8.len(shown) - maxn + 1))
            else
                shown = shown:sub(1, maxn)
            end
        end
        local tw = utf8.len(shown) * self.cw
        local tx
        if w.align == "right" then
            tx = w.x + w.w - 5 - tw
        else
            tx = w.x + 5
        end
        c:text(win, tx, w.y + (w.h - self.ch) // 2, shown, w.fg, w.bg)
    elseif w.kind == "textbox" then
        local focused = (self.focus == w)
        bevel(c, win, w.x, w.y, w.w, w.h, M.paper, M.lo, M.hi)
        self:ensure_cursor(w)
        local maxn = math.max(1, (w.w - 10) // self.cw)
        local shown = w.text:sub(w.scroll, w.scroll + maxn - 1)
        local ty = w.y + (w.h - self.ch) // 2
        if shown ~= "" then
            c:text(win, w.x + 5, ty, shown, M.ink, M.paper)
        end
        if focused then
            local rel = w.cursor - w.scroll
            local ch = w.text:sub(w.cursor, w.cursor)
            if ch == "" then ch = " " end
            if rel >= 0 and rel < maxn then
                c:text(win, w.x + 5 + rel * self.cw, ty, ch, M.paper, M.ink)
            end
        end
    elseif w.kind == "checkbox" then
        local ty = w.y + (w.h - self.ch) // 2
        bevel(c, win, w.x, ty, self.ch + 4, self.ch + 4, M.paper, M.lo, M.hi)
        if w.value then
            c:text(win, w.x + 2, ty + 2, "X", M.ink, M.paper)
        end
        if w.label ~= "" then
            c:text(win, w.x + self.ch + 8, ty, w.label, M.ink, self.bg)
        end
    elseif w.kind == "listbox" then
        local RH = self:row_height()
        local rows = self:visible_rows(w)
        self:ensure_visible(w)

        bevel(c, win, w.x, w.y, w.w, w.h, M.paper, M.lo, M.hi)
        for i = 0, rows - 1 do
            local idx = w.top + i
            local item = w.items[idx]
            if item == nil then break end
            local y = w.y + 2 + i * RH
            local bg = (idx == w.selected) and M.selbg or M.paper
            local fg = (idx == w.selected) and M.selfg or M.ink
            c:fill(win, w.x + 1, y, w.w - 2, RH, bg)
            c:text(win, w.x + 4, y + (RH - self.ch) // 2,
                tostring(item):sub(1, (w.w - 8) // self.cw), fg, bg)
        end
    elseif w.kind == "slider" then
        local ty = w.y + (w.h - 6) // 2
        c:fill(win, w.x, w.y, w.w, w.h, self.bg)
        bevel(c, win, w.x + 1, ty, w.w - 2, 6, self.bg, M.lo, M.hi)
        local span = w.max - w.min
        local frac = (span > 0) and ((w.value - w.min) / span) or 0
        local kw = 12
        local kx = w.x + 1 + math.floor(frac * (w.w - 2 - kw) + 0.5)
        bevel(c, win, kx, w.y + 2, kw, w.h - 4, self.bg, M.hi, M.lo)
    elseif w.kind == "progress" then
        bevel(c, win, w.x, w.y, w.w, w.h, M.paper, M.lo, M.hi)
        local inner = w.w - 4
        local fill = math.floor(w.frac * inner + 0.5)
        if fill > 0 then
            c:fill(win, w.x + 2, w.y + 2, fill, w.h - 4, M.selbg)
        end
    elseif w.kind == "frame" then
        bevel(c, win, w.x, w.y, w.w, w.h, self.bg, M.hi, M.lo)
        if w.title ~= "" then
            local tx = w.x + 10
            local ty = w.y + 1
            local tw = utf8.len(w.title) * self.cw
            c:fill(win, tx - 3, w.y, tw + 6, self.ch + 2, self.bg)
            c:text(win, tx, ty, w.title, M.ink, self.bg)
        end
    elseif w.kind == "separator" then
        if w.vertical then
            local gx = w.x + (w.w - 2) // 2
            c:fill(win, gx, w.y, 1, w.h, M.lo)
            c:fill(win, gx + 1, w.y, 1, w.h, M.hi)
        else
            local gy = w.y + (w.h - 2) // 2
            c:fill(win, w.x, gy, w.w, 1, M.lo)
            c:fill(win, w.x, gy + 1, w.w, 1, M.hi)
        end
    elseif w.kind == "radio" then
        local ty = w.y + (w.h - self.ch) // 2
        local cx, cy = w.x + self.ch // 2 + 3, ty + self.ch // 2
        local r = self.ch // 2
        for dy = -r, r do
            local hw = r - math.abs(dy)
            local bg = w.value and M.ink or M.paper
            c:fill(win, cx - hw, cy + dy, hw * 2 + 1, 1, bg)
        end
        if not w.value then
            c:fill(win, cx - r, cy, r * 2 + 1, 1, M.lo)
            c:fill(win, cx, cy - r, 1, r * 2 + 1, M.lo)
        end
        if w.label ~= "" then
            c:text(win, w.x + self.ch + 8, ty, w.label, M.ink, self.bg)
        end
    elseif w.kind == "dropdown" then
        local bw = self:drop_btn()
        bevel(c, win, w.x, w.y, w.w, w.h, M.paper, M.lo, M.hi)
        local label = ""
        if w.selected > 0 then label = tostring(w.items[w.selected] or "") end
        local maxn = math.max(1, (w.w - bw - 10) // self.cw)
        if utf8.len(label) > maxn then label = label:sub(1, maxn) end
        local ty = w.y + (w.h - self.ch) // 2
        if label ~= "" then c:text(win, w.x + 5, ty, label, M.ink, M.paper) end
        local bx = w.x + w.w - bw
        bevel(c, win, bx, w.y, bw, w.h, self.bg, M.hi, M.lo)
        local ax = bx + bw // 2
        local ay = w.y + w.h // 2 - 2
        for i = 0, 3 do
            c:fill(win, ax - 3 + i, ay + i, 7 - 2 * i, 1, M.ink)
        end
    elseif w.kind == "menubutton" then
        if w.open then
            bevel(c, win, w.x, w.y, w.w, w.h, self.bg, M.lo, M.hi)
        else
            bevel(c, win, w.x, w.y, w.w, w.h, self.bg, M.hi, M.lo)
        end
        local ty = w.y + (w.h - self.ch) // 2
        local label = tostring(w.label or "")
        local maxn = math.max(0, (w.w - 10 - self.cw) // self.cw)
        if utf8.len(label) > maxn then label = label:sub(1, maxn) end
        if label ~= "" then
            c:text(win, w.x + 5, ty, label, M.ink, self.bg)
        end
        local ax = w.x + w.w - 5 - self.cw // 2
        local ay = w.y + w.h // 2 - 2
        for i = 0, 2 do
            c:fill(win, ax - 2 + i, ay + i, 5 - 2 * i, 1, M.ink)
        end
    elseif w.kind == "spinbox" then
        local btn = self:spin_btn()
        local focused = (self.focus == w)
        bevel(c, win, w.x + btn, w.y, w.w - 2 * btn, w.h, M.paper, M.lo, M.hi)
        self:ensure_spin_cursor(w)
        local maxn = math.max(1, (w.w - 2 * btn - 10) // self.cw)
        local shown = w.text:sub(w.scroll, w.scroll + maxn - 1)
        local ty = w.y + (w.h - self.ch) // 2
        if shown ~= "" then
            c:text(win, w.x + btn + 5, ty, shown, M.ink, M.paper)
        end
        if focused then
            local rel = w.cursor - w.scroll
            local ch = w.text:sub(w.cursor, w.cursor)
            if ch == "" then ch = " " end
            if rel >= 0 and rel < maxn then
                c:text(win, w.x + btn + 5 + rel * self.cw, ty, ch, M.paper, M.ink)
            end
        end
        local function stepbtn(bx, glyph)
            bevel(c, win, bx, w.y, btn, w.h, self.bg, M.hi, M.lo)
            local gw = utf8.len(glyph) * self.cw
            c:text(win, bx + (btn - gw) // 2, ty, glyph, M.ink, self.bg)
        end
        stepbtn(w.x, "-")
        stepbtn(w.x + w.w - btn, "+")
    elseif w.kind == "scrollbar" then
        local up, track, down, ky, kh = self:scroll_geom(w)
        c:fill(win, w.x, w.y, w.w, w.h, self.bg)
        local function arrowbtn(b, downher)
            bevel(c, win, b.x, b.y, b.w, b.h, self.bg, M.hi, M.lo)
            local ax = b.x + b.w // 2
            local ay = b.y + b.h // 2
            if downher then
                for i = 0, 2 do
                    c:fill(win, ax - 2 + i, ay - 1 + i, 5 - 2 * i, 1, M.ink)
                end
            else
                for i = 0, 2 do
                    c:fill(win, ax - 2 + i, ay + 1 - i, 5 - 2 * i, 1, M.ink)
                end
            end
        end
        arrowbtn(up, false)
        arrowbtn(down, true)
        bevel(c, win, track.x, track.y, track.w, track.h, M.paper, M.lo, M.hi)
        if kh < track.h then
            bevel(c, win, track.x + 1, ky, track.w - 2, kh, self.bg, M.hi, M.lo)
        else
            bevel(c, win, track.x + 1, track.y + 1, track.w - 2, track.h - 2,
                self.bg, M.hi, M.lo)
        end
    elseif w.kind == "canvas" then
        c:fill(win, w.x, w.y, w.w, w.h, w.bg or self.bg)
        if type(w.ondraw) == "function" then
            pcall(w.ondraw, self, w)
        end
    end
    w.dirty = false
end

function App:draw_menu_popup(w)
    local c, win = self.client, self.win
    local x, y, pw, ph, rows = self:menu_popup(w)
    self:menu_top(w)
    local RH = self:row_height()
    bevel(c, win, x, y, pw, ph, M.paper, M.lo, M.hi)
    for i = 0, rows - 1 do
        local idx = w.top + i
        local item = w.items[idx]
        if item == nil then break end
        local ry = y + 2 + i * RH
        local bg = (idx == w.selected) and M.selbg or M.paper
        local fg = (idx == w.selected) and M.selfg or M.ink
        c:fill(win, x + 1, ry, pw - 2, RH, bg)
        c:text(win, x + 4, ry + (RH - self.ch) // 2,
            tostring(item):sub(1, (pw - 8) // self.cw), fg, bg)
    end
end

function App:draw_context_popup(p)
    local c, win = self.client, self.win
    if type(p) ~= "table" then return end
    self:pop_top(p)
    local RH = self:row_height()
    bevel(c, win, p.x, p.y, p.w, p.h, M.paper, M.lo, M.hi)
    for i = 0, p.rows - 1 do
        local idx = p.top + i
        local item = p.items[idx]
        if item == nil then break end
        local ry = p.y + 2 + i * RH
        local bg = (idx == p.selected) and M.selbg or M.paper
        local fg = (idx == p.selected) and M.selfg or M.ink
        c:fill(win, p.x + 1, ry, p.w - 2, RH, bg)
        c:text(win, p.x + 4, ry + (RH - self.ch) // 2,
            tostring(item):sub(1, (p.w - 8) // self.cw), fg, bg)
    end
end

function App:draw_dropdown_popup(w)
    local c, win = self.client, self.win
    local x, y, pw, ph, rows = self:dropdown_popup(w)
    self:dropdown_top(w)
    local RH = self:row_height()
    bevel(c, win, x, y, pw, ph, M.paper, M.lo, M.hi)
    for i = 0, rows - 1 do
        local idx = w.top + i
        local item = w.items[idx]
        if item == nil then break end
        local ry = y + 2 + i * RH
        local bg = (idx == w.selected) and M.selbg or M.paper
        local fg = (idx == w.selected) and M.selfg or M.ink
        c:fill(win, x + 1, ry, pw - 2, RH, bg)
        c:text(win, x + 4, ry + (RH - self.ch) // 2,
            tostring(item):sub(1, (pw - 8) // self.cw), fg, bg)
    end
end

function App:render(full)
    local c = self.client
    if not c then return false end
    c:begin()
    if full or self.bgdirty then
        c:fill(self.win, 0, 0, self.W, self.H, self.bg)
        self.bgdirty = false
    end

    local pops = {}
    local vpop = self:validpop()
    local any = full or self.bgdirty or self.popdirty
    if not any then
        for _, w in ipairs(self.widgets) do
            if w.dirty then
                any = true; break
            end
        end
    end
    for _, w in ipairs(self.widgets) do
        if (w.kind == "dropdown" or w.kind == "menubutton")
            and w.open and any then
            pops[#pops + 1] = w
        end
    end
    for _, w in ipairs(self.widgets) do
        if full or w.dirty then self:drawWidget(w) end
    end
    for _, w in ipairs(pops) do
        if w.kind == "menubutton" then
            self:draw_menu_popup(w)
        else
            self:draw_dropdown_popup(w)
        end
    end

    if vpop and any then self:draw_context_popup(vpop) end
    local ok, _ = c:commit()
    if not ok then
        self:dirtyAll()
        return false
    end
    self.popdirty = nil
    return true
end

function App:clock()
    if type(posix) == "table" and type(posix.time) == "function" then
        local ok, t = pcall(posix.time)
        if ok and type(t) == "number" then return t end
    end
    return nil
end

function App:due(last)
    local now = self:clock()
    if now == nil or last == nil then return true end
    return now - last >= 1
end

local INTERACTIVE = {
    button = true,
    textbox = true,
    checkbox = true,
    radio = true,
    listbox = true,
    dropdown = true,
    menubutton = true,
    slider = true,
    spinbox = true,
    scrollbar = true,
    canvas = true,
}

function App:hit(px, py)
    for i = #self.widgets, 1, -1 do
        local w = self.widgets[i]
        if INTERACTIVE[w.kind]
            and px >= w.x and px < w.x + w.w
            and py >= w.y and py < w.y + w.h then
            return w
        end
    end
    return nil
end

local FOCUSABLE = {
    textbox = true,
    listbox = true,
    dropdown = true,
    menubutton = true,
    checkbox = true,
    radio = true,
    slider = true,
    spinbox = true,
    scrollbar = true,
    button = true,
    canvas = true,
}

function App:focus_next(back)
    local order = {}
    for _, w in ipairs(self.widgets) do
        if FOCUSABLE[w.kind] then order[#order + 1] = w end
    end
    if #order == 0 then return end
    local i = 0
    for k, w in ipairs(order) do
        if w == self.focus then
            i = k; break
        end
    end
    if back then i = i - 1 else i = i + 1 end
    if i < 1 then i = #order end
    if i > #order then i = 1 end
    local old = self.focus
    self.focus = order[i]
    if old and (old.kind == "textbox" or old.kind == "spinbox") then
        old.dirty = true
    end
    if self.focus.kind == "textbox" or self.focus.kind == "spinbox" then
        self.focus.dirty = true
    end
end

function App:handle_mouse(m)
    if m.kind == "scroll" then
        self:handle_scroll(m)
        return
    end
    if m.kind == "down" then
        local btn = m.button or 0

        local p = self:validpop()
        if p then
            if btn == 0 then
                local idx = self:pop_row_at(p, m.x, m.y)
                if idx then
                    local cb = p.onpick
                    self:close_popup()
                    if cb then cb(idx) end
                    return
                end
                local inside = m.x >= p.x and m.x < p.x + p.w
                    and m.y >= p.y and m.y < p.y + p.h
                self:close_popup()
                if inside then return end
            else
                self:close_popup()
            end
        end

        if btn ~= 0 then
            self:close_dropdowns(nil)
            if self.rightclick then self.rightclick(m.x, m.y) end
            return
        end

        for _, o in ipairs(self.widgets) do
            if o.kind == "dropdown" and o.open then
                local idx = self:dropdown_row_at(o, m.x, m.y)
                if idx then
                    self:select(o, idx)
                    self:set_dropdown(o, false)
                    return
                end
                local onbox = m.x >= o.x and m.x < o.x + o.w
                    and m.y >= o.y and m.y < o.y + o.h
                self:set_dropdown(o, false)
                if onbox then return end
            elseif o.kind == "menubutton" and o.open then
                local idx = self:menu_row_at(o, m.x, m.y)
                if idx then
                    self:select(o, idx)
                    self:set_menu(o, false)
                    return
                end
                local onbox = m.x >= o.x and m.x < o.x + o.w
                    and m.y >= o.y and m.y < o.y + o.h
                self:set_menu(o, false)
                if onbox then return end
            end
        end
        local w = self:hit(m.x, m.y)
        if not w then return end
        if w.kind == "button" then
            w.pressed = true
            w.dirty = true
            self:render(false)
            if w.onpress then w.onpress(w) end
        elseif w.kind == "checkbox" then
            self.focus = w
            self:set_checkbox(w, not w.value)
        elseif w.kind == "radio" then
            self.focus = w
            self:set_radio(w, true)
        elseif w.kind == "textbox" then
            self.focus = w
            local rel = (m.x - (w.x + 5)) // self.cw
            w.cursor = math.min(math.max(w.scroll + rel, 1), #w.text + 1)
            w.dirty = true
        elseif w.kind == "spinbox" then
            self.focus = w
            local btn = self:spin_btn()
            if m.x < w.x + btn then
                self:spin_step(w, -1)
            elseif m.x >= w.x + w.w - btn then
                self:spin_step(w, 1)
            else
                local rel = (m.x - (w.x + btn + 5)) // self.cw
                w.cursor = math.min(math.max(w.scroll + rel, 1), #w.text + 1)
                w.dirty = true
            end
        elseif w.kind == "dropdown" then
            self:close_dropdowns(w)
            self.focus = w
            if w.open then
                self:set_dropdown(w, false)
            else
                self:set_dropdown(w, true)
                self:dropdown_top(w)
                w.dirty = true
            end
        elseif w.kind == "menubutton" then
            self:close_dropdowns(w)
            self.focus = w
            if w.open then
                self:set_menu(w, false)
            else
                self:set_menu(w, true)
            end
        elseif w.kind == "listbox" then
            self.focus = w
            local idx = self:row_at(w, m.x, m.y)
            if idx then
                if idx == w.selected then
                    if w.ondouble then w.ondouble(w, idx) end
                else
                    self:select(w, idx)
                end
            end
        elseif w.kind == "scrollbar" then
            self.focus = w
            local up, track, down, ky, kh = self:scroll_geom(w)
            if m.y < up.y + up.h then
                self:set_scroll(w, w.first - 1)
            elseif m.y >= down.y then
                self:set_scroll(w, w.first + 1)
            elseif m.y < ky then
                self:set_scroll(w, w.first - w.visible)
            elseif m.y >= ky + kh then
                self:set_scroll(w, w.first + w.visible)
            else
                w.grab = m.y - ky
                self.grab = w
            end
        elseif w.kind == "slider" then
            self.focus = w
            self.grab = w
            self:slide_to(w, m.x)
        elseif w.kind == "canvas" then
            self.focus = w
            self.grab = w
            if type(w.onmouse) == "function" then
                pcall(w.onmouse, self, w, m)
            end
        end
    elseif m.kind == "up" then
        if self.grab then
            local w = self.grab
            self.grab = nil
            if w.kind == "slider" then
                self:slide_to(w, m.x)
            elseif w.kind == "scrollbar" then
                w.grab = nil
            elseif w.kind == "canvas" then
                if type(w.onmouse) == "function" then
                    pcall(w.onmouse, self, w, m)
                end
            end
        end
        for _, w in ipairs(self.widgets) do
            if w.kind == "button" and w.pressed then
                w.pressed = false
                w.dirty = true
            end
            if w.kind == "scrollbar" then w.grab = nil end
        end
    elseif m.kind == "move" then
        if self.grab and self.grab.kind == "slider" then
            self:slide_to(self.grab, m.x)
        elseif self.grab and self.grab.kind == "scrollbar" then
            self:scroll_drag_to(self.grab, m.y)
        elseif self.grab and self.grab.kind == "canvas" then
            local w = self.grab
            if type(w.onmouse) == "function" then
                pcall(w.onmouse, self, w, m)
            end
        end
    end
end

function App:nudge_top(w, delta, rows, total)
    local maxfirst = math.max(1, total - rows + 1)
    local top = math.min(math.max((w.top or 1) + delta, 1), maxfirst)
    if top ~= w.top then
        w.top = top
        w.dirty = true
    end
end

function App:handle_scroll(m)
    local v = m.button or 0
    if v == 0 then return end
    local dir = v > 0 and 1 or -1
    local p = self:validpop()
    if p and self:pop_row_at(p, m.x, m.y) then
        self:nudge_top(p, 3 * dir, p.rows, #p.items)
        self.popdirty = true
        return
    end
    for _, o in ipairs(self.widgets) do
        if o.kind == "dropdown" and o.open
            and self:dropdown_row_at(o, m.x, m.y) then
            local rows = select(5, self:dropdown_popup(o))
            self:nudge_top(o, 3 * dir, rows, #o.items)
            return
        end
        if o.kind == "menubutton" and o.open
            and self:menu_row_at(o, m.x, m.y) then
            local rows = select(5, self:menu_popup(o))
            self:nudge_top(o, 3 * dir, rows, #o.items)
            return
        end
    end
    local w = self:hit(m.x, m.y)
    if not w then return end
    if w.kind == "listbox" then
        self:nudge_top(w, 3 * dir, self:visible_rows(w), #w.items)
    elseif w.kind == "dropdown" then
        if #w.items > 0 then
            local idx = (w.selected > 0 and w.selected or (dir > 0 and 0 or #w.items + 1)) + dir
            idx = math.min(math.max(idx, 1), #w.items)
            self:select(w, idx)
        end
    elseif w.kind == "scrollbar" then
        self:set_scroll(w, w.first + 3 * dir)
    elseif w.kind == "spinbox" then
        self:spin_step(w, dir)
    elseif w.kind == "slider" then
        local step = (w.max - w.min) / 20
        if step <= 0 then step = 1 end
        self:set_slider(w, w.value + dir * step)
    elseif w.kind == "canvas" then
        if type(w.onscroll) == "function" then
            pcall(w.onscroll, self, w, dir)
        end
    end
end

function App:slide_to(w, px)
    local x0, track = w.x + 1, w.w - 2 - 12
    if track < 1 then track = 1 end
    local frac = (px - x0 - 6) / track
    self:set_slider(w, w.min + frac * (w.max - w.min))
end

local function insert_at(w, ch)
    local L = w.text
    w.text = L:sub(1, w.cursor - 1) .. ch .. L:sub(w.cursor)
    w.cursor = w.cursor + #ch
    w.dirty = true
end

function App:handle_key(m)
    local mods = m.mods or 0

    if m.name == "tab" and (mods & 6) == 0 and self.tabfocus ~= false then
        self:focus_next((mods & 1) ~= 0)
        return
    end

    local p = self:validpop()
    if p then
        local name = m.name
        if name == "escape" then
            self:close_popup()
            return
        elseif name == "up" then
            self:pop_highlight(p, (p.selected > 0 and p.selected or 2) - 1)
            return
        elseif name == "down" then
            self:pop_highlight(p, (p.selected > 0 and p.selected or 0) + 1)
            return
        elseif name == "home" then
            self:pop_highlight(p, 1)
            return
        elseif name == "end" then
            self:pop_highlight(p, #p.items)
            return
        elseif name == "enter" or name == "space" then
            if p.selected > 0 then
                local cb = p.onpick
                local idx = p.selected
                self:close_popup()
                if cb then cb(idx) end
            else
                self:close_popup()
            end
            return
        else
            self:close_popup()
        end
    end
    local f = self.focus
    if f and FOCUSABLE[f.kind] and self:key_widget(f, m) then return end
    if self.keyhandler then self.keyhandler(m) end
end

function App:key_widget(w, m)
    local mods = m.mods or 0
    local name = m.name
    if w.kind == "textbox" then
        if name == "enter" then
            if w.onenter then w.onenter(w) end
            return true
        elseif name == "backspace" then
            if w.cursor > 1 then
                local L = w.text

                w.text = L:sub(1, w.cursor - 2) .. L:sub(w.cursor)
                w.cursor = w.cursor - 1
                w.dirty = true
                if w.onchange then w.onchange(w) end
            end
            return true
        elseif name == "delete" then
            if w.cursor <= #w.text then
                local L = w.text
                w.text = L:sub(1, w.cursor - 1) .. L:sub(w.cursor + 1)
                w.dirty = true
                if w.onchange then w.onchange(w) end
            end
            return true
        elseif name == "left" then
            w.cursor = math.max(1, w.cursor - 1)
            w.dirty = true
            return true
        elseif name == "right" then
            w.cursor = math.min(#w.text + 1, w.cursor + 1)
            w.dirty = true
            return true
        elseif name == "home" then
            w.cursor = 1
            w.dirty = true
            return true
        elseif name == "end" then
            w.cursor = #w.text + 1
            w.dirty = true
            return true
        elseif m.code and m.code >= 32 and m.code < 127 and (mods & 6) == 0 then
            insert_at(w, string.char(m.code))
            if w.onchange then w.onchange(w) end
            return true
        end
        return false
    elseif w.kind == "listbox" then
        if name == "up" then
            self:select(w, math.max(1, (w.selected > 0 and w.selected or 2) - 1))
            return true
        elseif name == "down" then
            self:select(w, math.min(#w.items, (w.selected > 0 and w.selected or 0) + 1))
            return true
        elseif name == "home" then
            self:select(w, 1)
            return true
        elseif name == "end" then
            self:select(w, #w.items)
            return true
        elseif name == "enter" or name == "space" then
            if w.selected > 0 and w.ondouble then w.ondouble(w, w.selected) end
            return true
        end
        return false
    elseif w.kind == "checkbox" then
        if name == "space" then
            self:set_checkbox(w, not w.value)
            return true
        end
        return false
    elseif w.kind == "radio" then
        if name == "space" then
            self:set_radio(w, true)
            return true
        elseif name == "left" or name == "up" then
            self:radio_step(w, -1)
            return true
        elseif name == "right" or name == "down" then
            self:radio_step(w, 1)
            return true
        end
        return false
    elseif w.kind == "dropdown" then
        if name == "escape" and w.open then
            self:set_dropdown(w, false)
            return true
        elseif name == "enter" or name == "space" then
            if w.open then
                self:set_dropdown(w, false)
            else
                self:close_dropdowns(w)
                self:set_dropdown(w, true)
                self:dropdown_top(w)
                w.dirty = true
            end
            return true
        elseif name == "up" then
            if w.open then
                if w.selected > 1 then self:select(w, w.selected - 1) end
            elseif w.selected > 1 then
                self:select(w, w.selected - 1)
            end
            return true
        elseif name == "down" then
            if w.open then
                if w.selected < #w.items then
                    self:select(w, (w.selected > 0 and w.selected or 0) + 1)
                end
            elseif w.selected < #w.items then
                self:select(w, (w.selected > 0 and w.selected or 0) + 1)
            end
            return true
        elseif name == "home" then
            if #w.items > 0 then self:select(w, 1) end
            return true
        elseif name == "end" then
            if #w.items > 0 then self:select(w, #w.items) end
            return true
        end
        return false
    elseif w.kind == "menubutton" then
        if name == "escape" and w.open then
            self:set_menu(w, false)
            return true
        elseif name == "enter" or name == "space" then
            if w.open then
                local idx = w.selected
                self:set_menu(w, false)
                if idx > 0 and w.onselect then w.onselect(w, idx) end
            else
                self:close_dropdowns(w)
                self:set_menu(w, true)
            end
            return true
        elseif name == "up" then
            if not w.open then
                self:close_dropdowns(w)
                self:set_menu(w, true)
            elseif w.selected > 1 then
                self:menu_highlight(w, w.selected - 1)
            end
            return true
        elseif name == "down" then
            if not w.open then
                self:close_dropdowns(w)
                self:set_menu(w, true)
            elseif w.selected < #w.items then
                self:menu_highlight(w, (w.selected > 0 and w.selected or 0) + 1)
            end
            return true
        elseif name == "home" then
            if not w.open then
                self:close_dropdowns(w)
                self:set_menu(w, true)
            elseif #w.items > 0 then
                self:menu_highlight(w, 1)
            end
            return true
        elseif name == "end" then
            if not w.open then
                self:close_dropdowns(w)
                self:set_menu(w, true)
            elseif #w.items > 0 then
                self:menu_highlight(w, #w.items)
            end
            return true
        elseif name == "left" or name == "right" then
            self:menu_step(w, name == "right" and 1 or -1)
            return true
        end
        return false
    elseif w.kind == "spinbox" then
        if name == "enter" then
            self:spin_commit(w)
            return true
        elseif name == "escape" then
            w.text = self:spin_format(w, w.value)
            w.cursor = #w.text + 1
            w.dirty = true
            return true
        elseif name == "up" then
            self:spin_step(w, 1)
            return true
        elseif name == "down" then
            self:spin_step(w, -1)
            return true
        elseif name == "backspace" then
            if w.cursor > 1 then
                local L = w.text
                w.text = L:sub(1, w.cursor - 2) .. L:sub(w.cursor)
                w.cursor = w.cursor - 1
                w.dirty = true
            end
            return true
        elseif name == "delete" then
            if w.cursor <= #w.text then
                local L = w.text
                w.text = L:sub(1, w.cursor - 1) .. L:sub(w.cursor + 1)
                w.dirty = true
            end
            return true
        elseif name == "left" then
            w.cursor = math.max(1, w.cursor - 1)
            w.dirty = true
            return true
        elseif name == "right" then
            w.cursor = math.min(#w.text + 1, w.cursor + 1)
            w.dirty = true
            return true
        elseif name == "home" then
            w.cursor = 1
            w.dirty = true
            return true
        elseif name == "end" then
            w.cursor = #w.text + 1
            w.dirty = true
            return true
        elseif m.code and m.code >= 32 and m.code < 127 and (mods & 6) == 0 then
            local ch = string.char(m.code)
            if ch:match("[0-9%-%+%.eE]") then
                insert_at(w, ch)
                return true
            end
        end
        return false
    elseif w.kind == "scrollbar" then
        if name == "up" or name == "left" then
            self:set_scroll(w, w.first - 1)
            return true
        elseif name == "down" or name == "right" then
            self:set_scroll(w, w.first + 1)
            return true
        elseif name == "home" then
            self:set_scroll(w, 1)
            return true
        elseif name == "end" then
            self:set_scroll(w, self:scroll_maxfirst(w))
            return true
        elseif name == "pageup" or name == "pageUp" then
            self:set_scroll(w, w.first - w.visible)
            return true
        elseif name == "pagedown" or name == "pageDown" then
            self:set_scroll(w, w.first + w.visible)
            return true
        end
        return false
    elseif w.kind == "button" then
        if name == "space" or name == "enter" then
            if w.onpress then w.onpress(w) end
            return true
        end
        return false
    elseif w.kind == "slider" then
        local step = (w.max - w.min) / 20
        if step <= 0 then step = 1 end
        if name == "left" or name == "down" then
            self:set_slider(w, w.value - step)
            return true
        elseif name == "right" or name == "up" then
            self:set_slider(w, w.value + step)
            return true
        elseif name == "home" then
            self:set_slider(w, w.min)
            return true
        elseif name == "end" then
            self:set_slider(w, w.max)
            return true
        end
        return false
    elseif w.kind == "canvas" then
        return false
    end
    return false
end

function App:run()
    local c = self.client
    local need_paint, last_try = not self:render(true), self:clock()
    while not self.quit do
        for _, m in ipairs(c:poll(0.2)) do
            if m.op == "close" then
                local veto = false
                if type(self.closehandler) == "function" then
                    local ok, v = pcall(self.closehandler)
                    veto = ok and v and true or false
                end
                if veto then
                    if not self:render(false) then
                        need_paint, last_try = true, self:clock()
                    end
                else
                    self.quit = true
                end
            elseif m.op == "destroyed" then
                self.quit = true
            elseif m.op == "map" or m.op == "configure" then
                self:handle_configure(m)
                if not self:render(true) then
                    need_paint, last_try = true, self:clock()
                end
            elseif m.op == "mouse" then
                self:handle_mouse(m)
                if not self:render(false) then
                    need_paint, last_try = true, self:clock()
                end
            elseif m.op == "key" and m.down then
                self:handle_key(m)
                if not self:render(false) then
                    need_paint, last_try = true, self:clock()
                end
            end
        end

        if self.tick_fn then
            local now = self:clock()
            local fire = false
            if now ~= nil then
                if self.tick_last == nil then
                    self.tick_last = now
                elseif now - self.tick_last >= self.tick_secs then
                    self.tick_last = now
                    fire = true
                end
            else
                self.tick_count = (self.tick_count or 0) + 1
                if self.tick_count >= math.max(1, math.floor(self.tick_secs / 0.2)) then
                    self.tick_count = 0
                    fire = true
                end
            end
            if fire then
                self.tick_fn()
                if not self:render(false) then
                    need_paint, last_try = true, self:clock()
                end
            end
        end
        if need_paint and self:due(last_try) then
            last_try = self:clock()
            need_paint = not self:render(true)
        end
        if type(event.poll) == "function" then
            local n = event.poll()
            if n == "terminate" then self.quit = true end
        end
    end
end

local function dialog_app(title, w, h)
    return M.App({ name = "dialog", title = title or "dialog", w = w, h = h })
end

function M.alert(opts)
    opts = opts or {}
    local app = dialog_app(opts.title, 260, 120)
    if not app then return nil, "cannot connect" end
    local lab = app:label({
        x = 10,
        y = 10,
        w = 240,
        h = 52,
        text = opts.text or "",
        anchor = "top"
    })
    local btn = app:button({
        x = 90,
        y = 72,
        w = 80,
        h = 30,
        label = "OK",
        onpress = function() app.quit = true end
    })
    app:onresize(function(W, H)
        lab.w = math.max(4, W - 20)
        lab.h = math.max(4, H - 68)
        lab.dirty = true
        btn.x = (W - 80) // 2
        btn.y = H - 30 - 10
        btn.dirty = true
    end)
    app:run()
    app:close()
    return true
end

function M.confirm(opts)
    opts = opts or {}
    local app = dialog_app(opts.title, 260, 120)
    if not app then return nil, "cannot connect" end
    local answer = false
    local lab = app:label({
        x = 10,
        y = 10,
        w = 240,
        h = 52,
        text = opts.text or "",
        anchor = "top"
    })
    local okb = app:button({
        x = 40,
        y = 72,
        w = 80,
        h = 30,
        label = "OK",
        onpress = function()
            answer = true; app.quit = true
        end
    })
    local cb = app:button({
        x = 140,
        y = 72,
        w = 80,
        h = 30,
        label = "Cancel",
        onpress = function() app.quit = true end
    })
    app:onresize(function(W, H)
        lab.w = math.max(4, W - 20)
        lab.h = math.max(4, H - 68)
        lab.dirty = true
        local x0 = (W - 180) // 2
        local y = H - 30 - 10
        okb.x, okb.y = x0, y
        cb.x, cb.y = x0 + 100, y
        okb.dirty, cb.dirty = true, true
    end)
    app:run()
    app:close()
    return answer
end

function M.prompt(opts)
    opts = opts or {}
    local app = dialog_app(opts.title, 300, 140)
    if not app then return nil, "cannot connect" end
    local answer = nil
    app:label({
        x = 10,
        y = 10,
        w = 280,
        h = 28,
        text = opts.text or "",
        anchor = "top"
    })
    local box = app:textbox({
        x = 10,
        y = 44,
        w = 280,
        text = opts.default or "",
        onenter = function(b)
            answer = b.text; app.quit = true
        end,
        anchor = "top"
    })
    app.focus = box
    local okb = app:button({
        x = 60,
        y = 94,
        w = 80,
        h = 30,
        label = "OK",
        onpress = function()
            answer = box.text; app.quit = true
        end
    })
    local cb = app:button({
        x = 160,
        y = 94,
        w = 80,
        h = 30,
        label = "Cancel",
        onpress = function() app.quit = true end
    })
    app:onresize(function(W, H)
        local x0 = (W - 180) // 2
        local y = H - 30 - 10
        okb.x, okb.y = x0, y
        cb.x, cb.y = x0 + 100, y
        okb.dirty, cb.dirty = true, true
    end)
    app:run()
    app:close()
    return answer
end

function M.choose(opts)
    opts = opts or {}
    local app = dialog_app(opts.title, 300, 220)
    if not app then return nil, "cannot connect" end
    local answer = nil
    app:label({
        x = 10,
        y = 10,
        w = 280,
        h = 28,
        text = opts.text or "",
        anchor = "top"
    })
    local list = app:listbox({
        x = 10,
        y = 44,
        w = 280,
        h = 116,
        items = opts.items or {},
        selected = opts.selected or 0,
        ondouble = function(l, idx)
            answer = idx; app.quit = true
        end,
        anchor = "all"
    })
    if opts.selected and opts.selected > 0 then app:select(list, opts.selected) end
    app.focus = list
    local okb = app:button({
        x = 60,
        y = 172,
        w = 80,
        h = 30,
        label = "OK",
        onpress = function()
            answer = list.selected > 0 and list.selected or nil
            app.quit = true
        end
    })
    local cb = app:button({
        x = 160,
        y = 172,
        w = 80,
        h = 30,
        label = "Cancel",
        onpress = function() app.quit = true end
    })
    app:onresize(function(W, H)
        list.h = math.max(20, H - 44 - 48)
        list.dirty = true
        local x0 = (W - 180) // 2
        local y = H - 30 - 10
        okb.x, okb.y = x0, y
        cb.x, cb.y = x0 + 100, y
        okb.dirty, cb.dirty = true, true
    end)
    app:onkey(function(m)
        if m.name == "enter" then
            answer = list.selected > 0 and list.selected or nil
            app.quit = true
        end
    end)
    app:run()
    app:close()
    return answer
end

local function fileapp_prog(override)
    if type(override) == "string" and override ~= "" then return override end
    if type(posix) == "table" and type(posix.getenv) == "function" then
        local ok, v = pcall(posix.getenv, "FILEAPP")
        if ok and type(v) == "string" and v ~= "" then return v end
    end
    return "/bin/xfile"
end

M.fileapp = fileapp_prog

local function pick_tmpfile()
    if type(posix) ~= "table" or type(posix.stat) ~= "function"
        or type(posix.writefile) ~= "function" then
        return nil
    end
    local pid = 0
    if type(posix.getpid) == "function" then
        local ok, v = pcall(posix.getpid)
        if ok and type(v) == "number" then pid = v end
    end
    for _ = 1, 50 do
        local r = {}
        for i = 1, 8 do r[i] = string.char(math.random(97, 122)) end
        local name = "/tmp/openfile." .. tostring(pid) .. "." .. table.concat(r)
        local st
        local ok, v = pcall(posix.stat, name)
        if ok then st = v end
        if not st then
            local wok, werr = posix.writefile(name, "")
            if wok then
                pcall(posix.chmod, name, 384)
                return name
            end
            if werr then return nil end
        end
    end
    return nil
end

local function pick_sleep()
    if type(sys) == "table" and type(sys.sleep) == "function" then
        pcall(sys.sleep, 0.05)
    elseif type(spp) == "table" and type(spp.poll) == "function" then
        pcall(spp.poll, {}, 0.05)
    end
end

local function pump_app(app)
    if type(app) ~= "table" or app.client == nil then return end
    local ok, msgs = pcall(function() return app.client:poll(0) end)
    if not ok or type(msgs) ~= "table" then return end
    local need = false
    for _, m in ipairs(msgs) do
        if type(m) == "table" and (m.op == "configure" or m.op == "map") then
            pcall(function() app:handle_configure(m) end)
            need = true
        elseif type(m) == "table" and m.op == "destroyed" then
            app.quit = true
        end
    end
    if need then pcall(function() app:render(true) end) end
end

local function pick_trim(s)
    return (s or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function pick_via_manager(mode, opts)
    opts = opts or {}
    if type(posix) ~= "table" or type(posix.spawn) ~= "function"
        or type(posix.wait) ~= "function" then
        return nil, "nospawn"
    end
    local prog = fileapp_prog(opts.fileapp)
    local outfile = pick_tmpfile()
    if not outfile then return nil, "notmp" end
    local args = { mode == "save" and "--savedialog" or "--opendialog",
        "--outfile", outfile }
    local start = opts.dir
    if (start == nil or start == "") and opts.start ~= nil then start = opts.start end
    if type(start) == "string" and start ~= "" then args[#args + 1] = start end
    local pid, serr = posix.spawn(prog, args)
    if not pid then
        pcall(posix.unlink, outfile)
        return nil, "spawn: " .. tostring(serr)
    end
    local code = nil
    while code == nil do
        if opts.app then
            pump_app(opts.app)
            if opts.app.quit then
                pcall(posix.kill, pid, 15)
                pcall(posix.wait, pid)
                pcall(posix.unlink, outfile)
                return nil, "killed"
            end
        end
        if type(opts.pump) == "function" then pcall(opts.pump) end
        if type(opts.abort) == "function" then
            local ok, stop = pcall(opts.abort)
            if ok and stop then
                pcall(posix.kill, pid, 15)
                pcall(posix.wait, pid)
                pcall(posix.unlink, outfile)
                return nil, "killed"
            end
        end
        local wpid, wcode = posix.wait(pid, true)
        if wpid == nil then
            code = 1
        elseif wpid ~= 0 then
            code = wcode
        end
        if code == nil then
            if type(event) == "table" and type(event.poll) == "function" then
                local ok, n = pcall(event.poll)
                if ok and n == "terminate" then
                    pcall(posix.kill, pid, 15)
                    pcall(posix.wait, pid)
                    pcall(posix.unlink, outfile)
                    return nil, "killed"
                end
            end
            pick_sleep()
        end
    end
    local data = nil
    if type(posix.readfile) == "function" then
        local ok, v = pcall(posix.readfile, outfile)
        if ok and type(v) == "string" then data = v end
    end
    pcall(posix.unlink, outfile)
    if code == 0 and pick_trim(data or "") ~= "" then
        return pick_trim(data)
    end
    return nil, "cancel"
end

function M.openfile(opts)
    opts = opts or {}
    local path, err = pick_via_manager("open", opts)
    if path then return path end
    if err == "cancel" or err == "killed" then return nil end
    return M.prompt({
        title = opts.title or "Open file",
        text = "Path:",
        default = opts.dir or opts.start or ""
    })
end

function M.savefile(opts)
    opts = opts or {}
    local path, err = pick_via_manager("save", opts)
    if path then return path end
    if err == "cancel" or err == "killed" then return nil end
    return M.prompt({
        title = opts.title or "Save file",
        text = "Path:",
        default = opts.dir or opts.start or ""
    })
end

return M
