local xd = require("xd")

local M = {}

M.themes = {
	classic = {
		style = "bevel",
		gray = 0xB0B0B0,
		face = 0xB0B0B0,
		light = 0xE8E8E8,
		hi = 0xE8E8E8,
		lo = 0x606060,
		paper = 0xFFFFFF,
		sunken = 0xE8E8E8,
		ink = 0x000000,
		selbg = 0x3050A0,
		selfg = 0xFFFFFF,
	},
}
M.theme_name = "aero"

function M.theme(name)
	if type(name) == "string" and M.themes[name] then
		M.theme_name = name
	end
	return M.themes[M.theme_name]
end

local function resolve_theme(opts)
	if opts then
		local t = type(opts.theme) == "string" and M.themes[opts.theme]
		if t then
			return t
		end
	end
	if type(env) == "table" and type(env.get) == "function" then
		local ok, v = pcall(env.get, "XUI_THEME")
		if ok and type(v) == "string" and M.themes[v] then
			return M.themes[v]
		end
	end
	return M.themes[M.theme_name]
end

setmetatable(M, {
	__index = function(_, k)
		local t = M.themes[M.theme_name]
		return t and t[k]
	end,
	__newindex = function(_, k, v)
		local t = M.themes[M.theme_name]
		if t and t[k] ~= nil then
			t[k] = v
		else
			rawset(M, k, v)
		end
	end,
})

local App = {}
App.__index = App
M.App = App

local function bevel(c, win, x, y, w, h, face, hi, lo)
	c:fill(win, x, y, w, h, face)
	c:fill(win, x, y, w, 1, hi)
	c:fill(win, x, y, 1, h, hi)
	c:fill(win, x, y + h - 1, w, 1, lo)
	c:fill(win, x + w - 1, y, 1, h, lo)
end

M.bevel = bevel

local function parse_anchor(a)
	if a == nil then
		return { left = true, top = true }
	end
	if type(a) == "string" then
		if a == "all" then
			return { left = true, top = true, right = true, bottom = true }
		elseif a == "top" then
			return { left = true, top = true, right = true }
		elseif a == "bottom" then
			return { left = true, bottom = true, right = true }
		elseif a == "left" then
			return { left = true, top = true, bottom = true }
		elseif a == "right" then
			return { top = true, bottom = true, right = true }
		elseif a == "tl" then
			return { left = true, top = true }
		elseif a == "tr" then
			return { top = true, right = true }
		elseif a == "bl" then
			return { bottom = true, left = true }
		elseif a == "br" then
			return { bottom = true, right = true }
		else
			return { left = true, top = true }
		end
	end
	if type(a) == "table" then
		return {
			left = a.left and true or false,
			top = a.top and true or false,
			right = a.right and true or false,
			bottom = a.bottom and true or false,
		}
	end
	return { left = true, top = true }
end

M.parse_anchor = parse_anchor

local function track(app, w, opts)
	w._anchor = parse_anchor(opts and opts.anchor)
	w._l = w.x or 0
	w._t = w.y or 0
	w._r = app.W - ((w.x or 0) + (w.w or 0))
	w._b = app.H - ((w.y or 0) + (w.h or 0))
	return w
end

local HINT_FIELDS = { "min_w", "min_h", "max_w", "max_h", "resizable", "focusable", "dialog", "transient_for" }

local function window_hints(opts)
	local h = {}
	for _, k in ipairs(HINT_FIELDS) do
		h[k] = opts[k]
	end
	if type(opts.hints) == "table" then
		for _, k in ipairs(HINT_FIELDS) do
			if h[k] == nil then
				h[k] = opts.hints[k]
			end
		end
	end
	return h
end

function M.App(opts)
	opts = opts or {}
	local client, err = xd.connect({
		name = opts.name or "xui",
		wm = opts.wm and true or nil,
	})
	if not client then
		return nil, err
	end
	local win, werr = client:window({
		w = opts.w or 320,
		h = opts.h or 200,
		title = opts.title or opts.name or "xui",
		kind = opts.kind,
		x = opts.x,
		y = opts.y,
		hints = window_hints(opts),
	})
	if not win then
		client:close()
		return nil, werr
	end
	local theme = resolve_theme(opts)
	local self = setmetatable({
		client = client,
		win = win,
		W = opts.w or 320,
		H = opts.h or 200,
		bg = opts.bg or theme.appBg or theme.gray,
		widgets = {},
		keyhandler = nil,
		quit = false,
		focus = nil,
		grab = nil,
		window_focused = true,
		cw = client.font.w,
		ch = client.font.h,
		theme = theme,
	}, App)
	client:map(win)
	return self
end

function App:close()
	if self.client then
		pcall(function()
			self.client:close()
		end)
		self.client = nil
	end
end

function App:dirty(w)
	if w then
		w.dirty = true
	else
		for _, wid in ipairs(self.widgets) do
			wid.dirty = true
		end
		self.bgdirty = true
	end
end

function App:dirtyAll()
	self:dirty(nil)
end

function App:set_anchor(w, anchor)
	w._anchor = parse_anchor(anchor)
	w._l = w.x or 0
	w._t = w.y or 0
	w._r = self.W - ((w.x or 0) + (w.w or 0))
	w._b = self.H - ((w.y or 0) + (w.h or 0))
end

function App:apply_anchors()
	for _, w in ipairs(self.widgets) do
		local a = w._anchor or { left = true, top = true }
		if w.x ~= nil and w.w ~= nil then
			local l, t, r, b = w._l or w.x, w._t or w.y, w._r or 0, w._b or 0
			if a.left and a.right then
				w.x = l
				w.w = math.max(4, self.W - l - r)
			elseif a.right and not a.left then
				w.x = self.W - r - w.w
			else
				w.x = l
			end
			if w.y ~= nil and w.h ~= nil then
				if a.top and a.bottom then
					w.y = t
					w.h = math.max(4, self.H - t - b)
				elseif a.bottom and not a.top then
					w.y = self.H - b - (w.h or 0)
				else
					w.y = t
				end
			end
			w.dirty = true
		end
	end
	self.bgdirty = true
end

function App:onresize(fn)
	self.resize_handler = fn
end

function App:handle_configure(m)
	if type(m) ~= "table" then
		return false
	end
	local w, h = m.w, m.h
	if type(w) ~= "number" or type(h) ~= "number" then
		return false
	end
	if w < 1 or h < 1 then
		return false
	end
	w, h = math.floor(w), math.floor(h)
	if w == self.W and h == self.H then
		return false
	end
	self.W, self.H = w, h
	self:apply_anchors()
	if self.resize_handler then
		pcall(self.resize_handler, w, h)
	end
	self:dirtyAll()
	return true
end

function App:label(opts)
	local w = {
		kind = "label",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 28,
		text = opts.text or "",
		align = opts.align or "left",
		fg = opts.fg or self.theme.ink,
		bg = opts.bg or self.theme.sunken,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:button(opts)
	local w = {
		kind = "button",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		label = opts.label or "?",
		onpress = opts.onpress,
		pressed = false,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:textbox(opts)
	local w = {
		kind = "textbox",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 24,
		text = opts.text or "",
		cursor = #(opts.text or "") + 1,
		scroll = 1,
		sel_anchor = nil,
		noecho = opts.noecho and true or false,
		onenter = opts.onenter,
		onchange = opts.onchange,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:checkbox(opts)
	local w = {
		kind = "checkbox",
		x = opts.x,
		y = opts.y,
		w = opts.w or ((#(opts.label or "") + 4) * self.cw + 20),
		h = opts.h or 20,
		label = opts.label or "",
		value = opts.value and true or false,
		onchange = opts.onchange,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:listbox(opts)
	local w = {
		kind = "listbox",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		items = opts.items or {},
		selected = opts.selected or 0,
		top = 1,
		onselect = opts.onselect,
		ondouble = opts.ondouble,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:slider(opts)
	local w = {
		kind = "slider",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 24,
		min = opts.min or 0,
		max = opts.max == nil and 100 or opts.max,
		value = opts.value or 0,
		onchange = opts.onchange,
		dirty = true,
	}
	if w.max < w.min then
		w.min, w.max = w.max, w.min
	end
	w.value = math.min(math.max(w.value, w.min), w.max)
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:progress(opts)
	local w = {
		kind = "progress",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 20,
		frac = math.min(math.max(opts.frac or 0, 0), 1),
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:frame(opts)
	local w = {
		kind = "frame",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		title = opts.title or "",
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:separator(opts)
	local w = {
		kind = "separator",
		x = opts.x,
		y = opts.y,
		w = opts.w or 6,
		h = opts.h or 6,
		vertical = opts.vertical and true or false,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:radio(opts)
	local w = {
		kind = "radio",
		x = opts.x,
		y = opts.y,
		w = opts.w or ((#(opts.label or "") + 4) * self.cw + 20),
		h = opts.h or 20,
		label = opts.label or "",
		group = opts.group or "__default__",
		value = opts.value and true or false,
		onchange = opts.onchange,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:dropdown(opts)
	local w = {
		kind = "dropdown",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 24,
		items = opts.items or {},
		selected = opts.selected or 0,
		top = 1,
		open = false,
		onselect = opts.onselect,
		dirty = true,
	}
	if w.selected < 0 or w.selected > #w.items then
		w.selected = 0
	end
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:menubutton(opts)
	local w = {
		kind = "menubutton",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 24,
		label = opts.label or "?",
		items = opts.items or {},
		selected = 0,
		top = 1,
		open = false,
		onselect = opts.onselect,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:menubar_layout(x, y, h, buttons)
	local cx = x
	for _, b in ipairs(buttons) do
		b.x, b.y, b.h = cx, y, h
		b.dirty = true
		cx = cx + (b.w or 0) + 2
	end
	return buttons
end

function App:spinbox(opts)
	local w = {
		kind = "spinbox",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 24,
		min = opts.min or 0,
		max = opts.max == nil and 100 or opts.max,
		step = opts.step or 1,
		value = opts.value or 0,
		onchange = opts.onchange,
		dirty = true,
	}
	if w.max < w.min then
		w.min, w.max = w.max, w.min
	end
	if w.step <= 0 then
		w.step = 1
	end
	w.value = math.min(math.max(w.value, w.min), w.max)
	w.value = self:spin_round(w, w.value)
	w.text = self:spin_format(w, w.value)
	w.cursor = #w.text + 1
	w.scroll = 1
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:scrollbar(opts)
	local w = {
		kind = "scrollbar",
		x = opts.x,
		y = opts.y,
		w = opts.w or 16,
		h = opts.h,
		total = opts.total or 0,
		visible = opts.visible or 1,
		first = opts.first or 1,
		grab = nil,
		onchange = opts.onchange,
		dirty = true,
	}
	if w.visible < 1 then
		w.visible = 1
	end
	if w.total < 0 then
		w.total = 0
	end
	w.first = self:scroll_clamp(w, w.first)
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:canvas(opts)
	local w = {
		kind = "canvas",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		bg = opts.bg or self.theme.paper,
		ondraw = opts.ondraw,
		onmouse = opts.onmouse,
		onscroll = opts.onscroll,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:tree(opts)
	local w = {
		kind = "tree",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		nodes = opts.nodes or (opts.root and { opts.root }) or {},
		selected = opts.selected,
		top = 1,
		indent = opts.indent or 12,
		row_h = opts.row_h or (self.ch + 6),
		expanded = opts.expanded or {},
		filter = nil,
		onselect = opts.onselect,
		ondouble = opts.ondouble,
		onactivate = opts.onactivate or opts.ondouble,
		onrightclick = opts.onrightclick,
		rows = nil,
		dirty = true,
	}
	if opts.autoexpand then
		for _, n in ipairs(w.nodes) do
			w.expanded[n] = true
		end
	end
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	self:tree_refresh(w)
	return w
end

function App:tabbar(opts)
	local w = {
		kind = "tabbar",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h or 24,
		tabs = opts.tabs or {},
		selected = opts.selected or 0,
		first = 1,
		onselect = opts.onselect,
		onclose = opts.onclose,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:textview(opts)
	local w = {
		kind = "textview",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		lines = opts.lines or {},
		top = opts.top or 1,
		hscroll = 0,
		cursor = { line = 1, col = 1 },
		anchor = nil,
		current = opts.current or 0,
		gutter = opts.gutter ~= false,
		gutter_mode = opts.gutter_mode or "line",
		bg = opts.bg or self.theme.paper,
		fg = opts.fg or self.theme.ink,
		selbg = opts.selbg,
		selfg = opts.selfg,
		curbg = opts.curbg,
		onactivate = opts.onactivate,
		onrowclick = opts.onrowclick,
		onrightclick = opts.onrightclick,
		onscroll = opts.onscroll,
		maxlen = 1,
		plain = {},
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	self:set_lines(w, w.lines, { keep = false })
	return w
end

function App:splitter(opts)
	local w = {
		kind = "splitter",
		x = opts.x,
		y = opts.y,
		w = opts.w,
		h = opts.h,
		orient = opts.orient or "v",
		value = opts.value or ((opts.orient or "v") == "v" and opts.x or opts.y) or 0,
		min = opts.min or 0,
		max = opts.max or 10000,
		onchange = opts.onchange,
		dirty = true,
	}
	track(self, w, opts)
	self.widgets[#self.widgets + 1] = w
	return w
end

function App:settext(w, text)
	text = text or ""
	if w.text ~= text then
		w.text = text
		if w.kind == "textbox" then
			w.cursor = math.min(w.cursor, #text + 1)
			w.sel_anchor = nil
			self:ensure_cursor(w)
		end
		w.dirty = true
	end
end

local function textbox_range(w)
	local a, b = w.sel_anchor, w.cursor
	if not a then
		return nil
	end
	if a > b then
		a, b = b, a
	end
	if a == b then
		return nil
	end
	return a, b
end

local function textbox_delete_range(w)
	local a, b = textbox_range(w)
	if not a then
		return false
	end
	w.text = w.text:sub(1, a - 1) .. w.text:sub(b)
	w.cursor = a
	w.sel_anchor = nil
	w.dirty = true
	return true
end

local function textbox_selection_text(w)
	local a, b = textbox_range(w)
	if not a then
		return nil
	end
	return w.text:sub(a, b - 1)
end

function App:set_checkbox(w, value)
	value = value and true or false
	if w.value ~= value then
		w.value = value
		w.dirty = true
		if w.onchange then
			w.onchange(w, value)
		end
	end
end

function App:setfrac(w, frac)
	frac = math.min(math.max(frac or 0, 0), 1)
	if w.frac ~= frac then
		w.frac = frac
		w.dirty = true
	end
end

function App:setitems(w, items)
	w.items = items or {}
	w.selected = 0
	w.top = 1
	w.dirty = true
end

function App:select(w, idx)
	idx = math.min(math.max(idx or 0, 0), #w.items)
	if w.selected ~= idx then
		w.selected = idx
		self:ensure_visible(w)
		w.dirty = true
		if idx > 0 and w.onselect then
			w.onselect(w, idx)
		end
	end
end

function App:set_slider(w, value)
	value = math.min(math.max(value, w.min), w.max)
	if w.min % 1 == 0 and w.max % 1 == 0 then
		value = math.floor(value + 0.5)
	end
	if w.value ~= value then
		w.value = value
		w.dirty = true
		if w.onchange then
			w.onchange(w, value)
		end
	end
end

function App:set_radio(w, value)
	value = value and true or false
	if value then
		for _, o in ipairs(self.widgets) do
			if o.kind == "radio" and o.group == w.group and o ~= w and o.value then
				o.value = false
				o.dirty = true
				if o.onchange then
					o.onchange(o, false)
				end
			end
		end
	end
	if w.value ~= value then
		w.value = value
		w.dirty = true
		if w.onchange then
			w.onchange(w, value)
		end
	end
end

function App:radio_step(w, dir)
	local group = {}
	for _, o in ipairs(self.widgets) do
		if o.kind == "radio" and o.group == w.group then
			group[#group + 1] = o
		end
	end
	if #group == 0 then
		return
	end
	local i = 1
	for k, o in ipairs(group) do
		if o == w then
			i = k
			break
		end
	end
	i = (i - 1 + dir) % #group + 1
	self.focus = group[i]
	self:set_radio(group[i], true)
end

function App:spin_round(w, value)
	if w.min % 1 == 0 and w.max % 1 == 0 and w.step % 1 == 0 then
		value = math.floor(value + 0.5)
	end
	return math.min(math.max(value, w.min), w.max)
end

function App:spin_format(w, value)
	if w.min % 1 == 0 and w.max % 1 == 0 and w.step % 1 == 0 then
		return string.format("%d", value)
	end
	return string.format("%.10g", value)
end

function App:spin_commit(w)
	local v = tonumber(w.text)
	if v == nil then
		w.text = self:spin_format(w, w.value)
		w.cursor = #w.text + 1
		w.dirty = true
		return
	end
	v = self:spin_round(w, v)
	if v ~= w.value then
		w.value = v
		if w.onchange then
			w.onchange(w, v)
		end
	end
	w.text = self:spin_format(w, w.value)
	w.cursor = #w.text + 1
	w.dirty = true
end

function App:set_spin(w, value)
	value = self:spin_round(w, value)
	if w.value ~= value then
		w.value = value
		if w.onchange then
			w.onchange(w, value)
		end
	end
	local text = self:spin_format(w, w.value)
	if w.text ~= text then
		w.text = text
		w.cursor = #text + 1
	end
	w.dirty = true
end

function App:spin_step(w, dir)
	self:spin_commit(w)
	self:set_spin(w, w.value + dir * w.step)
end

function App:scroll_maxfirst(w)
	return math.max(1, w.total - w.visible + 1)
end

function App:scroll_clamp(w, first)
	return math.min(math.max(first or 1, 1), self:scroll_maxfirst(w))
end

function App:set_scroll(w, first, visible, total)
	if total ~= nil then
		w.total = math.max(0, total)
	end
	if visible ~= nil then
		w.visible = math.max(1, visible)
	end
	first = self:scroll_clamp(w, first)
	if w.first ~= first then
		w.first = first
		w.dirty = true
		if w.onchange then
			w.onchange(w, first)
		end
	else
		w.dirty = true
	end
end

function App:tree_refresh(w)
	local rows = {}
	local filter = w.filter and w.filter ~= "" and w.filter:lower() or nil
	local function matches(node)
		if not filter then
			return true
		end
		if tostring(node.label or ""):lower():find(filter, 1, true) then
			return true
		end
		for _, c in ipairs(node.children or {}) do
			if matches(c) then
				return true
			end
		end
		return false
	end
	local function walk(node, depth)
		if not matches(node) then
			return
		end
		rows[#rows + 1] = { node = node, depth = depth }
		local open = w.expanded[node] or (filter ~= nil)
		if open then
			for _, c in ipairs(node.children or {}) do
				walk(c, depth + 1)
			end
		end
	end
	for _, n in ipairs(w.nodes or {}) do
		walk(n, 0)
	end
	w.rows = rows
	w.top = math.min(math.max(w.top, 1), math.max(1, #rows))
	w.dirty = true
end

function App:set_tree(w, nodes, opts)
	w.nodes = nodes or {}
	if opts and opts.expanded then
		w.expanded = opts.expanded
	end
	w.selected = nil
	w.top = 1
	self:tree_refresh(w)
end

function App:tree_filter(w, text)
	text = text or ""
	if w.filter ~= text then
		w.filter = text
		self:tree_refresh(w)
	end
end

function App:tree_expand(w, node, open)
	open = open and true or false
	if w.expanded[node] ~= open then
		w.expanded[node] = open
		self:tree_refresh(w)
	end
end

function App:tree_select(w, node, silent)
	w.selected = node
	local idx
	for i, r in ipairs(w.rows or {}) do
		if r.node == node then
			idx = i
			break
		end
		if idx == nil and r.node == node then
			idx = i
		end
	end
	if idx then
		local rows = self:tree_visible_rows(w)
		if idx < w.top then
			w.top = idx
		elseif idx >= w.top + rows then
			w.top = idx - rows + 1
		end
	end
	w.dirty = true
	if not silent and w.onselect then
		w.onselect(w, node)
	end
end

function App:tree_visible_rows(w)
	return math.max(1, (w.h - 4) // (w.row_h or (self.ch + 6)))
end

function App:tree_row_at(w, px, py)
	if px < w.x or px >= w.x + w.w or py < w.y + 2 then
		return nil
	end
	local i = (py - (w.y + 2)) // (w.row_h or (self.ch + 6))
	local rows = self:tree_visible_rows(w)
	if i < 0 or i >= rows then
		return nil
	end
	local idx = (w.top or 1) + i
	local row = w.rows and w.rows[idx]
	if row then
		return idx, row.node, row.depth
	end
	return nil
end

function App:set_tabs(w, tabs, selected)
	w.tabs = tabs or {}
	w.selected = selected or (w.selected <= #w.tabs and w.selected or 0)
	w.first = 1
	w.dirty = true
end

function App:tab_add(w, tab, select)
	w.tabs[#w.tabs + 1] = tab
	if select then
		w.selected = #w.tabs
	end
	w.dirty = true
	return #w.tabs
end

function App:tab_remove(w, idx)
	idx = idx or w.selected
	if idx < 1 or idx > #w.tabs then
		return
	end
	table.remove(w.tabs, idx)
	if w.selected > #w.tabs then
		w.selected = #w.tabs
	elseif w.selected >= idx and w.selected > 1 then
		w.selected = w.selected - 1
	end
	if w.first > #w.tabs then
		w.first = math.max(1, #w.tabs)
	end
	w.dirty = true
end

function App:select_tab(w, idx)
	idx = math.min(math.max(idx or 0, 0), #w.tabs)
	if w.selected ~= idx then
		w.selected = idx
		self:tab_ensure(w, idx)
		w.dirty = true
		if idx > 0 and w.onselect then
			w.onselect(w, idx, w.tabs[idx])
		end
	end
end

function App:tab_ensure(w, idx)
	if not idx or idx < 1 then
		return
	end
	w.first = math.max(1, math.min(w.first or 1, idx))
	local avail = (w.w or 100) - 2
	local function span(from, to)
		local n = 0
		for i = from, to do
			n = n + self:tab_width(w.tabs[i])
		end
		return n
	end
	while w.first < idx and span(w.first, idx) > avail do
		w.first = w.first + 1
	end
end

function App:tab_width(t)
	local n = utf8.len(tostring(t.label or "?")) + (t.closable and 5 or 3)
	return math.min(180, math.max(64, n * self.cw + 12))
end

function App:tab_layout(w)
	local x = w.x + 1
	local tabs = {}
	for i, t in ipairs(w.tabs) do
		local tw = self:tab_width(t)
		tabs[i] = { x = x, w = tw, tab = t }
		x = x + tw
	end
	return tabs
end

function App:tab_at(w, px, py)
	if py < w.y or py >= w.y + w.h then
		return nil
	end
	local tabs = self:tab_layout(w)
	for i, tb in ipairs(tabs) do
		if px >= tb.x and px < tb.x + tb.w then
			return i, tb
		end
	end
	return nil
end

function App:set_lines(w, lines, opts)
	opts = opts or {}
	w.lines = lines or {}
	w.plain = {}
	w.maxlen = 1
	w.hscroll = math.min(w.hscroll or 0, 100000)
	for i, l in ipairs(w.lines) do
		local text = type(l) == "table" and l.text or tostring(l)
		w.plain[i] = text
		local n = utf8.len(text)
		if n > w.maxlen then
			w.maxlen = n
		end
	end
	if not opts.keep then
		w.top = 1
		w.cursor = { line = 1, col = 1 }
		w.anchor = nil
		w.current = 0
		w.hscroll = 0
	end
	w.top = math.min(math.max(w.top or 1, 1), math.max(1, #w.lines))
	w.dirty = true
end

function App:textview_rows(w)
	local hh = w.h - 2
	if self:text_hscroll(w) then
		hh = hh - 8
	end
	return math.max(1, hh // self.ch)
end

function App:textview_vbar(w)
	local rows = self:textview_rows(w)
	if #w.lines <= rows then
		return nil
	end
	local tx = w.x + w.w - 8
	local ty = w.y + 2
	local th = w.h - 4 - (self:text_hscroll(w) and 8 or 0)
	local total = #w.lines
	local thumb = math.max(8, th * rows // total)
	local maxfirst = math.max(1, total - rows + 1)
	local frac = maxfirst > 1 and ((w.top - 1) / (maxfirst - 1)) or 0
	local oy = ty + math.floor((th - thumb) * frac + 0.5)
	return { x = tx + 1, y = oy, w = 6, h = thumb,
		track_y = ty, track_h = th, thumb = thumb }
end

function App:textview_hbar(w)
	if not self:text_hscroll(w) then
		return nil
	end
	local gw = self:text_gutter(w)
	local maxcols = math.max(1, (w.w - gw - 8) // self.cw)
	local hy = w.y + w.h - 8
	local span = w.maxlen + maxcols
	local tw = math.max(16, (w.w - 8) * maxcols // math.max(span, 1))
	local maxh = math.max(1, w.maxlen - maxcols + 1)
	local frac = (w.hscroll or 0) / math.max(1, maxh)
	local tx = w.x + math.floor((w.w - 8 - tw) * frac)
	return { x = tx, y = hy + 1, w = tw, h = 6,
		track_x = w.x, track_w = w.w - 8, thumb = tw, maxh = maxh }
end

function App:textview_drag_to(w, x, y)
	if w.grab_axis == "v" then
		local vb = self:textview_vbar(w)
		if vb then
			local span = vb.track_h - vb.thumb
			local off = w.grab_off or (vb.thumb // 2)
			local frac = span > 0 and ((y - vb.track_y - off) / span) or 0
			frac = math.min(1, math.max(0, frac))
			local rows = self:textview_rows(w)
			local maxfirst = math.max(1, #w.lines - rows + 1)
			w.top = 1 + math.floor(frac * (maxfirst - 1) + 0.5)
			w.dirty = true
		end
	elseif w.grab_axis == "h" then
		local hb = self:textview_hbar(w)
		if hb then
			local span = hb.track_w - hb.thumb
			local off = w.grab_off or (hb.thumb // 2)
			local frac = span > 0 and ((x - hb.track_x - off) / span) or 0
			frac = math.min(1, math.max(0, frac))
			w.hscroll = math.floor(frac * hb.maxh + 0.5)
			w.dirty = true
		end
	end
end

function App:text_hscroll(w)
	local gw = self:text_gutter(w)
	return gw + w.maxlen * self.cw + 4 > w.w - 8
end

function App:text_gutter(w)
	if not w.gutter then
		return 0
	end
	local n = #w.lines
	local digits = 1
	while n >= 10 do
		n = n // 10
		digits = digits + 1
	end
	if w.gutter_mode == "pc" then
		digits = math.max(digits, 4)
	end
	return digits * self.cw + 10
end

function App:show_line(w, line, center)
	line = math.min(math.max(line or 1, 1), math.max(1, #w.lines))
	local rows = self:textview_rows(w)
	if center then
		w.top = math.max(1, line - rows // 2)
	elseif line < (w.top or 1) then
		w.top = line
	elseif line >= (w.top or 1) + rows then
		w.top = line - rows + 1
	end
	w.current = line
	w.dirty = true
end

function App:set_current(w, line, scroll)
	w.current = line
	if line and line >= 1 then
		self:show_line(w, line, scroll)
	end
end

function App:text_col_at(w, px, line)
	local gw = self:text_gutter(w)
	local col = (px - (w.x + gw + 4)) // self.cw + 1 + (w.hscroll or 0)
	local n = utf8.len(w.plain[line] or "") + 1
	return math.max(1, math.min(col, n))
end

function App:text_line_at(w, py)
	local y0 = w.y + 1
	local i = (py - y0) // self.ch
	local line = (w.top or 1) + i
	if i < 0 or i >= self:textview_rows(w) or line < 1 or line > #w.lines then
		return nil
	end
	return line
end

function App:text_selection(w)
	if not w.anchor then
		return nil
	end
	local a, b = w.anchor, w.cursor
	if a.line > b.line or (a.line == b.line and a.col > b.col) then
		a, b = b, a
	end
	if a.line == b.line and a.col == b.col then
		return nil
	end
	return a, b
end

function App:selection_text(w)
	local a, b = self:text_selection(w)
	if not a then
		return ""
	end
	local out = {}
	for line = a.line, b.line do
		local text = w.plain[line] or ""
		local c1 = (line == a.line) and a.col or 1
		local c2 = (line == b.line) and b.col or (#text + 1)
		out[#out + 1] = text:sub(c1, c2 - 1)
	end
	return table.concat(out, "\n")
end

function App:copy_selection(w)
	local text = self:selection_text(w)
	if text ~= "" and self.client then
		self.client:clip_set(text)
		return text
	end
	return nil
end

function App:onkey(fn)
	self.keyhandler = fn
end

function App:onclose(fn)
	self.closehandler = fn
end

function App:onrightclick(fn)
	self.rightclick = fn
end

function App:ontick(secs, fn)
	self.tick_secs = (type(secs) == "number" and secs > 0) and secs or 2
	self.tick_fn = fn
	self.tick_last = nil
	self.tick_count = 0
end

function App:row_height()
	return self.ch + 4
end

function App:visible_rows(w)
	if w.kind == "dropdown" then
		return self:dropdown_prows(w)
	end
	if w.kind == "menubutton" then
		return self:menu_prows(w)
	end
	return math.max(1, (w.h - 4) // self:row_height())
end

function App:ensure_visible(w)
	if w.kind == "dropdown" then
		self:dropdown_top(w)
		return
	end
	if w.kind == "menubutton" then
		self:menu_top(w)
		return
	end
	local rows = self:visible_rows(w)
	if w.selected < w.top then
		w.top = w.selected
	end
	if w.selected > w.top + rows - 1 then
		w.top = w.selected - rows + 1
	end
	if w.top < 1 then
		w.top = 1
	end
end

function App:row_at(w, px, py)
	local y0 = w.y + 2
	if px < w.x or px >= w.x + w.w or py < y0 then
		return nil
	end
	local i = (py - y0) // self:row_height()
	if i < 0 or i >= self:visible_rows(w) then
		return nil
	end
	local idx = w.top + i
	if idx < 1 or idx > #w.items then
		return nil
	end
	return idx
end

function App:ensure_cursor(w)
	local maxn = math.max(1, (w.w - 10) // self.cw)
	if w.cursor < w.scroll then
		w.scroll = w.cursor
	end
	if w.cursor > w.scroll + maxn - 1 then
		w.scroll = w.cursor - maxn + 1
	end
	if w.scroll < 1 then
		w.scroll = 1
	end
	w.cursor = math.min(math.max(w.cursor, 1), #w.text + 1)
end

function App:ensure_spin_cursor(w)
	local maxn = math.max(1, (w.w - 2 * self:spin_btn() - 10) // self.cw)
	if w.cursor < w.scroll then
		w.scroll = w.cursor
	end
	if w.cursor > w.scroll + maxn - 1 then
		w.scroll = w.cursor - maxn + 1
	end
	if w.scroll < 1 then
		w.scroll = 1
	end
	w.cursor = math.min(math.max(w.cursor, 1), #w.text + 1)
end

function App:spin_btn()
	return 18
end

function App:drop_btn()
	return 18
end

function App:dropdown_prows(w)
	local below = (self.H - (w.y + w.h) - 2) // self:row_height()
	local above = (w.y - 2) // self:row_height()
	local room = math.max(below, above)
	return math.min(math.max(#w.items, 1), 8, math.max(room, 1))
end

function App:dropdown_popup(w)
	local rows = self:dropdown_prows(w)
	local h = rows * self:row_height() + 4
	local y = w.y + w.h + 1
	if y + h > self.H - 1 and w.y - 1 - h >= 0 then
		y = w.y - 1 - h
	end
	return w.x, y, w.w, h, rows
end

function App:dropdown_top(w)
	local _, _, _, _, rows = self:dropdown_popup(w)
	if w.selected > 0 then
		if w.selected < w.top then
			w.top = w.selected
		end
		if w.selected > w.top + rows - 1 then
			w.top = w.selected - rows + 1
		end
	end
	if w.top < 1 then
		w.top = 1
	end
	local maxfirst = math.max(1, #w.items - rows + 1)
	if w.top > maxfirst then
		w.top = maxfirst
	end
end

function App:dropdown_row_at(w, px, py)
	local x, y, pw, ph, rows = self:dropdown_popup(w)
	if px < x or px >= x + pw or py < y + 2 then
		return nil
	end
	local i = (py - (y + 2)) // self:row_height()
	if i < 0 or i >= rows then
		return nil
	end
	local idx = w.top + i
	if idx < 1 or idx > #w.items then
		return nil
	end
	return idx
end

function App:menu_prows(w)
	local below = (self.H - (w.y + w.h) - 2) // self:row_height()
	local above = (w.y - 2) // self:row_height()
	local room = math.max(below, above)
	return math.min(math.max(#w.items, 1), 8, math.max(room, 1))
end

function App:menu_popup(w)
	local rows = self:menu_prows(w)
	local h = rows * self:row_height() + 4
	local y = w.y + w.h + 1
	if y + h > self.H - 1 and w.y - 1 - h >= 0 then
		y = w.y - 1 - h
	end
	local pw = w.w or 40
	for _, it in ipairs(w.items or {}) do
		pw = math.max(pw, utf8.len(tostring(it)) * self.cw + 12)
	end
	local x = w.x
	if x + pw > self.W - 1 then
		x = math.max(0, self.W - 1 - pw)
	end
	return x, y, pw, h, rows
end

function App:menu_top(w)
	local _, _, _, _, rows = self:menu_popup(w)
	if w.selected > 0 then
		if w.selected < w.top then
			w.top = w.selected
		end
		if w.selected > w.top + rows - 1 then
			w.top = w.selected - rows + 1
		end
	end
	if w.top < 1 then
		w.top = 1
	end
	local maxfirst = math.max(1, #w.items - rows + 1)
	if w.top > maxfirst then
		w.top = maxfirst
	end
end

function App:menu_row_at(w, px, py)
	local x, y, pw, ph, rows = self:menu_popup(w)
	if px < x or px >= x + pw or py < y + 2 then
		return nil
	end
	local i = (py - (y + 2)) // self:row_height()
	if i < 0 or i >= rows then
		return nil
	end
	local idx = w.top + i
	if idx < 1 or idx > #w.items then
		return nil
	end
	return idx
end

function App:menu_highlight(w, idx)
	idx = math.min(math.max(idx or 0, 0), #w.items)
	if w.selected ~= idx then
		w.selected = idx
		self:menu_top(w)
		w.dirty = true
	end
end

function App:close_dropdowns(except)
	local closed = false
	for _, o in ipairs(self.widgets) do
		if (o.kind == "dropdown" or o.kind == "menubutton") and o.open and o ~= except then
			o.open = false
			closed = true
			if o.kind == "menubutton" then
				o.selected = 0
				o.top = 1
			end
		end
	end

	if closed then
		self:dirtyAll()
	end
end

function App:set_dropdown(w, open)
	open = open and true or false
	if w.open ~= open then
		w.open = open
		self:dirtyAll()
	else
		w.dirty = true
	end
end

function App:set_menu(w, open)
	open = open and true or false
	if w.open ~= open then
		w.open = open
		if open then
			w.selected = (#w.items > 0) and 1 or 0
			w.top = 1
			self:menu_top(w)
		else
			w.selected = 0
			w.top = 1
		end
		self:dirtyAll()
	else
		w.dirty = true
	end
end

function App:menu_step(w, dir)
	local bars = {}
	for _, o in ipairs(self.widgets) do
		if o.kind == "menubutton" then
			bars[#bars + 1] = o
		end
	end
	if #bars == 0 then
		return
	end
	local i = 1
	for k, o in ipairs(bars) do
		if o == w then
			i = k
			break
		end
	end
	i = (i - 1 + dir) % #bars + 1
	self:close_dropdowns(bars[i])
	self.focus = bars[i]
	self:set_menu(bars[i], true)
end

function App:popup(items, x, y, onpick)
	items = items or {}
	local w = 40
	for _, it in ipairs(items) do
		w = math.max(w, utf8.len(tostring(it)) * self.cw + 12)
	end
	local rows = math.min(math.max(#items, 1), 8)
	local h = rows * self:row_height() + 4
	x = math.max(0, math.min(math.floor(x or 0), math.max(0, self.W - w)))
	y = math.max(0, math.min(math.floor(y or 0), math.max(0, self.H - h)))
	self:close_dropdowns(nil)
	self.pop = {
		items = items,
		x = x,
		y = y,
		w = w,
		h = h,
		rows = rows,
		selected = (#items > 0) and 1 or 0,
		top = 1,
		onpick = onpick,
	}
	self.popdirty = true
	self:dirtyAll()
end

function App:close_popup()
	if self.pop then
		self.pop = nil
		self.popdirty = true
		self:dirtyAll()
	end
end

function App:validpop()
	local p = self.pop
	if type(p) == "table" and type(p.items) == "table" then
		return p
	end
	if p ~= nil then
		self.pop = nil
		self.popdirty = true
		self:dirtyAll()
	end
	return nil
end

function App:pop_top(p)
	if type(p) ~= "table" then
		return
	end
	if p.selected > 0 then
		if p.selected < p.top then
			p.top = p.selected
		end
		if p.selected > p.top + p.rows - 1 then
			p.top = p.selected - p.rows + 1
		end
	end
	if p.top < 1 then
		p.top = 1
	end
	local maxfirst = math.max(1, #p.items - p.rows + 1)
	if p.top > maxfirst then
		p.top = maxfirst
	end
end

function App:pop_row_at(p, px, py)
	if type(p) ~= "table" then
		return nil
	end
	if px < p.x or px >= p.x + p.w or py < p.y + 2 then
		return nil
	end
	local i = (py - (p.y + 2)) // self:row_height()
	if i < 0 or i >= p.rows then
		return nil
	end
	local idx = p.top + i
	if idx < 1 or idx > #p.items then
		return nil
	end
	return idx
end

function App:pop_highlight(p, idx)
	if type(p) ~= "table" or type(p.items) ~= "table" then
		return
	end
	idx = math.min(math.max(idx or 0, 0), #p.items)
	if p.selected ~= idx then
		p.selected = idx
		self:pop_top(p)
		self.popdirty = true
	end
end

function App:scroll_geom(w)
	local b = math.min(w.w, 20)
	local up = { x = w.x, y = w.y, w = w.w, h = b }
	local down = { x = w.x, y = w.y + w.h - b, w = w.w, h = b }
	local tx, ty, th = w.x, w.y + b, w.h - 2 * b
	if th < 1 then
		th = 1
	end
	local total = math.max(w.total, 1)
	local frac = math.min(w.visible, total) / total
	local kh = math.max(8, math.floor(th * frac + 0.5))
	if kh > th then
		kh = th
	end
	local maxfirst = self:scroll_maxfirst(w)
	local ky = ty
	if maxfirst > 1 then
		ky = ty + math.floor((th - kh) * (w.first - 1) / (maxfirst - 1) + 0.5)
	end
	return up, { x = tx, y = ty, w = w.w, h = th }, down, ky, kh
end

function App:scroll_drag_to(w, py)
	local _, track, _, _, kh = self:scroll_geom(w)
	local span = track.h - kh
	local maxfirst = self:scroll_maxfirst(w)
	if span < 1 or maxfirst <= 1 then
		return
	end
	local off = w.grab or 0
	local frac = (py - off - track.y) / span
	self:set_scroll(w, math.floor(frac * (maxfirst - 1) + 1.5))
end

local function paint_tree(a, c, win, w)
	local t = a.theme
	local rh = w.row_h or (a.ch + 6)
	a:tree_refresh(w)
	c:fill(win, w.x, w.y, w.w, w.h, t.paper or 0xFFFFFF)
	if t.lo then
		c:fill(win, w.x, w.y, w.w, 1, t.lo)
		c:fill(win, w.x, w.y, 1, w.h, t.lo)
		c:fill(win, w.x, w.y + w.h - 1, w.w, 1, t.hi or t.lo)
		c:fill(win, w.x + w.w - 1, w.y, 1, w.h, t.hi or t.lo)
	end
	local rows = w.rows or {}
	local vis = a:tree_visible_rows(w)
	local scrolls = #rows > vis
	local tw = w.w - (scrolls and 10 or 4)
	for i = 0, vis - 1 do
		local idx = (w.top or 1) + i
		local row = rows[idx]
		if not row then
			break
		end
		local y = w.y + 2 + i * rh
		local sel = (row.node == w.selected)
		if sel then
			c:fill(win, w.x + 1, y, tw, rh, t.selbg or 0x3050A0)
		end
		local node = row.node
		local x = w.x + 4 + row.depth * (w.indent or 12)
		if node.children and #node.children > 0 then
			local ax, ay = x + 3, y + rh // 2 - 2
			local col = sel and (t.selfg or 0xFFFFFF) or (t.ink or 0)
			if w.expanded[node] then
				for k = 0, 2 do
					c:fill(win, ax - 2 + k, ay + k, 5 - 2 * k, 1, col)
				end
			else
				for k = 0, 2 do
					c:fill(win, ax - 2 + k, ay - 2 + k, 1, 5 - 2 * k, col)
				end
			end
		end
		x = x + 10
		if node.icon then
			local ic = tostring(node.icon)
			c:text(win, x, y + (rh - a.ch) // 2, ic:sub(1, 2), sel and (t.selfg or 0xFFFFFF) or (node.color or t.ink or 0), false)
			x = x + a.cw * 3
		end
		local label = tostring(node.label or "")
		local avail = (tw - (x - w.x) - 6) // a.cw
		if node.badge then
			local bs = tostring(node.badge)
			avail = avail - #bs - 2
		end
		if avail > 0 and utf8.len(label) > avail then
			label = label:sub(1, avail - 1) .. "~"
		end
		if avail > 0 then
			c:text(win, x, y + (rh - a.ch) // 2, label, sel and (t.selfg or 0xFFFFFF) or (node.color or t.ink or 0), false)
		end
		if node.badge then
			local bs = tostring(node.badge)
			c:text(win, w.x + tw - 4 - #bs * a.cw, y + (rh - a.ch) // 2, bs,
				sel and (t.selfg or 0xFFFFFF) or (t.disabled or t.ink or 0), false)
		end
	end
	if scrolls then
		local tx = w.x + w.w - 8
		local ty = w.y + 2
		local th = w.h - 4
		c:fill(win, tx, ty, 6, th, t.track or t.paper or 0xFFFFFF)
		local thumb = math.max(8, (th * vis) // #rows)
		local maxfirst = math.max(1, #rows - vis + 1)
		local frac = maxfirst > 1 and ((w.top - 1) / (maxfirst - 1)) or 0
		local oy = ty + math.floor((th - thumb) * frac + 0.5)
		c:fill(win, tx + 1, oy, 4, thumb, t.selbd or t.selbg or t.lo or 0x808080)
	end
end

local function paint_tabbar(a, c, win, w)
	local t = a.theme
	c:fill(win, w.x, w.y, w.w, w.h, t.menuBody or t.face or 0xE8E8E8)
	local tabs = a:tab_layout(w)
	local active
	for i, tb in ipairs(tabs) do
		local x, tw = tb.x, tb.w
		if x + tw > w.x + w.w - 2 then
			break
		end
		local sel = (tb.index == w.selected)
		if sel then
			active = tb
			c:fill(win, x, w.y + 1, tw, w.h - 1, a.bg)
			c:fill(win, x, w.y + 1, tw, 1, t.hoverBorder or t.selbd or t.border or 0x808080)
			c:fill(win, x, w.y + 1, 1, w.h - 1, t.border or 0x808080)
			c:fill(win, x + tw - 1, w.y + 1, 1, w.h - 1, t.border or 0x808080)
		else
			c:fill(win, x, w.y + 3, tw, w.h - 3, t.menuBody or t.face or 0xE8E8E8)
			c:fill(win, x + tw - 1, w.y + 3, 1, w.h - 3, t.sep or t.border or 0x808080)
		end
		local label = tostring(tb.tab.label or "?")
		local closew = tb.tab.closable and a.cw + 4 or 0
		local maxn = (tw - closew - 12) // a.cw
		if maxn < 1 then maxn = 1 end
		if utf8.len(label) > maxn then
			label = label:sub(1, maxn - 1) .. "~"
		end
		c:text(win, x + 6, w.y + (w.h - a.ch) // 2, label, t.ink or 0, false)
		if tb.tab.dirty then
			c:fill(win, x + tw - closew - 7, w.y + (w.h - a.ch) // 2, 4, 4, t.selbg or 0x3050A0)
		end
		if tb.tab.closable then
			local cx = x + tw - a.cw - 6
			local cy = w.y + (w.h - a.ch) // 2
			c:fill(win, cx, cy + 2, a.cw, 1, t.ink or 0)
			c:fill(win, cx + a.cw - 1, cy + 2, 1, a.ch - 4, t.ink or 0)
			c:fill(win, cx + a.cw // 2 - 1, cy + 2, 1, a.ch - 4, t.ink or 0)
		end
	end
	if active and active.x > w.x + w.w - 20 then
		c:text(win, w.x + w.w - 12, w.y + 3, ">", t.ink or 0, false)
	end
	c:fill(win, w.x, w.y + w.h - 1, w.w, 1, t.border or t.sep or 0x808080)
end

local function paint_textview(a, c, win, w)
	local t = a.theme
	local bg = w.bg or t.paper or 0xFFFFFF
	local fg = w.fg or t.ink or 0
	local selbg = w.selbg or t.selbg or 0xCCE4F7
	local selfg = w.selfg or t.selfg or fg
	local curbg = w.curbg or t.selbgIn or 0xF0F4F8
	c:fill(win, w.x, w.y, w.w, w.h, bg)
	local gw = a:text_gutter(w)
	local rows = a:textview_rows(w)
	local hscroll = w.hscroll or 0
	local codex = w.x + gw + 4
	local maxcols = math.max(1, (w.w - gw - 8) // a.cw)
	local sa, sb = a:text_selection(w)
	for i = 0, rows - 1 do
		local line = (w.top or 1) + i
		local text = w.plain[line]
		if text == nil then
			break
		end
		local y = w.y + 2 + i * a.ch
		local lineinfo = type(w.lines[line]) == "table" and w.lines[line] or nil
		if lineinfo and lineinfo.bg then
			c:fill(win, w.x + 1, y, w.w - (a:text_hscroll(w) and 8 or 2), a.ch, lineinfo.bg)
		end
		if line == w.current then
			c:fill(win, w.x + 1, y, w.w - (a:text_hscroll(w) and 8 or 2), a.ch, curbg)
		end
		if sa and line >= sa.line and line <= sb.line then
			local c1 = (line == sa.line) and sa.col or 1
			local c2 = (line == sb.line) and sb.col or (#text + 1)
			local v1 = math.max(c1, hscroll + 1)
			local v2 = math.min(c2, hscroll + maxcols + 1)
			if v2 > v1 then
				c:fill(win, codex + (v1 - hscroll - 1) * a.cw, y,
					(v2 - v1) * a.cw, a.ch, selbg)
			end
		end
		if w.gutter then
			local gx = w.x + 6
			local num = lineinfo and lineinfo.gutter or line
			local ns = w.gutter_mode == "pc" and string.format("%04X", (num or 0) - 1) or tostring(num)
			c:text(win, w.x + gw - 6 - #ns * a.cw, y, ns, t.disabled or 0x707070, false)
		end
		local shown = text
		local n = utf8.len(shown)
		if n > hscroll then
			shown = shown:sub(hscroll + 1)
		else
			shown = ""
		end
		if utf8.len(shown) > maxcols then
			shown = shown:sub(1, maxcols)
		end
		if shown ~= "" then
			c:text(win, codex, y, shown, fg, false)
		end
		if lineinfo and lineinfo.spans then
			for _, sp in ipairs(lineinfo.spans) do
				local st = sp.col or 1
				local ln = sp.len or 1
				local en = st + ln
				local v1 = math.max(st, hscroll + 1)
				local v2 = math.min(en, hscroll + maxcols + 1)
				if v2 > v1 and text:sub(v1, v2 - 1) ~= "" then
					c:text(win, codex + (v1 - hscroll - 1) * a.cw, y,
						text:sub(v1, v2 - 1), sp.color or fg, false)
				end
			end
		end
		if lineinfo and lineinfo.marker then
			c:fill(win, w.x + 1, y, 3, a.ch, lineinfo.markerc or 0xE0A020)
		end
	end
	if w.gutter then
		c:fill(win, w.x + gw - 1, w.y, 1, w.h - (a:text_hscroll(w) and 8 or 0), t.sep or t.lo or 0x808080)
	end
	if a:text_hscroll(w) then
		local hy = w.y + w.h - 8
		c:fill(win, w.x, hy, w.w - 8, 8, t.track or 0xEEEEEE)
		local span = w.maxlen + maxcols
		local tw = math.max(16, (w.w - 8) * maxcols // math.max(span, 1))
		local maxh = math.max(1, w.maxlen - maxcols + 1)
		local tx = w.x + math.floor((w.w - 8 - tw) * (hscroll / math.max(1, maxh)))
		c:fill(win, tx, hy + 1, tw, 6, t.selbd or t.lo or 0x808080)
	end
	if #w.lines > rows then
		local tx = w.x + w.w - 8
		local ty = w.y + 2
		local th = w.h - 4 - (a:text_hscroll(w) and 8 or 0)
		c:fill(win, tx, ty, 8, th, t.track or 0xEEEEEE)
		local total = #w.lines
		local thumb = math.max(8, th * rows // total)
		local maxfirst = math.max(1, total - rows + 1)
		local frac = maxfirst > 1 and ((w.top - 1) / (maxfirst - 1)) or 0
		local oy = ty + math.floor((th - thumb) * frac + 0.5)
		c:fill(win, tx + 1, oy, 6, thumb, t.selbd or t.lo or 0x808080)
	end
end

local function paint_splitter(a, c, win, w)
	local t = a.theme
	c:fill(win, w.x, w.y, w.w, w.h, a.bg)
	if w.orient == "v" then
		local gx = w.x + w.w // 2
		c:fill(win, gx, w.y, 1, w.h, t.sep or t.lo or 0x808080)
		for k = -2, 2 do
			c:fill(win, gx + k, w.y + w.h // 2 - 6, 1, 12, t.hi or 0xE8E8E8)
		end
	else
		local gy = w.y + w.h // 2
		c:fill(win, w.x, gy, w.w, 1, t.sep or t.lo or 0x808080)
		for k = -2, 2 do
			c:fill(win, w.x + w.w // 2 - 6, gy + k, 12, 1, t.hi or 0xE8E8E8)
		end
	end
end

local P = {}
M.themes.classic.painters = P
P.tree = paint_tree
P.tabbar = paint_tabbar
P.textview = paint_textview
P.splitter = paint_splitter

function P.button(a, c, win, w)
	local t = a.theme
	if w.pressed then
		bevel(c, win, w.x, w.y, w.w, w.h, a.bg, t.lo, t.hi)
	else
		bevel(c, win, w.x, w.y, w.w, w.h, a.bg, t.hi, t.lo)
	end
	local kw = utf8.len(w.label) * a.cw
	c:text(win, w.x + (w.w - kw) // 2, w.y + (w.h - a.ch) // 2, w.label, t.ink, false)
end

function P.label(a, c, win, w)
	local t = a.theme
	bevel(c, win, w.x, w.y, w.w, w.h, w.bg, t.lo, t.hi)
	local shown = w.text
	local maxn = (w.w - 10) // a.cw
	if utf8.len(shown) > maxn then
		if w.align == "right" then
			shown = shown:sub(utf8.offset(shown, utf8.len(shown) - maxn + 1))
		else
			shown = shown:sub(1, maxn)
		end
	end
	local tw = utf8.len(shown) * a.cw
	local tx
	if w.align == "right" then
		tx = w.x + w.w - 5 - tw
	else
		tx = w.x + 5
	end
	c:text(win, tx, w.y + (w.h - a.ch) // 2, shown, w.fg, false)
end

local function paint_textbox_content(a, c, win, w, x, ty, shown, fg, selbg, selfg)
	local sa, sb = textbox_range(w)
	if sa then
		local rel1 = math.max(sa - (w.scroll or 1) + 1, 1)
		local rel2 = math.min(sb - (w.scroll or 1), #shown + 1)
		if rel2 > rel1 then
			local before = shown:sub(1, rel1 - 1)
			local sel = shown:sub(rel1, rel2 - 1)
			local after = shown:sub(rel2)
			local sx = x
			if before ~= "" then
				c:text(win, sx, ty, before, fg, false)
				sx = sx + #before * a.cw
			end
			c:fill(win, sx, ty, #sel * a.cw, a.ch, selbg or 0x3050A0)
			c:text(win, sx, ty, sel, selfg or fg, false)
			sx = sx + #sel * a.cw
			if after ~= "" then
				c:text(win, sx, ty, after, fg, false)
			end
			return
		end
	end
	if shown ~= "" then
		c:text(win, x, ty, shown, fg, false)
	end
end

function P.textbox(a, c, win, w)
	local t = a.theme
	local focused = (a.focus == w) and a.window_focused ~= false
	bevel(c, win, w.x, w.y, w.w, w.h, t.paper, t.lo, t.hi)
	a:ensure_cursor(w)
	local maxn = math.max(1, (w.w - 10) // a.cw)
	local shown = w.text:sub(w.scroll, w.scroll + maxn - 1)
	if w.noecho and shown ~= "" then
		shown = string.rep("*", #shown)
	end
	local ty = w.y + (w.h - a.ch) // 2
	paint_textbox_content(a, c, win, w, w.x + 5, ty, shown, t.ink, t.selbg, t.selfg)
	if focused then
		local rel = w.cursor - w.scroll
		local ch = w.text:sub(w.cursor, w.cursor)
		if ch == "" then
			ch = " "
		end
		if w.noecho and ch ~= " " then
			ch = "*"
		end
		if rel >= 0 and rel < maxn then
			c:text(win, w.x + 5 + rel * a.cw, ty, ch, t.paper, t.ink)
		end
	end
end

function P.checkbox(a, c, win, w)
	local t = a.theme
	local ty = w.y + (w.h - a.ch) // 2
	bevel(c, win, w.x, ty, a.ch + 4, a.ch + 4, t.paper, t.lo, t.hi)
	if w.value then
		c:text(win, w.x + 2, ty + 2, "X", t.ink, false)
	end
	if w.label ~= "" then
		c:text(win, w.x + a.ch + 8, ty, w.label, t.ink, false)
	end
end

function P.listbox(a, c, win, w)
	local t = a.theme
	local RH = a:row_height()
	local rows = a:visible_rows(w)
	a:ensure_visible(w)

	bevel(c, win, w.x, w.y, w.w, w.h, t.paper, t.lo, t.hi)
	local total = #w.items
	local scrolls = total > rows
	local tw = (w.w - 8)
	if scrolls then
		tw = (w.w - 16)
	end
	local cols = tw // a.cw
	for i = 0, rows - 1 do
		local idx = w.top + i
		local item = w.items[idx]
		if item == nil then
			break
		end
		local y = w.y + 2 + i * RH
		local bg = (idx == w.selected) and t.selbg or t.paper
		local fg = (idx == w.selected) and t.selfg or t.ink
		c:fill(win, w.x + 1, y, w.w - 2, RH, bg)
		c:text(win, w.x + 4, y + (RH - a.ch) // 2, tostring(item):sub(1, cols), fg, false)
	end
	if scrolls then
		local tx = w.x + w.w - 7
		local ty = w.y + 3
		local th = math.max(1, w.h - 6)
		c:fill(win, tx, ty, 5, th, t.paper)
		local thumb = math.max(8, (th * rows) // total)
		local maxfirst = math.max(1, total - rows + 1)
		local frac = maxfirst > 1 and ((w.top - 1) / (maxfirst - 1)) or 0
		local oy = ty + math.floor((th - thumb) * frac + 0.5)
		c:fill(win, tx + 1, oy, 3, thumb, t.selbg or t.lo)
		c:fill(win, tx + 1, oy, 1, thumb, t.hi)
	end
end

function P.slider(a, c, win, w)
	local t = a.theme
	local ty = w.y + (w.h - 6) // 2
	c:fill(win, w.x, w.y, w.w, w.h, a.bg)
	bevel(c, win, w.x + 1, ty, w.w - 2, 6, a.bg, t.lo, t.hi)
	local span = w.max - w.min
	local frac = (span > 0) and ((w.value - w.min) / span) or 0
	local kw = 12
	local kx = w.x + 1 + math.floor(frac * (w.w - 2 - kw) + 0.5)
	bevel(c, win, kx, w.y + 2, kw, w.h - 4, a.bg, t.hi, t.lo)
end

function P.progress(a, c, win, w)
	local t = a.theme
	bevel(c, win, w.x, w.y, w.w, w.h, t.paper, t.lo, t.hi)
	local inner = w.w - 4
	local fill = math.floor(w.frac * inner + 0.5)
	if fill > 0 then
		c:fill(win, w.x + 2, w.y + 2, fill, w.h - 4, t.selbg)
	end
end

function P.frame(a, c, win, w)
	local t = a.theme
	bevel(c, win, w.x, w.y, w.w, w.h, a.bg, t.hi, t.lo)
	if w.title ~= "" then
		local tx = w.x + 10
		local ty = w.y + 1
		local tw = utf8.len(w.title) * a.cw
		c:fill(win, tx - 3, w.y, tw + 6, a.ch + 2, a.bg)
		c:text(win, tx, ty, w.title, t.ink, false)
	end
end

function P.separator(a, c, win, w)
	local t = a.theme
	if w.vertical then
		local gx = w.x + (w.w - 2) // 2
		c:fill(win, gx, w.y, 1, w.h, t.lo)
		c:fill(win, gx + 1, w.y, 1, w.h, t.hi)
	else
		local gy = w.y + (w.h - 2) // 2
		c:fill(win, w.x, gy, w.w, 1, t.lo)
		c:fill(win, w.x, gy + 1, w.w, 1, t.hi)
	end
end

function P.radio(a, c, win, w)
	local t = a.theme
	local ty = w.y + (w.h - a.ch) // 2
	local cx, cy = w.x + a.ch // 2 + 3, ty + a.ch // 2
	local r = a.ch // 2
	for dy = -r, r do
		local hw = r - math.abs(dy)
		local bg = w.value and t.ink or t.paper
		c:fill(win, cx - hw, cy + dy, hw * 2 + 1, 1, bg)
	end
	if not w.value then
		c:fill(win, cx - r, cy, r * 2 + 1, 1, t.lo)
		c:fill(win, cx, cy - r, 1, r * 2 + 1, t.lo)
	end
	if w.label ~= "" then
		c:text(win, w.x + a.ch + 8, ty, w.label, t.ink, false)
	end
end

function P.dropdown(a, c, win, w)
	local t = a.theme
	local bw = a:drop_btn()
	bevel(c, win, w.x, w.y, w.w, w.h, t.paper, t.lo, t.hi)
	local label = ""
	if w.selected > 0 then
		label = tostring(w.items[w.selected] or "")
	end
	local maxn = math.max(1, (w.w - bw - 10) // a.cw)
	if utf8.len(label) > maxn then
		label = label:sub(1, maxn)
	end
	local ty = w.y + (w.h - a.ch) // 2
	if label ~= "" then
		c:text(win, w.x + 5, ty, label, t.ink, false)
	end
	local bx = w.x + w.w - bw
	bevel(c, win, bx, w.y, bw, w.h, a.bg, t.hi, t.lo)
	local ax = bx + bw // 2
	local ay = w.y + w.h // 2 - 2
	for i = 0, 3 do
		c:fill(win, ax - 3 + i, ay + i, 7 - 2 * i, 1, t.ink)
	end
end

function P.menubutton(a, c, win, w)
	local t = a.theme
	if w.open then
		bevel(c, win, w.x, w.y, w.w, w.h, a.bg, t.lo, t.hi)
	else
		bevel(c, win, w.x, w.y, w.w, w.h, a.bg, t.hi, t.lo)
	end
	local ty = w.y + (w.h - a.ch) // 2
	local label = tostring(w.label or "")
	local maxn = math.max(0, (w.w - 10 - a.cw) // a.cw)
	if utf8.len(label) > maxn then
		label = label:sub(1, maxn)
	end
	if label ~= "" then
		c:text(win, w.x + 5, ty, label, t.ink, false)
	end
	local ax = w.x + w.w - 5 - a.cw // 2
	local ay = w.y + w.h // 2 - 2
	for i = 0, 2 do
		c:fill(win, ax - 2 + i, ay + i, 5 - 2 * i, 1, t.ink)
	end
end

function P.spinbox(a, c, win, w)
	local t = a.theme
	local btn = a:spin_btn()
	local focused = (a.focus == w) and a.window_focused ~= false
	bevel(c, win, w.x + btn, w.y, w.w - 2 * btn, w.h, t.paper, t.lo, t.hi)
	a:ensure_spin_cursor(w)
	local maxn = math.max(1, (w.w - 2 * btn - 10) // a.cw)
	local shown = w.text:sub(w.scroll, w.scroll + maxn - 1)
	local ty = w.y + (w.h - a.ch) // 2
	if shown ~= "" then
		c:text(win, w.x + btn + 5, ty, shown, t.ink, false)
	end
	if focused then
		local rel = w.cursor - w.scroll
		local ch = w.text:sub(w.cursor, w.cursor)
		if ch == "" then
			ch = " "
		end
		if rel >= 0 and rel < maxn then
			c:text(win, w.x + btn + 5 + rel * a.cw, ty, ch, t.paper, t.ink)
		end
	end
	local function stepbtn(bx, glyph)
		bevel(c, win, bx, w.y, btn, w.h, a.bg, t.hi, t.lo)
		local gw = utf8.len(glyph) * a.cw
		c:text(win, bx + (btn - gw) // 2, ty, glyph, t.ink, false)
	end
	stepbtn(w.x, "-")
	stepbtn(w.x + w.w - btn, "+")
end

function P.scrollbar(a, c, win, w)
	local t = a.theme
	local up, track, down, ky, kh = a:scroll_geom(w)
	c:fill(win, w.x, w.y, w.w, w.h, a.bg)
	local function arrowbtn(b, downher)
		bevel(c, win, b.x, b.y, b.w, b.h, a.bg, t.hi, t.lo)
		local ax = b.x + b.w // 2
		local ay = b.y + b.h // 2
		if downher then
			for i = 0, 2 do
				c:fill(win, ax - 2 + i, ay - 1 + i, 5 - 2 * i, 1, t.ink)
			end
		else
			for i = 0, 2 do
				c:fill(win, ax - 2 + i, ay + 1 - i, 5 - 2 * i, 1, t.ink)
			end
		end
	end
	arrowbtn(up, false)
	arrowbtn(down, true)
	bevel(c, win, track.x, track.y, track.w, track.h, t.paper, t.lo, t.hi)
	if kh < track.h then
		bevel(c, win, track.x + 1, ky, track.w - 2, kh, a.bg, t.hi, t.lo)
	else
		bevel(c, win, track.x + 1, track.y + 1, track.w - 2, track.h - 2, a.bg, t.hi, t.lo)
	end
end

function P.canvas(a, c, win, w)
	c:fill(win, w.x, w.y, w.w, w.h, w.bg or a.bg)
	if type(w.ondraw) == "function" then
		pcall(w.ondraw, a, w)
	end
end

function P.menu_popup(a, c, win, w)
	local t = a.theme
	local x, y, pw, ph, rows = a:menu_popup(w)
	a:menu_top(w)
	local RH = a:row_height()
	bevel(c, win, x, y, pw, ph, t.paper, t.lo, t.hi)
	for i = 0, rows - 1 do
		local idx = w.top + i
		local item = w.items[idx]
		if item == nil then
			break
		end
		local ry = y + 2 + i * RH
		local bg = (idx == w.selected) and t.selbg or t.paper
		local fg = (idx == w.selected) and t.selfg or t.ink
		c:fill(win, x + 1, ry, pw - 2, RH, bg)
		c:text(win, x + 4, ry + (RH - a.ch) // 2, tostring(item):sub(1, (pw - 8) // a.cw), fg, false)
	end
end

function P.context_popup(a, c, win, p)
	local t = a.theme
	if type(p) ~= "table" then
		return
	end
	a:pop_top(p)
	local RH = a:row_height()
	bevel(c, win, p.x, p.y, p.w, p.h, t.paper, t.lo, t.hi)
	for i = 0, p.rows - 1 do
		local idx = p.top + i
		local item = p.items[idx]
		if item == nil then
			break
		end
		local ry = p.y + 2 + i * RH
		local bg = (idx == p.selected) and t.selbg or t.paper
		local fg = (idx == p.selected) and t.selfg or t.ink
		c:fill(win, p.x + 1, ry, p.w - 2, RH, bg)
		c:text(win, p.x + 4, ry + (RH - a.ch) // 2, tostring(item):sub(1, (p.w - 8) // a.cw), fg, false)
	end
end

function P.dropdown_popup(a, c, win, w)
	local t = a.theme
	local x, y, pw, ph, rows = a:dropdown_popup(w)
	a:dropdown_top(w)
	local RH = a:row_height()
	bevel(c, win, x, y, pw, ph, t.paper, t.lo, t.hi)
	for i = 0, rows - 1 do
		local idx = w.top + i
		local item = w.items[idx]
		if item == nil then
			break
		end
		local ry = y + 2 + i * RH
		local bg = (idx == w.selected) and t.selbg or t.paper
		local fg = (idx == w.selected) and t.selfg or t.ink
		c:fill(win, x + 1, ry, pw - 2, RH, bg)
		c:text(win, x + 4, ry + (RH - a.ch) // 2, tostring(item):sub(1, (pw - 8) // a.cw), fg, false)
	end
end

local AT = {
	style = "aero",
	hover = true,
	appBg = 0xF0F0F0,
	paper = 0xFFFFFF,
	sunken = 0xF0F0F0,
	ink = 0x111111,
	disabled = 0x838383,
	border = 0x8E8F8F,
	hoverBorder = 0x3C7FB1,
	pressBorder = 0x6D91AB,
	defBorder = 0x5586A3,
	disBg = 0xF4F4F4,
	disBorder = 0xADB2B5,
	focusRing = 0x98D1EF,
	selbg = 0xCCE4F7,
	selbd = 0x7EB4E2,
	selbgIn = 0xE4E9EE,
	arrow = 0x3A3A3A,
	checkSel = 0x2C7BB8,
	track = 0xF1F3F5,
	trackEdge = 0xDDE1E5,
	sliderTrack = 0xC9CFD5,
	progressBd = 0x3C8B34,
	sep = 0xB9BFC6,
	groupBd = 0xC9CFD4,
	menuBody = 0xF7F9FB,
	menuBorder = 0x9AA5AF,
	menuHoverBd = 0xA6C9E4,
	faceGrad = { { 0, 0xF2F2F2 }, { 0.45, 0xEBEBEB }, { 1, 0xCFCFCF } },
	glossA = { { 0, 0.50 }, { 0.49, 0.14 }, { 0.5, 0 }, { 1, 0 } },
	hoverGrad = { { 0, 0xEAF6FD }, { 0.45, 0xD9F0FC }, { 0.46, 0xBEE6FD }, { 1, 0xA7D9F5 } },
	pressGrad = { { 0, 0xE5F4FC }, { 0.45, 0xC4E5F6 }, { 0.46, 0x98D1EF }, { 1, 0x68B3DB } },
	checkGrad = { { 0, 0xDCEFFA }, { 0.45, 0x9DCDEB }, { 1, 0x5B9FD3 } },
	sliderFill = { { 0, 0x9FD0F0 }, { 1, 0x5B9FD3 } },
	progressFill = { { 0, 0xA5E28A }, { 0.45, 0x5BC53B }, { 1, 0x33A32B } },
	progGlossA = { { 0, 0.45 }, { 0.45, 0.10 }, { 0.5, 0 }, { 1, 0 } },
}

local function astop(stops, t)
	local n = #stops
	if n == 0 then
		return 0
	end
	if t <= stops[1][1] then
		return stops[1][2]
	end
	if t >= stops[n][1] then
		return stops[n][2]
	end
	for i = 1, n - 1 do
		local p0, v0 = stops[i][1], stops[i][2]
		local p1, v1 = stops[i + 1][1], stops[i + 1][2]
		if t <= p1 then
			local f = (p1 - p0 > 0) and (t - p0) / (p1 - p0) or 0
			return v0 + (v1 - v0) * f
		end
	end
	return stops[n][2]
end

local function astops_rgb(stops, t)
	local n = #stops
	if n == 0 then
		return 0, 0, 0
	end
	local v
	if t <= stops[1][1] then
		v = stops[1][2]
	elseif t >= stops[n][1] then
		v = stops[n][2]
	else
		for i = 1, n - 1 do
			local p0, c0 = stops[i][1], stops[i][2]
			local p1, c1 = stops[i + 1][1], stops[i + 1][2]
			if t <= p1 then
				local f = (p1 - p0 > 0) and (t - p0) / (p1 - p0) or 0
				local r0, g0, b0 = (c0 >> 16) & 255, (c0 >> 8) & 255, c0 & 255
				local r1, g1, b1 = (c1 >> 16) & 255, (c1 >> 8) & 255, c1 & 255
				return r0 + (r1 - r0) * f, g0 + (g1 - g0) * f, b0 + (b1 - b0) * f
			end
		end
		v = stops[n][2]
	end
	return (v >> 16) & 255, (v >> 8) & 255, v & 255
end

local function frgb(r, g, b)
	local ri = math.floor(r + 0.5)
	local gi = math.floor(g + 0.5)
	local bi = math.floor(b + 0.5)
	if ri < 0 then
		ri = 0
	elseif ri > 255 then
		ri = 255
	end
	if gi < 0 then
		gi = 0
	elseif gi > 255 then
		gi = 255
	end
	if bi < 0 then
		bi = 0
	elseif bi > 255 then
		bi = 255
	end
	return (ri << 16) | (gi << 8) | bi
end

local function amix(br, bgc, bb, r, g, b, a)
	return br + (r - br) * a, bgc + (g - bgc) * a, bb + (b - bb) * a
end

local function aface_at(layers, t)
	local r, g, b = astops_rgb(layers[1].stops, t)
	for i = 2, #layers do
		local L = layers[i]
		if L.alpha then
			local al = astop(L.alpha, t)
			if al > 0 then
				local orr, og, ob = 255, 255, 255
				if L.rgb then
					orr, og, ob = L.rgb[1], L.rgb[2], L.rgb[3]
				end
				r, g, b = amix(r, g, b, orr, og, ob, al)
			end
		end
	end
	return frgb(r, g, b)
end

local function avface(c, win, x, y, wd, ht, layers)
	if wd < 1 or ht < 1 then
		return
	end
	for i = 0, ht - 1 do
		local tt = (ht > 1) and i / (ht - 1) or 0
		c:fill(win, x, y + i, wd, 1, aface_at(layers, tt))
	end
end

local function aedge(c, win, x, y, wd, ht, bd, cut)
	if wd < 1 or ht < 1 then
		return
	end
	c:fill(win, x, y, wd, 1, bd)
	c:fill(win, x, y + ht - 1, wd, 1, bd)
	c:fill(win, x, y, 1, ht, bd)
	c:fill(win, x + wd - 1, y, 1, ht, bd)
	if cut then
		c:fill(win, x, y, 1, 1, cut)
		c:fill(win, x + wd - 1, y, 1, 1, cut)
		c:fill(win, x, y + ht - 1, 1, 1, cut)
		c:fill(win, x + wd - 1, y + ht - 1, 1, 1, cut)
	end
end

local function aglow(c, win, x, y, wd, ht, cut, rgbt, alphas)
	for k = 1, #alphas do
		local al = alphas[k]
		if al > 0 then
			local br, bgc, bb = (cut >> 16) & 255, (cut >> 8) & 255, cut & 255
			local col = frgb(amix(br, bgc, bb, rgbt[1], rgbt[2], rgbt[3], al))
			local rx, ry = x - k, y - k
			local rw, rh = wd + 2 * k, ht + 2 * k
			c:fill(win, rx, ry, rw, 1, col)
			c:fill(win, rx, ry + rh - 1, rw, 1, col)
			c:fill(win, rx, ry, 1, rh, col)
			c:fill(win, rx + rw - 1, ry, 1, rh, col)
			if cut then
				c:fill(win, rx, ry, 1, 1, cut)
				c:fill(win, rx + rw - 1, ry, 1, 1, cut)
				c:fill(win, rx, ry + rh - 1, 1, 1, cut)
				c:fill(win, rx + rw - 1, ry + rh - 1, 1, 1, cut)
			end
		end
	end
end

local function ainset(c, win, x, y, wd, ht, layers, rows, rgbt)
	if wd < 1 then
		return
	end
	for _, sh in ipairs(rows) do
		if sh[1] >= 0 and sh[1] < ht then
			local tt = (ht > 1) and sh[1] / (ht - 1) or 0
			local base = aface_at(layers, tt)
			local br, bgc, bb = (base >> 16) & 255, (base >> 8) & 255, base & 255
			c:fill(win, x, y + sh[1], wd, 1, frgb(amix(br, bgc, bb, rgbt[1], rgbt[2], rgbt[3], sh[2])))
		end
	end
end

local function acircle(c, win, cx, cy, r, col)
	for dy = -r, r do
		local hw = math.floor(math.sqrt(r * r - dy * dy) + 0.5)
		c:fill(win, cx - hw, cy + dy, hw * 2 + 1, 1, col)
	end
end

local function apix(c, win, x, y, rows, col)
	for j = 1, #rows do
		local row = rows[j]
		for i = 1, #row do
			if row:sub(i, i) ~= "." then
				c:fill(win, x + i - 1, y + j - 1, 1, 1, col)
			end
		end
	end
end

local function adots(c, win, x, y, wd, ht, col)
	if wd < 1 or ht < 1 then
		return
	end
	for i = 0, wd - 1, 2 do
		c:fill(win, x + i, y, 1, 1, col)
		c:fill(win, x + i, y + ht - 1, 1, 1, col)
	end
	for j = 0, ht - 1, 2 do
		c:fill(win, x, y + j, 1, 1, col)
		c:fill(win, x + wd - 1, y + j, 1, 1, col)
	end
end

local GLOW_BLUE = { 0x3C, 0x7F, 0xB1 }
local GLOW_CYAN = { 0x34, 0xBE, 0xFF }
local CHECK7 = {
	"......X",
	".....XX",
	"....XX.",
	"X..XX..",
	".XXXX..",
	"..XX...",
}
local ARROW_DN7 = { "XXXXXXX", ".XXXXX.", "..XXX..", "...X..." }

local AP = {}
AT.painters = AP
AP.tree = paint_tree
AP.tabbar = paint_tabbar
AP.textview = paint_textview
AP.splitter = paint_splitter
M.themes.aero = AT

function AP.button(a, c, win, w)
	local t = a.theme
	local bg = a.bg
	local fg, bd, face, glow, ring
	if w.disabled then
		fg, bd = t.disabled, t.disBorder
		face = { { stops = { { 0, t.disBg } } } }
	elseif w.pressed then
		fg, bd = t.ink, t.pressBorder
		face = { { stops = t.pressGrad } }
	elseif w.def then
		fg, bd = t.ink, t.defBorder
		face = { { stops = t.hoverGrad } }
		glow = { GLOW_CYAN, { 0.45, 0.28, 0.14 } }
	elseif a.focus == w then
		fg, bd = t.ink, t.border
		face = { { stops = t.faceGrad }, { alpha = t.glossA } }
		ring = true
	elseif w.hot then
		fg, bd = t.ink, t.hoverBorder
		face = { { stops = t.hoverGrad } }
		glow = { GLOW_BLUE, { 0.55, 0.30, 0.15 } }
	else
		fg, bd = t.ink, t.border
		face = { { stops = t.faceGrad }, { alpha = t.glossA } }
	end
	if glow then
		aglow(c, win, w.x, w.y, w.w, w.h, bg, glow[1], glow[2])
	end
	avface(c, win, w.x, w.y, w.w, w.h, face)
	if ring then
		aedge(c, win, w.x + 1, w.y + 1, w.w - 2, w.h - 2, t.focusRing, nil)
		aedge(c, win, w.x + 2, w.y + 2, w.w - 4, w.h - 4, t.focusRing, nil)
		adots(c, win, w.x + 4, w.y + 4, w.w - 8, w.h - 8, 0x333333)
	end
	if w.pressed then
		ainset(c, win, w.x + 1, w.y, w.w - 2, w.h, face, { { 1, 0.35 }, { 2, 0.18 }, { 3, 0.08 } }, { 20, 50, 80 })
	end
	aedge(c, win, w.x, w.y, w.w, w.h, bd, bg)
	local kw = utf8.len(w.label) * a.cw
	local dx, dy = 0, 0
	if w.pressed then
		dx, dy = 1, 1
	end
	local tx = w.x + (w.w - kw) // 2 + dx
	local ty = w.y + (w.h - a.ch) // 2 + dy
	c:text(win, tx, ty, w.label, fg, false)
end

function AP.label(a, c, win, w)
	local t = a.theme
	if w.bg then
		c:fill(win, w.x, w.y, w.w, w.h, w.bg)
	end
	local shown = w.text or ""
	local maxn = math.max(1, (w.w - 10) // a.cw)
	if utf8.len(shown) > maxn then
		if w.align == "right" then
			shown = shown:sub(utf8.offset(shown, utf8.len(shown) - maxn + 1))
		else
			shown = shown:sub(1, maxn)
		end
	end
	local tw = utf8.len(shown) * a.cw
	local tx
	if w.align == "right" then
		tx = w.x + w.w - 5 - tw
	else
		tx = w.x + 5
	end
	c:text(win, tx, w.y + (w.h - a.ch) // 2, shown, w.fg or t.ink, false)
end

function AP.textbox(a, c, win, w)
	local t = a.theme
	local dis = w.disabled and true or false
	local focused = (a.focus == w) and a.window_focused ~= false and not dis
	local bd = dis and t.disBorder or (focused and t.hoverBorder or t.border)
	local bgc = dis and t.disBg or t.paper
	local fg = dis and t.disabled or t.ink
	local face = { { stops = { { 0, bgc } } } }
	if focused then
		aglow(c, win, w.x, w.y, w.w, w.h, a.bg, GLOW_BLUE, { 0.40, 0.20 })
	end
	avface(c, win, w.x, w.y, w.w, w.h, face)
	if not dis then
		ainset(c, win, w.x + 1, w.y, w.w - 2, w.h, face, { { 1, 0.10 } }, { 0, 0, 0 })
	end
	aedge(c, win, w.x, w.y, w.w, w.h, bd, a.bg)
	a:ensure_cursor(w)
	local maxn = math.max(1, (w.w - 10) // a.cw)
	local shown = w.text:sub(w.scroll, w.scroll + maxn - 1)
	if w.noecho and shown ~= "" then
		shown = string.rep("*", #shown)
	end
	local ty = w.y + (w.h - a.ch) // 2
	paint_textbox_content(a, c, win, w, w.x + 5, ty, shown, fg, t.selbg, t.selfg)
	if focused then
		local rel = w.cursor - w.scroll
		local ch1 = w.text:sub(w.cursor, w.cursor)
		if ch1 == "" then
			ch1 = " "
		end
		if w.noecho and ch1 ~= " " then
			ch1 = "*"
		end
		if rel >= 0 and rel < maxn then
			c:text(win, w.x + 5 + rel * a.cw, ty, ch1, bgc, t.ink)
		end
	end
end

function AP.spinbox(a, c, win, w)
	local t = a.theme
	local btn = a:spin_btn()
	local focused = (a.focus == w) and a.window_focused ~= false
	local face = { { stops = { { 0, t.paper } } } }
	if focused then
		aglow(c, win, w.x + btn, w.y, w.w - 2 * btn, w.h, a.bg, GLOW_BLUE, { 0.40, 0.20 })
	end
	avface(c, win, w.x + btn, w.y, w.w - 2 * btn, w.h, face)
	ainset(c, win, w.x + btn + 1, w.y, w.w - 2 * btn - 2, w.h, face, { { 1, 0.10 } }, { 0, 0, 0 })
	aedge(c, win, w.x + btn, w.y, w.w - 2 * btn, w.h, focused and t.hoverBorder or t.border, a.bg)
	a:ensure_spin_cursor(w)
	local maxn = math.max(1, (w.w - 2 * btn - 10) // a.cw)
	local shown = w.text:sub(w.scroll, w.scroll + maxn - 1)
	local ty = w.y + (w.h - a.ch) // 2
	if shown ~= "" then
		c:text(win, w.x + btn + 5, ty, shown, t.ink, false)
	end
	if focused then
		local rel = w.cursor - w.scroll
		local ch1 = w.text:sub(w.cursor, w.cursor)
		if ch1 == "" then
			ch1 = " "
		end
		if rel >= 0 and rel < maxn then
			c:text(win, w.x + btn + 5 + rel * a.cw, ty, ch1, t.paper, t.ink)
		end
	end
	local gface = { { stops = t.faceGrad }, { alpha = t.glossA } }
	local function stepbtn(bx, glyph)
		avface(c, win, bx, w.y, btn, w.h, gface)
		aedge(c, win, bx, w.y, btn, w.h, t.border, a.bg)
		local gw = utf8.len(glyph) * a.cw
		c:text(win, bx + (btn - gw) // 2, ty, glyph, t.arrow, false)
	end
	stepbtn(w.x, "-")
	stepbtn(w.x + w.w - btn, "+")
end

function AP.checkbox(a, c, win, w)
	local t = a.theme
	local dis = w.disabled and true or false
	local ty = w.y + (w.h - a.ch) // 2
	local b = 17
	local bx, by = w.x, w.y + (w.h - b) // 2
	local hot = (w.hot or a.focus == w) and not dis
	if a.focus == w then
		aglow(c, win, bx, by, b, b, a.bg, GLOW_BLUE, { 0.40, 0.20 })
	end
	local bd = dis and t.disBorder or (hot and t.hoverBorder or t.border)
	local face
	if w.value and not dis then
		face = { { stops = t.checkGrad } }
	elseif dis then
		face = { { stops = { { 0, t.disBg } } } }
	else
		face = { { stops = { { 0, t.paper } } } }
	end
	avface(c, win, bx, by, b, b, face)
	if w.value and not dis then
		ainset(c, win, bx + 1, by, b - 2, b, face, { { 1, 0.6 } }, { 255, 255, 255 })
	end
	aedge(c, win, bx, by, b, b, bd, a.bg)
	if w.value then
		apix(c, win, bx + 5, by + 5, CHECK7, dis and 0xA8A8A8 or 0xFFFFFF)
	end
	if w.label ~= "" then
		c:text(win, w.x + a.ch + 8, ty, w.label, dis and t.disabled or t.ink, false)
	end
end

function AP.radio(a, c, win, w)
	local t = a.theme
	local dis = w.disabled and true or false
	local ty = w.y + (w.h - a.ch) // 2
	local cx, cy = w.x + 8, ty + a.ch // 2
	local r = 7
	local hot = (w.hot or a.focus == w) and not dis
	local ring = dis and t.disBorder or ((w.value or hot) and t.hoverBorder or t.border)
	acircle(c, win, cx, cy, r, ring)
	acircle(c, win, cx, cy, r - 1, dis and t.disBg or 0xFDFEFF)
	if w.value and not dis then
		acircle(c, win, cx, cy, r - 1, 0x5B9FD3)
		acircle(c, win, cx, cy - 1, r - 2, 0x9DCDEB)
		acircle(c, win, cx, cy + 1, 3, 0x1E6DA8)
		c:fill(win, cx - 1, cy - 3, 1, 1, 0xEAF6FD)
	end
	if w.label ~= "" then
		c:text(win, w.x + a.ch + 8, ty, w.label, dis and t.disabled or t.ink, false)
	end
end

function AP.dropdown(a, c, win, w)
	local t = a.theme
	local bw = a:drop_btn()
	local face = { { stops = { { 0, t.paper } } } }
	avface(c, win, w.x, w.y, w.w, w.h, face)
	ainset(c, win, w.x + 1, w.y, w.w - 2, w.h, face, { { 1, 0.10 } }, { 0, 0, 0 })
	aedge(c, win, w.x, w.y, w.w, w.h, t.border, a.bg)
	local label = ""
	if w.selected > 0 then
		label = tostring(w.items[w.selected] or "")
	end
	local maxn = math.max(1, (w.w - bw - 10) // a.cw)
	if utf8.len(label) > maxn then
		label = label:sub(1, maxn)
	end
	local ty = w.y + (w.h - a.ch) // 2
	if label ~= "" then
		c:text(win, w.x + 5, ty, label, t.ink, false)
	end
	local bx = w.x + w.w - bw
	local zface = { { stops = t.faceGrad }, { alpha = t.glossA } }
	avface(c, win, bx + 1, w.y + 1, bw - 2, w.h - 2, zface)
	aedge(c, win, bx + 1, w.y + 1, bw - 2, w.h - 2, t.border, t.paper)
	apix(c, win, bx + bw // 2 - 3, ty + 1, ARROW_DN7, t.arrow)
end

function AP.listbox(a, c, win, w)
	local t = a.theme
	local RH = a:row_height()
	local rows = a:visible_rows(w)
	a:ensure_visible(w)
	local face = { { stops = { { 0, t.paper } } } }
	avface(c, win, w.x, w.y, w.w, w.h, face)
	ainset(c, win, w.x + 1, w.y, w.w - 2, w.h, face, { { 1, 0.08 } }, { 0, 0, 0 })
	aedge(c, win, w.x, w.y, w.w, w.h, t.border, a.bg)
	for i = 0, rows - 1 do
		local idx = w.top + i
		local item = w.items[idx]
		if item == nil then
			break
		end
		local ry = w.y + 2 + i * RH
		local on = (idx == w.selected)
		if on then
			c:fill(win, w.x + 2, ry, w.w - 4, RH - 1, t.selbg)
			aedge(c, win, w.x + 2, ry, w.w - 4, RH - 1, t.selbd, t.paper)
		end
		c:text(
			win,
			w.x + 4,
			ry + (RH - a.ch) // 2,
			tostring(item):sub(1, (w.w - 8) // a.cw),
			t.ink,
			on and t.selbg or t.paper
		)
	end
end

function AP.slider(a, c, win, w)
	local t = a.theme
	c:fill(win, w.x, w.y, w.w, w.h, a.bg)
	local gy = w.y + (w.h - 5) // 2
	local groove = { { stops = { { 0, t.sliderTrack } } } }
	avface(c, win, w.x, gy, w.w, 5, groove)
	ainset(c, win, w.x + 1, gy, w.w - 2, 5, groove, { { 1, 0.15 } }, { 0, 0, 0 })
	aedge(c, win, w.x, gy, w.w, 5, 0xAEB4BA, a.bg)
	local span = w.max - w.min
	local frac = (span > 0) and ((w.value - w.min) / span) or 0
	local kw = 12
	local kx = w.x + 1 + math.floor(frac * (w.w - 2 - kw) + 0.5)
	local fw = kx - (w.x + 1)
	if fw > 0 then
		local total = math.max(fw - 1, 1)
		for i = 0, fw - 1 do
			c:fill(win, w.x + 1 + i, gy + 1, 1, 3, frgb(astops_rgb(t.sliderFill, i / total)))
		end
	end
	local ky = w.y + math.max(0, (w.h - 17) // 2)
	local kface = { { stops = t.faceGrad }, { alpha = t.glossA } }
	avface(c, win, kx, ky, kw, 17, kface)
	aedge(c, win, kx, ky, kw, 17, t.border, a.bg)
end

function AP.progress(a, c, win, w)
	local t = a.theme
	local face = { { stops = { { 0, t.paper } } } }
	avface(c, win, w.x, w.y, w.w, w.h, face)
	ainset(c, win, w.x + 1, w.y, w.w - 2, w.h, face, { { 1, 0.12 } }, { 0, 0, 0 })
	aedge(c, win, w.x, w.y, w.w, w.h, t.border, a.bg)
	local fw = math.max(2, math.floor(w.frac * (w.w - 4) + 0.5))
	if fw > w.w - 4 then
		fw = w.w - 4
	end
	if w.h >= 8 and fw >= 2 then
		local fface = { { stops = t.progressFill }, { alpha = t.progGlossA } }
		avface(c, win, w.x + 2, w.y + 2, fw, w.h - 4, fface)
		aedge(c, win, w.x + 2, w.y + 2, fw, w.h - 4, t.progressBd, t.paper)
	end
end

function AP.frame(a, c, win, w)
	local t = a.theme
	aedge(c, win, w.x, w.y, w.w, w.h, t.groupBd, a.bg)
	if w.title ~= "" then
		local tx = w.x + 10
		local tw = utf8.len(w.title) * a.cw
		c:fill(win, tx - 3, w.y, tw + 6, a.ch + 2, a.bg)
		c:text(win, tx, w.y + 1, w.title, t.ink, false)
	end
end

function AP.separator(a, c, win, w)
	local t = a.theme
	if w.vertical then
		local gx = w.x + (w.w - 1) // 2
		c:fill(win, gx, w.y, 1, w.h, t.sep)
	else
		local gy = w.y + (w.h - 1) // 2
		c:fill(win, w.x, gy, w.w, 1, t.sep)
	end
end

function AP.menubutton(a, c, win, w)
	local t = a.theme
	local chip = w.open or w.hot
	local face
	if chip then
		face = { { stops = t.hoverGrad } }
		avface(c, win, w.x, w.y, w.w, w.h, face)
		aedge(c, win, w.x, w.y, w.w, w.h, t.menuHoverBd, a.bg)
	end
	local ty = w.y + (w.h - a.ch) // 2
	local label = tostring(w.label or "")
	local maxn = math.max(0, (w.w - 10 - a.cw) // a.cw)
	if utf8.len(label) > maxn then
		label = label:sub(1, maxn)
	end
	if label ~= "" then
		c:text(win, w.x + 5, ty, label, t.ink, false)
	end
	local ax = w.x + w.w - 5 - a.cw // 2
	local ay = w.y + w.h // 2 - 2
	for i = 0, 2 do
		c:fill(win, ax - 2 + i, ay + i, 5 - 2 * i, 1, t.arrow)
	end
end

function AP.scrollbar(a, c, win, w)
	local t = a.theme
	local up, track, down, ky, kh = a:scroll_geom(w)
	local trackf = { { stops = { { 0, t.track } } } }
	avface(c, win, w.x, w.y, w.w, w.h, trackf)
	local br, bgc, bb = (t.track >> 16) & 255, (t.track >> 8) & 255, t.track & 255
	local scol = frgb(amix(br, bgc, bb, 0, 0, 0, 0.08))
	if w.h > 2 then
		c:fill(win, w.x + 1, w.y + 1, 1, w.h - 2, scol)
		c:fill(win, w.x + w.w - 2, w.y + 1, 1, w.h - 2, scol)
	end
	aedge(c, win, w.x, w.y, w.w, w.h, t.trackEdge, a.bg)
	local ax = up.x + up.w // 2
	local ayu = up.y + up.h // 2
	local ayd = down.y + down.h // 2
	for i = 0, 2 do
		c:fill(win, ax - 2 + i, ayu + 1 - i, 5 - 2 * i, 1, t.arrow)
		c:fill(win, ax - 2 + i, ayd - 1 + i, 5 - 2 * i, 1, t.arrow)
	end
	local tface = { { stops = t.faceGrad }, { alpha = t.glossA } }
	if track.w - 2 >= 1 and track.h - 2 >= 1 then
		if kh < track.h then
			avface(c, win, track.x + 1, ky, track.w - 2, kh, tface)
			aedge(c, win, track.x + 1, ky, track.w - 2, kh, t.border, t.track)
		else
			avface(c, win, track.x + 1, track.y + 1, track.w - 2, track.h - 2, tface)
			aedge(c, win, track.x + 1, track.y + 1, track.w - 2, track.h - 2, t.border, t.track)
		end
	end
end

function AP.canvas(a, c, win, w)
	c:fill(win, w.x, w.y, w.w, w.h, w.bg or a.bg)
	if type(w.ondraw) == "function" then
		pcall(w.ondraw, a, w)
	end
end

local function apopup_body(a, c, win, x, y, pw, ph, rows, top, items, sel)
	local t = a.theme
	local RH = a:row_height()
	local br, bgc, bb = (a.bg >> 16) & 255, (a.bg >> 8) & 255, a.bg & 255
	local s1 = frgb(amix(br, bgc, bb, 0, 0, 0, 0.30))
	local s2 = frgb(amix(br, bgc, bb, 0, 0, 0, 0.15))
	c:fill(win, x + pw + 1, y + 2, 2, ph + 2, s1)
	c:fill(win, x + 2, y + ph + 1, pw + 3, 2, s1)
	c:fill(win, x + pw + 3, y + 4, 2, ph + 2, s2)
	c:fill(win, x + 4, y + ph + 3, pw + 3, 2, s2)
	avface(c, win, x, y, pw, ph, { { stops = { { 0, t.menuBody } } } })
	aedge(c, win, x, y, pw, ph, t.menuBorder, a.bg)
	local hover = { { stops = t.hoverGrad } }
	for i = 0, rows - 1 do
		local idx = top + i
		local item = items[idx]
		if item == nil then
			break
		end
		local ry = y + 2 + i * RH
		local on = (idx == sel)
		if on then
			avface(c, win, x + 2, ry, pw - 4, RH - 2, hover)
			aedge(c, win, x + 2, ry, pw - 4, RH - 2, t.menuHoverBd, t.menuBody)
		end
		c:text(win, x + 4, ry + (RH - a.ch) // 2, tostring(item):sub(1, (pw - 8) // a.cw), t.ink, false)
	end
end

function AP.menu_popup(a, c, win, w)
	local x, y, pw, ph, rows = a:menu_popup(w)
	a:menu_top(w)
	apopup_body(a, c, win, x, y, pw, ph, rows, w.top, w.items, w.selected)
end

function AP.context_popup(a, c, win, p)
	if type(p) ~= "table" then
		return
	end
	a:pop_top(p)
	apopup_body(a, c, win, p.x, p.y, p.w, p.h, p.rows, p.top, p.items, p.selected)
end

function AP.dropdown_popup(a, c, win, w)
	local x, y, pw, ph, rows = a:dropdown_popup(w)
	a:dropdown_top(w)
	apopup_body(a, c, win, x, y, pw, ph, rows, w.top, w.items, w.selected)
end

function App:drawWidget(w)
	local painter = self.theme.painters[w.kind]
	if painter then
		painter(self, self.client, self.win, w)
	end
	w.dirty = false
end

function App:draw_menu_popup(w)
	local painter = self.theme.painters.menu_popup
	if painter then
		painter(self, self.client, self.win, w)
	end
end

function App:draw_context_popup(p)
	local painter = self.theme.painters.context_popup
	if painter then
		painter(self, self.client, self.win, p)
	end
end

function App:draw_dropdown_popup(w)
	local painter = self.theme.painters.dropdown_popup
	if painter then
		painter(self, self.client, self.win, w)
	end
end

function App:render(full)
	local c = self.client
	if not c then
		return false
	end
	if self._last_focus ~= self.focus then
		if self._last_focus then
			self._last_focus.dirty = true
		end
		if self.focus then
			self.focus.dirty = true
		end
		self._last_focus = self.focus
	end
	c:begin()
	if full or self.bgdirty then
		c:fill(self.win, 0, 0, self.W, self.H, self.bg)
		self.bgdirty = false
	end

	local pops = {}
	local vpop = self:validpop()
	local any = full or self.bgdirty or self.popdirty
	if not any then
		for _, w in ipairs(self.widgets) do
			if w.dirty then
				any = true
				break
			end
		end
	end
	for _, w in ipairs(self.widgets) do
		if (w.kind == "dropdown" or w.kind == "menubutton") and w.open and any then
			pops[#pops + 1] = w
		end
	end
	for _, w in ipairs(self.widgets) do
		if full or w.dirty then
			self:drawWidget(w)
		end
	end
	for _, w in ipairs(pops) do
		if w.kind == "menubutton" then
			self:draw_menu_popup(w)
		else
			self:draw_dropdown_popup(w)
		end
	end

	if vpop and any then
		self:draw_context_popup(vpop)
	end
	local ok, _ = c:commit()
	if not ok then
		self:dirtyAll()
		return false
	end
	self.popdirty = nil
	return true
end

function App:clock()
	if type(time) == "table" and type(time.monotonic) == "function" then
		local ok, t = pcall(time.monotonic)
		if ok and type(t) == "number" then
			return t
		end
	end
	return nil
end

function App:due(last)
	local now = self:clock()
	if now == nil or last == nil then
		return true
	end
	return now - last >= 1
end

local INTERACTIVE = {
	button = true,
	textbox = true,
	checkbox = true,
	radio = true,
	listbox = true,
	dropdown = true,
	menubutton = true,
	slider = true,
	spinbox = true,
	scrollbar = true,
	canvas = true,
	tree = true,
	tabbar = true,
	textview = true,
	splitter = true,
}

function App:hit(px, py)
	for i = #self.widgets, 1, -1 do
		local w = self.widgets[i]
		if INTERACTIVE[w.kind] and px >= w.x and px < w.x + w.w and py >= w.y and py < w.y + w.h then
			return w
		end
	end
	return nil
end

function App:set_hot(w)
	if self.hot == w then
		return
	end
	self.hot = w
	for _, o in ipairs(self.widgets) do
		o.hot = (o == w) or nil
	end
	self:dirtyAll()
end

local FOCUSABLE = {
	textbox = true,
	listbox = true,
	dropdown = true,
	menubutton = true,
	checkbox = true,
	radio = true,
	slider = true,
	spinbox = true,
	scrollbar = true,
	button = true,
	canvas = true,
	tree = true,
	tabbar = true,
	textview = true,
	splitter = true,
}

function App:focus_next(back)
	local order = {}
	for _, w in ipairs(self.widgets) do
		if FOCUSABLE[w.kind] then
			order[#order + 1] = w
		end
	end
	if #order == 0 then
		return
	end
	local i = 0
	for k, w in ipairs(order) do
		if w == self.focus then
			i = k
			break
		end
	end
	if back then
		i = i - 1
	else
		i = i + 1
	end
	if i < 1 then
		i = #order
	end
	if i > #order then
		i = 1
	end
	local old = self.focus
	self:blur(old)
	self.focus = order[i]
	if old and (old.kind == "textbox" or old.kind == "spinbox") then
		old.dirty = true
	end
	if self.focus.kind == "textbox" or self.focus.kind == "spinbox" then
		self.focus.dirty = true
	end
end

function App:blur(w)
	if w and w.kind == "spinbox" then
		self:spin_commit(w)
	end
end

function App:tree_selected_row(w)
	for i, r in ipairs(w.rows or {}) do
		if r.node == w.selected then
			return i
		end
	end
	return 0
end

function App:tree_move(w, delta)
	local idx = self:tree_selected_row(w)
	if idx == 0 then
		idx = w.top or 1
	else
		idx = math.min(math.max(idx + delta, 1), #(w.rows or {}))
	end
	local row = w.rows and w.rows[idx]
	if row then
		self:tree_select(w, row.node)
	end
end

function App:tree_toggle_selected(w)
	local idx = self:tree_selected_row(w)
	local row = idx > 0 and w.rows[idx] or nil
	if row then
		local n = row.node
		if n.children and #n.children > 0 then
			w.expanded[n] = not w.expanded[n]
			self:tree_refresh(w)
		end
	end
end

function App:tree_parent(w, node)
	local function walk(nodes, parent)
		for _, n in ipairs(nodes or {}) do
			if n == node then
				return parent
			end
			local p = walk(n.children, n)
			if p ~= nil then
				return p
			end
		end
		return nil
	end
	return walk(w.nodes, nil) or nil
end

function App:tree_activate(w)
	local idx = self:tree_selected_row(w)
	local row = idx > 0 and w.rows[idx] or nil
	if row and w.onactivate then
		w.onactivate(w, row.node)
	end
end

function App:tab_move(w, delta)
	if #w.tabs == 0 then
		return
	end
	local idx = math.min(math.max((w.selected or 0) + delta, 1), #w.tabs)
	self:select_tab(w, idx)
end

function App:text_clamp(w)
	local line = math.min(math.max(w.cursor.line, 1), math.max(1, #w.lines))
	local n = utf8.len(w.plain[line] or "") + 1
	w.cursor.line = line
	w.cursor.col = math.min(math.max(w.cursor.col, 1), n)
end

function App:text_move(w, dl, dc, extend)
	if not extend then
		w.anchor = { line = w.cursor.line, col = w.cursor.col }
	end
	w.cursor.line = w.cursor.line + dl
	w.cursor.col = w.cursor.col + dc
	self:text_clamp(w)
	self:show_line(w, w.cursor.line)
	w.dirty = true
end

function App:text_move_home(w, extend)
	if not extend then
		w.anchor = { line = w.cursor.line, col = w.cursor.col }
	end
	w.cursor.col = 1
	w.dirty = true
end

function App:text_move_end(w, extend)
	if not extend then
		w.anchor = { line = w.cursor.line, col = w.cursor.col }
	end
	w.cursor.col = utf8.len(w.plain[w.cursor.line] or "") + 1
	w.dirty = true
end

function App:text_page(w, dir, extend)
	local rows = self:textview_rows(w)
	if not extend then
		w.anchor = { line = w.cursor.line, col = w.cursor.col }
	end
	w.cursor.line = w.cursor.line + dir * rows
	self:text_clamp(w)
	self:show_line(w, w.cursor.line)
	w.dirty = true
end

function App:splitter_set(w, value, fire)
	value = math.min(math.max(value, w.min), w.max)
	if w.value ~= value then
		w.value = value
		w.dirty = true
		if fire ~= false and w.onchange then
			w.onchange(w, value)
		end
	end
end

function App:handle_mouse(m)
	if m.kind == "scroll" then
		self:handle_scroll(m)
		return
	end
	if m.kind == "down" then
		local btn = m.button or 0

		local fw = self.focus
		if
			fw
			and fw.kind == "spinbox"
			and not (m.x >= fw.x and m.x < fw.x + fw.w and m.y >= fw.y and m.y < fw.y + fw.h)
		then
			self:blur(fw)
		end

		local p = self:validpop()
		if p then
			if btn == 0 then
				local idx = self:pop_row_at(p, m.x, m.y)
				if idx then
					local cb = p.onpick
					self:close_popup()
					if cb then
						cb(idx)
					end
					return
				end
				local inside = m.x >= p.x and m.x < p.x + p.w and m.y >= p.y and m.y < p.y + p.h
				self:close_popup()
				if inside then
					return
				end
			else
				self:close_popup()
			end
		end

		if btn ~= 0 then
			self:close_dropdowns(nil)
			local rw = self:hit(m.x, m.y)
			self.lastright = { x = m.x, y = m.y, w = rw }
			if rw and rw.onrightclick then
				rw.onrightclick(self, rw, m.x, m.y)
			end
			if self.rightclick then
				self.rightclick(m.x, m.y)
			end
			return
		end

		for _, o in ipairs(self.widgets) do
			if o.kind == "dropdown" and o.open then
				local idx = self:dropdown_row_at(o, m.x, m.y)
				if idx then
					self:select(o, idx)
					self:set_dropdown(o, false)
					return
				end
				local onbox = m.x >= o.x and m.x < o.x + o.w and m.y >= o.y and m.y < o.y + o.h
				self:set_dropdown(o, false)
				if onbox then
					return
				end
			elseif o.kind == "menubutton" and o.open then
				local idx = self:menu_row_at(o, m.x, m.y)
				if idx then
					self:select(o, idx)
					self:set_menu(o, false)
					return
				end
				local onbox = m.x >= o.x and m.x < o.x + o.w and m.y >= o.y and m.y < o.y + o.h
				self:set_menu(o, false)
				if onbox then
					return
				end
			end
		end
		local w = self:hit(m.x, m.y)
		if not w then
			return
		end
		if w.kind == "button" then
			w.pressed = true
			w.dirty = true
			self:render(false)
			if w.onpress then
				w.onpress(w)
			end
		elseif w.kind == "checkbox" then
			self.focus = w
			self:set_checkbox(w, not w.value)
		elseif w.kind == "radio" then
			self.focus = w
			self:set_radio(w, true)
		elseif w.kind == "textbox" then
			self.focus = w
			local rel = (m.x - (w.x + 5)) // self.cw
			local pos = math.min(math.max(w.scroll + rel, 1), #w.text + 1)
			if ((m.mods or 0) & 1) ~= 0 then
				w.sel_anchor = w.sel_anchor or w.cursor
			else
				w.sel_anchor = nil
			end
			w.cursor = pos
			w.dirty = true
		elseif w.kind == "spinbox" then
			self.focus = w
			local btn = self:spin_btn()
			if m.x < w.x + btn then
				self:spin_step(w, -1)
			elseif m.x >= w.x + w.w - btn then
				self:spin_step(w, 1)
			else
				local rel = (m.x - (w.x + btn + 5)) // self.cw
				w.cursor = math.min(math.max(w.scroll + rel, 1), #w.text + 1)
				w.dirty = true
			end
		elseif w.kind == "dropdown" then
			self:close_dropdowns(w)
			self.focus = w
			if w.open then
				self:set_dropdown(w, false)
			else
				self:set_dropdown(w, true)
				self:dropdown_top(w)
				w.dirty = true
			end
		elseif w.kind == "menubutton" then
			self:close_dropdowns(w)
			self.focus = w
			if w.open then
				self:set_menu(w, false)
			else
				self:set_menu(w, true)
			end
		elseif w.kind == "listbox" then
			self.focus = w
			local idx = self:row_at(w, m.x, m.y)
			if idx then
				if idx == w.selected then
					if w.ondouble then
						w.ondouble(w, idx)
					end
				else
					self:select(w, idx)
				end
			end
		elseif w.kind == "scrollbar" then
			self.focus = w
			local up, track, down, ky, kh = self:scroll_geom(w)
			if m.y < up.y + up.h then
				self:set_scroll(w, w.first - 1)
			elseif m.y >= down.y then
				self:set_scroll(w, w.first + 1)
			elseif m.y < ky then
				self:set_scroll(w, w.first - w.visible)
			elseif m.y >= ky + kh then
				self:set_scroll(w, w.first + w.visible)
			else
				w.grab = m.y - ky
				self.grab = w
			end
		elseif w.kind == "slider" then
			self.focus = w
			self.grab = w
			self:slide_to(w, m.x)
		elseif w.kind == "tree" then
			self.focus = w
			local idx, node, depth = self:tree_row_at(w, m.x, m.y)
			if node then
				local ax = w.x + 4 + depth * (w.indent or 12)
				if node.children and #node.children > 0 and m.x >= ax and m.x < ax + 12 then
					w.expanded[node] = not w.expanded[node]
					self:tree_refresh(w)
				else
					if node == w.selected and w.ondouble then
						w.ondouble(w, node)
					else
						self:tree_select(w, node)
					end
				end
			end
		elseif w.kind == "tabbar" then
			self.focus = w
			local idx, tb = self:tab_at(w, m.x, m.y)
			if idx then
				local closable = tb.tab.closable
				local cx = tb.x + tb.w - self.cw - 6
				if closable and m.x >= cx - 2 then
					if w.onclose then
						w.onclose(w, idx, tb.tab)
					end
				else
					self:select_tab(w, idx)
				end
			end
		elseif w.kind == "textview" then
			self.focus = w
			local vb = self:textview_vbar(w)
			if vb and m.x >= w.x + w.w - 8 then
				if m.y >= vb.y and m.y < vb.y + vb.h then
					w.grab_off = m.y - vb.y
				else
					w.grab_off = vb.thumb // 2
				end
				w.grab_axis = "v"
				self.grab = w
				self:textview_drag_to(w, m.x, m.y)
			elseif self:text_hscroll(w) and m.y >= w.y + w.h - 8 then
				local hb = self:textview_hbar(w)
				w.grab_off = (hb and m.y >= hb.y and m.x >= hb.x and m.x < hb.x + hb.w)
					and (m.x - hb.x) or (hb and hb.thumb // 2 or 8)
				w.grab_axis = "h"
				self.grab = w
				self:textview_drag_to(w, m.x, m.y)
			else
				w.grab_axis = nil
				local line = self:text_line_at(w, m.y)
				if line then
					local col = self:text_col_at(w, m.x, line)
					local shift = ((m.mods or 0) & 1) ~= 0
					if not shift then
						w.anchor = { line = line, col = col }
					end
					w.cursor = { line = line, col = col }
					w.current = line
					w.dirty = true
					if line >= w.top and line < w.top + self:textview_rows(w) then
						if line >= w.top + self:textview_rows(w) - 1 then
							self:show_line(w, line)
						end
					end
					self.grab = w
					if w.onrowclick then
						w.onrowclick(self, w, line, col)
					end
				end
			end
		elseif w.kind == "splitter" then
			self.focus = w
			self.grab = w
			local v = (w.orient == "v") and m.x or m.y
			self:splitter_set(w, v)
		elseif w.kind == "canvas" then
			self.focus = w
			self.grab = w
			if type(w.onmouse) == "function" then
				pcall(w.onmouse, self, w, m)
			end
		end
	elseif m.kind == "up" then
		if self.grab then
			local w = self.grab
			self.grab = nil
			if w.kind == "slider" then
				self:slide_to(w, m.x)
			elseif w.kind == "scrollbar" then
				w.grab = nil
			elseif w.kind == "textview" then
				w.grab_axis = nil
				w.dirty = true
			elseif w.kind == "splitter" then
				if w.onchange then
					w.onchange(w, w.value)
				end
			elseif w.kind == "canvas" then
				if type(w.onmouse) == "function" then
					pcall(w.onmouse, self, w, m)
				end
			end
		end
		for _, w in ipairs(self.widgets) do
			if w.kind == "button" and w.pressed then
				w.pressed = false
				w.dirty = true
			end
			if w.kind == "scrollbar" then
				w.grab = nil
			end
		end
	elseif m.kind == "move" then
		if self.grab and self.grab.kind == "slider" then
			self:slide_to(self.grab, m.x)
		elseif self.grab and self.grab.kind == "scrollbar" then
			self:scroll_drag_to(self.grab, m.y)
		elseif self.grab and self.grab.kind == "textview" then
			local w = self.grab
			if w.grab_axis then
				self:textview_drag_to(w, m.x, m.y)
			else
				local line = self:text_line_at(w, m.y)
				if line then
					w.cursor = { line = line, col = self:text_col_at(w, m.x, line) }
					w.dirty = true
				end
			end
		elseif self.grab and self.grab.kind == "splitter" then
			local w = self.grab
			local v = (w.orient == "v") and m.x or m.y
			self:splitter_set(w, v)
		elseif self.grab and self.grab.kind == "canvas" then
			local w = self.grab
			if type(w.onmouse) == "function" then
				pcall(w.onmouse, self, w, m)
			end
		elseif not self.grab then
			local w = self:hit(m.x, m.y)
			if w and w.kind == "canvas" and type(w.onmouse) == "function" then
				pcall(w.onmouse, self, w, m)
			end
		end
		if self.theme.hover and not self.grab and not self:validpop() then
			self:set_hot(self:hit(m.x, m.y))
		end
	end
end

function App:nudge_top(w, delta, rows, total)
	local maxfirst = math.max(1, total - rows + 1)
	local top = math.min(math.max((w.top or 1) + delta, 1), maxfirst)
	if top ~= w.top then
		w.top = top
		w.dirty = true
	end
end

function App:handle_scroll(m)
	local v = m.button or 0
	if v == 0 then
		return
	end
	local dir = v > 0 and 1 or -1
	local p = self:validpop()
	if p and self:pop_row_at(p, m.x, m.y) then
		self:nudge_top(p, 3 * dir, p.rows, #p.items)
		self.popdirty = true
		return
	end
	for _, o in ipairs(self.widgets) do
		if o.kind == "dropdown" and o.open and self:dropdown_row_at(o, m.x, m.y) then
			local rows = select(5, self:dropdown_popup(o))
			self:nudge_top(o, 3 * dir, rows, #o.items)
			return
		end
		if o.kind == "menubutton" and o.open and self:menu_row_at(o, m.x, m.y) then
			local rows = select(5, self:menu_popup(o))
			self:nudge_top(o, 3 * dir, rows, #o.items)
			return
		end
	end
	local w = self:hit(m.x, m.y)
	if not w then
		return
	end
	if w.kind == "listbox" then
		self:nudge_top(w, 3 * dir, self:visible_rows(w), #w.items)
	elseif w.kind == "dropdown" then
		if #w.items > 0 then
			local idx = (w.selected > 0 and w.selected or (dir > 0 and 0 or #w.items + 1)) + dir
			idx = math.min(math.max(idx, 1), #w.items)
			self:select(w, idx)
		end
	elseif w.kind == "scrollbar" then
		self:set_scroll(w, w.first + 3 * dir)
	elseif w.kind == "spinbox" then
		self:spin_step(w, dir)
	elseif w.kind == "slider" then
		local step = (w.max - w.min) / 20
		if step <= 0 then
			step = 1
		end
		self:set_slider(w, w.value + dir * step)
	elseif w.kind == "tree" then
		self:nudge_top(w, 3 * dir, self:tree_visible_rows(w), #(w.rows or {}))
		w.dirty = true
	elseif w.kind == "tabbar" then
		w.first = math.max(1, (w.first or 1) + dir)
		w.dirty = true
	elseif w.kind == "textview" then
		local rows = self:textview_rows(w)
		w.top = math.min(math.max(1, (w.top or 1) + 3 * dir),
			math.max(1, #w.lines - rows + 1))
		w.dirty = true
		if w.onscroll then
			w.onscroll(self, w, dir)
		end
	elseif w.kind == "canvas" then
		if type(w.onscroll) == "function" then
			pcall(w.onscroll, self, w, dir)
		end
	end
end

function App:slide_to(w, px)
	local x0, track = w.x + 1, w.w - 2 - 12
	if track < 1 then
		track = 1
	end
	local frac = (px - x0 - 6) / track
	self:set_slider(w, w.min + frac * (w.max - w.min))
end

local function insert_at(w, ch)
	local L = w.text
	w.text = L:sub(1, w.cursor - 1) .. ch .. L:sub(w.cursor)
	w.cursor = w.cursor + #ch
	w.dirty = true
end

function App:handle_key(m)
	local mods = m.mods or 0

	if m.name == "tab" and (mods & 6) == 0 and self.tabfocus ~= false then
		self:focus_next((mods & 1) ~= 0)
		return
	end

	local p = self:validpop()
	if p then
		local name = m.name
		if name == "escape" then
			self:close_popup()
			return
		elseif name == "up" then
			self:pop_highlight(p, (p.selected > 0 and p.selected or 2) - 1)
			return
		elseif name == "down" then
			self:pop_highlight(p, (p.selected > 0 and p.selected or 0) + 1)
			return
		elseif name == "home" then
			self:pop_highlight(p, 1)
			return
		elseif name == "end" then
			self:pop_highlight(p, #p.items)
			return
		elseif name == "enter" or name == "space" then
			if p.selected > 0 then
				local cb = p.onpick
				local idx = p.selected
				self:close_popup()
				if cb then
					cb(idx)
				end
			else
				self:close_popup()
			end
			return
		else
			self:close_popup()
		end
	end
	local f = self.focus
	if f and FOCUSABLE[f.kind] and self:key_widget(f, m) then
		return
	end
	if self.keyhandler then
		self.keyhandler(m)
	end
end

function App:key_widget(w, m)
	local mods = m.mods or 0
	local name = m.name
	if w.kind == "textbox" then
		local ctrl = (mods & 2) ~= 0
		local shift = (mods & 1) ~= 0
		local function move_to(pos, extend)
			if extend then
				w.sel_anchor = w.sel_anchor or w.cursor
			else
				w.sel_anchor = nil
			end
			w.cursor = pos
			w.dirty = true
		end
		if ctrl and name == "a" then
			w.sel_anchor = 1
			w.cursor = #w.text + 1
			w.dirty = true
			return true
		elseif ctrl and name == "c" then
			local text = textbox_selection_text(w)
			if text and text ~= "" and self.client then
				self.client:clip_set(text)
			end
			return true
		elseif ctrl and name == "x" then
			local text = textbox_selection_text(w)
			if text and text ~= "" and self.client then
				self.client:clip_set(text)
				textbox_delete_range(w)
				if w.onchange then
					w.onchange(w)
				end
			end
			return true
		elseif name == "enter" then
			if w.onenter then
				w.onenter(w)
			end
			return true
		elseif name == "backspace" then
			local changed = textbox_delete_range(w)
			if not changed and w.cursor > 1 then
				local L = w.text

				w.text = L:sub(1, w.cursor - 2) .. L:sub(w.cursor)
				w.cursor = w.cursor - 1
				w.dirty = true
				changed = true
			end
			if changed and w.onchange then
				w.onchange(w)
			end
			return true
		elseif name == "delete" then
			local changed = textbox_delete_range(w)
			if not changed and w.cursor <= #w.text then
				local L = w.text
				w.text = L:sub(1, w.cursor - 1) .. L:sub(w.cursor + 1)
				w.dirty = true
				changed = true
			end
			if changed and w.onchange then
				w.onchange(w)
			end
			return true
		elseif name == "left" then
			move_to(math.max(1, w.cursor - 1), shift)
			return true
		elseif name == "right" then
			move_to(math.min(#w.text + 1, w.cursor + 1), shift)
			return true
		elseif name == "home" then
			move_to(1, shift)
			return true
		elseif name == "end" then
			move_to(#w.text + 1, shift)
			return true
		elseif m.code and m.code >= 32 and m.code < 127 and (mods & 6) == 0 then
			textbox_delete_range(w)
			insert_at(w, string.char(m.code))
			if w.onchange then
				w.onchange(w)
			end
			return true
		end
		return false
	elseif w.kind == "listbox" then
		if name == "up" then
			self:select(w, math.max(1, (w.selected > 0 and w.selected or 2) - 1))
			return true
		elseif name == "down" then
			self:select(w, math.min(#w.items, (w.selected > 0 and w.selected or 0) + 1))
			return true
		elseif name == "pageup" then
			local rows = self:visible_rows(w)
			self:nudge_top(w, -rows, rows, #w.items)
			return true
		elseif name == "pagedown" then
			local rows = self:visible_rows(w)
			self:nudge_top(w, rows, rows, #w.items)
			return true
		elseif name == "home" then
			self:select(w, 1)
			return true
		elseif name == "end" then
			self:select(w, #w.items)
			return true
		elseif name == "enter" or name == "space" then
			if w.selected > 0 and w.ondouble then
				w.ondouble(w, w.selected)
			end
			return true
		end
		return false
	elseif w.kind == "checkbox" then
		if name == "space" then
			self:set_checkbox(w, not w.value)
			return true
		end
		return false
	elseif w.kind == "radio" then
		if name == "space" then
			self:set_radio(w, true)
			return true
		elseif name == "left" or name == "up" then
			self:radio_step(w, -1)
			return true
		elseif name == "right" or name == "down" then
			self:radio_step(w, 1)
			return true
		end
		return false
	elseif w.kind == "dropdown" then
		if name == "escape" and w.open then
			self:set_dropdown(w, false)
			return true
		elseif name == "enter" or name == "space" then
			if w.open then
				self:set_dropdown(w, false)
			else
				self:close_dropdowns(w)
				self:set_dropdown(w, true)
				self:dropdown_top(w)
				w.dirty = true
			end
			return true
		elseif name == "up" then
			if w.open then
				if w.selected > 1 then
					self:select(w, w.selected - 1)
				end
			elseif w.selected > 1 then
				self:select(w, w.selected - 1)
			end
			return true
		elseif name == "down" then
			if w.open then
				if w.selected < #w.items then
					self:select(w, (w.selected > 0 and w.selected or 0) + 1)
				end
			elseif w.selected < #w.items then
				self:select(w, (w.selected > 0 and w.selected or 0) + 1)
			end
			return true
		elseif name == "home" then
			if #w.items > 0 then
				self:select(w, 1)
			end
			return true
		elseif name == "end" then
			if #w.items > 0 then
				self:select(w, #w.items)
			end
			return true
		end
		return false
	elseif w.kind == "menubutton" then
		if name == "escape" and w.open then
			self:set_menu(w, false)
			return true
		elseif name == "enter" or name == "space" then
			if w.open then
				local idx = w.selected
				self:set_menu(w, false)
				if idx > 0 and w.onselect then
					w.onselect(w, idx)
				end
			else
				self:close_dropdowns(w)
				self:set_menu(w, true)
			end
			return true
		elseif name == "up" then
			if not w.open then
				self:close_dropdowns(w)
				self:set_menu(w, true)
			elseif w.selected > 1 then
				self:menu_highlight(w, w.selected - 1)
			end
			return true
		elseif name == "down" then
			if not w.open then
				self:close_dropdowns(w)
				self:set_menu(w, true)
			elseif w.selected < #w.items then
				self:menu_highlight(w, (w.selected > 0 and w.selected or 0) + 1)
			end
			return true
		elseif name == "home" then
			if not w.open then
				self:close_dropdowns(w)
				self:set_menu(w, true)
			elseif #w.items > 0 then
				self:menu_highlight(w, 1)
			end
			return true
		elseif name == "end" then
			if not w.open then
				self:close_dropdowns(w)
				self:set_menu(w, true)
			elseif #w.items > 0 then
				self:menu_highlight(w, #w.items)
			end
			return true
		elseif name == "left" or name == "right" then
			self:menu_step(w, name == "right" and 1 or -1)
			return true
		end
		return false
	elseif w.kind == "spinbox" then
		if name == "enter" then
			self:spin_commit(w)
			return true
		elseif name == "escape" then
			w.text = self:spin_format(w, w.value)
			w.cursor = #w.text + 1
			w.dirty = true
			return true
		elseif name == "up" then
			self:spin_step(w, 1)
			return true
		elseif name == "down" then
			self:spin_step(w, -1)
			return true
		elseif name == "backspace" then
			if w.cursor > 1 then
				local L = w.text
				w.text = L:sub(1, w.cursor - 2) .. L:sub(w.cursor)
				w.cursor = w.cursor - 1
				w.dirty = true
			end
			return true
		elseif name == "delete" then
			if w.cursor <= #w.text then
				local L = w.text
				w.text = L:sub(1, w.cursor - 1) .. L:sub(w.cursor + 1)
				w.dirty = true
			end
			return true
		elseif name == "left" then
			w.cursor = math.max(1, w.cursor - 1)
			w.dirty = true
			return true
		elseif name == "right" then
			w.cursor = math.min(#w.text + 1, w.cursor + 1)
			w.dirty = true
			return true
		elseif name == "home" then
			w.cursor = 1
			w.dirty = true
			return true
		elseif name == "end" then
			w.cursor = #w.text + 1
			w.dirty = true
			return true
		elseif m.code and m.code >= 32 and m.code < 127 and (mods & 6) == 0 then
			local ch = string.char(m.code)
			if ch:match("[0-9%-%+%.eE]") then
				insert_at(w, ch)
				return true
			end
		end
		return false
	elseif w.kind == "scrollbar" then
		if name == "up" or name == "left" then
			self:set_scroll(w, w.first - 1)
			return true
		elseif name == "down" or name == "right" then
			self:set_scroll(w, w.first + 1)
			return true
		elseif name == "home" then
			self:set_scroll(w, 1)
			return true
		elseif name == "end" then
			self:set_scroll(w, self:scroll_maxfirst(w))
			return true
		elseif name == "pageup" or name == "pageUp" then
			self:set_scroll(w, w.first - w.visible)
			return true
		elseif name == "pagedown" or name == "pageDown" then
			self:set_scroll(w, w.first + w.visible)
			return true
		end
		return false
	elseif w.kind == "button" then
		if name == "space" or name == "enter" then
			if w.onpress then
				w.onpress(w)
			end
			return true
		end
		return false
	elseif w.kind == "slider" then
		local step = (w.max - w.min) / 20
		if step <= 0 then
			step = 1
		end
		if name == "left" or name == "down" then
			self:set_slider(w, w.value - step)
			return true
		elseif name == "right" or name == "up" then
			self:set_slider(w, w.value + step)
			return true
		elseif name == "home" then
			self:set_slider(w, w.min)
			return true
		elseif name == "end" then
			self:set_slider(w, w.max)
			return true
		end
		return false
	elseif w.kind == "tree" then
		local idx = self:tree_selected_row(w)
		if name == "up" then
			self:tree_move(w, -1)
			return true
		elseif name == "down" then
			self:tree_move(w, 1)
			return true
		elseif name == "pageup" then
			self:tree_move(w, -self:tree_visible_rows(w))
			return true
		elseif name == "pagedown" then
			self:tree_move(w, self:tree_visible_rows(w))
			return true
		elseif name == "home" then
			if w.rows and w.rows[1] then
				self:tree_select(w, w.rows[1].node)
			end
			return true
		elseif name == "end" then
			if w.rows and w.rows[#w.rows] then
				self:tree_select(w, w.rows[#w.rows].node)
			end
			return true
		elseif name == "left" then
			local row = idx > 0 and w.rows and w.rows[idx] or nil
			if row then
				local n = row.node
				if w.expanded[n] and n.children and #n.children > 0 then
					w.expanded[n] = false
					self:tree_refresh(w)
				else
					local par = self:tree_parent(w, n)
					if par then
						self:tree_select(w, par)
					end
				end
			end
			return true
		elseif name == "right" then
			local row = idx > 0 and w.rows and w.rows[idx] or nil
			if row then
				local n = row.node
				if n.children and #n.children > 0 then
					if not w.expanded[n] then
						w.expanded[n] = true
						self:tree_refresh(w)
					elseif n.children[1] then
						self:tree_select(w, n.children[1])
					end
				end
			end
			return true
		elseif name == "enter" or name == "space" then
			self:tree_activate(w)
			return true
		end
		return false
	elseif w.kind == "tabbar" then
		if name == "left" then
			self:tab_move(w, -1)
			return true
		elseif name == "right" then
			self:tab_move(w, 1)
			return true
		elseif name == "home" then
			self:select_tab(w, 1)
			return true
		elseif name == "end" then
			self:select_tab(w, #w.tabs)
			return true
		elseif name == "enter" or name == "space" then
			self:select_tab(w, w.selected)
			return true
		end
		return false
	elseif w.kind == "textview" then
		local shift = (mods & 1) ~= 0
		local ctrl = (mods & 2) ~= 0
		if ctrl and name == "c" then
			self:copy_selection(w)
			return true
		elseif ctrl and name == "a" then
			w.anchor = { line = 1, col = 1 }
			w.cursor = { line = #w.lines, col = utf8.len(w.plain[#w.lines] or "") + 1 }
			w.dirty = true
			return true
		elseif name == "up" then
			self:text_move(w, -1, 0, shift)
			return true
		elseif name == "down" then
			self:text_move(w, 1, 0, shift)
			return true
		elseif name == "left" then
			self:text_move(w, 0, -1, shift)
			return true
		elseif name == "right" then
			self:text_move(w, 0, 1, shift)
			return true
		elseif name == "pageup" then
			self:text_page(w, -1, shift)
			return true
		elseif name == "pagedown" then
			self:text_page(w, 1, shift)
			return true
		elseif name == "home" then
			if ctrl then
				w.cursor = { line = 1, col = 1 }
				self:show_line(w, 1)
				w.dirty = true
			else
				self:text_move_home(w, shift)
			end
			return true
		elseif name == "end" then
			if ctrl then
				w.cursor = { line = #w.lines, col = utf8.len(w.plain[#w.lines] or "") + 1 }
				self:show_line(w, #w.lines)
				w.dirty = true
			else
				self:text_move_end(w, shift)
			end
			return true
		elseif name == "enter" then
			if w.onactivate then
				w.onactivate(self, w, w.current or w.cursor.line, w.cursor.col)
			end
			return true
		end
		return false
	elseif w.kind == "splitter" then
		if name == "left" or name == "up" then
			self:splitter_set(w, w.value - 8)
			return true
		elseif name == "right" or name == "down" then
			self:splitter_set(w, w.value + 8)
			return true
		end
		return false
	elseif w.kind == "canvas" then
		return false
	end
	return false
end

function App:run()
	local c = self.client
	local need_paint, last_try = not self:render(true), self:clock()
	while not self.quit do
		for _, m in ipairs(c:poll(0.2)) do
			if type(m) ~= "table" then
			elseif m.op == "close" then
				local veto = false
				if type(self.closehandler) == "function" then
					local ok, v = pcall(self.closehandler)
					veto = ok and v and true or false
				end
				if veto then
					if not self:render(false) then
						need_paint, last_try = true, self:clock()
					end
				else
					self.quit = true
				end
			elseif m.op == "destroyed" then
				self.quit = true
			elseif m.op == "focus" then
				self.window_focused = not (m.focused == false)
				if self.focus then
					self.focus.dirty = true
				end
				if self._last_focus then
					self._last_focus.dirty = true
				end
				if not self:render(false) then
					need_paint, last_try = true, self:clock()
				end
			elseif m.op == "map" or m.op == "configure" then
				self:handle_configure(m)
				if not self:render(true) then
					need_paint, last_try = true, self:clock()
				end
			elseif m.op == "mouse" then
				self:handle_mouse(m)
				if not self:render(false) then
					need_paint, last_try = true, self:clock()
				end
			elseif m.op == "key" and m.down then
				self:handle_key(m)
				if not self:render(false) then
					need_paint, last_try = true, self:clock()
				end
			end
		end

		if self.tick_fn then
			local now = self:clock()
			local fire = false
			if now ~= nil then
				if self.tick_last == nil then
					self.tick_last = now
				elseif now - self.tick_last >= self.tick_secs then
					self.tick_last = now
					fire = true
				end
			else
				self.tick_count = (self.tick_count or 0) + 1
				if self.tick_count >= math.max(1, math.floor(self.tick_secs / 0.2)) then
					self.tick_count = 0
					fire = true
				end
			end
			if fire then
				self.tick_fn()
				if not self:render(false) then
					need_paint, last_try = true, self:clock()
				end
			end
		end
		if need_paint and self:due(last_try) then
			last_try = self:clock()
			need_paint = not self:render(true)
		end
		if type(event.poll) == "function" then
			local n = event.poll()
			if n == "terminate" then
				self.quit = true
			end
		end
	end
end

local function dialog_app(title, w, h, transient_for)
	return M.App({
		name = "dialog",
		title = title or "dialog",
		w = w,
		h = h,
		dialog = true,
		transient_for = transient_for,
	})
end

function M.alert(opts)
	opts = opts or {}
	local app = dialog_app(opts.title, 260, 120, opts.transient_for)
	if not app then
		return nil, "cannot connect"
	end
	local lab = app:label({
		x = 10,
		y = 10,
		w = 240,
		h = 52,
		text = opts.text or "",
		anchor = "top",
	})
	local btn = app:button({
		x = 90,
		y = 72,
		w = 80,
		h = 30,
		label = "OK",
		onpress = function()
			app.quit = true
		end,
	})
	app:onresize(function(W, H)
		lab.w = math.max(4, W - 20)
		lab.h = math.max(4, H - 68)
		lab.dirty = true
		btn.x = (W - 80) // 2
		btn.y = H - 30 - 10
		btn.dirty = true
	end)
	app:run()
	app:close()
	return true
end

function M.confirm(opts)
	opts = opts or {}
	local app = dialog_app(opts.title, 260, 120, opts.transient_for)
	if not app then
		return nil, "cannot connect"
	end
	local answer = false
	local lab = app:label({
		x = 10,
		y = 10,
		w = 240,
		h = 52,
		text = opts.text or "",
		anchor = "top",
	})
	local okb = app:button({
		x = 40,
		y = 72,
		w = 80,
		h = 30,
		label = "OK",
		onpress = function()
			answer = true
			app.quit = true
		end,
	})
	local cb = app:button({
		x = 140,
		y = 72,
		w = 80,
		h = 30,
		label = "Cancel",
		onpress = function()
			app.quit = true
		end,
	})
	app:onresize(function(W, H)
		lab.w = math.max(4, W - 20)
		lab.h = math.max(4, H - 68)
		lab.dirty = true
		local x0 = (W - 180) // 2
		local y = H - 30 - 10
		okb.x, okb.y = x0, y
		cb.x, cb.y = x0 + 100, y
		okb.dirty, cb.dirty = true, true
	end)
	app:run()
	app:close()
	return answer
end

function M.prompt(opts)
	opts = opts or {}
	local app = dialog_app(opts.title, 300, 140, opts.transient_for)
	if not app then
		return nil, "cannot connect"
	end
	local answer = nil
	app:label({
		x = 10,
		y = 10,
		w = 280,
		h = 28,
		text = opts.text or "",
		anchor = "top",
	})
	local box = app:textbox({
		x = 10,
		y = 44,
		w = 280,
		text = opts.default or "",
		onenter = function(b)
			answer = b.text
			app.quit = true
		end,
		anchor = "top",
	})
	app.focus = box
	local okb = app:button({
		x = 60,
		y = 94,
		w = 80,
		h = 30,
		label = "OK",
		onpress = function()
			answer = box.text
			app.quit = true
		end,
	})
	local cb = app:button({
		x = 160,
		y = 94,
		w = 80,
		h = 30,
		label = "Cancel",
		onpress = function()
			app.quit = true
		end,
	})
	app:onresize(function(W, H)
		local x0 = (W - 180) // 2
		local y = H - 30 - 10
		okb.x, okb.y = x0, y
		cb.x, cb.y = x0 + 100, y
		okb.dirty, cb.dirty = true, true
	end)
	app:run()
	app:close()
	return answer
end

function M.choose(opts)
	opts = opts or {}
	local app = dialog_app(opts.title, 300, 220, opts.transient_for)
	if not app then
		return nil, "cannot connect"
	end
	local answer = nil
	app:label({
		x = 10,
		y = 10,
		w = 280,
		h = 28,
		text = opts.text or "",
		anchor = "top",
	})
	local list = app:listbox({
		x = 10,
		y = 44,
		w = 280,
		h = 116,
		items = opts.items or {},
		selected = opts.selected or 0,
		ondouble = function(l, idx)
			answer = idx
			app.quit = true
		end,
		anchor = "all",
	})
	if opts.selected and opts.selected > 0 then
		app:select(list, opts.selected)
	end
	app.focus = list
	local okb = app:button({
		x = 60,
		y = 172,
		w = 80,
		h = 30,
		label = "OK",
		onpress = function()
			answer = list.selected > 0 and list.selected or nil
			app.quit = true
		end,
	})
	local cb = app:button({
		x = 160,
		y = 172,
		w = 80,
		h = 30,
		label = "Cancel",
		onpress = function()
			app.quit = true
		end,
	})
	app:onresize(function(W, H)
		list.h = math.max(20, H - 44 - 48)
		list.dirty = true
		local x0 = (W - 180) // 2
		local y = H - 30 - 10
		okb.x, okb.y = x0, y
		cb.x, cb.y = x0 + 100, y
		okb.dirty, cb.dirty = true, true
	end)
	app:onkey(function(m)
		if m.name == "enter" then
			answer = list.selected > 0 and list.selected or nil
			app.quit = true
		end
	end)
	app:run()
	app:close()
	return answer
end

local function fileapp_prog(override)
	if type(override) == "string" and override ~= "" then
		return override
	end
	if type(env) == "table" and type(env.get) == "function" then
		local ok, v = pcall(env.get, "FILEAPP")
		if ok and type(v) == "string" and v ~= "" then
			return v
		end
	end
	return "/bin/xfile"
end

M.fileapp = fileapp_prog

local function pick_tmpfile()
	if type(fs) ~= "table" or type(fs.stat) ~= "function" or type(fs.open) ~= "function" then
		return nil
	end
	local pid = 0
	if type(proc) == "table" and type(proc.getpid) == "function" then
		local ok, v = pcall(proc.getpid)
		if ok and type(v) == "number" then
			pid = v
		end
	end
	for _ = 1, 50 do
		local r = {}
		for i = 1, 8 do
			r[i] = string.char(math.random(97, 122))
		end
		local name = "/tmp/openfile." .. tostring(pid) .. "." .. table.concat(r)
		local st
		local ok, v = pcall(fs.stat, name)
		if ok then
			st = v
		end
		if not st then
			local h = fs.open(name, "w")
			if h then
				h:write("")
				h:close()
				pcall(fs.chmod, name, 384)
				return name
			end
			return nil
		end
	end
	return nil
end

local function pick_sleep()
	if type(sys) == "table" and type(sys.sleep) == "function" then
		pcall(sys.sleep, 0.05)
	elseif type(spp) == "table" and type(spp.poll) == "function" then
		pcall(spp.poll, {}, 0.05)
	end
end

local function pump_app(app)
	if type(app) ~= "table" or app.client == nil then
		return
	end
	local ok, msgs = pcall(function()
		return app.client:poll(0)
	end)
	if not ok or type(msgs) ~= "table" then
		return
	end
	local need = false
	for _, m in ipairs(msgs) do
		if type(m) == "table" and (m.op == "configure" or m.op == "map") then
			pcall(function()
				app:handle_configure(m)
			end)
			need = true
		elseif type(m) == "table" and m.op == "destroyed" then
			app.quit = true
		end
	end
	if need then
		pcall(function()
			app:render(true)
		end)
	end
end

local function pick_trim(s)
	return (s or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function pick_via_manager(mode, opts)
	opts = opts or {}
	if type(proc) ~= "table" or type(proc.spawn) ~= "function" or type(posix) ~= "table" or type(posix.wait) ~= "function" then
		return nil, "nospawn"
	end
	local prog = fileapp_prog(opts.fileapp)
	local outfile = pick_tmpfile()
	if not outfile then
		return nil, "notmp"
	end
	local args = { mode == "save" and "--savedialog" or "--opendialog", "--outfile", outfile }
	local start = opts.dir
	if (start == nil or start == "") and opts.start ~= nil then
		start = opts.start
	end
	if type(start) == "string" and start ~= "" then
		args[#args + 1] = start
	end
	local pid, _, serr = proc.spawn(prog, args)
	if not pid then
		pcall(fs.delete, outfile)
		return nil, "spawn: " .. tostring(serr)
	end
	local code = nil
	while code == nil do
		if opts.app then
			pump_app(opts.app)
			if opts.app.quit then
				pcall(proc.kill, pid, "term")
				pcall(proc.wait, pid)
				pcall(fs.delete, outfile)
				return nil, "killed"
			end
		end
		if type(opts.pump) == "function" then
			pcall(opts.pump)
		end
		if type(opts.abort) == "function" then
			local ok, stop = pcall(opts.abort)
			if ok and stop then
				pcall(proc.kill, pid, "term")
				pcall(proc.wait, pid)
				pcall(fs.delete, outfile)
				return nil, "killed"
			end
		end
		local wpid, wcode = posix.wait(pid, true)
		if wpid == nil then
			code = 1
		elseif wpid ~= 0 then
			code = wcode
		end
		if code == nil then
			if type(event) == "table" and type(event.poll) == "function" then
				local ok, n = pcall(event.poll)
				if ok and n == "terminate" then
					pcall(proc.kill, pid, "term")
					pcall(proc.wait, pid)
					pcall(fs.delete, outfile)
					return nil, "killed"
				end
			end
			pick_sleep()
		end
	end
	local data = nil
	if type(fs) == "table" and type(fs.open) == "function" then
		local h = fs.open(outfile, "r")
		data = h and h:read("a")
		if h then
			h:close()
		end
	end
	pcall(fs.delete, outfile)
	if code == 0 and pick_trim(data or "") ~= "" then
		return pick_trim(data)
	end
	return nil, "cancel"
end

function M.openfile(opts)
	opts = opts or {}
	local path, err = pick_via_manager("open", opts)
	if path then
		return path
	end
	if err == "cancel" or err == "killed" then
		return nil
	end
	return M.prompt({
		title = opts.title or "Open file",
		text = "Path:",
		default = opts.dir or opts.start or "",
		transient_for = opts.app and opts.app.win or nil,
	})
end

function M.savefile(opts)
	opts = opts or {}
	local path, err = pick_via_manager("save", opts)
	if path then
		return path
	end
	if err == "cancel" or err == "killed" then
		return nil
	end
	return M.prompt({
		title = opts.title or "Save file",
		text = "Path:",
		default = opts.dir or opts.start or "",
		transient_for = opts.app and opts.app.win or nil,
	})
end

return M
