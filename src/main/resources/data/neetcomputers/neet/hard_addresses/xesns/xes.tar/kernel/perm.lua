local K = ...

local Pm = {}
K.perm = Pm

local R = K.rawfs

local function o(s) return tonumber(s, 8) end
Pm.STICKY = o "1000"
Pm.MASK = o "1777"
local META = "/.xesperm"
Pm.META = META

function Pm.key(fp)
    local segs = {}
    for raw in fp:gmatch("[^/]+") do
        local seg = raw:lower():gsub("[%. ]+$", "")
        if seg ~= "" then segs[#segs + 1] = seg end
    end
    return "/" .. table.concat(segs, "/")
end

local ckey = Pm.key

function Pm.hidden(fp) return ckey(fp) == META end

local function under(key, dir)
    return key == dir or key:sub(1, #dir + 1) == dir .. "/"
end

function Pm.parentKey(key)
    if key == "/" then return nil end
    local par = key:match("^(.*)/[^/]*$")
    if par == "" then return "/" end
    return par
end

local EXEC_DIRS = { "/bin", "/sbin", "/usr/bin", "/usr/sbin", "/usr/libexec", "/libexec" }

local function isRootPart(slot, part)
    return K.root ~= nil and K.root.slot == slot and K.root.part == part
end

function Pm.default(slot, part, key, isdir)
    local mode = isdir and o "755" or o "644"
    local gid = 0
    if isRootPart(slot, part) then
        if under(key, "/root") or under(key, "/var/db")
            or key == "/etc/master.passwd" or key:sub(1, 19) == "/etc/master.passwd."
            or key == "/etc/doas.conf" then
            mode = isdir and o "700" or o "600"
        elseif key:sub(1, 14) == "/var/log/auth." then
            mode = o "640"
        elseif isdir and (key == "/tmp" or key == "/var/tmp") then
            mode = o "1777"
        elseif not isdir then
            for _, d in ipairs(EXEC_DIRS) do
                if under(key, d) then
                    mode = o "755"
                    break
                end
            end
        end
    end
    return { mode = mode, uid = 0, gid = gid, dir = isdir and true or false }
end

local stores = {}

local function loadStore(slot, part)
    local id = slot .. ":" .. part
    local st = stores[id]
    if st then return st end
    st = { slot = slot, part = part, e = {} }
    stores[id] = st
    local data = R.readAll(slot, part, META)
    if data then
        for line in data:gmatch("[^\n]+") do
            local m, u, g, path = line:match("^(%d+) (%d+) (%d+) (/.*)$")
            if m then
                st.e[ckey(path)] = { mode = tonumber(m, 8) & Pm.MASK, uid = tonumber(u), gid = tonumber(g) }
            elseif K.klog then
                K.klog("perm: ignoring bad line in %s:%s", part, META)
            end
        end
    end
    return st
end

local function save(st)
    local keys = {}
    for k in pairs(st.e) do keys[#keys + 1] = k end
    table.sort(keys)
    local out = {}
    for _, k in ipairs(keys) do
        local e = st.e[k]
        out[#out + 1] = string.format("%o %d %d %s", e.mode, e.uid, e.gid, k)
    end
    local ok, err = R.writeAll(st.slot, st.part, META, table.concat(out, "\n") .. (#out > 0 and "\n" or ""))
    if not ok and K.klog then K.klog("perm: cannot write %s:%s: %s", st.part, META, tostring(err)) end
    return ok
end

function Pm.meta(slot, part, fp, isdir)
    local key = ckey(fp)
    local e = loadStore(slot, part).e[key]
    if e then return { mode = e.mode, uid = e.uid, gid = e.gid, dir = isdir and true or false } end
    return Pm.default(slot, part, key, isdir)
end

function Pm.set(slot, part, fp, m)
    local st = loadStore(slot, part)
    st.e[ckey(fp)] = { mode = m.mode & Pm.MASK, uid = m.uid, gid = m.gid }
    return save(st)
end

function Pm.drop(slot, part, fp)
    local st = loadStore(slot, part)
    local key = ckey(fp)
    if st.e[key] then
        st.e[key] = nil
        return save(st)
    end
    return true
end

function Pm.reload() stores = {} end

local function inGroup(cred, gid)
    if cred.gid == gid then return true end
    local gs = cred.groups
    if gs then for i = 1, #gs do if gs[i] == gid then return true end end end
    return false
end
Pm.inGroup = inGroup

function Pm.permits(cred, meta, want)
    if cred.uid == 0 then
        if (want & 1) ~= 0 and not meta.dir and (meta.mode & o "111") == 0 then return false end
        return true
    end
    local cls
    if cred.uid == meta.uid then
        cls = (meta.mode >> 6) & 7
    elseif inGroup(cred, meta.gid) then
        cls = (meta.mode >> 3) & 7
    else
        cls = meta.mode & 7
    end
    return (cls & want) == want
end

function Pm.traverse(cred, slot, part, fp)
    if cred.uid == 0 then return true end
    local key = ckey(fp)
    if not Pm.permits(cred, Pm.meta(slot, part, "/", true), 1) then return false end
    local acc = ""
    local segs = {}
    for seg in key:gmatch("[^/]+") do segs[#segs + 1] = seg end
    for i = 1, #segs - 1 do
        acc = acc .. "/" .. segs[i]
        if not Pm.permits(cred, Pm.meta(slot, part, acc, true), 1) then return false end
    end
    return true
end

function Pm.stickyOk(cred, dmeta, ometa)
    if cred.uid == 0 or (dmeta.mode & Pm.STICKY) == 0 then return true end
    return cred.uid == ometa.uid or cred.uid == dmeta.uid
end

local IMMUTABLE_PARTS = { bios = true, system = true }
local IMMUTABLE_PATHS = { "/kernel", "/boot.lua", "/sbin", "/bin", "/usr/bin", "/usr/sbin",
    "/usr/lib/xes", "/etc/rc" }

function Pm.immutable(slot, part, fp)
    if (K.securelevel or 0) < 1 then return false end
    if IMMUTABLE_PARTS[part] then return true end
    if isRootPart(slot, part) then
        local key = ckey(fp)
        for _, d in ipairs(IMMUTABLE_PATHS) do
            if under(key, d) then return true end
        end
    end
    return false
end
