local K = ...

-- The host file system stores no mode/uid/gid: POSIX metadata lives in the per-partition
-- sidecar /.xesperm and a path without an entry gets Pm.default.  There is no host rename, so
-- saves are journalled through <sidecar>.new (see Pm.sidecarWrite and Pm.sidecarRead).

local Pm = {}
K.perm = Pm

local R = K.rawfs

local function o(s)
	return tonumber(s, 8)
end
Pm.STICKY = o("1000")
Pm.MASK = o("1777")
local META = "/.xesperm"
Pm.META = META

function Pm.key(fp)
	local segs = {}
	for raw in fp:gmatch("[^/]+") do
		segs[#segs + 1] = raw
	end
	return "/" .. table.concat(segs, "/")
end

local ckey = Pm.key

local TEMP, TRAILER = ".new", "# end\n"
Pm.TEMP = TEMP
local temps = { [META .. TEMP] = true }

function Pm.hidden(fp)
	return ckey(fp) == META or temps[ckey(fp)] == true
end

function Pm.hideTemp(fp)
	temps[ckey(fp) .. TEMP] = true
end

local function under(key, dir)
	return key == dir or key:sub(1, #dir + 1) == dir .. "/"
end

function Pm.parentKey(key)
	if key == "/" then
		return nil
	end
	local par = key:match("^(.*)/[^/]*$")
	if par == "" then
		return "/"
	end
	return par
end

local EXEC_DIRS = { "/bin", "/sbin", "/usr/bin", "/usr/sbin", "/usr/libexec", "/libexec" }

local function isRootPart(slot, part)
	return K.root ~= nil and K.root.slot == slot and K.root.part == part
end

function Pm.default(slot, part, key, isdir)
	local mode = isdir and o("755") or o("644")
	local gid = 0
	if isRootPart(slot, part) then
		if
			under(key, "/root")
			or under(key, "/var/db")
			or key == "/etc/master.passwd"
			or key:sub(1, 19) == "/etc/master.passwd."
			or key == "/etc/doas.conf"
		then
			mode = isdir and o("700") or o("600")
		elseif key:sub(1, 14) == "/var/log/auth." then
			mode = o("640")
		elseif isdir and (key == "/tmp" or key == "/var/tmp") then
			mode = o("1777")
		elseif not isdir then
			for _, d in ipairs(EXEC_DIRS) do
				if under(key, d) then
					mode = o("755")
					break
				end
			end
		end
	end
	return { mode = mode, uid = 0, gid = gid, dir = isdir and true or false }
end

local stores = {}

local function parseLine(line)
	local m, u, g, path = line:match("^(%d+) (%d+) (%d+) (/.*)$")
	if not m then
		return nil
	end
	return path, tonumber(m, 8) & Pm.MASK, tonumber(u), tonumber(g)
end

local function whole(data, parse)
	if data == "" then
		return true
	end
	if data:sub(-1) ~= "\n" then
		return false
	end
	for line in data:gmatch("(.-)\n") do
		if parse(line) == nil then
			return false
		end
	end
	return true
end
Pm.whole = whole

function Pm.sidecarRead(slot, part, fp, parse)
	local data = R.readAll(slot, part, fp .. TEMP)
	if data ~= nil then
		if data:sub(-#TRAILER) == TRAILER and whole(data:sub(1, -#TRAILER - 1), parse) then
			data = data:sub(1, -#TRAILER - 1)
			if R.writeAll(slot, part, fp, data) then
				R.remove(slot, part, fp .. TEMP)
			end
			return data
		end
		R.remove(slot, part, fp .. TEMP)
	end
	return R.readAll(slot, part, fp)
end

function Pm.sidecarWrite(slot, part, fp, data)
	local tmp, journal = fp .. TEMP, data .. TRAILER
	local ok, err = R.writeAll(slot, part, tmp, journal)
	if ok and R.readAll(slot, part, tmp) ~= journal then
		ok, err = nil, "incomplete write to " .. tmp
	end
	if not ok then
		R.remove(slot, part, tmp)
		return nil, err
	end
	local old = R.readAll(slot, part, fp)
	ok, err = R.writeAll(slot, part, fp, data)
	if ok and R.readAll(slot, part, fp) ~= data then
		ok, err = nil, "incomplete write to " .. fp
	end
	if not ok then
		if old ~= nil and R.writeAll(slot, part, fp, old) and R.readAll(slot, part, fp) == old then
			R.remove(slot, part, tmp)
		end
		return nil, err
	end
	R.remove(slot, part, tmp)
	return true
end

local function save(st)
	local keys = {}
	for k in pairs(st.e) do
		keys[#keys + 1] = k
	end
	table.sort(keys)
	local out = {}
	for _, k in ipairs(keys) do
		local e = st.e[k]
		out[#out + 1] = string.format("%o %d %d %s", e.mode, e.uid, e.gid, st.p[k] or k)
	end
	local ok, err = Pm.sidecarWrite(st.slot, st.part, META, table.concat(out, "\n") .. (#out > 0 and "\n" or ""))
	if not ok and K.klog then
		K.klog("perm: cannot write %s:%s: %s", st.part, META, tostring(err))
	end
	return ok
end

local function resolvePath(slot, part, path, cache)
	if path == "/" then
		return "/"
	end
	local cur = ""
	for seg in path:gmatch("[^/]+") do
		local dir = cur == "" and "/" or cur
		local names = cache[dir]
		if names == nil then
			names = R.list(slot, part, dir) or false
			cache[dir] = names
		end
		if not names then
			return nil
		end
		local found = nil
		for _, name in ipairs(names) do
			if name == seg then
				found = name
				break
			end
		end
		if not found then
			return nil
		end
		cur = cur .. "/" .. found
	end
	return cur
end

local function loadStore(slot, part)
	local id = slot .. ":" .. part
	local st = stores[id]
	if st then
		return st
	end
	st = { slot = slot, part = part, e = {}, p = {} }
	stores[id] = st
	local data = Pm.sidecarRead(slot, part, META, parseLine)
	if data then
		for line in data:gmatch("[^\n]+") do
			local path, mode, uid, gid = parseLine(line)
			if path then
				local key = ckey(path)
				st.e[key] = { mode = mode, uid = uid, gid = gid }
				st.p[key] = path
			elseif K.klog then
				K.klog("perm: ignoring bad line in %s:%s", part, META)
			end
		end
	end
	local dirty, cache = false, {}
	for key, path in pairs(st.p) do
		local actual = R.exists(slot, part, path) and path or resolvePath(slot, part, path, cache)
		if actual then
			if actual ~= path then
				st.p[key] = actual
				dirty = true
			end
		end
	end
	if dirty then
		save(st)
	end
	return st
end

function Pm.meta(slot, part, fp, isdir)
	local key = ckey(fp)
	local e = loadStore(slot, part).e[key]
	if e then
		return { mode = e.mode, uid = e.uid, gid = e.gid, dir = isdir and true or false }
	end
	return Pm.default(slot, part, key, isdir)
end

function Pm.set(slot, part, fp, m)
	local st = loadStore(slot, part)
	local key = ckey(fp)
	st.e[key] = { mode = m.mode & Pm.MASK, uid = m.uid, gid = m.gid }
	st.p[key] = fp
	return save(st)
end

function Pm.drop(slot, part, fp)
	local st = loadStore(slot, part)
	local key = ckey(fp)
	if st.e[key] then
		st.e[key] = nil
		st.p[key] = nil
		return save(st)
	end
	return true
end

function Pm.reload()
	stores = {}
end

local function inGroup(cred, gid)
	if cred.gid == gid then
		return true
	end
	local gs = cred.groups
	if gs then
		for i = 1, #gs do
			if gs[i] == gid then
				return true
			end
		end
	end
	return false
end
Pm.inGroup = inGroup

function Pm.permits(cred, meta, want)
	if cred.uid == 0 then
		if (want & 1) ~= 0 and not meta.dir and (meta.mode & o("111")) == 0 then
			return false
		end
		return true
	end
	local cls
	if cred.uid == meta.uid then
		cls = (meta.mode >> 6) & 7
	elseif inGroup(cred, meta.gid) then
		cls = (meta.mode >> 3) & 7
	else
		cls = meta.mode & 7
	end
	return (cls & want) == want
end

function Pm.traverse(cred, slot, part, fp)
	if cred.uid == 0 then
		return true
	end
	local key = ckey(fp)
	if not Pm.permits(cred, Pm.meta(slot, part, "/", true), 1) then
		return false
	end
	local acc = ""
	local segs = {}
	for seg in key:gmatch("[^/]+") do
		segs[#segs + 1] = seg
	end
	for i = 1, #segs - 1 do
		acc = acc .. "/" .. segs[i]
		if not Pm.permits(cred, Pm.meta(slot, part, acc, true), 1) then
			return false
		end
	end
	return true
end

function Pm.stickyOk(cred, dmeta, ometa)
	if cred.uid == 0 or (dmeta.mode & Pm.STICKY) == 0 then
		return true
	end
	return cred.uid == ometa.uid or cred.uid == dmeta.uid
end

local IMMUTABLE_PARTS = { bios = true, system = true }
local IMMUTABLE_PATHS_L1 = { "/kernel", "/boot.lua", "/etc/rc" }
local IMMUTABLE_PATHS_L2 = { "/sbin", "/bin", "/usr/bin", "/usr/sbin", "/usr/lib/xes", "/libexec" }

-- Securelevel >= 1 freezes the bios and system partitions and, on the root one, /kernel, /boot.lua
-- and /etc/rc; level 2 adds the program directories (/bin, /usr/lib/xes, ...), which stay
-- writable at 1 because xpm(1) installs its programs and libraries there.
function Pm.immutable(slot, part, fp)
	local level = K.securelevel or 0
	if level < 1 then
		return false
	end
	if IMMUTABLE_PARTS[part] then
		return true
	end
	if isRootPart(slot, part) then
		local key = ckey(fp)
		for _, d in ipairs(IMMUTABLE_PATHS_L1) do
			if under(key, d) then
				return true
			end
		end
		if level >= 2 then
			for _, d in ipairs(IMMUTABLE_PATHS_L2) do
				if under(key, d) then
					return true
				end
			end
		end
	end
	return false
end
