local K, API, X = ...

local T = {}

local host = rawget(_G, "internet")
if type(host) ~= "table" or type(host.hasAccess) ~= "function" then
	T.__eventonly = true
	return T
end
if type(host.GET) ~= "function" or type(host.POST) ~= "function" then
	K.klog("kernel: ext: internet: host internet lacks GET/POST; ext.internet not reported")
	T.__eventonly = true
	return T
end

local FIELD = "net"

local CODE_BADREQUEST = 400
local MSG_BADREQUEST = "BAD REQUEST"

local EVENT_KINDS = {
	HttpResponse = true,
	WebsocketOpened = true,
	WebsocketMessage = true,
	WebsocketSendSuccess = true,
	WebsocketSendFailure = true,
	WebsocketClosed = true,
}

local pending = {}
local pendingCount = 0
local sockets = setmetatable({}, { __mode = "k" })

local function stateOf(p)
	local s = p and rawget(p, FIELD)
	if type(s) ~= "table" then
		return nil
	end
	return s
end

local function guard(p, name)
	local s = stateOf(p)
	local fn = s and s.deny
	if type(fn) ~= "function" then
		return
	end
	local verdict, msg = fn(p, name)
	if verdict == nil or verdict == false then
		return
	end
	local text
	if type(verdict) == "string" then
		text = verdict
	elseif type(msg) == "string" and msg ~= "" then
		text = msg
	else
		text = "Internet access denied"
	end
	error(text, 0)
end

local function checkUrl(url, pattern)
	if type(url) ~= "string" or not url:match(pattern) then
		error("Invalid URL", 0)
	end
end

local function checkHeaders(headers)
	if headers == nil then
		return
	end
	if type(headers) ~= "table" then
		error("Invalid Header (All values must be strings)", 0)
	end
	for k, v in pairs(headers) do
		if type(k) ~= "string" or type(v) ~= "string" then
			error("Invalid Header (All values must be strings)", 0)
		end
	end
end

local function push(p, name, ...)
	if type(p) ~= "table" or p.state == "Z" then
		return false
	end
	return K.pushEvent(p, name, ...)
end

local function drop(id)
	if pending[id] then
		pending[id] = nil
		pendingCount = pendingCount - 1
	end
end

local function reserve(id, proc, kind)
	if not pending[id] then
		pendingCount = pendingCount + 1
	end
	pending[id] = { proc = proc, kind = kind }
end

local function one(ev)
	if type(ev) ~= "table" then
		return
	end
	local kind = ev[1]
	if type(kind) ~= "string" or not EVENT_KINDS[kind] then
		return
	end

	if kind == "WebsocketSendFailure" and type(ev[2]) ~= "number" then
		local msg = ev[2]
		for proc, n in pairs(sockets) do
			if n > 0 then
				push(proc, "WebsocketSendFailure", msg)
			end
		end
		return
	end

	local id = ev[2]
	if type(id) ~= "number" then
		return
	end
	local entry = pending[id]
	if not entry then
		return
	end
	local proc = entry.proc

	if kind == "WebsocketOpened" or kind == "WebsocketClosed" then
		if entry.kind ~= "ws" then
			drop(id)
			return
		end
	end

	if kind == "HttpResponse" then
		drop(id)
	elseif kind == "WebsocketOpened" then
		sockets[proc] = (sockets[proc] or 0) + 1
	elseif kind == "WebsocketClosed" then
		drop(id)
		local n = (sockets[proc] or 0) - 1
		sockets[proc] = n > 0 and n or nil
	end

	push(proc, kind, table.unpack(ev, 2, ev.n or #ev))
end

local function route(ev)
	if type(ev) ~= "table" then
		return
	end
	if type(ev[1]) == "table" then
		for i = 1, #ev do
			one(ev[i])
		end
		return
	end
	one(ev)
end

local PENDING_SWEEP = 256

local function sweep()
	if pendingCount < PENDING_SWEEP then
		return
	end
	for id, entry in pairs(pending) do
		if type(entry.proc) ~= "table" or entry.proc.state == "Z" then
			drop(id)
		end
	end
end

local prevSink = K.on_network
if not rawget(K, "internetRouted") then
	rawset(K, "internetRouted", true)
	K.on_network = function(ev)
		pcall(route, ev)
		if type(prevSink) == "function" then
			return prevSink(ev)
		end
	end
end

local prevRelease = K.http_release
if not rawget(K, "internetReleaseChained") then
	rawset(K, "internetReleaseChained", true)
	K.http_release = function(p)
		for id, entry in pairs(pending) do
			if entry.proc == p then
				drop(id)
			end
		end
		sockets[p] = nil
		if type(prevRelease) == "function" then
			return prevRelease(p)
		end
	end
end

local SYNTHETIC_BASE = 0x40000000
local syntheticId = SYNTHETIC_BASE

local function nextSynthetic()
	local kernelPending = K.httpPending
	while true do
		syntheticId = syntheticId + 1
		if syntheticId > 0x7FFFFFFF then
			syntheticId = SYNTHETIC_BASE + 1
		end
		local taken = pending[syntheticId] ~= nil
		if not taken and type(kernelPending) == "table" then
			taken = kernelPending[syntheticId] ~= nil
		end
		if not taken then
			return syntheticId
		end
	end
end

local function issue(p, name, fn, ...)
	local ok, id = pcall(fn, ...)
	if not ok or type(id) ~= "number" then
		local synthetic = nextSynthetic()
		push(p, "HttpResponse", synthetic, CODE_BADREQUEST, MSG_BADREQUEST, {})
		if not ok then
			K.klog("kernel: ext: internet: host %s failed: %s", name, tostring(id))
		end
		return synthetic
	end
	local entry = pending[id]
	if entry and entry.proc ~= p then
		K.klog("kernel: ext: internet: host reused pending id %d", id)
	end
	reserve(id, p, name == "CreateWebsocket" and "ws" or "http")
	sweep()
	return id
end

function T.GET(p, url, headers)
	guard(p, "GET")
	checkUrl(url, "^https?://")
	checkHeaders(headers)
	return issue(p, "GET", host.GET, url, headers)
end

function T.POST(p, url, headers, body)
	guard(p, "POST")
	checkUrl(url, "^https?://")
	checkHeaders(headers)
	return issue(p, "POST", host.POST, url, headers, body)
end

function T.CreateWebsocket(p, url, headers)
	guard(p, "CreateWebsocket")
	checkUrl(url, "^wss?://")
	checkHeaders(headers)
	if type(host.CreateWebsocket) ~= "function" then
		error("Websocket connections are not supported", 0)
	end
	return issue(p, "CreateWebsocket", host.CreateWebsocket, url, headers)
end

function T.hasAccess(p)
	return host.hasAccess() and true or false
end

function T.isReady(p)
	if type(host.isReady) == "function" then
		return host.isReady() and true or false
	end
	return T.hasAccess(p)
end

K.internet = {
	deny = function(p, fn)
		if type(p) ~= "table" then
			return nil, "no process record"
		end
		if fn ~= nil and type(fn) ~= "function" then
			return nil, "deny predicate must be a function"
		end
		local s = rawget(p, FIELD)
		if type(s) ~= "table" then
			s = {}
			p[FIELD] = s
		end
		s.deny = fn
		return true
	end,

	allowAll = function(p)
		if type(p) ~= "table" then
			return nil, "no process record"
		end
		p[FIELD] = nil
		return true
	end,

	isDenied = function(p, name)
		local s = stateOf(p)
		local fn = s and s.deny
		if type(fn) ~= "function" then
			return false
		end
		local verdict = fn(p, name)
		return verdict ~= nil and verdict ~= false
	end,

	pending = function(p)
		local out = {}
		for id, entry in pairs(pending) do
			if entry.proc == p then
				out[#out + 1] = id
			end
		end
		table.sort(out)
		return out
	end,
}

T.__hooks = {
	HttpResponse = route,
	WebsocketOpened = route,
	WebsocketMessage = route,
	WebsocketSendSuccess = route,
	WebsocketSendFailure = route,
	WebsocketClosed = route,
}

T.__ext = { ["ext.internet"] = 1 }

return T
