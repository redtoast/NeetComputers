local K = ...

local GREY = K.rgb(170, 170, 170)

function K.main()
    local data, err = K.rawRead("/usr/share/fonts/lucida-10x16.psf")
    if not data then K.panic("cannot read console font: " .. tostring(err)) end
    local font, ferr = K.psf.load(data, 0)
    if not font then K.panic("bad console font: " .. tostring(ferr)) end

    local gdata = K.rawRead("/usr/share/fonts/6x8.psf")
    if gdata then
        local gfont = K.psf.load(gdata, 0)
        if gfont then K.gfxfont = gfont end
    end

    for i = 1, 4 do K.ttys[i] = K.TTY.new("ttyv" .. (i - 1), font) end
    K.tty0 = K.ttys[1]
    K.nulltty = K.TTY.new("-", font)
    K.rootdir = K.rootdir
    K.tty_show(K.tty0)

    K.booting = true
    K.logsink = function(line)
        if K.booting then
            K.tty0:printText(line .. "\n", GREY, K.BLACK, false)
            K.tty_flush(true)
        end
    end

    K.klog("%s %s (%s) #0: %s", K.NAME, K.RELEASE, K.KERNEL, K.dateString())
    K.klog("YSLua %s, machine %s, console %dx%d", _VERSION,
        tostring(chip.getMachine and chip.getMachine() or "neet"), K.tty0.cols, K.tty0.rows)
    K.klog("root on %s:%s", K.root.id, K.root.part)
    for _, d in ipairs(K.rawfs.disks()) do
        K.klog("disk%d: %s  [%s]", d.slot, d.id, table.concat(K.rawfs.partitions(d.slot) or {}, ", "))
    end
    local host = K.vfs.readFile(K.rootdir .. "etc/hostname")
    if host and host:match("%S") then K.hostname = host:match("^%s*(%S+)") end
    K.klog("hostname %s, scheduler quantum %d instructions", K.hostname, K.quantum)
    K.securelevel = 0
    K.crypto.random_init()

    local init, serr = K.spawn(nil, K.rootdir .. "sbin/init", {}, {
        name = "init",
        uid = 0,
        tty = K.ttys[1],
        setsid = true,
        env = { PATH = "/bin:/sbin:/usr/bin:/usr/sbin", HOME = "/", TERM = "neat", USER = "root" },
    })
    if not init then K.panic("cannot start /sbin/init: " .. tostring(serr)) end
    K.klog("starting init as pid %d", init.pid)

    local ok, e = xpcall(K.run, debug.traceback)
    if not ok then K.panic(e) end
end

function K.doShutdown(mode)
    K.booting = true
    K.crypto.random_saveseed()
    local t = K.ttys[1]
    K.tty_show(t)
    t:printText(mode == "reboot" and "Rebooting...\n" or "System halted.\n", GREY, K.BLACK, false)
    K.tty_flush(true)
    coroutine.yield()
    if mode == "reboot" then chip.reboot() else chip.shutdown() end
    while true do coroutine.yield() end
end
