local K = ...

local GREY = K.rgb(170, 170, 170)

function K.main()
	local font, cname
	local font_errors = {}
	local function load_psf(path, pad)
		local data, err = K.rawRead(path)
		if not data then
			font_errors[#font_errors + 1] = path .. ": " .. tostring(err)
			return nil
		end
		local ok, f, ferr = pcall(K.psf.load, data, pad)
		if not ok then
			font_errors[#font_errors + 1] = path .. ": " .. tostring(f)
			return nil
		end
		if not f then
			font_errors[#font_errors + 1] = path .. ": " .. tostring(ferr)
			return nil
		end
		return f
	end

	local tdata = K.rawRead("/usr/share/fonts/iosevka-term.otf")
	if tdata then
		local ok, tf = pcall(K.ttfont.load, tdata, 16)
		if ok and tf then
			font, cname = tf, "iosevka-term (libfntp)"
		end
	end
	if not font then
		for _, cand in ipairs({
			"/usr/share/fonts/lucida-10x16.psf",
			"/usr/share/fonts/default8x9.psf",
			"/usr/share/fonts/6x8.psf",
		}) do
			local f = load_psf(cand, 0)
			if f then
				font = f
				local base = cand:match("([^/]+)$") or cand
				cname = base .. " (psf)"
				if base ~= "lucida-10x16.psf" then
					cname = cname .. " fallback"
				end
				break
			end
		end
	end
	if not font then
		K.panic("no usable console font: " .. table.concat(font_errors, "; "))
	end

	if tdata then
		local ok, gfont = pcall(K.ttfont.load, tdata, 12)
		if ok and gfont then
			K.gfxfont = gfont
		end
	end
	if not K.gfxfont then
		for _, cand in ipairs({
			"/usr/share/fonts/default8x9.psf",
			"/usr/share/fonts/6x8.psf",
			"/usr/share/fonts/lucida-10x16.psf",
		}) do
			local gfont = load_psf(cand, 0)
			if gfont then
				K.gfxfont = gfont
				break
			end
		end
	end

	for i = 1, 4 do
		K.ttys[i] = K.TTY.new("ttyv" .. (i - 1), font)
	end
	K.tty0 = K.ttys[1]
	K.nulltty = K.TTY.new("-", font)
	K.rootdir = K.rootdir
	K.tty_show(K.tty0)

	K.booting = true
	K.logsink = function(line)
		if K.booting then
			K.tty0:printText(line .. "\n", GREY, K.BLACK, false)
			K.tty_flush(true)
		end
	end

	K.klog("%s %s (%s) #0: %s", K.NAME, K.RELEASE, K.KERNEL, K.dateString())
	K.klog(
		"YSLua %s, machine %s, console %dx%d (%s)",
		_VERSION,
		tostring(chip.getMachine and chip.getMachine() or "neet"),
		K.tty0.cols,
		K.tty0.rows,
		cname
	)
	K.klog("root on %s:%s", K.root.id, K.root.part)
	for _, d in ipairs(K.rawfs.disks()) do
		K.klog("disk%d: %s  [%s]", d.slot, d.id, table.concat(K.rawfs.partitions(d.slot) or {}, ", "))
	end
	local host = K.vfs.readFile(K.rootdir .. "etc/hostname")
	if host and host:match("%S") then
		K.hostname = host:match("^%s*(%S+)")
	end
	K.klog("hostname %s, scheduler quantum %d instructions", K.hostname, K.quantum)
	K.securelevel = 0
	K.crypto.random_init()

	local selftest = K.rawRead("/etc/selftest")
	if selftest and selftest:match("%S") then
		local suite = selftest:match("^%s*([%w_%-]+)") or "all"
		K.testsink = rawget(_G, "print")
		K.klog("selftest: suite %s", suite)
		local idle = K.spawn(nil, K.rootdir .. "tests/helpers/idle.lua", {}, {
			name = "selftest-init",
			uid = 0,
			tty = K.ttys[1],
			setsid = true,
			env = { PATH = "/bin:/sbin:/usr/bin:/usr/sbin", HOME = "/", USER = "root" },
		})
		if not idle then
			K.panic("selftest: cannot start idle init")
		end
		local testproc, terrr = K.spawn(nil, K.rootdir .. "tests/run.lua", { suite }, {
			name = "selftest",
			uid = 0,
			tty = K.ttys[1],
			setsid = true,
			env = {
				PATH = "/bin:/sbin:/usr/bin:/usr/sbin",
				HOME = "/",
				TERM = "neat",
				USER = "root",
				XES_SELFTEST = suite,
			},
		})
		if not testproc then
			K.panic("selftest: cannot start suite: " .. tostring(terrr))
		end
		K.klog("starting selftest as pid %d", testproc.pid)
		local ok, e = xpcall(K.run, debug.traceback)
		if not ok then
			K.panic(e)
		end
		return
	end

	local init, serr = K.spawn(nil, K.rootdir .. "sbin/init", {}, {
		name = "init",
		uid = 0,
		tty = K.ttys[1],
		setsid = true,
		env = { PATH = "/bin:/sbin:/usr/bin:/usr/sbin", HOME = "/", TERM = "neat", USER = "root" },
	})
	if not init then
		K.panic("cannot start /sbin/init: " .. tostring(serr))
	end
	K.klog("starting init as pid %d", init.pid)

	local ok, e = xpcall(K.run, debug.traceback)
	if not ok then
		K.panic(e)
	end
end

function K.doShutdown(mode)
	K.booting = true
	K.crypto.random_saveseed()
	local t = K.ttys[1]
	K.tty_show(t)
	t:printText(mode == "reboot" and "Rebooting...\n" or "System halted.\n", GREY, K.BLACK, false)
	K.tty_flush(true)
	coroutine.yield()
	if mode == "reboot" then
		chip.reboot()
	else
		chip.shutdown()
	end
	while true do
		coroutine.yield()
	end
end
