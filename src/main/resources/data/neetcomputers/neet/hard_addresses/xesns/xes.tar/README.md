# XesNS

XesNS is a BSD-flavoured operating system for NEET computers.

Install the contents of this directory on a disk partition named `xes`, then boot it with the NEATO bootloader. The loader starts `/boot.lua`; `XES_ROOT` may select a root as `disk-id:xes`, `slot:xes`, or `any:xes` (the default).

Use `help` and `man` from the shell for command and system documentation.

XesNS boots to a text console.  Run `setup-desktop` as root to enable
the graphical login greeter and desktop session for the next boot, or
use `startxes` for a single graphical session from the console.

XesNS is distributed under the 2-clause BSD License; see `LICENSE`.
