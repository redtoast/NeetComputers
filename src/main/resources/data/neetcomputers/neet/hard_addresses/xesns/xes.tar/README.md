# XesNS

XesNS is a BSD-flavoured operating system for NEATO-compatible computers. This tree is the root filesystem for release **0.1.0-beta.1**.

Install the contents of this directory on a NEATO disk partition named `xes`, then boot it with the NEATO bootloader. The loader starts `/boot.lua`; `XES_ROOT` may select a root as `disk-id:xes`, `slot:xes`, or `any:xes` (the default).

Use `help` and `man` from the shell for command and system documentation.

This is a beta release. XesNS is distributed under the 2-clause BSD License; see `LICENSE`.
