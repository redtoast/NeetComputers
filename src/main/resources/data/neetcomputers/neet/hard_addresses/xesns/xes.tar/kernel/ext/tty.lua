local K, API, X = ...
local T = {}

local function ttyOf(p)
	local t = p and p.tty
	if not t or t == K.nulltty then
		return nil
	end
	return t
end

function T.setRaw(p, on)
	if type(on) ~= "boolean" then
		K.argcheck.err(1, "setRaw", "boolean", on)
	end
	local t = ttyOf(p)
	if not t then
		return nil, "ENOTSUP", "no controlling terminal"
	end
	return t:setRaw(p, on)
end

function T.isRaw(p)
	local t = ttyOf(p)
	if not t then
		return false
	end
	return t:isRaw()
end

function T.size(p)
	local t = ttyOf(p)
	if not t then
		return nil, "ENOTSUP", "no controlling terminal"
	end
	return t.cols, t.rows
end

T.__ext = { ["ext.tty"] = 1 }

return T
