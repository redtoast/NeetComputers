local K = ...

local V = {}
K.vfs = V

local R, P = K.rawfs, K.path
local Pm = K.perm
local function o(s)
	return tonumber(s, 8)
end

local function msgOf(e)
	return (tostring(e):gsub("^[^:]*:%d+:%s*", ""))
end

local function stringHandle(str)
	local pos = 0
	local h = { readable = true, writable = false }
	function h:read(fmt)
		fmt = fmt or "l"
		if type(fmt) == "number" then
			if fmt < 0 then
				return nil, "invalid count"
			end
			if fmt == 0 then
				return pos < #str and "" or nil
			end
			if pos >= #str then
				return nil
			end
			local s = str:sub(pos + 1, pos + fmt)
			pos = pos + #s
			return s
		elseif fmt == "a" then
			local s = str:sub(pos + 1)
			pos = #str
			return s
		elseif fmt == "l" then
			if pos >= #str then
				return nil
			end
			local nl = str:find("\n", pos + 1, true)
			local line
			if nl then
				line = str:sub(pos + 1, nl - 1)
				pos = nl
			else
				line = str:sub(pos + 1)
				pos = #str
			end
			return line
		end
		return nil, "invalid format"
	end

	function h:write()
		return nil, "file is read-only"
	end

	function h:seek(whence, off)
		whence, off = whence or "cur", off or 0
		local np
		if whence == "set" then
			np = off
		elseif whence == "cur" then
			np = pos + off
		elseif whence == "end" then
			np = #str + off
		else
			return nil, "invalid option"
		end
		if np < 0 or np > #str then
			return nil, "invalid offset"
		end
		pos = np
		return pos
	end

	function h:flush()
		return true
	end

	function h:close()
		return true
	end

	return h
end
V.stringHandle = stringHandle

local function rawHandle(raw, readable, writable)
	local h = { readable = readable, writable = writable }
	function h:read(fmt)
		if not readable then
			return nil, "file not open for reading"
		end
		fmt = fmt or "l"
		if type(fmt) == "number" then
			if fmt < 0 then
				return nil, "invalid count"
			end
			local ok, r = pcall(raw.read, math.floor(fmt))
			if not ok then
				return nil, msgOf(r)
			end
			if r == nil or (r == "" and fmt > 0) then
				return nil
			end
			return r
		elseif fmt == "l" or fmt == "a" then
			local ok, r = pcall(raw.read, fmt)
			if not ok then
				return nil, msgOf(r)
			end
			if r == nil and fmt == "a" then
				return ""
			end
			return r
		end
		return nil, "invalid format"
	end

	function h:write(s)
		if not writable then
			return nil, "file not open for writing"
		end
		if #s == 0 then
			return true
		end
		local ok, r = pcall(raw.write, s)
		if not ok then
			return nil, msgOf(r)
		end
		local fok, ferr = pcall(raw.flush)
		if not fok then
			return nil, msgOf(ferr)
		end
		return true
	end

	function h:seek(whence, off)
		local ok, r = pcall(raw.seek, whence or "cur", off or 0)
		if not ok then
			return nil, msgOf(r)
		end
		return r
	end

	function h:flush()
		local ok, r = pcall(raw.flush)
		if not ok then
			return nil, msgOf(r)
		end
		return true
	end

	function h:close()
		local ok, r = pcall(raw.close)
		if not ok then
			return nil, msgOf(r)
		end
		return true
	end

	return h
end

local function appendHandle(slot, part, fp)
	local h = { readable = false, writable = true }
	function h:read()
		return nil, "file not open for reading"
	end

	function h:write(s)
		if #s == 0 then
			return true
		end
		local parent = fp:match("^(.*)/[^/]*$")
		if parent == nil or parent == "" then
			parent = "/"
		end
		if not R.isDir(slot, part, parent) then
			return nil, "no such file or directory"
		end
		local raw, err = R.open(slot, part, fp, "a")
		if not raw then
			return nil, err
		end
		local ok, r = pcall(raw.write, s)
		local fok, ferr = pcall(raw.flush)
		pcall(raw.close)
		if not ok then
			return nil, msgOf(r)
		end
		if not fok then
			return nil, msgOf(ferr)
		end
		return true
	end

	function h:seek(whence, off)
		whence, off = whence or "cur", off or 0
		local raw, err = R.open(slot, part, fp, "r")
		if not raw then
			return nil, err
		end
		local ok, sz = pcall(raw.seek, "end", 0)
		pcall(raw.close)
		if not ok then
			return nil, msgOf(sz)
		end
		if type(sz) ~= "number" then
			return nil, "invalid offset"
		end
		if whence == "end" then
			return sz + off
		end
		if whence == "set" then
			if off < 0 or off > sz then
				return nil, "invalid offset"
			end
			return off
		end
		if whence == "cur" then
			if off < 0 or off > sz then
				return nil, "invalid offset"
			end
			return off
		end
		return nil, "invalid option"
	end

	function h:flush()
		return true
	end

	function h:close()
		return true
	end

	return h
end

local virtual = {}

local mountsByFp = {}
local VIRTUAL_TOPS = { ["/dev"] = true, ["/proc"] = true, ["/mnt"] = true }

local function findMountFp(fp)
	local best, bestm = nil, nil
	for k, m in pairs(mountsByFp) do
		if fp == k or fp:sub(1, #k + 1) == k .. "/" then
			if not best or #k > #best then
				best, bestm = k, m
			end
		end
	end
	if not best then
		return nil
	end
	local rest = fp:sub(#best + 1)
	if rest == "" then
		rest = "/"
	end
	return bestm, rest
end

local function underFp(fp, dir)
	return fp == dir or fp:sub(1, #dir + 1) == dir .. "/"
end

local function isRootPartition(slot, part)
	if not K.root or part ~= K.root.part then
		return false
	end
	if K.root.slot ~= nil then
		return slot == K.root.slot
	end
	local d = R.diskByRef(K.root.id)
	return d ~= nil and d.slot == slot
end

local function routeRaw(full)
	local id, part, fp = P.split(full)
	if not id then
		return nil, "bad path"
	end
	if K.root and id == K.root.id and part == K.root.part then
		if fp == "/mnt" or fp:sub(1, 5) == "/mnt/" then
			local rest = fp:sub(6)
			if rest == "" then
				return "virtual", virtual["/mnt"], "/"
			end
			local first, tail = rest:match("^([^/]+)(.*)$")
			tail = (tail == "") and "/" or tail

			for _, d in ipairs(R.disks()) do
				if R.hasPartition(d.slot, first) and not isRootPartition(d.slot, first) then
					return routeRaw(P.join(d.id, first, tail, false))
				end
			end

			local d = R.diskByRef(first)
			if d then
				local pname, ptail = tail:match("^/([^/]+)(.*)$")
				if not pname then
					return "virtual", virtual["/mnt"], "/" .. first
				end
				if isRootPartition(d.slot, pname) then
					return nil, "no such file or directory"
				end
				return routeRaw(P.join(d.id, pname, ptail == "" and "/" or ptail, false))
			end
			return nil, "no such file or directory"
		end

		local mm, mrest = findMountFp(fp)
		if mm then
			return "real", mm.slot, mm.part, mrest
		end
		for prefix, drv in pairs(virtual) do
			if prefix ~= "/mnt" and (fp == prefix or fp:sub(1, #prefix + 1) == prefix .. "/") then
				local sub = fp:sub(#prefix + 1)
				return "virtual", drv, sub == "" and "/" or sub
			end
		end
	end
	local d = R.diskByRef(id)
	if not d then
		return nil, "no such disk: " .. id
	end
	return "real", d.slot, part, fp
end

-- mtimes and symlinks are kernel-emulated through sidecars under /var/db (whole seconds; the host
-- stores no metadata) and saved with the journalled protocol of /.xesperm (Pm.sidecarWrite).
local MTIME_FP, SYMLINK_FP = "/var/db/mtimes", "/var/db/symlinks"
Pm.hideTemp(MTIME_FP)
Pm.hideTemp(SYMLINK_FP)
local LINK_MAX = 8
local mtimes, mtimesLoaded = {}, false
local links, linksLoaded = {}, false
local fifos = {}
local fifoBufs = {}
local sidecarBusy = false

local function rootSlotPart()
	if K.root then
		if K.root.slot then
			return K.root.slot, K.root.part
		end
		local d = R.diskByRef(K.root.id)
		if d then
			return d.slot, K.root.part
		end
	end
end

local function scarKey(slot, part, fp)
	return slot .. ":" .. part .. ":" .. Pm.key(fp)
end

local function parseTime(line)
	local k, v = line:match("^(.*) (.*)$")
	local n = k and tonumber(v)
	if n then
		return k, math.tointeger(n) or n
	end
end

local function parseLink(line)
	local k, v = line:match("^(.-)\t(.*)$")
	if k and v ~= nil then
		return k, v
	end
end

local function loadSidecar(fp, parse)
	local t = {}
	local slot, part = rootSlotPart()
	if slot == nil then
		return t
	end
	local data = Pm.sidecarRead(slot, part, fp, parse)
	if not data then
		return t
	end
	for line in data:gmatch("[^\n]+") do
		local k, v = parse(line)
		if k ~= nil then
			t[k] = v
		end
	end
	return t
end

local function saveSidecar(fp, t, fmt)
	if sidecarBusy then
		return
	end
	local slot, part = rootSlotPart()
	if slot == nil then
		return
	end
	local keys = {}
	for k in pairs(t) do
		keys[#keys + 1] = k
	end
	table.sort(keys)
	local out = {}
	for _, k in ipairs(keys) do
		out[#out + 1] = fmt(k, t[k])
	end
	sidecarBusy = true
	pcall(R.mkdir, slot, part, "/var/db")
	pcall(Pm.sidecarWrite, slot, part, fp, table.concat(out, "\n") .. (#out > 0 and "\n" or ""))
	sidecarBusy = false
end

local function loadMtimes()
	if mtimesLoaded then
		return
	end
	mtimesLoaded = true
	mtimes = loadSidecar(MTIME_FP, parseTime)
end

local function saveMtimes()
	saveSidecar(MTIME_FP, mtimes, function(k, v)
		return k .. " " .. tostring(math.floor(v))
	end)
end

local function loadLinks()
	if linksLoaded then
		return
	end
	linksLoaded = true
	links = loadSidecar(SYMLINK_FP, parseLink)
end

local function saveLinks()
	saveSidecar(SYMLINK_FP, links, function(k, v)
		return k .. "\t" .. v
	end)
end

local function fifoAt(slot, part, fp)
	return fifos[scarKey(slot, part, fp)] and true or false
end

local function linkTarget(slot, part, fp)
	loadLinks()
	return links[scarKey(slot, part, fp)]
end

local function isMtimeDb(slot, part, fp)
	local rs, rp = rootSlotPart()
	return rs ~= nil and slot == rs and part == rp and Pm.key(fp) == Pm.key(MTIME_FP)
end

local function touchReal(slot, part, fp)
	if isMtimeDb(slot, part, fp) then
		return
	end
	loadMtimes()
	mtimes[scarKey(slot, part, fp)] = math.floor(K.now())
	saveMtimes()
end

local function dropReal(slot, part, fp)
	loadMtimes()
	local key = scarKey(slot, part, fp)
	if mtimes[key] ~= nil then
		mtimes[key] = nil
		saveMtimes()
	end
end

local function carryReal(s1, p1, f1, s2, p2, f2)
	loadMtimes()
	local ko, kn = scarKey(s1, p1, f1), scarKey(s2, p2, f2)
	mtimes[kn] = mtimes[ko] or math.floor(K.now())
	if ko ~= kn then
		mtimes[ko] = nil
	end
	saveMtimes()
end

local function splitFp(fp)
	local segs = {}
	for s in fp:gmatch("[^/]+") do
		segs[#segs + 1] = s
	end
	return segs
end

local function route(full, nofollow)
	local cur = full
	for _ = 0, LINK_MAX do
		local kind, a, b, c = routeRaw(cur)
		if kind ~= "real" then
			return kind, a, b, c
		end
		local id = P.split(cur)
		local segs = splitFp(c)
		local moved = false
		local acc = ""
		for i, seg in ipairs(segs) do
			acc = acc .. "/" .. seg
			local last = (i == #segs)
			if not last or not nofollow then
				local tgt = linkTarget(a, b, acc)
				if tgt then
					local parent = acc:match("^(.*)/[^/]*$")
					if parent == "" then
						parent = "/"
					end
					local ok, base = pcall(P.resolve, tgt, P.join(id, b, parent, true), 3)
					if not ok or not base then
						return nil, "no such file or directory"
					end
					if i < #segs then
						local rest = {}
						for j = i + 1, #segs do
							rest[#rest + 1] = segs[j]
						end
						local bid, bpart, bfp = P.split(base)
						local tail = table.concat(rest, "/")
						base = P.join(
							bid,
							bpart,
							bfp == "/" and ("/" .. tail) or (bfp:gsub("/+$", "") .. "/" .. tail),
							false
						)
					end
					cur = base
					moved = true
					break
				end
			end
		end
		if not moved then
			return kind, a, b, c
		end
	end
	return nil, "too many levels of symbolic links"
end

function V.resolve(p, path, level)
	return P.resolve(path, p and p.cwd or K.rootdir, (level or 2) + 1)
end

function V.stat(full)
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil
	end
	if kind == "virtual" then
		return a.stat(b)
	end
	if c == "/" then
		return R.hasPartition(a, b) and "dir" or nil
	end
	if linkTarget(a, b, c) then
		return "link"
	end
	if fifoAt(a, b, c) then
		return "fifo"
	end
	if R.isDir(a, b, c) then
		return "dir"
	end
	if R.isFile(a, b, c) then
		return "file"
	end
	return nil
end

local function followStat(full)
	local kind, a, b, c = route(full)
	if not kind then
		return nil
	end
	if kind == "virtual" then
		return a.stat(b)
	end
	if c == "/" then
		return R.hasPartition(a, b) and "dir" or nil
	end
	if fifoAt(a, b, c) then
		return "fifo"
	end
	if R.isDir(a, b, c) then
		return "dir"
	end
	if R.isFile(a, b, c) then
		return "file"
	end
	return nil
end

local function canonFp(fp)
	local d, p, f = P.split(fp)
	if not d then
		return fp
	end
	return P.join(d, p, Pm.key(f), false)
end

local function missingError(full)
	local pst = followStat(canonFp(P.dirname(full)))
	if pst ~= nil and pst ~= "dir" then
		return "not a directory"
	end
	return "no such file or directory"
end

function V.mount(p, full, slot, part, fstype, opts)
	local id, mpart, fp = P.split(full)
	if not id then
		return nil, "bad path"
	end
	if not (K.root and id == K.root.id and mpart == K.root.part) then
		return nil, "mountpoints must be on the root file system"
	end
	fp = P.normalize(fp)
	if fp == "/" then
		return nil, "cannot mount on /"
	end
	for top in pairs(VIRTUAL_TOPS) do
		if underFp(fp, top) then
			return nil, "cannot mount on " .. top
		end
	end
	for k in pairs(mountsByFp) do
		if fp == k then
			return nil, "already mounted"
		end
		if underFp(fp, k) or underFp(k, fp) then
			return nil, "mountpoint conflicts with " .. k
		end
	end
	if fstype ~= nil and fstype ~= "xesfs" then
		return nil, "unsupported file system type: " .. tostring(fstype)
	end
	local disk = nil
	for _, d in ipairs(R.disks()) do
		if d.slot == slot then
			disk = d
			break
		end
	end
	if not disk then
		return nil, "no such disk"
	end
	if not R.hasPartition(slot, part) then
		return nil, "no such partition: " .. tostring(part)
	end
	local rs, rp = rootSlotPart()
	if rs ~= nil and slot == rs and part == rp then
		return nil, "cannot mount the root file system"
	end
	for k, m in pairs(mountsByFp) do
		if m.slot == slot and m.part == part then
			return nil, "already mounted on " .. k
		end
	end
	if V.stat(full) ~= "dir" then
		if not V.stat(full) then
			return nil, "no such file or directory"
		end
		return nil, "not a directory"
	end
	local kind, a, b, c = route(full)
	if not kind or kind ~= "real" then
		return nil, "cannot mount here"
	end
	local kids, lerr = R.list(a, b, c)
	if not kids then
		return nil, lerr or "cannot inspect mountpoint"
	end
	if #kids > 0 then
		return nil, "mountpoint is not empty"
	end
	if p ~= nil then
		local ok, err = V.access(p, full, "write")
		if ok ~= true then
			return nil, err
		end
		if rs ~= nil and Pm.immutable(rs, rp, fp) then
			return nil, "operation not permitted"
		end
	end
	mountsByFp[fp] = {
		mpfp = fp,
		slot = slot,
		part = part,
		disk = disk.id,
		fstype = "xesfs",
		opts = opts or "rw",
	}
	K.klog("mounted %s:%s on %s", disk.id, part, fp)
	return true
end

function V.unmount(p, full, force)
	local id, mpart, fp = P.split(full)
	if not id then
		return nil, "bad path"
	end
	fp = P.normalize(fp)
	local m = (K.root and id == K.root.id and mpart == K.root.part) and mountsByFp[fp] or nil
	if not m then
		return nil, "not currently mounted"
	end
	if not force then
		for _, pr in pairs(K.procs or {}) do
			local cwd = pr.cwd
			if type(cwd) == "string" then
				local cid, cpart, cfp = P.split(cwd)
				if cid and K.root and cid == K.root.id and cpart == K.root.part then
					cfp = P.normalize(cfp)
					if underFp(cfp, fp) then
						return nil, "device busy"
					end
				end
			end
		end
	end
	mountsByFp[fp] = nil
	K.klog("unmounted %s", fp)
	return true
end

function V.mountlist()
	local out = {}
	for _, m in pairs(mountsByFp) do
		out[#out + 1] = m
	end
	table.sort(out, function(x, y)
		return x.mpfp < y.mpfp
	end)
	return out
end

function V.access(p, full, kind)
	if p == nil then
		return true
	end
	local k, a, b, c = route(full, kind == "create" or kind == "delete" or nil)
	if not k then
		return nil, a
	end

	if k == "virtual" then
		local meta = a.meta and a.meta(b, p)
		if not meta then
			return true
		end
		if kind == "stat" then
			return true
		end
		local want = (kind == "read" and 4) or (kind == "exec" and 5) or (kind == "search" and 1) or 2
		if Pm.permits(p, meta, want) then
			return true
		end
		return nil, "permission denied"
	end

	if Pm.hidden(c) then
		return nil, "permission denied"
	end
	local mutating = kind == "write" or kind == "create" or kind == "delete"
	if mutating and Pm.immutable(a, b, c) then
		return nil, "operation not permitted"
	end
	if not Pm.traverse(p, a, b, c) then
		return nil, "permission denied"
	end
	if kind == "stat" then
		return true
	end

	local isdir = R.isDir(a, b, c)
	local exists = isdir or R.isFile(a, b, c)

	if kind == "read" or kind == "search" or kind == "exec" then
		if not exists then
			return true
		end
		local want = (kind == "read" and 4) or (kind == "search" and 1) or 5
		if Pm.permits(p, Pm.meta(a, b, c, isdir), want) then
			return true
		end
		return nil, "permission denied"
	end

	if c == "/" then
		return nil, "permission denied"
	end
	if kind == "write" and exists then
		if isdir then
			if Pm.permits(p, Pm.meta(a, b, c, true), 3) then
				return true
			end
			return nil, "permission denied"
		end
		if Pm.permits(p, Pm.meta(a, b, c, false), 2) then
			return true
		end
		return nil, "permission denied"
	end
	local pfp = c:match("^(.*)/[^/]*$")
	if pfp == nil or pfp == "" then
		pfp = "/"
	end
	local guard = 0
	while pfp ~= "/" and not R.isDir(a, b, pfp) do
		local up = pfp:match("^(.*)/[^/]*$")
		if up == nil or up == "" then
			up = "/"
		end
		if up == pfp then
			break
		end
		pfp = up
		guard = guard + 1
		if guard > 128 then
			return nil, "permission denied"
		end
	end
	if not R.isDir(a, b, pfp) then
		return nil, "permission denied"
	end
	local pmeta = Pm.meta(a, b, pfp, true)
	if not Pm.permits(p, pmeta, 3) then
		return nil, "permission denied"
	end
	if kind == "delete" and exists then
		if not Pm.stickyOk(p, pmeta, Pm.meta(a, b, c, isdir)) then
			return nil, "permission denied"
		end
	end
	return true
end

function V.allowed(p, op, full)
	return V.access(p, full, op == "read" and "read" or "write") == true
end

function V.perm(p, full, want)
	if p == nil then
		return true
	end
	if V.access(p, full, "stat") ~= true then
		return false
	end
	local k, a, b, c = route(full)
	if not k then
		return false
	end
	local st = V.stat(full)
	if not st then
		return false
	end
	local meta
	if k == "virtual" then
		meta = a.meta and a.meta(b, p)
	else
		meta = Pm.meta(a, b, c, st == "dir")
	end
	if not meta then
		return false
	end
	meta.dir = st == "dir"
	if k == "real" and (want & 2) ~= 0 and Pm.immutable(a, b, c) then
		return false
	end
	return Pm.permits(p, meta, want)
end

local function newMeta(p, base, kernelMode)
	if p == nil then
		return { mode = kernelMode or o("600"), uid = 0, gid = 0 }
	end
	return { mode = base & ~(p.umask or 18) & o("777"), uid = p.uid or 0, gid = p.gid or 0 }
end

local function fileMeta(p, createMode)
	local base = createMode or o("666")
	if p == nil then
		return { mode = base, uid = 0, gid = 0 }
	end
	return { mode = base & ~(p.umask or 18) & o("777"), uid = p.uid or 0, gid = p.gid or 0 }
end

function V.exists(p, full)
	if V.access(p, full, "stat") ~= true then
		return false
	end
	return V.stat(full) ~= nil
end

function V.isDir(p, full)
	return V.stat(full) == "dir"
end

function V.isFile(p, full)
	return V.stat(full) == "file"
end

-- atimes: a third emulated sidecar under /var/db, whole seconds, saved like the mtimes.
local ATIME_FP = "/var/db/atimes"
Pm.hideTemp(ATIME_FP)
local atimes, atimesLoaded = {}, false

local function hash32(s)
	local h = 2166136261
	for i = 1, #s do
		h = ((h ~ s:byte(i)) * 16777619) & 0xFFFFFFFF
	end
	return h ~= 0 and h or 1
end

local function loadAtimes()
	if atimesLoaded then
		return
	end
	atimesLoaded = true
	atimes = loadSidecar(ATIME_FP, parseTime)
end

local function saveAtimes()
	saveSidecar(ATIME_FP, atimes, function(k, v)
		return k .. " " .. tostring(math.floor(v))
	end)
end

function V.reloadSidecars()
	mtimes, mtimesLoaded = {}, false
	links, linksLoaded = {}, false
	atimes, atimesLoaded = {}, false
end

local function fillTimes(info, key, mt)
	loadAtimes()
	info.mtime = mt
	info.atime = atimes[key] or mt
	info.ctime = mt
	return info
end

local function fillIdentity(info, inokey, devseed, kind, size)
	info.ino = hash32(inokey)
	info.dev = hash32("dev:" .. devseed)
	info.nlink = kind == "dir" and 2 or 1
	info.rdev = 0
	info.blksize = 4096
	info.blocks = math.ceil((size or 0) / 512)
	return info
end

local function virtualPrefix(drv)
	for prefix, d in pairs(virtual) do
		if d == drv then
			return prefix
		end
	end
end

function V.statx(p, full)
	local ok, err = V.access(p, full, "stat")
	if ok ~= true then
		return nil, err
	end
	local k, a, b, c = route(full)
	if not k then
		return nil, a
	end
	local st = followStat(full)
	if not st then
		return nil, missingError(full)
	end
	local info = { type = st }
	local m
	if k == "virtual" then
		m = a.meta and a.meta(b, p)
	else
		m = Pm.meta(a, b, c, st == "dir")
	end
	if m then
		info.mode, info.uid, info.gid = m.mode, m.uid, m.gid
	end
	if st == "file" then
		local h = V.open(nil, full, "r")
		if h then
			info.size = h:seek("end") or 0
			pcall(h.close, h)
		end
	else
		info.size = 0
	end
	if k == "real" then
		local rk, ra, rb, rc = route(full, true)
		if rk == "real" then
			local tgt = linkTarget(ra, rb, rc)
			if tgt then
				info.link = tgt
				if st == "link" then
					info.size = #tgt
				end
			end
			loadMtimes()
			local key = scarKey(ra, rb, rc)
			fillTimes(info, key, mtimes[key] or mtimes[scarKey(a, b, c)])
			fillIdentity(info, key, a .. ":" .. b, st, info.size)
		end
	else
		local prefix = virtualPrefix(a)
		local key = "virtual:" .. tostring(prefix) .. ":" .. Pm.key(b)
		fillTimes(info, key, nil)
		fillIdentity(info, key, "virtual:" .. tostring(prefix), st, info.size)
	end
	return info
end

function V.lstatx(p, full)
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil, a
	end
	if kind == "virtual" then
		return V.statx(p, full)
	end
	if c == "/" then
		return V.statx(p, full)
	end
	if Pm.hidden(c) then
		return nil, "permission denied"
	end
	local st = V.stat(full)
	if not st then
		return nil, missingError(full)
	end
	local info = { type = st }
	local m = Pm.meta(a, b, c, st == "dir")
	if m then
		info.mode, info.uid, info.gid = m.mode, m.uid, m.gid
	end
	if st == "link" then
		local tgt = linkTarget(a, b, c)
		info.link = tgt
		info.size = tgt and #tgt or 0
	elseif st == "file" then
		local h = V.open(nil, full, "r")
		if h then
			info.size = h:seek("end") or 0
			pcall(h.close, h)
		end
	else
		info.size = 0
	end
	loadMtimes()
	local key = scarKey(a, b, c)
	fillTimes(info, key, mtimes[key])
	fillIdentity(info, key, a .. ":" .. b, st, info.size)
	return info
end

function V.utime(p, full, mt, at)
	if mt ~= nil and math.type(mt) ~= "integer" then
		return nil, "invalid time"
	end
	if at ~= nil and math.type(at) ~= "integer" then
		return nil, "invalid time"
	end
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil, a
	end
	if kind ~= "real" then
		return nil, "operation not supported"
	end
	if
		c ~= "/"
		and not linkTarget(a, b, c)
		and not fifoAt(a, b, c)
		and not R.isDir(a, b, c)
		and not R.isFile(a, b, c)
	then
		return nil, "no such file or directory"
	end
	if Pm.hidden(c) then
		return nil, "permission denied"
	end
	if Pm.immutable(a, b, c) then
		return nil, "operation not permitted"
	end
	if p ~= nil then
		if not Pm.traverse(p, a, b, c) then
			return nil, "permission denied"
		end
		local m = Pm.meta(a, b, c, R.isDir(a, b, c))
		if p.uid ~= 0 and p.uid ~= m.uid and not Pm.permits(p, m, 2) then
			return nil, "permission denied"
		end
	end
	loadMtimes()
	local key = scarKey(a, b, c)
	local m = mt or math.floor(K.now())
	mtimes[key] = m
	saveMtimes()
	loadAtimes()
	atimes[key] = at or m
	saveAtimes()
	return true
end

function V.symlink(p, target, linkpath)
	if type(target) ~= "string" or target == "" then
		return nil, "invalid target"
	end
	if target:find("%c") then
		return nil, "invalid target"
	end
	local ok, err = V.access(p, linkpath, "create")
	if ok ~= true then
		return nil, err
	end
	local kind, a, b, c = route(linkpath, true)
	if not kind then
		return nil, a
	end
	if kind ~= "real" then
		return nil, "cannot create a link on a virtual file system"
	end
	if c == "/" then
		return nil, "file exists"
	end
	if linkTarget(a, b, c) or fifoAt(a, b, c) or R.isDir(a, b, c) or R.isFile(a, b, c) then
		return nil, "file exists"
	end
	if followStat(P.dirname(linkpath)) ~= "dir" then
		return nil, "no such directory"
	end
	local raw, rerr = R.open(a, b, c, "w")
	if not raw then
		return nil, rerr
	end
	pcall(raw.close)
	Pm.set(a, b, c, newMeta(p, o("777"), o("777")))
	loadLinks()
	links[scarKey(a, b, c)] = target
	saveLinks()
	touchReal(a, b, c)
	local pk, pa, pb, pc = route(P.dirname(linkpath))
	if pk == "real" then
		touchReal(pa, pb, pc)
	end
	return true
end

function V.readlink(p, full)
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil, a
	end
	if kind ~= "real" then
		return nil, "not a symbolic link"
	end
	if Pm.hidden(c) then
		return nil, "permission denied"
	end
	if p ~= nil and not Pm.traverse(p, a, b, c) then
		return nil, "permission denied"
	end
	local tgt = linkTarget(a, b, c)
	if not tgt then
		return nil, "not a symbolic link"
	end
	return tgt
end

function V.mkfifo(p, full)
	local ok, err = V.access(p, full, "create")
	if ok ~= true then
		return nil, err
	end
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil, a
	end
	if kind ~= "real" then
		return nil, "cannot create a fifo on a virtual file system"
	end
	if c == "/" then
		return nil, "file exists"
	end
	if linkTarget(a, b, c) or fifoAt(a, b, c) or R.isDir(a, b, c) or R.isFile(a, b, c) then
		return nil, "file exists"
	end
	if followStat(P.dirname(full)) ~= "dir" then
		return nil, "no such directory"
	end
	Pm.set(a, b, c, newMeta(p, o("666"), o("666")))
	fifos[scarKey(a, b, c)] = { slot = a, part = b, fp = c }
	touchReal(a, b, c)
	local pk, pa, pb, pc = route(P.dirname(full))
	if pk == "real" then
		touchReal(pa, pb, pc)
	end
	return true
end

function V.list(p, full)
	local ok, err = V.access(p, full, "read")
	if not ok then
		return nil, err
	end
	local kind, a, b, c = route(full)
	if not kind then
		return nil, a
	end
	if kind == "virtual" then
		if a.stat(b) ~= "dir" then
			return nil, "not a directory"
		end
		return a.list(b)
	end
	if followStat(full) ~= "dir" then
		return nil, followStat(full) and "not a directory" or "no such file or directory"
	end
	local names, lerr = R.list(a, b, c)
	if names then
		local out = {}
		for _, n in ipairs(names) do
			if not Pm.hidden(c .. "/" .. n) then
				out[#out + 1] = n
			end
		end
		names = out
	end
	if names then
		for _, f in pairs(fifos) do
			if f.slot == a and f.part == b then
				local d, n = f.fp:match("^(.*/)([^/]+)$")
				if n then
					local base = (d == "/" or d == "") and "/" or d:sub(1, -2)
					if base == c then
						names[#names + 1] = n
					end
				end
			end
		end
	end
	return names, lerr
end

function V.mkdir(p, full)
	local ok, err = V.access(p, full, "create")
	if not ok then
		return nil, err
	end
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil, a
	end
	if kind == "virtual" then
		return nil, "read-only file system"
	end
	if c == "/" or linkTarget(a, b, c) or V.stat(full) then
		return nil, "file exists"
	end
	local parent = P.dirname(full)
	if followStat(parent) ~= "dir" then
		return nil, "no such directory"
	end
	local rok, rerr = R.mkdir(a, b, c)
	if not rok then
		return nil, rerr
	end
	Pm.set(a, b, c, newMeta(p, o("777"), o("700")))
	touchReal(a, b, c)
	local pk, pa, pb, pc = route(parent)
	if pk == "real" then
		touchReal(pa, pb, pc)
	end
	return true
end

function V.remove(p, full)
	local ok, err = V.access(p, full, "delete")
	if not ok then
		return nil, err
	end
	local kind, a, b, c = route(full, true)
	if not kind then
		return nil, a
	end
	if kind == "virtual" then
		return nil, "read-only file system"
	end
	if c == "/" then
		return nil, "cannot delete a partition root"
	end
	local parent = P.dirname(full)
	if linkTarget(a, b, c) then
		local rok, rerr = R.remove(a, b, c)
		if not rok then
			return nil, rerr
		end
		loadLinks()
		links[scarKey(a, b, c)] = nil
		saveLinks()
		Pm.drop(a, b, c)
		dropReal(a, b, c)
		local pk, pa, pb, pc = route(parent)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
		return true
	end
	local st = V.stat(full)
	if st == "fifo" then
		fifos[scarKey(a, b, c)] = nil
		fifoBufs[scarKey(a, b, c)] = nil
		Pm.drop(a, b, c)
		dropReal(a, b, c)
		local pk, pa, pb, pc = route(parent)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
		return true
	end
	if not st then
		return nil, "no such file or directory"
	end
	if st == "dir" then
		local kids = R.list(a, b, c)
		if kids and #kids > 0 then
			return nil, "directory not empty"
		end
	end
	local rok, rerr = R.remove(a, b, c)
	if not rok then
		return nil, rerr
	end
	Pm.drop(a, b, c)
	dropReal(a, b, c)
	local pk, pa, pb, pc = route(parent)
	if pk == "real" then
		touchReal(pa, pb, pc)
	end
	return true
end

local function normMode(mode)
	if type(mode) ~= "string" then
		return nil
	end
	local m = mode:gsub("b$", "")
	if m == "r" or m == "w" or m == "a" or m == "r+" or m == "w+" or m == "a+" then
		return m
	end
end
V.normMode = normMode

local function dirHandle(full)
	local h = { readable = false, writable = false, dir = true, path = full }
	function h:read()
		return nil, "is a directory"
	end

	function h:write()
		return nil, "is a directory"
	end

	function h:seek()
		return nil, "invalid option"
	end

	function h:flush()
		return true
	end

	function h:close()
		return true
	end

	return h
end

local function pathHandle(full, kind)
	local h = { readable = false, writable = false, path = full, dir = kind == "dir", pathonly = true }
	function h:read()
		return nil, "file not open for reading"
	end

	function h:write()
		return nil, "file not open for writing"
	end

	function h:seek()
		return nil, "invalid option"
	end

	function h:flush()
		return true
	end

	function h:close()
		return true
	end

	return h
end

local function fifoHandle(st, readable, writable)
	local closed = false
	local h = { readable = readable, writable = writable }
	local function canBlock()
		local p = K.current
		return p ~= nil and coroutine.isyieldable() and p or nil
	end
	function h:read(fmt)
		if not readable then
			return nil, "file not open for reading"
		end
		fmt = fmt or "l"
		if type(fmt) == "number" then
			if fmt < 0 then
				return nil, "invalid count"
			end
			if fmt == 0 then
				return (#st.buf > 0 or st.writers > 0) and "" or nil
			end
			while #st.buf == 0 and st.writers > 0 do
				local p = canBlock()
				if not p then
					break
				end
				K.block(p, function()
					return #st.buf > 0 or st.writers == 0
				end)
			end
			if #st.buf == 0 then
				return nil
			end
			local s = st.buf:sub(1, fmt)
			st.buf = st.buf:sub(#s + 1)
			return s
		elseif fmt == "a" then
			while st.writers > 0 do
				local p = canBlock()
				if not p then
					break
				end
				K.block(p, function()
					return st.writers == 0
				end)
			end
			local s = st.buf
			st.buf = ""
			return s
		elseif fmt == "l" then
			while true do
				local nl = st.buf:find("\n", 1, true)
				if nl then
					local line = st.buf:sub(1, nl - 1)
					st.buf = st.buf:sub(nl + 1)
					return line
				end
				if st.writers == 0 then
					if st.buf == "" then
						return nil
					end
					local rest = st.buf
					st.buf = ""
					return rest
				end
				local p = canBlock()
				if not p then
					return nil
				end
				K.block(p, function()
					return st.buf:find("\n", 1, true) ~= nil or st.writers == 0
				end)
			end
		end
		return nil, "invalid format"
	end

	function h:write(s)
		if not writable then
			return nil, "file not open for reading"
		end
		if #s == 0 then
			return true
		end
		if st.readers == 0 then
			return nil, "broken pipe"
		end
		st.buf = st.buf .. s
		while #st.buf > 4096 do
			local p = canBlock()
			if not p then
				break
			end
			K.block(p, function()
				return #st.buf <= 4096 or st.readers == 0
			end)
			if st.readers == 0 then
				return nil, "broken pipe"
			end
		end
		return true
	end

	function h:seek()
		return nil, "illegal seek"
	end

	function h:flush()
		return true
	end

	function h:close()
		if closed then
			return true
		end
		closed = true
		if readable then
			st.readers = math.max(0, st.readers - 1)
		end
		if writable then
			st.writers = math.max(0, st.writers - 1)
		end
		if st.readers == 0 and st.writers == 0 then
			st.buf = ""
		end
		return true
	end

	return h
end

local function fifoWaitCancel(pr)
	local w = pr and pr._fifoWait
	if not w then
		return
	end
	pr._fifoWait = nil
	local fst = w.fst
	if w.m == "r" then
		fst.readers = math.max(0, fst.readers - 1)
	else
		fst.writers = math.max(0, fst.writers - 1)
	end
end

function V.releaseWaiters(pr)
	if pr ~= nil then
		pcall(fifoWaitCancel, pr)
	end
end

function V.open(p, full, mode, createMode, opts)
	local m = normMode(mode)
	if not m then
		error("invalid open mode '" .. tostring(mode) .. "'", 3)
	end
	local readable = m == "r" or m:find("+", 1, true) ~= nil
	local writable = m ~= "r"
	if type(opts) ~= "table" then
		opts = {}
	end

	if opts.follow == false and not opts.path and V.stat(full) == "link" then
		return nil, "operation not supported"
	end
	if opts.exclusive and not writable then
		return nil, "invalid argument"
	end

	local kind, a, b, c = route(full)
	if not kind then
		return nil, a
	end
	local st
	if kind == "real" then
		if opts.path and opts.follow == false then
			st = V.stat(full)
		else
			st = followStat(full)
		end
	else
		st = a.stat(b)
	end

	local ok, err
	if opts.path then
		ok, err = V.access(p, full, "stat")
	elseif opts.directory then
		if st ~= "dir" then
			return nil, "not a directory"
		end
		ok, err = V.access(p, full, "search")
	else
		if writable then
			ok, err = V.access(p, full, "write")
			if not ok then
				return nil, err
			end
		end
		if readable then
			ok, err = V.access(p, full, "read")
			if not ok then
				return nil, err
			end
		end
	end
	if not ok then
		return nil, err
	end
	local function decorate(h, loc)
		loc.openmode = m
		loc.readable = readable
		loc.writable = writable
		h.loc = loc
		h.cloexec = opts.closeOnExec and true or false
		h.nonblock = opts.nonblock and true or false
		h.pathonly = opts.path and true or false
		return h
	end

	if kind == "virtual" then
		if st == nil then
			return nil, "no such file or directory"
		end
		if opts.directory then
			if st ~= "dir" then
				return nil, "not a directory"
			end
			return decorate(dirHandle(full), { virtual = true, full = full, kind = st, dir = true })
		end
		if opts.path then
			return decorate(pathHandle(full, st), {
				virtual = true,
				full = full,
				kind = st,
				dir = st == "dir",
				nofollow = opts.follow == false,
			})
		end
		if st == "dir" then
			return nil, "is a directory"
		end
		local h, oerr = a.open(p, b, m)
		if not h then
			return nil, oerr
		end
		return decorate(h, { virtual = true, full = full, kind = st, dir = st == "dir" })
	end

	if opts.directory or opts.path then
		if st == nil then
			return nil, "no such file or directory"
		end
		if opts.directory and st ~= "dir" then
			return nil, "not a directory"
		end
		local h = opts.directory and dirHandle(full) or pathHandle(full, st)
		return decorate(h, {
			slot = a,
			part = b,
			fp = c,
			full = full,
			kind = st,
			dir = st == "dir",
			nofollow = opts.follow == false,
		})
	end
	if st == "dir" then
		return nil, "is a directory"
	end
	if st == "fifo" then
		if readable and writable then
			return nil, "operation not supported"
		end
		local key = scarKey(a, b, c)
		local fst = fifoBufs[key]
		if not fst then
			fst = { buf = "", readers = 0, writers = 0, readersOpened = 0, writersOpened = 0 }
			fifoBufs[key] = fst
		elseif fst.readersOpened == nil then
			fst.readersOpened, fst.writersOpened = 0, 0
		end
		if m == "r" then
			fst.readers = fst.readers + 1
		else
			fst.writers = fst.writers + 1
			touchReal(a, b, c)
		end
		local p = K.current
		if p ~= nil and coroutine.isyieldable() then
			local openedR, openedW = fst.readersOpened, fst.writersOpened
			local function ready()
				if m == "r" then
					return fst.writers > 0 or fst.writersOpened ~= openedW
				end
				return fst.readers > 0 or fst.readersOpened ~= openedR
			end
			p._fifoWait = { fst = fst, m = m }
			local wok, werr = pcall(function()
				while not ready() and fifoBufs[key] == fst do
					K.block(p, function()
						return fifoBufs[key] ~= fst or ready()
					end)
				end
			end)
			p._fifoWait = nil
			if not wok or fifoBufs[key] ~= fst then
				if m == "r" then
					fst.readers = math.max(0, fst.readers - 1)
				else
					fst.writers = math.max(0, fst.writers - 1)
				end
				if not wok then
					error(werr, 0)
				end
				return nil, "no such file or directory"
			end
		end
		if m == "r" then
			fst.readersOpened = fst.readersOpened + 1
		else
			fst.writersOpened = fst.writersOpened + 1
		end
		local h = fifoHandle(fst, m == "r", m ~= "r")
		return decorate(h, { slot = a, part = b, fp = c, full = full, kind = "fifo" })
	end
	local existed = st ~= nil
	local parent = P.dirname(full)
	local pst = followStat(canonFp(parent))
	if writable and pst ~= "dir" then
		if pst ~= nil then
			return nil, "not a directory"
		end
		return nil, "no such directory"
	end
	if m == "r" and not existed then
		if pst ~= nil and pst ~= "dir" then
			return nil, "not a directory"
		end
		return nil, "no such file or directory"
	end
	if m == "r+" and not existed then
		if pst ~= nil and pst ~= "dir" then
			return nil, "not a directory"
		end
		return nil, "no such file or directory"
	end
	if opts.exclusive and existed then
		return nil, "file exists"
	end
	if m == "a" then
		if not existed then
			local cr, cerr = R.open(a, b, c, "a", { exclusive = opts.exclusive })
			if not cr then
				return nil, cerr
			end
			pcall(cr.close)
			Pm.set(a, b, c, fileMeta(p, createMode))
		end
		touchReal(a, b, c)
		local pk, pa, pb, pc = route(parent)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
		local h = appendHandle(a, b, c)
		local meta = Pm.meta(a, b, c, false)
		return decorate(h, {
			slot = a,
			part = b,
			fp = c,
			full = full,
			kind = "file",
			umode = meta.mode,
			uuid = meta.uid,
			ugid = meta.gid,
		})
	end
	local raw, rerr = R.open(a, b, c, m, { exclusive = opts.exclusive })
	if not raw then
		return nil, rerr
	end
	if writable and not existed then
		Pm.set(a, b, c, fileMeta(p, createMode))
	end
	if writable then
		touchReal(a, b, c)
		local pk, pa, pb, pc = route(parent)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
	end
	local meta = Pm.meta(a, b, c, false)
	local h = rawHandle(raw, readable, writable)
	return decorate(h, {
		slot = a,
		part = b,
		fp = c,
		full = full,
		kind = "file",
		raw = raw,
		umode = meta.mode,
		uuid = meta.uid,
		ugid = meta.gid,
	})
end

function V.truncate(p, full, size)
	if math.type(size) ~= "integer" or size < 0 then
		return nil, "invalid argument"
	end
	local ok, err = V.access(p, full, "write")
	if not ok then
		return nil, err
	end
	local kind, a, b, c = route(full)
	if not kind then
		return nil, a
	end
	if kind ~= "real" then
		return nil, "read-only file system"
	end
	local st = followStat(full)
	if not st then
		return nil, missingError(full)
	end
	if st == "dir" then
		return nil, "is a directory"
	end
	if st == "fifo" then
		return nil, "invalid argument"
	end
	local rok, rerr = R.truncate(a, b, c, size)
	if not rok then
		return nil, rerr
	end
	loadMtimes()
	mtimes[scarKey(a, b, c)] = math.floor(K.now())
	saveMtimes()
	return true
end

function V.truncateHandle(p, h, size)
	if type(h) ~= "table" or not h.loc then
		return nil, "bad file descriptor"
	end
	local loc = h.loc
	if not h.writable or h.pathonly or loc.dir then
		return nil, "bad file descriptor"
	end
	if math.type(size) ~= "integer" or size < 0 then
		return nil, "invalid argument"
	end
	if loc.virtual then
		return nil, "operation not supported"
	end
	if loc.kind == "fifo" then
		return nil, "invalid argument"
	end
	if loc.raw and type(loc.raw.truncate) == "function" then
		local ok, r = pcall(loc.raw.truncate, size)
		if not ok then
			return nil, msgOf(r)
		end
		if r == false then
			return nil, "cannot truncate file"
		end
	else
		local ok, err = R.truncate(loc.slot, loc.part, loc.fp, size)
		if not ok then
			return nil, err
		end
	end
	loadMtimes()
	mtimes[scarKey(loc.slot, loc.part, loc.fp)] = math.floor(K.now())
	saveMtimes()
	return true
end

function V.statHandle(p, h)
	if type(h) ~= "table" or not h.loc then
		return nil, "bad file descriptor"
	end
	local loc = h.loc
	if loc.virtual or loc.dir or h.pathonly or loc.kind == "dir" or loc.kind == "fifo" then
		if loc.nofollow then
			return V.lstatx(p, loc.full)
		end
		return V.statx(p, loc.full)
	end
	local info = { type = loc.kind or "file", mode = loc.umode, uid = loc.uuid, gid = loc.ugid }
	local size
	if loc.raw and type(loc.raw.size) == "function" then
		local ok, r = pcall(loc.raw.size)
		if ok and type(r) == "number" then
			size = r
		end
	end
	if size == nil then
		local si = V.statx(nil, loc.full)
		if si then
			size = si.size
		end
	end
	info.size = size
	local key = scarKey(loc.slot, loc.part, loc.fp)
	loadMtimes()
	fillTimes(info, key, mtimes[key])
	fillIdentity(info, key, loc.slot .. ":" .. loc.part, info.type, size)
	return info
end

function V.statfs(p, full)
	local ok, err = V.access(p, full, "stat")
	if ok ~= true then
		return nil, err
	end
	local kind, a, b, c = route(full)
	if not kind then
		return nil, a
	end
	if kind == "virtual" then
		return { total = nil, free = nil }
	end
	local st = followStat(full)
	if not st then
		return nil, missingError(full)
	end
	local info, serr = R.statfs(a, b, c)
	if not info then
		return nil, serr
	end
	return info
end

local function sameLoc(a1, b1, c1, a2, b2, c2)
	return a1 == a2 and b1 == b2 and Pm.key(c1) == Pm.key(c2)
end

local function mountBusy(fp)
	for k in pairs(mountsByFp) do
		if fp == k or underFp(fp, k) or underFp(k, fp) then
			return true
		end
	end
	return false
end

local function childFp(base, name)
	return base == "/" and ("/" .. name) or (base .. "/" .. name)
end

local function copyOneFile(a1, b1, src, a2, b2, dst)
	local data, derr = R.readAll(a1, b1, src)
	if not data then
		return nil, derr
	end
	local meta = Pm.meta(a1, b1, src, false)
	local raw, oerr = R.open(a2, b2, dst, "w")
	if not raw then
		return nil, oerr
	end
	local wok, werr = pcall(function()
		if #data > 0 then
			raw.write(data)
		end
		raw.flush()
	end)
	pcall(raw.close)
	if not wok then
		return nil, msgOf(werr)
	end
	Pm.set(a2, b2, dst, meta)
	if linkTarget(a2, b2, dst) then
		loadLinks()
		links[scarKey(a2, b2, dst)] = nil
		saveLinks()
	end
	if fifoAt(a2, b2, dst) then
		fifos[scarKey(a2, b2, dst)] = nil
		fifoBufs[scarKey(a2, b2, dst)] = nil
	end
	loadMtimes()
	mtimes[scarKey(a2, b2, dst)] = mtimes[scarKey(a1, b1, src)] or math.floor(K.now())
	saveMtimes()
	return true
end

local function copyOneLink(a1, b1, src, a2, b2, dst)
	local tgt = linkTarget(a1, b1, src)
	if not tgt then
		return nil, "no such file or directory"
	end
	local meta = Pm.meta(a1, b1, src, false)
	local raw, oerr = R.open(a2, b2, dst, "w")
	if not raw then
		return nil, oerr
	end
	pcall(raw.close)
	Pm.set(a2, b2, dst, meta)
	loadLinks()
	links[scarKey(a2, b2, dst)] = tgt
	saveLinks()
	loadMtimes()
	mtimes[scarKey(a2, b2, dst)] = mtimes[scarKey(a1, b1, src)] or math.floor(K.now())
	saveMtimes()
	return true
end

local function copyOneFifo(a1, b1, src, a2, b2, dst)
	local meta = Pm.meta(a1, b1, src, false)
	Pm.set(a2, b2, dst, meta)
	local kn = scarKey(a2, b2, dst)
	fifos[kn] = { slot = a2, part = b2, fp = dst }
	fifoBufs[kn] = fifoBufs[scarKey(a1, b1, src)]
	loadMtimes()
	mtimes[kn] = mtimes[scarKey(a1, b1, src)] or math.floor(K.now())
	saveMtimes()
	return true
end

local function copyTree(a1, b1, src, a2, b2, dst)
	local smeta = Pm.meta(a1, b1, src, true)
	local rok, rerr = R.mkdir(a2, b2, dst)
	if not rok then
		return nil, rerr
	end
	Pm.set(a2, b2, dst, { mode = smeta.mode, uid = smeta.uid, gid = smeta.gid })
	local kids, lerr = R.list(a1, b1, src)
	if not kids then
		R.remove(a2, b2, dst)
		Pm.drop(a2, b2, dst)
		return nil, lerr
	end
	for _, n in ipairs(kids) do
		local s, d = childFp(src, n), childFp(dst, n)
		local ok, err
		if linkTarget(a1, b1, s) then
			ok, err = copyOneLink(a1, b1, s, a2, b2, d)
		elseif fifoAt(a1, b1, s) then
			ok, err = copyOneFifo(a1, b1, s, a2, b2, d)
		elseif R.isDir(a1, b1, s) then
			ok, err = copyTree(a1, b1, s, a2, b2, d)
		elseif R.isFile(a1, b1, s) then
			ok, err = copyOneFile(a1, b1, s, a2, b2, d)
		else
			ok, err = nil, "no such file or directory"
		end
		if not ok then
			return nil, err
		end
	end
	loadMtimes()
	mtimes[scarKey(a2, b2, dst)] = mtimes[scarKey(a1, b1, src)] or math.floor(K.now())
	saveMtimes()
	return true
end

local function removeTree(a, b, fp)
	local key = scarKey(a, b, fp)
	if linkTarget(a, b, fp) then
		local rok, rerr = R.remove(a, b, fp)
		if not rok then
			return nil, rerr
		end
		loadLinks()
		links[key] = nil
		saveLinks()
		Pm.drop(a, b, fp)
		dropReal(a, b, fp)
		return true
	end
	if fifoAt(a, b, fp) then
		fifos[key] = nil
		fifoBufs[key] = nil
		Pm.drop(a, b, fp)
		dropReal(a, b, fp)
		return true
	end
	if R.isDir(a, b, fp) then
		local kids, lerr = R.list(a, b, fp)
		if not kids then
			return nil, lerr
		end
		for _, n in ipairs(kids) do
			local ok, err = removeTree(a, b, childFp(fp, n))
			if not ok then
				return nil, err
			end
		end
	elseif not R.isFile(a, b, fp) then
		return nil, "no such file or directory"
	end
	local rok, rerr = R.remove(a, b, fp)
	if not rok then
		return nil, rerr
	end
	Pm.drop(a, b, fp)
	dropReal(a, b, fp)
	return true
end

local function underKey(k, base)
	return k == base or k:sub(1, #base + 1) == base .. "/"
end

local function repathCwd(q, a1, b1, c1, c2)
	local qc = q.cwd or ""
	local kk, qa, qb, qfp = route(qc)
	if kk ~= "real" or qa ~= a1 or qb ~= b1 then
		return
	end
	local kc, kold = Pm.key(qfp), Pm.key(c1)
	if not underKey(kc, kold) then
		return
	end
	local d, pt = P.split(qc)
	if not d then
		return
	end
	local nfp = Pm.key(c2) .. kc:sub(#kold + 1)
	q.cwd = P.join(d, pt, nfp, qfp:sub(-1) == "/")
	q.launchcwd = q.cwd
end

function V.move(p, fa, fb)
	local ka, a1, b1, c1 = route(fa, true)
	if not ka then
		return nil, a1
	end
	local kb, a2, b2, c2 = route(fb, true)
	if not kb then
		return nil, a2
	end
	if ka ~= "real" or kb ~= "real" then
		return nil, "cannot move on a virtual file system"
	end
	if c1 == "/" or c2 == "/" then
		return nil, "cannot rename a partition root"
	end
	if sameLoc(a1, b1, c1, a2, b2, c2) then
		return true
	end
	if a1 ~= a2 or b1 ~= b2 then
		return nil, "cannot move between partitions"
	end
	local sa = V.stat(fa)
	if not sa then
		return nil, "no such file or directory"
	end
	if sa ~= "file" and sa ~= "link" and sa ~= "fifo" and sa ~= "dir" then
		return nil, "only files and directories can be moved"
	end
	if sa == "dir" then
		local k1, k2 = Pm.key(c1), Pm.key(c2)
		if k2 == k1 or k2:sub(1, #k1 + 1) == k1 .. "/" then
			return nil, "cannot move a directory into itself"
		end
	end
	local rs, rp = rootSlotPart()
	if rs ~= nil and a1 == rs and b1 == rp and (mountBusy(c1) or mountBusy(c2)) then
		return nil, "device busy"
	end
	local ok, err = V.access(p, fa, "delete")
	if ok ~= true then
		return nil, err
	end
	local sb = V.stat(fb)
	ok, err = V.access(p, fb, sb and "delete" or "create")
	if ok ~= true then
		return nil, err
	end
	if followStat(P.dirname(fb)) ~= "dir" then
		return nil, "no such directory"
	end
	if sb == "dir" and sa ~= "dir" then
		return nil, "is a directory"
	end
	if sa == "dir" and sb ~= nil and sb ~= "dir" then
		return nil, "not a directory"
	end
	local parentB = P.dirname(fb)
	if sb == "dir" then
		local kids = R.list(a2, b2, c2)
		if kids and #kids > 0 then
			return nil, "directory not empty"
		end
		local rok, rerr = R.remove(a2, b2, c2)
		if not rok then
			return nil, rerr
		end
		Pm.drop(a2, b2, c2)
		dropReal(a2, b2, c2)
	elseif sb ~= nil then
		local rok, rerr = removeTree(a2, b2, c2)
		if not rok then
			return nil, rerr
		end
	end
	if sa == "dir" then
		local cok, cerr = copyTree(a1, b1, c1, a2, b2, c2)
		if not cok then
			return nil, cerr
		end
		carryReal(a1, b1, c1, a2, b2, c2)
		local rok, rerr = removeTree(a1, b1, c1)
		if not rok then
			return nil, rerr
		end
		for _, q in pairs(K.procs or {}) do
			repathCwd(q, a1, b1, c1, c2)
		end
		local pk, pa, pb, pc = route(parentB)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
		return true
	end
	if sa == "link" then
		local cok, cerr = copyOneLink(a1, b1, c1, a2, b2, c2)
		if not cok then
			return nil, cerr
		end
		local rok, rerr = R.remove(a1, b1, c1)
		if not rok then
			return nil, rerr
		end
		loadLinks()
		if scarKey(a1, b1, c1) ~= scarKey(a2, b2, c2) then
			links[scarKey(a1, b1, c1)] = nil
		end
		saveLinks()
		Pm.drop(a1, b1, c1)
		carryReal(a1, b1, c1, a2, b2, c2)
		local pk, pa, pb, pc = route(parentB)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
		return true
	end
	if sa == "fifo" then
		local cok, cerr = copyOneFifo(a1, b1, c1, a2, b2, c2)
		if not cok then
			return nil, cerr
		end
		local ko, kn = scarKey(a1, b1, c1), scarKey(a2, b2, c2)
		if ko ~= kn then
			fifos[ko] = nil
			fifoBufs[ko] = nil
		end
		Pm.drop(a1, b1, c1)
		carryReal(a1, b1, c1, a2, b2, c2)
		local pk, pa, pb, pc = route(parentB)
		if pk == "real" then
			touchReal(pa, pb, pc)
		end
		return true
	end
	local cok, cerr = copyOneFile(a1, b1, c1, a2, b2, c2)
	if not cok then
		return nil, cerr
	end
	local rok, rerr = R.remove(a1, b1, c1)
	if not rok then
		return nil, rerr
	end
	Pm.drop(a1, b1, c1)
	carryReal(a1, b1, c1, a2, b2, c2)
	local pk, pa, pb, pc = route(parentB)
	if pk == "real" then
		touchReal(pa, pb, pc)
	end
	return true
end

function V.chmod(p, full, mode)
	if math.type(mode) ~= "integer" or mode < 0 or mode > o("7777") then
		return nil, "invalid mode"
	end
	if (mode & ~Pm.MASK) ~= 0 then
		return nil, "setuid/setgid bits are not supported"
	end
	local ok, err = V.access(p, full, "stat")
	if ok ~= true then
		return nil, err
	end
	local k, a, b, c = route(full)
	if not k then
		return nil, a
	end
	local st = V.stat(full)
	if not st then
		return nil, "no such file or directory"
	end
	if k == "virtual" then
		if not a.chmod then
			return nil, "operation not supported"
		end
		local m = a.meta(b, p)
		if p and p.uid ~= 0 and p.uid ~= m.uid then
			return nil, "operation not permitted"
		end
		return a.chmod(b, mode)
	end
	if Pm.immutable(a, b, c) then
		return nil, "operation not permitted"
	end
	local m = Pm.meta(a, b, c, st == "dir")
	if p and p.uid ~= 0 and p.uid ~= m.uid then
		return nil, "operation not permitted"
	end
	if st ~= "dir" and (mode & Pm.STICKY) ~= 0 then
		return nil, "the sticky bit is only valid on directories"
	end
	Pm.set(a, b, c, { mode = mode, uid = m.uid, gid = m.gid })
	return true
end

function V.chown(p, full, uid, gid)
	for _, v in ipairs({ uid or 0, gid or 0 }) do
		if math.type(v) ~= "integer" or v < 0 or v > 0x7fffffff then
			return nil, "invalid id"
		end
	end
	local ok, err = V.access(p, full, "stat")
	if ok ~= true then
		return nil, err
	end
	local k, a, b, c = route(full)
	if not k then
		return nil, a
	end
	local st = V.stat(full)
	if not st then
		return nil, "no such file or directory"
	end
	local m
	if k == "virtual" then
		if not a.chown then
			return nil, "operation not supported"
		end
		m = a.meta(b, p)
	else
		if Pm.immutable(a, b, c) then
			return nil, "operation not permitted"
		end
		m = Pm.meta(a, b, c, st == "dir")
	end
	if p and p.uid ~= 0 then
		if p.uid ~= m.uid then
			return nil, "operation not permitted"
		end
		if uid ~= nil and uid ~= m.uid then
			return nil, "operation not permitted"
		end
		if gid ~= nil and not Pm.inGroup(p, gid) then
			return nil, "operation not permitted"
		end
	end
	if k == "virtual" then
		return a.chown(b, uid, gid)
	end
	Pm.set(a, b, c, { mode = m.mode, uid = uid or m.uid, gid = gid or m.gid })
	return true
end

function V.readFile(full)
	local h, err = V.open(nil, full, "r")
	if not h then
		return nil, err
	end
	local data, rerr = h:read("a")
	local cok, cerr = h:close()
	if data == nil and rerr then
		return nil, rerr
	end
	if cok == nil then
		return nil, cerr
	end
	return data or ""
end

function V.writeFile(full, data, mode)
	local h, err = V.open(nil, full, "w", mode)
	if not h then
		return nil, err
	end
	local ok, werr = h:write(data)
	local cok, cerr = h:close()
	if not ok then
		return nil, werr
	end
	if cok == nil then
		return nil, cerr
	end
	return true
end

function V.disks()
	return R.disks()
end

function V.partitions(ref)
	local d = R.diskByRef(ref)
	if not d then
		return nil, "no such disk"
	end
	return R.partitions(d.slot)
end

local dev = {}
local function devHandle(spec)
	local h = { readable = spec.read ~= nil, writable = spec.write ~= nil }
	function h:read(fmt)
		if not spec.read then
			return nil, "not readable"
		end
		return spec.read(fmt)
	end

	function h:write(s)
		if not spec.write then
			return nil, "not writable"
		end
		return spec.write(s)
	end

	function h:seek()
		return 0
	end

	function h:flush()
		return true
	end

	function h:close()
		return true
	end

	return h
end

local function ttyWriter(getTty)
	return function(p, s)
		local t = getTty(p)
		if not t then
			return nil, "no controlling terminal"
		end
		t:printText(s, K.WHITE, K.BLACK, false)
		return true
	end
end

local function zeroRead(fmt)
	if type(fmt) == "number" then
		return fmt > 0 and string.rep("\0", fmt) or ""
	end
	return fmt == "a" and "" or nil
end

local function randomRead(fmt)
	if type(fmt) ~= "number" or fmt < 0 then
		return nil
	end
	return K.crypto.random_bytes(math.min(math.floor(fmt), 4096))
end

local function devNodes()
	local nodes = {}
	nodes["null"] = function()
		return devHandle({
			read = function()
				return nil
			end,
			write = function()
				return true
			end,
		})
	end
	nodes["zero"] = function()
		return devHandle({
			read = zeroRead,
			write = function()
				return true
			end,
		})
	end
	nodes["random"] = function()
		return devHandle({ read = randomRead })
	end
	nodes["urandom"] = nodes["random"]
	nodes["klog"] = function()
		return stringHandle(table.concat(K.klog_lines(), "\n") .. "\n")
	end
	nodes["tty"] = function(p)
		local t = p and p.tty
		return devHandle({
			write = function(s)
				if not t then
					return nil, "no controlling terminal"
				end
				t:printText(s, K.WHITE, K.BLACK, false)
				return true
			end,
		})
	end
	nodes["console"] = function()
		return devHandle({
			write = function(s)
				K.ttys[1]:printText(s, K.WHITE, K.BLACK, false)
				return true
			end,
		})
	end
	for _, n in ipairs({ "stdout", "stderr" }) do
		local fdno = (n == "stdout") and 1 or 2
		nodes[n] = function(p)
			return devHandle({
				write = function(s)
					local st = p and (p[n] or p.fds[fdno])
					if not st then
						return nil, "no such stream"
					end
					if type(st.write) ~= "function" then
						return nil, "not open for writing"
					end
					return st:write(s)
				end,
			})
		end
	end
	nodes["stdin"] = function(p)
		return devHandle({
			read = function(fmt)
				local st = p and (p.stdin or p.fds[0])
				if not st then
					return nil, "no such stream"
				end
				if type(st.read) ~= "function" then
					return nil, "not open for reading"
				end
				return st:read(fmt)
			end,
		})
	end
	nodes["tty"] = function(p)
		local t = p and p.tty
		if not t or t == K.nulltty then
			return nil, "no controlling terminal"
		end
		local h = devHandle({
			read = function(fmt)
				return K.ttyread(t, fmt)
			end,
			write = function(s)
				t:printText(s, K.WHITE, K.BLACK, false)
				return true
			end,
		})
		h.isatty = function()
			return true
		end
		return h
	end
	return nodes
end
local devnodes = devNodes()

local function ttyIndex(name)
	return tonumber(name:match("^ttyv(%d+)$"))
end

dev.stat = function(sub)
	if sub == "/" then
		return "dir"
	end
	local name = sub:sub(2)
	if name:find("/") then
		return nil
	end
	if devnodes[name] then
		return "file"
	end
	local i = ttyIndex(name)
	if i and K.ttys[i + 1] then
		return "file"
	end
	local v = name:match("^vcs(%d+)$")
	if v and K.ttys[tonumber(v) + 1] then
		return "file"
	end
end
dev.list = function()
	local out = {}
	for n in pairs(devnodes) do
		out[#out + 1] = n
	end
	for i = 1, #K.ttys do
		out[#out + 1] = "ttyv" .. (i - 1)
		out[#out + 1] = "vcs" .. (i - 1)
	end
	table.sort(out)
	return out
end
dev.open = function(p, sub, mode)
	local name = sub:sub(2)
	local mk = devnodes[name]
	if mk then
		return mk(p)
	end
	local i = ttyIndex(name)
	if i and K.ttys[i + 1] then
		local t = K.ttys[i + 1]
		return devHandle({
			write = function(s)
				t:printText(s, K.WHITE, K.BLACK, false)
				return true
			end,
		})
	end
	local v = name:match("^vcs(%d+)$")
	if v and K.ttys[tonumber(v) + 1] then
		return stringHandle(K.ttys[tonumber(v) + 1]:dump())
	end
	return nil, "no such device"
end

local DEVMODE = {
	null = o("666"),
	zero = o("666"),
	random = o("666"),
	urandom = o("666"),
	tty = o("666"),
	stdin = o("666"),
	stdout = o("666"),
	stderr = o("666"),
	console = o("600"),
	klog = o("640"),
}
local devmeta = {}

dev.meta = function(sub)
	if sub == "/" then
		return { mode = o("755"), uid = 0, gid = 0, dir = true }
	end
	if not dev.stat(sub) then
		return nil
	end
	local name = sub:sub(2)
	local ov = devmeta[name]
	if ov then
		return { mode = ov.mode, uid = ov.uid, gid = ov.gid, dir = false }
	end
	return { mode = DEVMODE[name] or o("600"), uid = 0, gid = 0, dir = false }
end
local function devChangeable(name)
	return ttyIndex(name) ~= nil or name:match("^vcs%d+$") ~= nil
end
dev.chmod = function(sub, mode)
	local name = sub:sub(2)
	if not devChangeable(name) or not dev.stat(sub) then
		return nil, "operation not supported"
	end
	local m = dev.meta(sub)
	devmeta[name] = { mode = mode & o("777"), uid = m.uid, gid = m.gid }
	return true
end
dev.chown = function(sub, uid, gid)
	local name = sub:sub(2)
	if not devChangeable(name) or not dev.stat(sub) then
		return nil, "operation not supported"
	end
	local m = dev.meta(sub)
	devmeta[name] = { mode = m.mode, uid = uid or m.uid, gid = gid or m.gid }
	return true
end
virtual["/dev"] = dev

local proc = {}

local STATE_NAME = { R = "running", S = "sleeping", Z = "zombie", T = "stopped" }

local function procMem(p)
	if p.co and coroutine.memoryused then
		local ok, m = pcall(coroutine.memoryused, p.co)
		if ok and type(m) == "number" then
			return math.tointeger(m) or m
		end
	end
	return 0
end
local function procMemDeep(p)
	if p.co and coroutine.memoryused then
		local ok, m = pcall(coroutine.memoryused, p.co, true)
		if ok and type(m) == "number" then
			return math.tointeger(m) or m
		end
	end
	return procMem(p)
end
local function gcBytes()
	if collectgarbage then
		local ok, v = pcall(collectgarbage, "count")
		if ok and type(v) == "number" then
			return math.floor(v * 1024)
		end
	end
	return nil
end

local function procStatus(pr, reader)
	local lines = {
		"Name:\t" .. pr.name,
		"Pid:\t" .. pr.pid,
		"PPid:\t" .. pr.ppid,
		"Pgid:\t" .. pr.pgid,
		"State:\t" .. pr.state .. " (" .. (STATE_NAME[pr.state] or "?") .. ")",
		"Uid:\t" .. pr.uid,
		"Tty:\t" .. (pr.tty and pr.tty.name or "-"),
		"Nice:\t" .. pr.nice,
		"Cwd:\t" .. ((reader == nil or reader.uid == 0 or reader.uid == pr.uid) and pr.cwd or "-"),
		"Slices:\t" .. pr.slices,
		"Cpu:\t" .. string.format("%.3f", pr.cputime),
		"Mem:\t" .. procMem(pr),
		"MemDeep:\t" .. procMemDeep(pr),
		"Started:\t" .. string.format("%.3f", pr.started - K.boottime),
	}
	return table.concat(lines, "\n") .. "\n"
end

local function findProc(name)
	local n = tonumber(name)
	return n and K.procs and K.procs[n]
end

local function procFile(p, name)
	if name == "version" then
		return string.format("%s %s (%s) YSLua %s\n", K.NAME, K.RELEASE, K.KERNEL, _VERSION)
	elseif name == "uptime" then
		return string.format("%.2f\n", K.uptime())
	elseif name == "loadavg" then
		local a, b, c = K.loadavg()
		return string.format("%.2f %.2f %.2f %d/%d\n", a, b, c, K.nrunning(), K.nprocs())
	elseif name == "mounts" then
		local out = {}
		out[#out + 1] = string.format("%s:%s / xesfs rw 0 0", K.root.id, K.root.part)
		for _, m in ipairs(V.mountlist()) do
			out[#out + 1] = string.format("%s:%s %s xesfs %s 0 0", m.disk, m.part, m.mpfp, m.opts or "rw")
		end
		out[#out + 1] = "devfs /dev devfs rw 0 0"
		out[#out + 1] = "procfs /proc procfs ro 0 0"
		out[#out + 1] = "mntfs /mnt mntfs ro 0 0"
		return table.concat(out, "\n") .. "\n"
	elseif name == "partitions" then
		local out = {}
		for _, d in ipairs(R.disks()) do
			for _, part in ipairs(R.partitions(d.slot) or {}) do
				out[#out + 1] = string.format("%d %s %s", d.slot, d.id, part)
			end
		end
		return table.concat(out, "\n") .. "\n"
	elseif name == "cpuinfo" then
		return string.format(
			"machine\t: %s\nvm\t: YSLua %s\nquantum\t: %d instructions\n",
			tostring(chip.getMachine and chip.getMachine() or "neet"),
			_VERSION,
			K.quantum
		)
	elseif name == "meminfo" then
		local procs, n = 0, 0
		for _, p in pairs(K.procs or {}) do
			procs, n = procs + procMem(p), n + 1
		end
		local hb = gcBytes()
		return string.format(
			"HeapBytes:\t%s\nProcsBytes:\t%d\nNprocs:\t%d\n",
			hb ~= nil and tostring(hb) or "unavailable",
			procs,
			n
		)
	elseif name == "cmdline" then
		return table.concat(K.boot.args, " ") .. "\n"
	end
end

local function procVisible(reader, pr)
	if type(pr) ~= "table" then
		return true
	end
	reader = reader or K.current
	if reader == nil or reader.uid == 0 or pr.uid == reader.uid then
		return true
	end
	local sec = K.sec
	return sec == nil or sec.see_other_uids ~= 0
end

local function procFor(first)
	if first == "self" then
		return K.current or true
	end
	return findProc(first)
end

proc.stat = function(sub)
	if sub == "/" then
		return "dir"
	end
	local first, rest = sub:match("^/([^/]+)(.*)$")
	if not first then
		return nil
	end
	if rest == "" then
		if first == "self" or findProc(first) then
			return procVisible(nil, procFor(first)) and "dir" or nil
		end
		if procFile(nil, first) then
			return "file"
		end
		return nil
	end
	local pr = procFor(first)
	if not pr then
		return nil
	end
	if not procVisible(nil, pr) then
		return nil
	end
	local leaf = rest:sub(2)
	if leaf == "status" or leaf == "cmdline" or leaf == "cwd" then
		return "file"
	end
end
proc.list = function(sub)
	local out = { "version", "uptime", "loadavg", "mounts", "partitions", "cpuinfo", "meminfo", "cmdline", "self" }
	if sub == "/" then
		for pid, pr in pairs(K.procs or {}) do
			if procVisible(nil, pr) then
				out[#out + 1] = tostring(pid)
			end
		end
	else
		return { "status", "cmdline", "cwd" }
	end
	table.sort(out)
	return out
end
proc.open = function(p, sub, mode)
	if mode ~= "r" then
		return nil, "read-only file system"
	end
	local first, rest = sub:match("^/([^/]+)(.*)$")
	if not first then
		return nil, "is a directory"
	end
	if rest == "" then
		local s = procFile(p, first)
		if s then
			return stringHandle(s)
		end
		return nil, "no such file"
	end
	local pr = (first == "self") and (p or K.current) or findProc(first)
	if not pr then
		return nil, "no such process"
	end
	if not procVisible(p, pr) then
		return nil, "no such process"
	end
	local leaf = rest:sub(2)
	if leaf == "status" then
		return stringHandle(procStatus(pr, p))
	elseif leaf == "cmdline" then
		return stringHandle(pr.name .. " " .. table.concat(pr.args or {}, " ") .. "\n")
	elseif leaf == "cwd" then
		return stringHandle(pr.cwd .. "\n")
	end
	return nil, "no such file"
end
proc.meta = function(sub, reader)
	if sub == "/" then
		return { mode = o("555"), uid = 0, gid = 0, dir = true }
	end
	local first, rest = sub:match("^/([^/]+)(.*)$")
	if not first then
		return nil
	end
	local pr = (first == "self") and (reader or K.current) or findProc(first)
	if rest == "" then
		if pr then
			if not procVisible(reader, pr) then
				return nil
			end
			return { mode = o("555"), uid = pr.uid, gid = 0, dir = true }
		end
		if procFile(nil, first) then
			return { mode = o("444"), uid = 0, gid = 0, dir = false }
		end
		return nil
	end
	if not pr then
		return nil
	end
	if not procVisible(reader, pr) then
		return nil
	end
	local leaf = rest:sub(2)
	if leaf == "status" then
		return { mode = o("444"), uid = pr.uid, gid = 0, dir = false }
	end
	if leaf == "cmdline" or leaf == "cwd" then
		return { mode = o("400"), uid = pr.uid, gid = 0, dir = false }
	end
	return nil
end
virtual["/proc"] = proc

local mnt = {}
mnt.stat = function(sub)
	if sub == "/" then
		return "dir"
	end
	return "dir"
end
mnt.list = function(sub)
	local out, seen = {}, {}
	if sub == "/" then
		for _, d in ipairs(R.disks()) do
			for _, part in ipairs(R.partitions(d.slot) or {}) do
				if not isRootPartition(d.slot, part) and not seen[part] then
					seen[part] = true
					out[#out + 1] = part
				end
			end
		end
		for _, d in ipairs(R.disks()) do
			local any = false
			for _, part in ipairs(R.partitions(d.slot) or {}) do
				if not isRootPartition(d.slot, part) then
					any = true
					break
				end
			end
			if any and not seen[d.id] then
				seen[d.id] = true
				out[#out + 1] = d.id
			end
		end
	else
		local d = R.diskByRef(sub:sub(2))
		if d then
			for _, part in ipairs(R.partitions(d.slot) or {}) do
				if not isRootPartition(d.slot, part) then
					out[#out + 1] = part
				end
			end
		end
	end
	table.sort(out)
	return out
end
mnt.open = function()
	return nil, "is a directory"
end
mnt.meta = function()
	return { mode = o("555"), uid = 0, gid = 0, dir = true }
end
virtual["/mnt"] = mnt

if K.ready then
	K.ready.file = function()
		return true, true
	end
end
