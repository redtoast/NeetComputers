local K = ...

local V = {}
K.vfs = V

local R, P = K.rawfs, K.path
local Pm = K.perm
local function o(s) return tonumber(s, 8) end

local function msgOf(e) return (tostring(e):gsub("^[^:]*:%d+:%s*", "")) end

local function stringHandle(str)
    local pos = 0
    local h = { readable = true, writable = false }
    function h:read(fmt)
        fmt = fmt or "l"
        if type(fmt) == "number" then
            if fmt < 0 then return nil, "invalid count" end
            if fmt == 0 then return pos < #str and "" or nil end
            if pos >= #str then return nil end
            local s = str:sub(pos + 1, pos + fmt)
            pos = pos + #s
            return s
        elseif fmt == "a" then
            local s = str:sub(pos + 1)
            pos = #str
            return s
        elseif fmt == "l" then
            if pos >= #str then return nil end
            local nl = str:find("\n", pos + 1, true)
            local line
            if nl then
                line = str:sub(pos + 1, nl - 1); pos = nl
            else
                line = str:sub(pos + 1); pos = #str
            end
            return line
        end
        return nil, "invalid format"
    end

    function h:write() return nil, "file is read-only" end

    function h:seek(whence, off)
        whence, off = whence or "cur", off or 0
        local np
        if whence == "set" then
            np = off
        elseif whence == "cur" then
            np = pos + off
        elseif whence == "end" then
            np = #str + off
        else
            return nil, "invalid option"
        end
        if np < 0 or np > #str then return nil, "invalid offset" end
        pos = np
        return pos
    end

    function h:flush() return true end

    function h:close() return true end

    return h
end
V.stringHandle = stringHandle

local function rawHandle(raw, readable, writable)
    local h = { readable = readable, writable = writable }
    function h:read(fmt)
        if not readable then return nil, "file not open for reading" end
        fmt = fmt or "l"
        if type(fmt) == "number" then
            if fmt < 0 then return nil, "invalid count" end
            local ok, r = pcall(raw.read, math.floor(fmt))
            if not ok then return nil, msgOf(r) end
            if r == nil or (r == "" and fmt > 0) then return nil end
            return r
        elseif fmt == "l" or fmt == "a" then
            local ok, r = pcall(raw.read, fmt)
            if not ok then return nil, msgOf(r) end
            if r == nil and fmt == "a" then return "" end
            return r
        end
        return nil, "invalid format"
    end

    function h:write(s)
        if not writable then return nil, "file not open for writing" end
        if #s == 0 then return true end
        local ok, r = pcall(raw.write, s)
        if not ok then return nil, msgOf(r) end
        return true
    end

    function h:seek(whence, off)
        local ok, r = pcall(raw.seek, whence or "cur", off or 0)
        if not ok then return nil, msgOf(r) end
        return r
    end

    function h:flush()
        local ok, r = pcall(raw.flush)
        if not ok then return nil, msgOf(r) end
        return true
    end

    function h:close()
        pcall(raw.close)
        return true
    end

    return h
end

local virtual = {}

local mountsByFp = {}
local VIRTUAL_TOPS = { ["/dev"] = true, ["/proc"] = true, ["/mnt"] = true }

local function findMountFp(fp)
    local best, bestm = nil, nil
    for k, m in pairs(mountsByFp) do
        if fp == k or fp:sub(1, #k + 1) == k .. "/" then
            if not best or #k > #best then best, bestm = k, m end
        end
    end
    if not best then return nil end
    local rest = fp:sub(#best + 1)
    if rest == "" then rest = "/" end
    return bestm, rest
end

local function underFp(fp, dir)
    return fp == dir or fp:sub(1, #dir + 1) == dir .. "/"
end

local function routeRaw(full)
    local id, part, fp = P.split(full)
    if not id then return nil, "bad path" end
    if K.root and id == K.root.id and part == K.root.part then
        if fp == "/mnt" or fp:sub(1, 5) == "/mnt/" then
            local rest = fp:sub(6)
            if rest == "" then return "virtual", virtual["/mnt"], "/" end
            local first, tail = rest:match("^([^/]+)(.*)$")
            tail = (tail == "") and "/" or tail

            for _, d in ipairs(R.disks()) do
                if R.hasPartition(d.slot, first) then
                    return routeRaw(P.join(d.id, first, tail, false))
                end
            end

            local d = R.diskByRef(first)
            if d then
                local pname, ptail = tail:match("^/([^/]+)(.*)$")
                if not pname then return "virtual", virtual["/mnt"], "/" .. first end
                return routeRaw(P.join(d.id, pname, ptail == "" and "/" or ptail, false))
            end
            return nil, "no such file or directory"
        end

        local mm, mrest = findMountFp(fp)
        if mm then
            return "real", mm.slot, mm.part, mrest
        end
        for prefix, drv in pairs(virtual) do
            if prefix ~= "/mnt" and (fp == prefix or fp:sub(1, #prefix + 1) == prefix .. "/") then
                local sub = fp:sub(#prefix + 1)
                return "virtual", drv, sub == "" and "/" or sub
            end
        end
    end
    local d = R.diskByRef(id)
    if not d then return nil, "no such disk: " .. id end
    return "real", d.slot, part, fp
end

local MTIME_FP, SYMLINK_FP, FIFO_FP = "/var/db/mtimes", "/var/db/symlinks", "/var/db/fifos"
local LINK_MAX = 8
local mtimes, mtimesLoaded = {}, false
local links, linksLoaded = {}, false
local fifos, fifosLoaded = {}, false
local fifoBufs = {}
local sidecarBusy = false

local function rootSlotPart()
    if K.root then
        if K.root.slot then return K.root.slot, K.root.part end
        local d = R.diskByRef(K.root.id)
        if d then return d.slot, K.root.part end
    end
end

local function scarKey(slot, part, fp) return slot .. ":" .. part .. ":" .. Pm.key(fp) end

local function loadSidecar(fp, parse)
    local t = {}
    local slot, part = rootSlotPart()
    if slot == nil then return t end
    local data = R.readAll(slot, part, fp)
    if not data then return t end
    for line in data:gmatch("[^\n]+") do
        local k, v = parse(line)
        if k ~= nil then t[k] = v end
    end
    return t
end

local function saveSidecar(fp, t, fmt)
    if sidecarBusy then return end
    local slot, part = rootSlotPart()
    if slot == nil then return end
    local keys = {}
    for k in pairs(t) do keys[#keys + 1] = k end
    table.sort(keys)
    local out = {}
    for _, k in ipairs(keys) do out[#out + 1] = fmt(k, t[k]) end
    sidecarBusy = true
    pcall(R.mkdir, slot, part, "/var/db")
    pcall(R.writeAll, slot, part, fp, table.concat(out, "\n") .. (#out > 0 and "\n" or ""))
    sidecarBusy = false
end

local function loadMtimes()
    if mtimesLoaded then return end
    mtimesLoaded = true
    mtimes = loadSidecar(MTIME_FP, function(line)
        local k, v = line:match("^(.*) (%d+)$")
        if k and v then return k, tonumber(v) end
    end)
end

local function saveMtimes()
    saveSidecar(MTIME_FP, mtimes, function(k, v) return k .. " " .. tostring(math.floor(v)) end)
end

local function loadLinks()
    if linksLoaded then return end
    linksLoaded = true
    links = loadSidecar(SYMLINK_FP, function(line)
        local k, v = line:match("^(.-)\t(.*)$")
        if k and v ~= nil then return k, v end
    end)
end

local function saveLinks()
    saveSidecar(SYMLINK_FP, links, function(k, v) return k .. "\t" .. v end)
end

local function loadFifos()
    if fifosLoaded then return end
    fifosLoaded = true
    fifos = loadSidecar(FIFO_FP, function(line)
        if line ~= "" then return line, true end
    end)
end

local function saveFifos()
    saveSidecar(FIFO_FP, fifos, function(k) return k end)
end

local function fifoAt(slot, part, fp)
    loadFifos()
    return fifos[scarKey(slot, part, fp)] and true or false
end

local function linkTarget(slot, part, fp)
    loadLinks()
    return links[scarKey(slot, part, fp)]
end

local function isMtimeDb(slot, part, fp)
    local rs, rp = rootSlotPart()
    return rs ~= nil and slot == rs and part == rp and Pm.key(fp) == Pm.key(MTIME_FP)
end

local function touchReal(slot, part, fp)
    if isMtimeDb(slot, part, fp) then return end
    loadMtimes()
    mtimes[scarKey(slot, part, fp)] = math.floor(K.now())
    saveMtimes()
end

local function dropReal(slot, part, fp)
    loadMtimes()
    local key = scarKey(slot, part, fp)
    if mtimes[key] ~= nil then
        mtimes[key] = nil
        saveMtimes()
    end
end

local function carryReal(s1, p1, f1, s2, p2, f2)
    loadMtimes()
    local ko, kn = scarKey(s1, p1, f1), scarKey(s2, p2, f2)
    mtimes[kn] = mtimes[ko] or math.floor(K.now())
    if ko ~= kn then mtimes[ko] = nil end
    saveMtimes()
end

local function splitFp(fp)
    local segs = {}
    for s in fp:gmatch("[^/]+") do segs[#segs + 1] = s end
    return segs
end

local function route(full, nofollow)
    local cur = full
    for _ = 0, LINK_MAX do
        local kind, a, b, c = routeRaw(cur)
        if kind ~= "real" then return kind, a, b, c end
        local id = P.split(cur)
        local segs = splitFp(c)
        local moved = false
        local acc = ""
        for i, seg in ipairs(segs) do
            acc = acc .. "/" .. seg
            local last = (i == #segs)
            if (not last or not nofollow) then
                local tgt = linkTarget(a, b, acc)
                if tgt then
                    local parent = acc:match("^(.*)/[^/]*$")
                    if parent == "" then parent = "/" end
                    local ok, base = pcall(P.resolve, tgt, P.join(id, b, parent, true), 3)
                    if not ok or not base then return nil, "no such file or directory" end
                    if i < #segs then
                        local rest = {}
                        for j = i + 1, #segs do rest[#rest + 1] = segs[j] end
                        local bid, bpart, bfp = P.split(base)
                        local tail = table.concat(rest, "/")
                        base = P.join(bid, bpart, bfp == "/" and ("/" .. tail) or (bfp:gsub("/+$", "") .. "/" .. tail),
                            false)
                    end
                    cur = base
                    moved = true
                    break
                end
            end
        end
        if not moved then return kind, a, b, c end
    end
    return nil, "too many levels of symbolic links"
end

function V.resolve(p, path, level)
    return P.resolve(path, p and p.cwd or K.rootdir, (level or 2) + 1)
end

function V.stat(full)
    local kind, a, b, c = route(full, true)
    if not kind then return nil end
    if kind == "virtual" then return a.stat(b) end
    if c == "/" then return R.hasPartition(a, b) and "dir" or nil end
    if linkTarget(a, b, c) then return "link" end
    if fifoAt(a, b, c) then return "fifo" end
    if R.isDir(a, b, c) then return "dir" end
    if R.isFile(a, b, c) then return "file" end
    return nil
end

local function followStat(full)
    local kind, a, b, c = route(full)
    if not kind then return nil end
    if kind == "virtual" then return a.stat(b) end
    if c == "/" then return R.hasPartition(a, b) and "dir" or nil end
    if fifoAt(a, b, c) then return "fifo" end
    if R.isDir(a, b, c) then return "dir" end
    if R.isFile(a, b, c) then return "file" end
    return nil
end

function V.mount(p, full, slot, part, fstype, opts)
    local id, mpart, fp = P.split(full)
    if not id then return nil, "bad path" end
    if not (K.root and id == K.root.id and mpart == K.root.part) then
        return nil, "mountpoints must be on the root file system"
    end
    fp = P.normalize(fp)
    if fp == "/" then return nil, "cannot mount on /" end
    for top in pairs(VIRTUAL_TOPS) do
        if underFp(fp, top) then return nil, "cannot mount on " .. top end
    end
    for k in pairs(mountsByFp) do
        if fp == k then return nil, "already mounted" end
        if underFp(fp, k) or underFp(k, fp) then
            return nil, "mountpoint conflicts with " .. k
        end
    end
    if fstype ~= nil and fstype ~= "xesfs" then
        return nil, "unsupported file system type: " .. tostring(fstype)
    end
    local disk = nil
    for _, d in ipairs(R.disks()) do if d.slot == slot then
            disk = d
            break
        end end
    if not disk then return nil, "no such disk" end
    if not R.hasPartition(slot, part) then return nil, "no such partition: " .. tostring(part) end
    local rs, rp = rootSlotPart()
    if rs ~= nil and slot == rs and part == rp then
        return nil, "cannot mount the root file system"
    end
    for k, m in pairs(mountsByFp) do
        if m.slot == slot and m.part == part then
            return nil, "already mounted on " .. k
        end
    end
    if V.stat(full) ~= "dir" then
        if not V.stat(full) then return nil, "no such file or directory" end
        return nil, "not a directory"
    end
    local kind, a, b, c = route(full)
    if not kind or kind ~= "real" then return nil, "cannot mount here" end
    local kids, lerr = R.list(a, b, c)
    if not kids then return nil, lerr or "cannot inspect mountpoint" end
    if #kids > 0 then return nil, "mountpoint is not empty" end
    if p ~= nil then
        local ok, err = V.access(p, full, "write")
        if ok ~= true then return nil, err end
        if rs ~= nil and Pm.immutable(rs, rp, fp) then
            return nil, "operation not permitted"
        end
    end
    mountsByFp[fp] = {
        mpfp = fp,
        slot = slot,
        part = part,
        disk = disk.id,
        fstype = "xesfs",
        opts = opts or "rw"
    }
    K.klog("mounted %s:%s on %s", disk.id, part, fp)
    return true
end

function V.unmount(p, full, force)
    local id, mpart, fp = P.split(full)
    if not id then return nil, "bad path" end
    fp = P.normalize(fp)
    local m = (K.root and id == K.root.id and mpart == K.root.part) and mountsByFp[fp] or nil
    if not m then return nil, "not currently mounted" end
    if not force then
        for _, pr in pairs(K.procs or {}) do
            local cwd = pr.cwd
            if type(cwd) == "string" then
                local cid, cpart, cfp = P.split(cwd)
                if cid and K.root and cid == K.root.id and cpart == K.root.part then
                    cfp = P.normalize(cfp)
                    if underFp(cfp, fp) then return nil, "device busy" end
                end
            end
        end
    end
    mountsByFp[fp] = nil
    K.klog("unmounted %s", fp)
    return true
end

function V.mountlist()
    local out = {}
    for _, m in pairs(mountsByFp) do out[#out + 1] = m end
    table.sort(out, function(x, y) return x.mpfp < y.mpfp end)
    return out
end

function V.access(p, full, kind)
    if p == nil then return true end
    local k, a, b, c = route(full, kind == "create" or kind == "delete" or nil)
    if not k then return nil, a end

    if k == "virtual" then
        local meta = a.meta and a.meta(b, p)
        if not meta then return true end
        if kind == "stat" then return true end
        local want = (kind == "read" and 4) or (kind == "exec" and 5) or (kind == "search" and 1) or 2
        if Pm.permits(p, meta, want) then return true end
        return nil, "permission denied"
    end

    if Pm.hidden(c) then return nil, "permission denied" end
    local mutating = kind == "write" or kind == "create" or kind == "delete"
    if mutating and Pm.immutable(a, b, c) then return nil, "operation not permitted" end
    if not Pm.traverse(p, a, b, c) then return nil, "permission denied" end
    if kind == "stat" then return true end

    local isdir = R.isDir(a, b, c)
    local exists = isdir or R.isFile(a, b, c)

    if kind == "read" or kind == "search" or kind == "exec" then
        if not exists then return true end
        local want = (kind == "read" and 4) or (kind == "search" and 1) or 5
        if Pm.permits(p, Pm.meta(a, b, c, isdir), want) then return true end
        return nil, "permission denied"
    end

    if c == "/" then return nil, "permission denied" end
    if kind == "write" and exists then
        if isdir then return true end
        if Pm.permits(p, Pm.meta(a, b, c, false), 2) then return true end
        return nil, "permission denied"
    end
    local pfp = c:match("^(.*)/[^/]*$")
    if pfp == nil or pfp == "" then pfp = "/" end
    if not R.isDir(a, b, pfp) then return true end
    local pmeta = Pm.meta(a, b, pfp, true)
    if not Pm.permits(p, pmeta, 3) then return nil, "permission denied" end
    if kind == "delete" and exists then
        if not Pm.stickyOk(p, pmeta, Pm.meta(a, b, c, isdir)) then return nil, "permission denied" end
    end
    return true
end

function V.allowed(p, op, full)
    return V.access(p, full, op == "read" and "read" or "write") == true
end

function V.perm(p, full, want)
    if p == nil then return true end
    if V.access(p, full, "stat") ~= true then return false end
    local k, a, b, c = route(full)
    if not k then return false end
    local st = V.stat(full)
    if not st then return false end
    local meta
    if k == "virtual" then meta = a.meta and a.meta(b, p) else meta = Pm.meta(a, b, c, st == "dir") end
    if not meta then return false end
    meta.dir = st == "dir"
    if k == "real" and (want & 2) ~= 0 and Pm.immutable(a, b, c) then return false end
    return Pm.permits(p, meta, want)
end

local function newMeta(p, base, kernelMode)
    if p == nil then return { mode = kernelMode or o "600", uid = 0, gid = 0 } end
    return { mode = base & ~(p.umask or 18) & o "777", uid = p.uid or 0, gid = p.gid or 0 }
end

function V.exists(p, full)
    if V.access(p, full, "stat") ~= true then return false end
    return V.stat(full) ~= nil
end

function V.isDir(p, full) return V.stat(full) == "dir" end

function V.isFile(p, full) return V.stat(full) == "file" end

function V.statx(p, full)
    local ok, err = V.access(p, full, "stat")
    if ok ~= true then return nil, err end
    local k, a, b, c = route(full)
    if not k then return nil, a end
    local st = followStat(full)
    if not st then return nil, "no such file or directory" end
    local info = { type = st }
    local m
    if k == "virtual" then m = a.meta and a.meta(b, p) else m = Pm.meta(a, b, c, st == "dir") end
    if m then info.mode, info.uid, info.gid = m.mode, m.uid, m.gid end
    if st == "fifo" then
        local fst = fifoBufs[scarKey(a, b, c)]
        info.size = fst and #fst.buf or 0
        if k == "real" then
            loadMtimes()
            info.mtime = mtimes[scarKey(a, b, c)]
        end
        return info
    end
    if st == "file" then
        local h = V.open(nil, full, "r")
        if h then
            info.size = h:seek("end") or 0; h:close()
        end
    end
    if k == "real" then
        local rk, ra, rb, rc = route(full, true)
        if rk == "real" then
            local tgt = linkTarget(ra, rb, rc)
            if tgt then info.link = tgt end
            loadMtimes()
            info.mtime = mtimes[scarKey(ra, rb, rc)] or mtimes[scarKey(a, b, c)]
        end
    end
    return info
end

function V.utime(p, full, mt)
    if mt ~= nil and (math.type(mt) ~= "integer" or mt < 0) then return nil, "invalid time" end
    local ok, err = V.access(p, full, "write")
    if ok ~= true then return nil, err end
    local kind, a, b, c = route(full, true)
    if not kind then return nil, a end
    if kind ~= "real" then return nil, "operation not supported" end
    if c ~= "/" and not linkTarget(a, b, c) and not fifoAt(a, b, c)
        and not R.isDir(a, b, c) and not R.isFile(a, b, c) then
        return nil, "no such file or directory"
    end
    if Pm.immutable(a, b, c) then return nil, "operation not permitted" end
    loadMtimes()
    mtimes[scarKey(a, b, c)] = mt or math.floor(K.now())
    saveMtimes()
    return true
end

function V.symlink(p, target, linkpath)
    if type(target) ~= "string" or target == "" then return nil, "invalid target" end
    if target:find("%c") then return nil, "invalid target" end
    local ok, err = V.access(p, linkpath, "create")
    if ok ~= true then return nil, err end
    local kind, a, b, c = route(linkpath, true)
    if not kind then return nil, a end
    if kind ~= "real" then return nil, "cannot create a link on a virtual file system" end
    if c == "/" then return nil, "file exists" end
    if linkTarget(a, b, c) or fifoAt(a, b, c) or R.isDir(a, b, c) or R.isFile(a, b, c) then
        return nil, "file exists"
    end
    if followStat(P.dirname(linkpath)) ~= "dir" then return nil, "no such directory" end
    local raw, rerr = R.open(a, b, c, "w")
    if not raw then return nil, rerr end
    pcall(raw.close)
    Pm.set(a, b, c, newMeta(p, o "777", o "777"))
    loadLinks()
    links[scarKey(a, b, c)] = target
    saveLinks()
    touchReal(a, b, c)
    local pk, pa, pb, pc = route(P.dirname(linkpath))
    if pk == "real" then touchReal(pa, pb, pc) end
    return true
end

function V.readlink(p, full)
    local ok, err = V.access(p, full, "stat")
    if ok ~= true then return nil, err end
    local kind, a, b, c = route(full, true)
    if not kind then return nil, a end
    if kind ~= "real" then return nil, "not a symbolic link" end
    local tgt = linkTarget(a, b, c)
    if not tgt then return nil, "not a symbolic link" end
    return tgt
end

function V.mkfifo(p, full)
    local ok, err = V.access(p, full, "create")
    if ok ~= true then return nil, err end
    local kind, a, b, c = route(full, true)
    if not kind then return nil, a end
    if kind ~= "real" then return nil, "cannot create a fifo on a virtual file system" end
    if c == "/" then return nil, "file exists" end
    if linkTarget(a, b, c) or fifoAt(a, b, c) or R.isDir(a, b, c) or R.isFile(a, b, c) then
        return nil, "file exists"
    end
    if followStat(P.dirname(full)) ~= "dir" then return nil, "no such directory" end
    local raw, rerr = R.open(a, b, c, "w")
    if not raw then return nil, rerr end
    pcall(raw.close)
    Pm.set(a, b, c, newMeta(p, o "666", o "666"))
    loadFifos()
    fifos[scarKey(a, b, c)] = true
    saveFifos()
    touchReal(a, b, c)
    local pk, pa, pb, pc = route(P.dirname(full))
    if pk == "real" then touchReal(pa, pb, pc) end
    return true
end

function V.list(p, full)
    local ok, err = V.access(p, full, "read")
    if not ok then return nil, err end
    local kind, a, b, c = route(full)
    if not kind then return nil, a end
    if kind == "virtual" then
        if a.stat(b) ~= "dir" then return nil, "not a directory" end
        return a.list(b)
    end
    if followStat(full) ~= "dir" then
        return nil, followStat(full) and "not a directory" or "no such file or directory"
    end
    local names, lerr = R.list(a, b, c)
    if names and c == "/" then
        local out = {}
        for _, n in ipairs(names) do if not Pm.hidden("/" .. n) then out[#out + 1] = n end end
        names = out
    end
    return names, lerr
end

function V.mkdir(p, full)
    local ok, err = V.access(p, full, "create")
    if not ok then return nil, err end
    local kind, a, b, c = route(full, true)
    if not kind then return nil, a end
    if kind == "virtual" then return nil, "read-only file system" end
    if c == "/" or linkTarget(a, b, c) or V.stat(full) then return nil, "file exists" end
    local parent = P.dirname(full)
    if followStat(parent) ~= "dir" then return nil, "no such directory" end
    local rok, rerr = R.mkdir(a, b, c)
    if not rok then return nil, rerr end
    Pm.set(a, b, c, newMeta(p, o "777", o "700"))
    touchReal(a, b, c)
    local pk, pa, pb, pc = route(parent)
    if pk == "real" then touchReal(pa, pb, pc) end
    return true
end

function V.remove(p, full)
    local ok, err = V.access(p, full, "delete")
    if not ok then return nil, err end
    local kind, a, b, c = route(full, true)
    if not kind then return nil, a end
    if kind == "virtual" then return nil, "read-only file system" end
    if c == "/" then return nil, "cannot delete a partition root" end
    local parent = P.dirname(full)
    if linkTarget(a, b, c) then
        local rok, rerr = R.remove(a, b, c)
        if not rok then return nil, rerr end
        loadLinks()
        links[scarKey(a, b, c)] = nil
        saveLinks()
        Pm.drop(a, b, c)
        dropReal(a, b, c)
        local pk, pa, pb, pc = route(parent)
        if pk == "real" then touchReal(pa, pb, pc) end
        return true
    end
    local st = V.stat(full)
    if st == "fifo" then
        local rok, rerr = R.remove(a, b, c)
        if not rok then return nil, rerr end
        loadFifos()
        fifos[scarKey(a, b, c)] = nil
        saveFifos()
        fifoBufs[scarKey(a, b, c)] = nil
        Pm.drop(a, b, c)
        dropReal(a, b, c)
        local pk, pa, pb, pc = route(parent)
        if pk == "real" then touchReal(pa, pb, pc) end
        return true
    end
    if not st then return nil, "no such file or directory" end
    if st == "dir" then
        local kids = R.list(a, b, c)
        if kids and #kids > 0 then return nil, "directory not empty" end
    end
    local rok, rerr = R.remove(a, b, c)
    if not rok then return nil, rerr end
    Pm.drop(a, b, c)
    dropReal(a, b, c)
    local pk, pa, pb, pc = route(parent)
    if pk == "real" then touchReal(pa, pb, pc) end
    return true
end

local function normMode(mode)
    if type(mode) ~= "string" then return nil end
    local m = mode:gsub("b$", "")
    if m == "r" or m == "w" or m == "a" then return m end
end

local function fifoHandle(st, readable, writable)
    if readable then st.readers = st.readers + 1 end
    if writable then st.writers = st.writers + 1 end
    local closed = false
    local h = { readable = readable, writable = writable }
    local function canBlock()
        local p = K.current
        return p ~= nil and coroutine.isyieldable() and p or nil
    end
    function h:read(fmt)
        if not readable then return nil, "file not open for reading" end
        fmt = fmt or "l"
        if type(fmt) == "number" then
            if fmt < 0 then return nil, "invalid count" end
            if fmt == 0 then return (#st.buf > 0 or st.writers > 0) and "" or nil end
            while #st.buf == 0 and st.writers > 0 do
                local p = canBlock()
                if not p then break end
                K.block(p, function() return #st.buf > 0 or st.writers == 0 end)
            end
            if #st.buf == 0 then return nil end
            local s = st.buf:sub(1, fmt)
            st.buf = st.buf:sub(#s + 1)
            return s
        elseif fmt == "a" then
            while st.writers > 0 do
                local p = canBlock()
                if not p then break end
                K.block(p, function() return st.writers == 0 end)
            end
            local s = st.buf
            st.buf = ""
            return s
        elseif fmt == "l" then
            while true do
                local nl = st.buf:find("\n", 1, true)
                if nl then
                    local line = st.buf:sub(1, nl - 1)
                    st.buf = st.buf:sub(nl + 1)
                    return line
                end
                if st.writers == 0 then
                    if st.buf == "" then return nil end
                    local rest = st.buf
                    st.buf = ""
                    return rest
                end
                local p = canBlock()
                if not p then return nil end
                K.block(p, function() return st.buf:find("\n", 1, true) ~= nil or st.writers == 0 end)
            end
        end
        return nil, "invalid format"
    end

    function h:write(s)
        if not writable then return nil, "file not open for writing" end
        if #s == 0 then return true end
        st.buf = st.buf .. s
        return true
    end

    function h:seek() return nil, "illegal seek" end

    function h:flush() return true end

    function h:close()
        if closed then return true end
        closed = true
        if readable then st.readers = math.max(0, st.readers - 1) end
        if writable then st.writers = math.max(0, st.writers - 1) end
        return true
    end

    return h
end

function V.open(p, full, mode, createMode)
    local m = normMode(mode)
    if not m then error("invalid open mode '" .. tostring(mode) .. "'", 3) end
    local ok, err = V.access(p, full, m == "r" and "read" or "write")
    if not ok then return nil, err end
    local kind, a, b, c = route(full)
    if not kind then return nil, a end
    if kind == "virtual" then
        if a.stat(b) == "dir" then return nil, "is a directory" end
        return a.open(p, b, m)
    end
    local st = followStat(full)
    if st == "dir" then return nil, "is a directory" end
    if m == "r" and not st then return nil, "no such file or directory" end
    local existed = st ~= nil
    local parent = P.dirname(full)
    if m ~= "r" then
        if followStat(parent) ~= "dir" then return nil, "no such directory" end
    end
    if st == "fifo" then
        local key = scarKey(a, b, c)
        local fst = fifoBufs[key]
        if not fst then
            fst = { buf = "", readers = 0, writers = 0 }
            fifoBufs[key] = fst
        end
        if m ~= "r" then touchReal(a, b, c) end
        if m == "r" then return fifoHandle(fst, true, false) end
        return fifoHandle(fst, false, true)
    end
    local raw, rerr = R.open(a, b, c, m)
    if not raw then return nil, rerr end
    if m ~= "r" and not existed then Pm.set(a, b, c, newMeta(p, o "666", createMode)) end
    if m ~= "r" then
        touchReal(a, b, c)
        local pk, pa, pb, pc = route(parent)
        if pk == "real" then touchReal(pa, pb, pc) end
    end
    return rawHandle(raw, m == "r", m ~= "r")
end

function V.move(p, fa, fb)
    local ka, a1, b1, c1 = route(fa, true)
    if not ka then return nil, a1 end
    local kb, a2, b2, c2 = route(fb, true)
    if not kb then return nil, a2 end
    if ka ~= "real" or kb ~= "real" then return nil, "cannot move on a virtual file system" end
    local sa = V.stat(fa)
    if not sa then return nil, "no such file or directory" end
    if sa ~= "file" and sa ~= "link" and sa ~= "fifo" then return nil, "only regular files can be moved" end
    local sb = followStat(fb)
    if sb == "dir" then return nil, "is a directory" end
    if a1 == a2 and b1 == b2 and Pm.key(c1) == Pm.key(c2) then return true end
    local ok, err = V.access(p, fa, "delete")
    if ok ~= true then return nil, err end
    ok, err = V.access(p, fb, sb and "delete" or "create")
    if ok ~= true then return nil, err end
    if followStat(P.dirname(fb)) ~= "dir" then return nil, "no such directory" end
    local parentB = P.dirname(fb)
    if sa == "link" then
        local tgt = linkTarget(a1, b1, c1)
        if not tgt then return nil, "no such file or directory" end
        local meta = Pm.meta(a1, b1, c1, false)
        local raw, oerr = R.open(a2, b2, c2, "w")
        if not raw then return nil, oerr end
        pcall(raw.close)
        Pm.set(a2, b2, c2, meta)
        loadLinks()
        links[scarKey(a2, b2, c2)] = tgt
        if scarKey(a1, b1, c1) ~= scarKey(a2, b2, c2) then links[scarKey(a1, b1, c1)] = nil end
        saveLinks()
        local rok, rerr = R.remove(a1, b1, c1)
        if not rok then return nil, rerr end
        Pm.drop(a1, b1, c1)
        carryReal(a1, b1, c1, a2, b2, c2)
        local pk, pa, pb, pc = route(parentB)
        if pk == "real" then touchReal(pa, pb, pc) end
        return true
    end
    if sa == "fifo" then
        local meta = Pm.meta(a1, b1, c1, false)
        local raw, oerr = R.open(a2, b2, c2, "w")
        if not raw then return nil, oerr end
        pcall(raw.close)
        Pm.set(a2, b2, c2, meta)
        loadFifos()
        local ko, kn = scarKey(a1, b1, c1), scarKey(a2, b2, c2)
        fifos[kn] = true
        if ko ~= kn then
            fifos[ko] = nil
            fifoBufs[kn] = fifoBufs[ko]
            fifoBufs[ko] = nil
        end
        saveFifos()
        local rok, rerr = R.remove(a1, b1, c1)
        if not rok then return nil, rerr end
        Pm.drop(a1, b1, c1)
        carryReal(a1, b1, c1, a2, b2, c2)
        local pk, pa, pb, pc = route(parentB)
        if pk == "real" then touchReal(pa, pb, pc) end
        return true
    end
    local data, derr = V.readFile(fa)
    if not data then return nil, derr end
    local meta = Pm.meta(a1, b1, c1, false)
    local raw, oerr = R.open(a2, b2, c2, "w")
    if not raw then return nil, oerr end
    local wok, werr = pcall(function()
        if #data > 0 then raw.write(data) end
        raw.flush()
    end)
    pcall(raw.close)
    if not wok then return nil, msgOf(werr) end
    Pm.set(a2, b2, c2, meta)
    if linkTarget(a2, b2, c2) then
        loadLinks()
        links[scarKey(a2, b2, c2)] = nil
        saveLinks()
    end
    if fifoAt(a2, b2, c2) then
        loadFifos()
        fifos[scarKey(a2, b2, c2)] = nil
        saveFifos()
        fifoBufs[scarKey(a2, b2, c2)] = nil
    end
    local rok, rerr = R.remove(a1, b1, c1)
    if not rok then return nil, rerr end
    Pm.drop(a1, b1, c1)
    carryReal(a1, b1, c1, a2, b2, c2)
    local pk, pa, pb, pc = route(parentB)
    if pk == "real" then touchReal(pa, pb, pc) end
    return true
end

function V.chmod(p, full, mode)
    if math.type(mode) ~= "integer" or mode < 0 or mode > o "7777" then return nil, "invalid mode" end
    if (mode & ~Pm.MASK) ~= 0 then return nil, "setuid/setgid bits are not supported" end
    local ok, err = V.access(p, full, "stat")
    if ok ~= true then return nil, err end
    local k, a, b, c = route(full)
    if not k then return nil, a end
    local st = V.stat(full)
    if not st then return nil, "no such file or directory" end
    if k == "virtual" then
        if not a.chmod then return nil, "operation not supported" end
        local m = a.meta(b, p)
        if p and p.uid ~= 0 and p.uid ~= m.uid then return nil, "operation not permitted" end
        return a.chmod(b, mode)
    end
    if Pm.immutable(a, b, c) then return nil, "operation not permitted" end
    local m = Pm.meta(a, b, c, st == "dir")
    if p and p.uid ~= 0 and p.uid ~= m.uid then return nil, "operation not permitted" end
    if st ~= "dir" and (mode & Pm.STICKY) ~= 0 then return nil, "the sticky bit is only valid on directories" end
    Pm.set(a, b, c, { mode = mode, uid = m.uid, gid = m.gid })
    return true
end

function V.chown(p, full, uid, gid)
    for _, v in ipairs({ uid or 0, gid or 0 }) do
        if math.type(v) ~= "integer" or v < 0 or v > 0x7fffffff then return nil, "invalid id" end
    end
    local ok, err = V.access(p, full, "stat")
    if ok ~= true then return nil, err end
    local k, a, b, c = route(full)
    if not k then return nil, a end
    local st = V.stat(full)
    if not st then return nil, "no such file or directory" end
    local m
    if k == "virtual" then
        if not a.chown then return nil, "operation not supported" end
        m = a.meta(b, p)
    else
        if Pm.immutable(a, b, c) then return nil, "operation not permitted" end
        m = Pm.meta(a, b, c, st == "dir")
    end
    if p and p.uid ~= 0 then
        if p.uid ~= m.uid then return nil, "operation not permitted" end
        if uid ~= nil and uid ~= m.uid then return nil, "operation not permitted" end
        if gid ~= nil and not Pm.inGroup(p, gid) then return nil, "operation not permitted" end
    end
    if k == "virtual" then return a.chown(b, uid, gid) end
    Pm.set(a, b, c, { mode = m.mode, uid = uid or m.uid, gid = gid or m.gid })
    return true
end

function V.readFile(full)
    local h, err = V.open(nil, full, "r")
    if not h then return nil, err end
    local data = h:read("a")
    h:close()
    return data or ""
end

function V.writeFile(full, data, mode)
    local h, err = V.open(nil, full, "w", mode)
    if not h then return nil, err end
    local ok, werr = h:write(data)
    h:close()
    if not ok then return nil, werr end
    return true
end

function V.disks() return R.disks() end

function V.partitions(ref)
    local d = R.diskByRef(ref)
    if not d then return nil, "no such disk" end
    return R.partitions(d.slot)
end

local dev = {}
local function devHandle(spec)
    local h = { readable = spec.read ~= nil, writable = spec.write ~= nil }
    function h:read(fmt)
        if not spec.read then return nil, "not readable" end
        return spec.read(fmt)
    end

    function h:write(s)
        if not spec.write then return nil, "not writable" end
        return spec.write(s)
    end

    function h:seek() return 0 end

    function h:flush() return true end

    function h:close() return true end

    return h
end

local function ttyWriter(getTty)
    return function(p, s)
        local t = getTty(p)
        if not t then return nil, "no controlling terminal" end
        t:printText(s, K.WHITE, K.BLACK, false)
        return true
    end
end

local function zeroRead(fmt)
    if type(fmt) == "number" then return fmt > 0 and string.rep("\0", fmt) or "" end
    return fmt == "a" and "" or nil
end

local function randomRead(fmt)
    if type(fmt) ~= "number" or fmt < 0 then return nil end
    return K.crypto.random_bytes(math.min(math.floor(fmt), 4096))
end

local function devNodes()
    local nodes = {}
    nodes["null"] = function()
        return devHandle({
            read = function() return nil end, write = function() return true end })
    end
    nodes["zero"] = function() return devHandle({ read = zeroRead, write = function() return true end }) end
    nodes["random"] = function() return devHandle({ read = randomRead }) end
    nodes["urandom"] = nodes["random"]
    nodes["klog"] = function()
        return stringHandle(table.concat(K.klog_lines(), "\n") .. "\n")
    end
    nodes["tty"] = function(p)
        local t = p and p.tty
        return devHandle({
            write = function(s)
                if not t then return nil, "no controlling terminal" end
                t:printText(s, K.WHITE, K.BLACK, false)
                return true
            end
        })
    end
    nodes["console"] = function()
        return devHandle({ write = function(s)
            K.ttys[1]:printText(s, K.WHITE, K.BLACK, false)
            return true
        end })
    end
    for _, n in ipairs({ "stdout", "stderr" }) do
        nodes[n] = function(p)
            return devHandle({
                write = function(s)
                    local st = p and p[n]
                    if not st then return nil, "no such stream" end
                    return st:write(s)
                end
            })
        end
    end
    nodes["stdin"] = function(p)
        return devHandle({
            read = function(fmt)
                local st = p and p.stdin
                if not st then return nil end
                return st:read(fmt)
            end
        })
    end
    return nodes
end
local devnodes = devNodes()

local function ttyIndex(name) return tonumber(name:match("^ttyv(%d+)$")) end

dev.stat = function(sub)
    if sub == "/" then return "dir" end
    local name = sub:sub(2)
    if name:find("/") then return nil end
    if devnodes[name] then return "file" end
    local i = ttyIndex(name)
    if i and K.ttys[i + 1] then return "file" end
    local v = name:match("^vcs(%d+)$")
    if v and K.ttys[tonumber(v) + 1] then return "file" end
end
dev.list = function()
    local out = {}
    for n in pairs(devnodes) do out[#out + 1] = n end
    for i = 1, #K.ttys do
        out[#out + 1] = "ttyv" .. (i - 1)
        out[#out + 1] = "vcs" .. (i - 1)
    end
    table.sort(out)
    return out
end
dev.open = function(p, sub, mode)
    local name = sub:sub(2)
    local mk = devnodes[name]
    if mk then return mk(p) end
    local i = ttyIndex(name)
    if i and K.ttys[i + 1] then
        local t = K.ttys[i + 1]
        return devHandle({ write = function(s)
            t:printText(s, K.WHITE, K.BLACK, false)
            return true
        end })
    end
    local v = name:match("^vcs(%d+)$")
    if v and K.ttys[tonumber(v) + 1] then
        return stringHandle(K.ttys[tonumber(v) + 1]:dump())
    end
    return nil, "no such device"
end

local DEVMODE = {
    null = o "666",
    zero = o "666",
    random = o "666",
    urandom = o "666",
    tty = o "666",
    stdin = o "666",
    stdout = o "666",
    stderr = o "666",
    console = o "600",
    klog = o "640"
}
local devmeta = {}

dev.meta = function(sub)
    if sub == "/" then return { mode = o "755", uid = 0, gid = 0, dir = true } end
    if not dev.stat(sub) then return nil end
    local name = sub:sub(2)
    local ov = devmeta[name]
    if ov then return { mode = ov.mode, uid = ov.uid, gid = ov.gid, dir = false } end
    return { mode = DEVMODE[name] or o "600", uid = 0, gid = 0, dir = false }
end
local function devChangeable(name) return ttyIndex(name) ~= nil or name:match("^vcs%d+$") ~= nil end
dev.chmod = function(sub, mode)
    local name = sub:sub(2)
    if not devChangeable(name) or not dev.stat(sub) then return nil, "operation not supported" end
    local m = dev.meta(sub)
    devmeta[name] = { mode = mode & o "777", uid = m.uid, gid = m.gid }
    return true
end
dev.chown = function(sub, uid, gid)
    local name = sub:sub(2)
    if not devChangeable(name) or not dev.stat(sub) then return nil, "operation not supported" end
    local m = dev.meta(sub)
    devmeta[name] = { mode = m.mode, uid = uid or m.uid, gid = gid or m.gid }
    return true
end
virtual["/dev"] = dev

local proc = {}

local STATE_NAME = { R = "running", S = "sleeping", Z = "zombie", T = "stopped" }

local function procMem(p)
    if p.co and coroutine.memoryused then
        local ok, m = pcall(coroutine.memoryused, p.co)
        if ok and type(m) == "number" then return math.tointeger(m) or m end
    end
    return 0
end
local function procMemDeep(p)
    if p.co and coroutine.memoryused then
        local ok, m = pcall(coroutine.memoryused, p.co, true)
        if ok and type(m) == "number" then return math.tointeger(m) or m end
    end
    return procMem(p)
end
local function gcBytes()
    if collectgarbage then
        local ok, v = pcall(collectgarbage, "count")
        if ok and type(v) == "number" then return math.floor(v * 1024) end
    end
    return 0
end

local function procStatus(pr, reader)
    local lines = {
        "Name:\t" .. pr.name,
        "Pid:\t" .. pr.pid,
        "PPid:\t" .. pr.ppid,
        "Pgid:\t" .. pr.pgid,
        "State:\t" .. pr.state .. " (" .. (STATE_NAME[pr.state] or "?") .. ")",
        "Uid:\t" .. pr.uid,
        "Tty:\t" .. (pr.tty and pr.tty.name or "-"),
        "Nice:\t" .. pr.nice,
        "Cwd:\t" .. ((reader == nil or reader.uid == 0 or reader.uid == pr.uid) and pr.cwd or "-"),
        "Slices:\t" .. pr.slices,
        "Cpu:\t" .. string.format("%.3f", pr.cputime),
        "Mem:\t" .. procMem(pr),
        "MemDeep:\t" .. procMemDeep(pr),
        "Started:\t" .. string.format("%.3f", pr.started - K.boottime),
    }
    return table.concat(lines, "\n") .. "\n"
end

local function findProc(name)
    local n = tonumber(name)
    return n and K.procs and K.procs[n]
end

local function procFile(p, name)
    if name == "version" then
        return string.format("%s %s (%s) YSLua %s\n", K.NAME, K.RELEASE, K.KERNEL, _VERSION)
    elseif name == "uptime" then
        return string.format("%.2f\n", K.uptime())
    elseif name == "loadavg" then
        local a, b, c = K.loadavg()
        return string.format("%.2f %.2f %.2f %d/%d\n", a, b, c, K.nrunning(), K.nprocs())
    elseif name == "mounts" then
        local out = {}
        out[#out + 1] = string.format("%s:%s / xesfs rw 0 0", K.root.id, K.root.part)
        for _, m in ipairs(V.mountlist()) do
            out[#out + 1] = string.format("%s:%s %s xesfs %s 0 0",
                m.disk, m.part, m.mpfp, m.opts or "rw")
        end
        out[#out + 1] = "devfs /dev devfs rw 0 0"
        out[#out + 1] = "procfs /proc procfs ro 0 0"
        out[#out + 1] = "mntfs /mnt mntfs ro 0 0"
        return table.concat(out, "\n") .. "\n"
    elseif name == "partitions" then
        local out = {}
        for _, d in ipairs(R.disks()) do
            for _, part in ipairs(R.partitions(d.slot) or {}) do
                out[#out + 1] = string.format("%d %s %s", d.slot, d.id, part)
            end
        end
        return table.concat(out, "\n") .. "\n"
    elseif name == "cpuinfo" then
        return string.format("machine\t: %s\nvm\t: YSLua %s\nquantum\t: %d instructions\n",
            tostring(chip.getMachine and chip.getMachine() or "neet"), _VERSION, K.quantum)
    elseif name == "meminfo" then
        local procs, n = 0, 0
        for _, p in pairs(K.procs or {}) do procs, n = procs + procMem(p), n + 1 end
        return string.format("HeapBytes:\t%d\nProcsBytes:\t%d\nNprocs:\t%d\n",
            gcBytes(), procs, n)
    elseif name == "cmdline" then
        return table.concat(K.boot.args, " ") .. "\n"
    end
end

proc.stat = function(sub)
    if sub == "/" then return "dir" end
    local first, rest = sub:match("^/([^/]+)(.*)$")
    if not first then return nil end
    if rest == "" then
        if first == "self" or findProc(first) then return "dir" end
        if procFile(nil, first) then return "file" end
        return nil
    end
    local pr = (first == "self") and true or findProc(first)
    if not pr then return nil end
    local leaf = rest:sub(2)
    if leaf == "status" or leaf == "cmdline" or leaf == "cwd" then return "file" end
end
proc.list = function(sub)
    local out = { "version", "uptime", "loadavg", "mounts", "partitions", "cpuinfo", "meminfo", "cmdline", "self" }
    if sub == "/" then
        for pid in pairs(K.procs or {}) do out[#out + 1] = tostring(pid) end
    else
        return { "status", "cmdline", "cwd" }
    end
    table.sort(out)
    return out
end
proc.open = function(p, sub, mode)
    if mode ~= "r" then return nil, "read-only file system" end
    local first, rest = sub:match("^/([^/]+)(.*)$")
    if not first then return nil, "is a directory" end
    if rest == "" then
        local s = procFile(p, first)
        if s then return stringHandle(s) end
        return nil, "no such file"
    end
    local pr = (first == "self") and p or findProc(first)
    if not pr then return nil, "no such process" end
    local leaf = rest:sub(2)
    if leaf == "status" then
        return stringHandle(procStatus(pr, p))
    elseif leaf == "cmdline" then
        return stringHandle(pr.name .. " " .. table.concat(pr.args or {}, " ") .. "\n")
    elseif leaf == "cwd" then
        return stringHandle(pr.cwd .. "\n")
    end
    return nil, "no such file"
end
proc.meta = function(sub, reader)
    if sub == "/" then return { mode = o "555", uid = 0, gid = 0, dir = true } end
    local first, rest = sub:match("^/([^/]+)(.*)$")
    if not first then return nil end
    local pr = (first == "self") and (reader or K.current) or findProc(first)
    if rest == "" then
        if pr then return { mode = o "555", uid = pr.uid, gid = 0, dir = true } end
        if procFile(nil, first) then return { mode = o "444", uid = 0, gid = 0, dir = false } end
        return nil
    end
    if not pr then return nil end
    local leaf = rest:sub(2)
    if leaf == "status" then return { mode = o "444", uid = pr.uid, gid = 0, dir = false } end
    if leaf == "cmdline" or leaf == "cwd" then return { mode = o "400", uid = pr.uid, gid = 0, dir = false } end
    return nil
end
virtual["/proc"] = proc

local mnt = {}
mnt.stat = function(sub)
    if sub == "/" then return "dir" end
    return "dir"
end
mnt.list = function(sub)
    local out, seen = {}, {}
    if sub == "/" then
        for _, d in ipairs(R.disks()) do
            for _, part in ipairs(R.partitions(d.slot) or {}) do
                if not seen[part] then
                    seen[part] = true; out[#out + 1] = part
                end
            end
        end
        for _, d in ipairs(R.disks()) do
            if not seen[d.id] then
                seen[d.id] = true; out[#out + 1] = d.id
            end
        end
    else
        local d = R.diskByRef(sub:sub(2))
        for _, part in ipairs(d and R.partitions(d.slot) or {}) do out[#out + 1] = part end
    end
    table.sort(out)
    return out
end
mnt.open = function() return nil, "is a directory" end
mnt.meta = function() return { mode = o "555", uid = 0, gid = 0, dir = true } end
virtual["/mnt"] = mnt
