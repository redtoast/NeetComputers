local K, API, X = ...

local T = {}

local host = rawget(_G, "headsup")
if type(host) ~= "table" or type(host.getSize) ~= "function" then
	T.__eventonly = true
	return T
end

local function passthrough(fn)
	return function(p, ...)
		return fn(...)
	end
end

local count = 0
for name, fn in pairs(host) do
	if type(name) == "string" and type(fn) == "function" then
		T[name] = passthrough(fn)
		count = count + 1
	end
end

if count == 0 then
	T = { __eventonly = true }
	return T
end

T.__ext = { ["ext.headsup"] = 1 }

return T
