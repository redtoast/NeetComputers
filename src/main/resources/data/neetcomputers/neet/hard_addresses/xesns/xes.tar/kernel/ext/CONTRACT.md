# Extension area contract (for kernel/ext/<area>.lua)

This is the exact contract an area module must follow. `kernel/ext.lua` loads
every area at boot; nothing else needs to change for a new area to appear in the
guest environment.

## Shape

```lua
local K, API, X = ...
local T = {}
-- functions take the calling process `p` first
function T.example(p, arg) ... end
return T
```

- `K` is the kernel namespace (see `kernel/klib.lua`, `kernel/neato.lua`,
  `kernel/proc.lua`, `kernel/sched.lua`, `kernel/vfs.lua`).
- `API` is `K.neato`: the core tables (`API.fs`, `API.proc`, `API.job`,
  `API.stdio`, `API.time`, `API.sys`, `API.user`, `API.auth`, `API.term`,
  `API.event`). Delegate to these before reimplementing anything.
- `X` is the shared area table; `X.fs`, `X.proc`, etc. are the other loaded
  areas (use for cross-area delegation only, e.g. a new area calling
  `X.proc.signal`).

## Names the guest sees

- The file name is the global name by default: `ext/poll.lua` -> `poll`.
- To provide a different global, set `T.__global = "io"` (e.g.
  `ext/peripherals.lua` provides the NEATO `io` global; `ext/headsup.lua`
  provides `headsup`).
- Functions are bound to the caller at call time by `K.extbind`, so write
  `function T.foo(p, ...)` and call `foo.bar(...)` in the guest.
- A function that belongs at the process root instead of under a table goes in
  `T.__top = { klog = fn }`.

## Declaring the extension

- `T.__ext = { ["ext.screen"] = 1 }` (map form) or `T.__ext = { "ext.screen" }`
  (array form, version 1). These entries become `sys.getExtensions()`.
- **Nothing may appear half there.** If the host capability the extension needs
  is absent (`rawget(_G, "screen") == nil`), do NOT set `T.__ext` and do NOT
  define any of its functions, events or globals. A guest must see the
  extension as simply unsupported, exactly as NEATO's registry requires.
- If the extension is additive with no NEATO name (e.g. `x.xesns.time`), still
  declare it under the vendor name.

## Events

For an extension that delivers events (compat, mouse, ...), set:

```lua
T.__eventonly = true               -- contributes no global table
T.__ext = { ["ext.mouse"] = 1 }
T.__hooks = { mouse = function(e) ... end }  -- keyed by queue name (lowercase)
                                           -- or by host event kind
```

`KBD.pump()` (kernel/kbd.lua) calls `K.extensionHooks[key]` for every event in
the host queues `User`, `System`, `Peripheral`, `Compatibility`, `Unlabeled`.
`key` is the lowercased queue name, or the event's kind string (`e[1]`). The
hook receives the raw host event table `e`. Deliver guest events with
`K.tty_input(tty, name, ...)` or `K.pushEvent(p, name, ...)`:

- `K.input(name, ...)` delivers to the active console's foreground group.
- For mouse: the events are `mouseMoved/mouseClicked/mouseDragged/
  mouseReleased/mouseScrolled`, coordinates as the host reports them.

## Errors

Return NEATO tuples `nil, CODE, message` for ordinary failures; `K.argcheck.err`
raises for bad argument types (same as the core API). Use only codes from
`neato/common/errors.md`; there is no ENOSYS.

## Validation

`luac -p kernel/ext/<area>.lua` must pass. Keep the header comment factual and
free of any internal project name; describe what the area does.
