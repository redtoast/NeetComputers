local K, API, X = ...

local T = {}

local argerr = K.argcheck.err

local PAYLOAD_MAX_RAW = 3072
local PAYLOAD_MAX_B64 = 4096
local PAYLOAD_MAX_DEPTH = 32
local ID_LEN = 16
local INBOX_MAX = 16
local MAX_INFLIGHT = 8
local SEQ_MAX = 1073741823
local RETRANSMIT_START = 1
local RETRANSMIT_START_RPP = 2
local RETRANSMIT_CAP = 8
local RETRANSMIT_ROUNDS = 5
local SYN_REPEAT = 4
local SYN_REPEAT_GAP = 1
local SYN_REPEAT_GAP_RPP = 2
local HALFOPEN_LIFETIME = 10
local MAX_SEGMENT_VALUES = 7

local BROADCAST = "ffffffffffff"

local function validPort(n)
	return math.type(n) == "integer" and n >= 1 and n <= 65535
end

local function validAddress(s)
	return type(s) == "string" and #s == 12 and s:match("^[0-9a-f]+$") ~= nil and s ~= "000000000000"
end

local function validId(s)
	return type(s) == "string" and #s == ID_LEN and s:match("^[0-9a-f]+$") ~= nil
end

local function newId()
	return K.crypto.tohex(K.crypto.random_bytes(8))
end

local ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local DECODE = {}
for i = 1, #ALPHABET do
	DECODE[ALPHABET:sub(i, i)] = i - 1
end

local function base64Encode(s)
	local out = {}
	for i = 1, #s, 3 do
		local a, b, c = s:byte(i, i + 2)
		local n = (a << 16) | ((b or 0) << 8) | (c or 0)
		out[#out + 1] = ALPHABET:sub(((n >> 18) & 63) + 1, ((n >> 18) & 63) + 1)
			.. ALPHABET:sub(((n >> 12) & 63) + 1, ((n >> 12) & 63) + 1)
			.. (b and ALPHABET:sub(((n >> 6) & 63) + 1, ((n >> 6) & 63) + 1) or "=")
			.. (c and ALPHABET:sub((n & 63) + 1, (n & 63) + 1) or "=")
	end
	return table.concat(out)
end

local function base64Decode(s)
	if type(s) ~= "string" or #s % 4 ~= 0 then
		return nil
	end
	local out = {}
	for i = 1, #s, 4 do
		local q = {}
		for j = 0, 3 do
			local ch = s:sub(i + j, i + j)
			if ch == "=" and j >= 2 then
				q[j] = nil
			else
				local v = DECODE[ch]
				if v == nil then
					return nil
				end
				q[j] = v
			end
		end
		local n = ((q[0] or 0) << 18) | ((q[1] or 0) << 12) | ((q[2] or 0) << 6) | (q[3] or 0)
		out[#out + 1] = string.char((n >> 16) & 255)
		if q[2] then
			out[#out + 1] = string.char((n >> 8) & 255)
		end
		if q[3] then
			out[#out + 1] = string.char(n & 255)
		end
	end
	return table.concat(out)
end

local function encodeInto(out, v, depth, seen)
	local tv = type(v)
	if tv == "boolean" then
		out[#out + 1] = v and "T" or "F"
		return true
	end
	if tv == "number" then
		if v ~= v then
			return false
		end
		if math.type(v) == "integer" then
			out[#out + 1] = "i" .. string.format("%d", v) .. ";"
		else
			out[#out + 1] = "f" .. string.format("%.17g", v) .. ";"
		end
		return true
	end
	if tv == "string" then
		out[#out + 1] = ("s%d:%s"):format(#v, v)
		return true
	end
	if tv ~= "table" then
		return false
	end
	if depth > PAYLOAD_MAX_DEPTH then
		return false
	end
	if seen[v] then
		return false
	end
	seen[v] = true
	local n, keys = 0, {}
	for k in pairs(v) do
		n = n + 1
		keys[#keys + 1] = k
	end
	out[#out + 1] = ("t%d;"):format(n)
	for _, k in ipairs(keys) do
		if not encodeInto(out, k, depth + 1, seen) or not encodeInto(out, v[k], depth + 1, seen) then
			seen[v] = nil
			return false
		end
	end
	seen[v] = nil
	return true
end

local function decodeInto(s, pos, depth)
	if depth > PAYLOAD_MAX_DEPTH then
		return nil, nil, "payload nests deeper than " .. PAYLOAD_MAX_DEPTH
	end
	if pos > #s then
		return nil, nil, "payload ends early"
	end
	local rest = s:sub(pos)
	local tag = rest:sub(1, 1)
	if tag == "T" or tag == "F" then
		return tag == "T", pos + 1
	end
	if tag == "i" or tag == "f" then
		local num = rest:match("^.[^;]*;")
		if not num then
			return nil, nil, "unterminated number"
		end
		local text = num:sub(2, -2)
		local v
		if tag == "i" then
			v = math.tointeger(tonumber(text))
			if not v then
				return nil, nil, "bad integer"
			end
		else
			v = tonumber(text)
			if v == nil or v ~= v then
				return nil, nil, "bad float"
			end
		end
		return v, pos + #num
	end
	if tag == "s" then
		local len = rest:match("^s(%d+):")
		if not len then
			return nil, nil, "unterminated string length"
		end
		local n = tonumber(len)
		local start = 2 + #len + 1
		if not n or start + n - 1 > #rest then
			return nil, nil, "string runs past the payload"
		end
		return rest:sub(start, start + n - 1), pos + start + n - 1
	end
	if tag == "t" then
		local count = rest:match("^t(%d+);")
		if not count then
			return nil, nil, "unterminated table count"
		end
		local n = tonumber(count)
		local after = 1 + #count + 1
		if not n or n * 2 > #rest - (after - 1) then
			return nil, nil, "table count exceeds the payload"
		end
		local tbl, at = {}, pos + after
		for _ = 1, n do
			local k, v
			k, at = decodeInto(s, at, depth + 1)
			if at == nil then
				return nil, nil, "bad table key"
			end
			v, at = decodeInto(s, at, depth + 1)
			if at == nil then
				return nil, nil, "bad table value"
			end
			tbl[k] = v
		end
		return tbl, at
	end
	return nil, nil, "unknown payload tag"
end

local function encodePayload(payload)
	local out = {}
	if not encodeInto(out, payload, 1, {}) then
		return nil, "EINVAL", "payload cannot be sent"
	end
	local raw = table.concat(out)
	if #raw > PAYLOAD_MAX_RAW then
		return nil, "EMSGSIZE", "payload is larger than the network allows"
	end
	return base64Encode(raw)
end

local function decodePayload(text)
	if type(text) ~= "string" or #text > PAYLOAD_MAX_B64 then
		return nil
	end
	local raw = base64Decode(text)
	if not raw then
		return nil
	end
	local value, at = decodeInto(raw, 1, 1)
	if at == nil or at ~= #raw + 1 then
		return nil
	end
	return value
end

local function frameFits(values)
	if #values < 1 or #values > 16 then
		return nil, "EINVAL", "a frame holds 1 to 16 values"
	end
	local chars = 0
	for i = 1, #values do
		local v = values[i]
		local tv = type(v)
		if tv == "string" then
			if #v > 4096 then
				return nil, "EMSGSIZE", "a frame string holds at most 4096 characters"
			end
			for j = 1, #v do
				local b = v:byte(j)
				if b < 0x01 or b > 0x7f then
					return nil, "EINVAL", "a frame string uses bytes 0x01 to 0x7f"
				end
			end
			chars = chars + #v
		elseif tv == "number" then
			if v ~= v then
				return nil, "EINVAL", "a frame value cannot be nan"
			end
			if math.type(v) == "integer" and (v < -2147483648 or v > 2147483647) then
				return nil, "ERANGE", "a frame integer fits in 32 bits"
			end
		elseif tv ~= "boolean" then
			return nil, "EINVAL", "a frame value is a boolean, number or string"
		end
	end
	if chars > 4608 then
		return nil, "EMSGSIZE", "a frame holds at most 4608 string characters"
	end
	return true
end

local function validWindow(n)
	return math.type(n) == "integer" and n >= 0 and n <= 2147483647
end

local function validSeq(n)
	return math.type(n) == "integer" and n >= 1 and n <= SEQ_MAX
end

local S = {}

function S.syn(source, targetPort, sourcePort, window)
	if not validId(source) or not validPort(targetPort) or not validPort(sourcePort) or not validWindow(window) then
		return nil, "EINVAL", "invalid syn"
	end
	return { "spp", "syn", source, "", targetPort, sourcePort, window }
end

function S.synack(source, target, window)
	if not validId(source) or not validId(target) or not validWindow(window) then
		return nil, "EINVAL", "invalid synack"
	end
	return { "spp", "synack", source, target, window }
end

function S.data(source, target, seq, payload)
	if not validId(source) or not validId(target) or not validSeq(seq) then
		return nil, "EINVAL", "invalid data"
	end
	local encoded, code, msg = encodePayload(payload)
	if not encoded then
		return nil, code, msg
	end
	return { "spp", "data", source, target, seq, encoded }
end

function S.ack(source, target, ack, window)
	if not validId(source) or not validId(target) or not validWindow(window) then
		return nil, "EINVAL", "invalid ack"
	end
	if math.type(ack) ~= "integer" or ack < 0 or ack > SEQ_MAX then
		return nil, "EINVAL", "invalid ack number"
	end
	return { "spp", "ack", source, target, ack, window }
end

function S.fin(source, target, seq)
	if not validId(source) or not validId(target) or not validSeq(seq) then
		return nil, "EINVAL", "invalid fin"
	end
	return { "spp", "fin", source, target, seq }
end

function S.rst(source, target)
	if not validId(source) or not validId(target) then
		return nil, "EINVAL", "invalid rst"
	end
	return { "spp", "rst", source, target }
end

local function parseSegment(frame)
	if type(frame) ~= "table" then
		return nil
	end
	local n = #frame
	if n < 1 or n > MAX_SEGMENT_VALUES or frame[1] ~= "spp" then
		return nil
	end
	if frameFits(frame) ~= true then
		return nil
	end
	local kind, source, target = frame[2], frame[3], frame[4]
	if not validId(source) then
		return nil
	end
	if kind == "syn" then
		if n ~= 7 or target ~= "" then
			return nil
		end
		if not validPort(frame[5]) or not validPort(frame[6]) or not validWindow(frame[7]) then
			return nil
		end
		return {
			kind = "syn",
			source = source,
			targetPort = frame[5],
			sourcePort = frame[6],
			window = frame[7],
		}
	end
	if not validId(target) then
		return nil
	end
	if kind == "synack" then
		if n ~= 5 or not validWindow(frame[5]) then
			return nil
		end
		return { kind = "synack", source = source, target = target, window = frame[5] }
	end
	if kind == "data" then
		if n ~= 6 or not validSeq(frame[5]) then
			return nil
		end
		local payload = decodePayload(frame[6])
		if payload == nil then
			return nil
		end
		return { kind = "data", source = source, target = target, seq = frame[5], payload = payload }
	end
	if kind == "ack" then
		if n ~= 6 or math.type(frame[5]) ~= "integer" or frame[5] < 0 or frame[5] > SEQ_MAX then
			return nil
		end
		if not validWindow(frame[6]) then
			return nil
		end
		return { kind = "ack", source = source, target = target, ack = frame[5], window = frame[6] }
	end
	if kind == "fin" then
		if n ~= 5 or not validSeq(frame[5]) then
			return nil
		end
		return { kind = "fin", source = source, target = target, seq = frame[5] }
	end
	if kind == "rst" then
		if n ~= 4 then
			return nil
		end
		return { kind = "rst", source = source, target = target }
	end
	return nil
end

local function remotePeer(host)
	if not validAddress(host) then
		return nil
	end
	return { origin = "remote", host = host }
end

local function rpp()
	return type(K.rppSend) == "function"
end

local function medium()
	return nil
end

local function available()
	return medium() ~= nil
end

local function gate()
	if not available() then
		return nil, "ENOTSUP", 'scope "network" needs a medium that reaches another computer'
	end
	return nil, "ENOTSUP", 'scope "network" is not implemented for this medium'
end

function T.getNetworkStatus(p)
	local _, code, msg = gate()
	return {
		scope = "network",
		available = available(),
		rpp = rpp(),
		medium = medium(),
		code = code,
		message = msg,
	}
end

function T.available(p)
	return available()
end

local function checkPort(port, fname)
	if type(port) ~= "number" then
		argerr(1, fname, "integer", port)
	end
	if not validPort(port) then
		return nil, "EINVAL", "port must be from 1 to 65535"
	end
	return true
end

function T.listen(p, port, opts)
	local ok, code, msg = checkPort(port, "listen")
	if not ok then
		return nil, code, msg
	end
	if opts ~= nil and type(opts) ~= "table" then
		argerr(2, "listen", "table", opts)
	end
	if opts and opts.scope ~= nil and opts.scope ~= "network" then
		return nil, "EINVAL", "this is the network scope"
	end
	local _, gcode, gmsg = gate()
	return nil, gcode, gmsg
end

function T.connect(p, port, opts)
	local ok, code, msg = checkPort(port, "connect")
	if not ok then
		return nil, code, msg
	end
	if opts ~= nil and type(opts) ~= "table" then
		argerr(2, "connect", "table", opts)
	end
	local host = opts and opts.host
	if host ~= nil then
		if type(host) ~= "string" then
			argerr(2, "connect", "table", opts)
		end
		if opts.scope ~= nil and opts.scope ~= "network" then
			return nil, "EINVAL", "host requires network scope"
		end
		if not rpp() then
			return nil, "ENOTSUP", "opts.host needs ext.rpp"
		end
		if not validAddress(host) then
			return nil, "EINVAL", "host is not an address"
		end
		if not available() then
			return nil, "EHOSTUNREACH", "no route to " .. host
		end
	end
	if opts and opts.scope ~= nil and opts.scope ~= "network" then
		return nil, "EINVAL", "this is the network scope"
	end
	local _, gcode, gmsg = gate()
	return nil, gcode, gmsg
end

local function retransmitStart(rppOn)
	return rppOn and RETRANSMIT_START_RPP or RETRANSMIT_START
end

function T.newConnection(now, id, peer, rppOn, synSegment)
	if not validId(id) then
		return nil, "EINVAL", "invalid connection id"
	end
	if type(peer) ~= "table" or peer.origin ~= "remote" then
		return nil, "EINVAL", "a network connection has a remote peer"
	end
	return {
		id = id,
		peerId = nil,
		peer = peer,
		rpp = rppOn and true or false,
		state = "connecting",
		maxPayload = PAYLOAD_MAX_RAW,
		inbox = {},
		inboxMax = INBOX_MAX,
		unsent = {},
		sendSeq = 0,
		delivered = 0,
		peerWindow = 0,
		synAt = now,
		synRepeats = 0,
		synSegment = synSegment,
		rtxAt = nil,
		rtxTimeout = retransmitStart(rppOn),
		rtxRounds = 0,
		finSeq = nil,
		finSent = false,
		peerFin = false,
	}
end

function T.newHalfOpen(now, listener, segment)
	if type(segment) ~= "table" or segment.kind ~= "syn" then
		return nil, "EINVAL", "a half-open connection starts from a syn"
	end
	local id = newId()
	local synack, code, msg = S.synack(id, segment.source, INBOX_MAX)
	if not synack then
		return nil, code, msg
	end
	return {
		listener = listener,
		source = segment.source,
		targetPort = segment.targetPort,
		sourcePort = segment.sourcePort,
		window = segment.window,
		at = now,
		id = id,
		synack = synack,
	}
end

function T.expireHalfOpen(halfOpen, now)
	for i = #halfOpen, 1, -1 do
		if now - halfOpen[i].at > HALFOPEN_LIFETIME then
			table.remove(halfOpen, i)
		end
	end
end

function T.acceptSynack(conn, now, segment, host)
	if conn.state ~= "connecting" then
		return S.rst(conn.id, segment.source)
	end
	if conn.peerId ~= nil then
		return S.rst(conn.id, conn.peerId)
	end
	conn.peerId = segment.source
	conn.peer = remotePeer(host) or conn.peer
	conn.peerWindow = math.min(segment.window, MAX_INFLIGHT)
	conn.state = "open"
	conn.openedAt = now
	conn.rtxAt = nil
	local ack, code, msg = S.ack(conn.id, conn.peerId, 0, INBOX_MAX)
	if not ack then
		return nil, code, msg
	end
	return ack
end

function T.acceptAck(halfOpen, now, segment)
	if segment.kind ~= "ack" and segment.kind ~= "data" then
		return nil, "EINVAL", "a half-open connection is completed by an ack"
	end
	if segment.target ~= halfOpen.id then
		return nil, "EINVAL", "the ack is for another connection"
	end
	return {
		id = halfOpen.id,
		peerId = segment.source,
		peer = remotePeer(halfOpen.source),
		rpp = false,
		state = "open",
		maxPayload = PAYLOAD_MAX_RAW,
		inbox = {},
		inboxMax = INBOX_MAX,
		unsent = {},
		sendSeq = 0,
		delivered = 0,
		peerWindow = math.min(segment.window or 0, MAX_INFLIGHT),
		peerPort = halfOpen.sourcePort,
		port = halfOpen.targetPort,
		synAt = now,
		synRepeats = 0,
		rtxAt = nil,
		rtxTimeout = retransmitStart(false),
		rtxRounds = 0,
		finSeq = nil,
		finSent = false,
		peerFin = false,
	}
end

function T.step(conn, now)
	local out = {}
	if conn.state == "reset" or conn.state == "closed" then
		return out
	end
	if conn.state == "connecting" then
		local gap = conn.rpp and SYN_REPEAT_GAP_RPP or SYN_REPEAT_GAP
		if now - conn.synAt >= gap then
			if conn.synRepeats < SYN_REPEAT and conn.synSegment then
				conn.synRepeats = conn.synRepeats + 1
				conn.synAt = now
				out[#out + 1] = conn.synSegment
			else
				conn.state, conn.timedOut = "closed", true
			end
		end
		return out
	end
	if conn.state == "closing" and conn.finSeq and #conn.unsent == 0 and not conn.finSent then
		local fin = S.fin(conn.id, conn.peerId, conn.finSeq)
		if fin then
			conn.finSent = true
			conn.rtxAt = now + conn.rtxTimeout
			out[#out + 1] = fin
		end
	end
	if conn.rtxAt and now >= conn.rtxAt then
		if conn.rtxRounds + 1 > RETRANSMIT_ROUNDS then
			conn.state = "reset"
			local rst = S.rst(conn.id, conn.peerId)
			if rst then
				out[#out + 1] = rst
			end
			return out
		end
		conn.rtxRounds = conn.rtxRounds + 1
		conn.rtxTimeout = math.min(conn.rtxTimeout * 2, RETRANSMIT_CAP)
		conn.rtxAt = now + conn.rtxTimeout
		if conn.finSeq and #conn.unsent == 0 then
			local fin = S.fin(conn.id, conn.peerId, conn.finSeq)
			if fin then
				out[#out + 1] = fin
			end
		else
			for _, msg in ipairs(conn.unsent) do
				local seg = S.data(conn.id, conn.peerId, msg.seq, msg.payload)
				if seg then
					out[#out + 1] = seg
				end
			end
		end
	end
	return out
end

function T.queue(conn, now, payload)
	if conn.state ~= "open" and conn.state ~= "closing" then
		return nil, "ECONNRESET", "the connection is not open"
	end
	local inflight = math.min(conn.peerWindow, MAX_INFLIGHT)
	if #conn.unsent > 0 and #conn.unsent >= inflight then
		return nil, "ETIMEDOUT", "the peer's window is exhausted"
	end
	local seq = conn.sendSeq + 1
	if seq > SEQ_MAX then
		conn.state = "reset"
		return nil, "ECONNRESET", "the sequence number ran out"
	end
	conn.sendSeq = seq
	conn.unsent[#conn.unsent + 1] = { seq = seq, payload = payload }
	if not conn.rtxAt then
		conn.rtxAt = now + conn.rtxTimeout
	end
	return true
end

function T.receive(conn, now, segment)
	if conn.state == "reset" then
		return nil, "ECONNRESET"
	end
	if segment.kind == "rst" then
		conn.state = "reset"
		return nil, "ECONNRESET"
	end
	if segment.kind == "ack" then
		conn.peerWindow = segment.window
		while #conn.unsent > 0 and conn.unsent[1].seq <= segment.ack do
			table.remove(conn.unsent, 1)
		end
		conn.rtxRounds = 0
		conn.rtxTimeout = retransmitStart(conn.rpp)
		if #conn.unsent > 0 or conn.finSeq then
			conn.rtxAt = now + conn.rtxTimeout
		else
			conn.rtxAt = nil
		end
		return nil
	end
	if segment.kind == "data" or segment.kind == "fin" then
		if segment.seq == conn.delivered + 1 and #conn.inbox < conn.inboxMax then
			conn.delivered = conn.delivered + 1
			if segment.kind == "data" then
				conn.inbox[#conn.inbox + 1] = segment.payload
			else
				conn.peerFin = true
			end
		end
		local window = conn.inboxMax - #conn.inbox
		local ack, code, msg = S.ack(conn.id, conn.peerId, conn.delivered, window)
		if not ack then
			return nil, code, msg
		end
		return ack
	end
	return nil
end

function T.close(conn)
	if conn.state == "reset" or conn.state == "closed" then
		return nil, "ECONNRESET", "the connection is already gone"
	end
	conn.state = "closing"
	conn.finSeq = conn.sendSeq + 1
	conn.sendSeq = conn.finSeq
	conn.finSent = false
	return true
end

function T.on_segment(p, transport, packet)
	local segment = parseSegment(transport)
	T.stats.seen = T.stats.seen + 1
	if not segment then
		T.stats.invalid = T.stats.invalid + 1
		return false
	end
	T.stats.valid = T.stats.valid + 1
	T.stats.lastKind = segment.kind
	if type(packet) == "table" and type(packet.source) == "string" then
		T.stats.lastSource = packet.source
	end
	return true
end

T.stats = { seen = 0, valid = 0, invalid = 0, lastKind = nil, lastSource = nil }

T.segments = {
	syn = S.syn,
	synack = S.synack,
	data = S.data,
	ack = S.ack,
	fin = S.fin,
	rst = S.rst,
	parse = parseSegment,
	encode = encodePayload,
	decode = decodePayload,
	newId = newId,
	validId = validId,
	peer = remotePeer,
	BROADCAST = BROADCAST,
}

T.limits = {
	maxPayload = PAYLOAD_MAX_RAW,
	window = MAX_INFLIGHT,
	halfOpen = HALFOPEN_LIFETIME,
	retransmit = RETRANSMIT_START,
	retransmitWithRpp = RETRANSMIT_START_RPP,
	maxRetransmit = RETRANSMIT_CAP,
	rounds = RETRANSMIT_ROUNDS,
}

T.__global = "sppRemote"
T.__ext = { ["x.xesns.sppRemote"] = 1 }

return T
