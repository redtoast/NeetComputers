local M = {}

M.VERSION = "0.3.0"

local mfloor = math.floor

local MAX_DIM = 2048
local MAX_BYTES = 8 * 1024 * 1024

local ZZ = {
	1,
	2,
	9,
	17,
	10,
	3,
	4,
	11,
	18,
	25,
	33,
	26,
	19,
	12,
	5,
	6,
	13,
	20,
	27,
	34,
	41,
	49,
	42,
	35,
	28,
	21,
	14,
	7,
	8,
	15,
	22,
	29,
	36,
	43,
	50,
	57,
	58,
	51,
	44,
	37,
	30,
	23,
	16,
	24,
	31,
	38,
	45,
	52,
	59,
	60,
	53,
	46,
	39,
	32,
	40,
	47,
	54,
	61,
	62,
	55,
	48,
	56,
	63,
	64,
}

local STD_DC_BITS = { 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0 }
local STD_DC_VALS = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 }
local STD_DCC_BITS = { 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0 }
local STD_AC_BITS = { 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d }
local STD_AC_VALS = {
	0x01,
	0x02,
	0x03,
	0x00,
	0x04,
	0x11,
	0x05,
	0x12,
	0x21,
	0x31,
	0x41,
	0x06,
	0x13,
	0x51,
	0x61,
	0x07,
	0x22,
	0x71,
	0x14,
	0x32,
	0x81,
	0x91,
	0xa1,
	0x08,
	0x23,
	0x42,
	0xb1,
	0xc1,
	0x15,
	0x52,
	0xd1,
	0xf0,
	0x24,
	0x33,
	0x62,
	0x72,
	0x82,
	0x09,
	0x0a,
	0x16,
	0x17,
	0x18,
	0x19,
	0x1a,
	0x25,
	0x26,
	0x27,
	0x28,
	0x29,
	0x2a,
	0x34,
	0x35,
	0x36,
	0x37,
	0x38,
	0x39,
	0x3a,
	0x43,
	0x44,
	0x45,
	0x46,
	0x47,
	0x48,
	0x49,
	0x4a,
	0x53,
	0x54,
	0x55,
	0x56,
	0x57,
	0x58,
	0x59,
	0x5a,
	0x63,
	0x64,
	0x65,
	0x66,
	0x67,
	0x68,
	0x69,
	0x6a,
	0x73,
	0x74,
	0x75,
	0x76,
	0x77,
	0x78,
	0x79,
	0x7a,
	0x83,
	0x84,
	0x85,
	0x86,
	0x87,
	0x88,
	0x89,
	0x8a,
	0x92,
	0x93,
	0x94,
	0x95,
	0x96,
	0x97,
	0x98,
	0x99,
	0x9a,
	0xa2,
	0xa3,
	0xa4,
	0xa5,
	0xa6,
	0xa7,
	0xa8,
	0xa9,
	0xaa,
	0xb2,
	0xb3,
	0xb4,
	0xb5,
	0xb6,
	0xb7,
	0xb8,
	0xb9,
	0xba,
	0xc2,
	0xc3,
	0xc4,
	0xc5,
	0xc6,
	0xc7,
	0xc8,
	0xc9,
	0xca,
	0xd2,
	0xd3,
	0xd4,
	0xd5,
	0xd6,
	0xd7,
	0xd8,
	0xd9,
	0xda,
	0xe1,
	0xe2,
	0xe3,
	0xe4,
	0xe5,
	0xe6,
	0xe7,
	0xe8,
	0xe9,
	0xea,
	0xf1,
	0xf2,
	0xf3,
	0xf4,
	0xf5,
	0xf6,
	0xf7,
	0xf8,
	0xf9,
	0xfa,
}
local STD_ACC_BITS = { 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77 }
local STD_ACC_VALS = {
	0x00,
	0x01,
	0x02,
	0x03,
	0x11,
	0x04,
	0x05,
	0x21,
	0x31,
	0x06,
	0x12,
	0x41,
	0x51,
	0x07,
	0x61,
	0x71,
	0x13,
	0x22,
	0x32,
	0x81,
	0x08,
	0x14,
	0x42,
	0x91,
	0xa1,
	0xb1,
	0xc1,
	0x09,
	0x23,
	0x33,
	0x52,
	0xf0,
	0x15,
	0x62,
	0x72,
	0xd1,
	0x0a,
	0x16,
	0x24,
	0x34,
	0xe1,
	0x25,
	0xf1,
	0x17,
	0x18,
	0x19,
	0x1a,
	0x26,
	0x27,
	0x28,
	0x29,
	0x2a,
	0x35,
	0x36,
	0x37,
	0x38,
	0x39,
	0x3a,
	0x43,
	0x44,
	0x45,
	0x46,
	0x47,
	0x48,
	0x49,
	0x4a,
	0x53,
	0x54,
	0x55,
	0x56,
	0x57,
	0x58,
	0x59,
	0x5a,
	0x63,
	0x64,
	0x65,
	0x66,
	0x67,
	0x68,
	0x69,
	0x6a,
	0x73,
	0x74,
	0x75,
	0x76,
	0x77,
	0x78,
	0x79,
	0x7a,
	0x82,
	0x83,
	0x84,
	0x85,
	0x86,
	0x87,
	0x88,
	0x89,
	0x8a,
	0x92,
	0x93,
	0x94,
	0x95,
	0x96,
	0x97,
	0x98,
	0x99,
	0x9a,
	0xa2,
	0xa3,
	0xa4,
	0xa5,
	0xa6,
	0xa7,
	0xa8,
	0xa9,
	0xaa,
	0xb2,
	0xb3,
	0xb4,
	0xb5,
	0xb6,
	0xb7,
	0xb8,
	0xb9,
	0xba,
	0xc2,
	0xc3,
	0xc4,
	0xc5,
	0xc6,
	0xc7,
	0xc8,
	0xc9,
	0xca,
	0xd2,
	0xd3,
	0xd4,
	0xd5,
	0xd6,
	0xd7,
	0xd8,
	0xd9,
	0xda,
	0xe2,
	0xe3,
	0xe4,
	0xe5,
	0xe6,
	0xe7,
	0xe8,
	0xe9,
	0xea,
	0xf2,
	0xf3,
	0xf4,
	0xf5,
	0xf6,
	0xf7,
	0xf8,
	0xf9,
	0xfa,
}

function M.detect(data, path)
	if type(data) == "string" and #data >= 2 then
		if data:byte(1) == 0xFF and data:byte(2) == 0xD8 then
			return true
		end
	end
	if type(path) == "string" then
		local lp = path:lower()
		if lp:match("%.jpe?g$") then
			return true
		end
	end
	return false
end

local function u16be(s, p)
	local a, b = s:byte(p, p + 1)
	if not b then
		return nil
	end
	return a * 256 + b
end

local function build_huff(bits, vals)
	local total = 0
	for i = 1, 16 do
		total = total + (bits[i] or 0)
	end
	if total == 0 or total > 256 or #vals < total then
		return nil, "bad huffman table"
	end
	local map = {}
	local code, k = 0, 1
	for len = 1, 16 do
		for _ = 1, bits[len] or 0 do
			map[len] = map[len] or {}
			map[len][code] = vals[k]
			k = k + 1
			code = code + 1
		end
		code = code * 2
	end
	return { map = map }
end

local function get_huff(info, tc, th)
	local key = tc * 4 + th + 1
	local tab = info.ht[key]
	if tab then
		return tab
	end
	local bits, vals
	if tc == 0 then
		if th == 0 then
			bits, vals = STD_DC_BITS, STD_DC_VALS
		else
			bits, vals = STD_DCC_BITS, STD_DC_VALS
		end
	else
		if th == 0 then
			bits, vals = STD_AC_BITS, STD_AC_VALS
		else
			bits, vals = STD_ACC_BITS, STD_ACC_VALS
		end
	end
	local terr
	tab, terr = build_huff(bits, vals)
	if not tab then
		return nil, terr
	end
	info.ht[key] = tab
	return tab
end

local function parse_exif_orientation(body)
	if type(body) ~= "string" or #body < 14 or body:sub(1, 6) ~= "Exif\0\0" then
		return nil
	end
	local t = body:sub(7)
	local bo = t:sub(1, 2)
	local le
	if bo == "II" then
		le = true
	elseif bo == "MM" then
		le = false
	else
		return nil
	end
	local function r16(p)
		local a, b = t:byte(p, p + 1)
		if not b then
			return nil
		end
		return le and (a + b * 256) or (a * 256 + b)
	end
	local function r32(p)
		local a, b, c, d = t:byte(p, p + 3)
		if not d then
			return nil
		end
		if le then
			return ((d * 256 + c) * 256 + b) * 256 + a
		end
		return ((a * 256 + b) * 256 + c) * 256 + d
	end
	if r16(3) ~= 42 then
		return nil
	end
	local ifd = r32(5)
	if not ifd then
		return nil
	end
	local count = r16(ifd + 1)
	if not count or count > 512 then
		return nil
	end
	for i = 0, count - 1 do
		local e = ifd + 3 + i * 12
		if r16(e) == 0x0112 then
			local typ, n = r16(e + 2), r32(e + 4)
			if typ == 3 and n and n >= 1 then
				local v = r16(e + 8)
				if v and v >= 1 and v <= 8 then
					return v
				end
			end
		end
	end
	return nil
end

function M.parse(data)
	if type(data) ~= "string" or #data == 0 then
		return nil, "empty jpg data"
	end
	if #data > MAX_BYTES then
		return nil, "jpg too large"
	end
	if #data < 2 or data:byte(1) ~= 0xFF or data:byte(2) ~= 0xD8 then
		return nil, "not a jpg image"
	end

	local info = {
		width = nil,
		height = nil,
		comps = nil,
		hmax = 1,
		vmax = 1,
		qt = {},
		ht = {},
		scan = nil,
		scan_comps = nil,
		scans = {},
		progressive = false,
		restart = 0,
		adobe = nil,
		jfif = false,
		orientation = 1,
	}
	local n = #data
	local pos = 3
	local seen_sof, seen_sos = false, false

	local function seg(pos)
		if pos + 3 > n then
			return nil, nil, "truncated jpg segment"
		end
		local len = u16be(data, pos + 2)
		if not len or len < 2 or pos + 1 + len > n then
			return nil, nil, "truncated jpg segment"
		end
		return data:sub(pos + 4, pos + 1 + len), pos + 2 + len, nil
	end

	while pos <= n do
		if data:byte(pos) ~= 0xFF then
			return nil, "bad jpg marker"
		end
		local m = data:byte(pos + 1)
		if not m then
			return nil, "truncated jpg data"
		end
		while m == 0xFF do
			pos = pos + 1
			m = data:byte(pos + 1)
			if not m then
				return nil, "truncated jpg data"
			end
		end
		if m == 0x00 then
			return nil, "bad jpg marker"
		end
		if m == 0xD8 then
			pos = pos + 2
		elseif m == 0xD9 then
			break
		elseif m == 0x01 or (m >= 0xD0 and m <= 0xD7) then
			pos = pos + 2
		elseif m == 0xC0 or m == 0xC1 or m == 0xC2 then
			if seen_sof then
				return nil, "duplicate jpg frame"
			end
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			if #body < 6 then
				return nil, "bad jpg frame"
			end
			local prec = body:byte(1)
			local h, w = u16be(body, 2), u16be(body, 4)
			local nf = body:byte(6)
			if m == 0xC1 and prec ~= 8 then
				return nil, "unsupported jpg precision"
			end
			if prec ~= 8 then
				return nil, "unsupported jpg precision"
			end
			if not w or w < 1 or w > MAX_DIM or not h or h < 1 or h > MAX_DIM then
				return nil, "bad jpg dimensions"
			end
			if w * h * 4 > MAX_BYTES then
				return nil, "jpg too large"
			end
			if nf ~= 1 and nf ~= 3 then
				return nil, "unsupported jpg component count"
			end
			if #body < 6 + 3 * nf then
				return nil, "bad jpg frame"
			end
			local comps = {}
			for i = 1, nf do
				local o = 7 + (i - 1) * 3
				local cid, hv, tq = body:byte(o, o + 2)
				local hh, vv = mfloor(hv / 16), hv % 16
				if hh < 1 or hh > 4 or vv < 1 or vv > 4 or tq > 3 then
					return nil, "bad jpg component"
				end
				comps[i] = { id = cid, h = hh, v = vv, tq = tq }
				if hh > info.hmax then
					info.hmax = hh
				end
				if vv > info.vmax then
					info.vmax = vv
				end
			end
			info.width, info.height, info.comps = w, h, comps
			info.progressive = (m == 0xC2)
			seen_sof = true
		elseif m == 0xC4 then
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			local p = 1
			while p <= #body do
				if p + 17 > #body + 1 then
					return nil, "bad jpg huffman table"
				end
				local tc_th = body:byte(p)
				local tc, th = mfloor(tc_th / 16), tc_th % 16
				if tc > 1 or th > 3 then
					return nil, "bad jpg huffman table"
				end
				local bits = { body:byte(p + 1, p + 16) }
				local total = 0
				for i = 1, 16 do
					total = total + (bits[i] or 0)
				end
				if p + 16 + total > #body then
					return nil, "bad jpg huffman table"
				end
				local vals = {}
				for i = 1, total do
					vals[i] = body:byte(p + 16 + i)
				end
				local tab, terr = build_huff(bits, vals)
				if not tab then
					return nil, terr
				end
				info.ht[tc * 4 + th + 1] = tab
				p = p + 17 + total
			end
		elseif
			m == 0xC3
			or (m >= 0xC5 and m <= 0xCB)
			or (m >= 0xCD and m <= 0xCF)
			or m == 0xDE
			or m == 0xF1
			or m == 0xDC
		then
			return nil, "unsupported jpg frame type"
		elseif m == 0xD4 or m == 0xCC then
			local _, npos, err = seg(pos)
			if not _ then
				return nil, err
			end
			pos = npos
		elseif m == 0xDB then
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			local p = 1
			while p <= #body do
				local pq_tq = body:byte(p)
				local pq, tq = mfloor(pq_tq / 16), pq_tq % 16
				if tq > 3 or (pq ~= 0 and pq ~= 1) then
					return nil, "bad jpg quant table"
				end
				local step = pq == 0 and 1 or 2
				if p + 64 * step > #body then
					return nil, "bad jpg quant table"
				end
				local qt = {}
				if pq == 0 then
					for i = 1, 64 do
						qt[ZZ[i]] = body:byte(p + i)
					end
				else
					for i = 1, 64 do
						qt[ZZ[i]] = body:byte(p + 1 + (i - 1) * 2) * 256 + body:byte(p + 2 + (i - 1) * 2)
					end
				end
				info.qt[tq + 1] = qt
				p = p + 1 + 64 * step
			end
		elseif m == 0xDD then
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			if #body ~= 2 then
				return nil, "bad jpg restart interval"
			end
			info.restart = u16be(body, 1) or 0
		elseif m == 0xE0 then
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			if body:sub(1, 4) == "JFIF" then
				info.jfif = true
			end
		elseif m == 0xE1 then
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			local orient = parse_exif_orientation(body)
			if orient then
				info.orientation = orient
			end
		elseif m == 0xEE then
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			pos = npos
			if body:sub(1, 5) == "Adobe" and #body >= 12 then
				info.adobe = body:byte(12)
			end
		elseif m == 0xDA then
			if not seen_sof then
				return nil, "jpg scan before frame"
			end
			local body, npos, err = seg(pos)
			if not body then
				return nil, err
			end
			local ns = body:byte(1)
			if not ns or ns < 1 or ns > 4 or #body < 1 + 2 * ns + 3 then
				return nil, "bad jpg scan"
			end
			if ns > #info.comps then
				return nil, "bad jpg scan"
			end
			local scomps = {}
			for i = 1, ns do
				local cs, tdta = body:byte(2 + (i - 1) * 2, 3 + (i - 1) * 2)
				local td, ta = mfloor(tdta / 16), tdta % 16
				if td > 3 or ta > 3 then
					return nil, "bad jpg scan"
				end
				local fc = nil
				for _, c in ipairs(info.comps) do
					if c.id == cs then
						fc = c
						break
					end
				end
				if not fc then
					return nil, "bad jpg scan"
				end
				scomps[i] = { comp = fc, td = td, ta = ta, id = cs }
			end
			for _, sc in ipairs(scomps) do
				local terr
				sc.dctab, terr = get_huff(info, 0, sc.td)
				if not sc.dctab then
					return nil, tostring(terr)
				end
				sc.actab, terr = get_huff(info, 1, sc.ta)
				if not sc.actab then
					return nil, tostring(terr)
				end
				sc.qt = info.qt[sc.comp.tq + 1]
				if not sc.qt then
					return nil, "jpg missing quant table"
				end
			end
			local ss, se = body:byte(2 + 2 * ns, 3 + 2 * ns)
			local ax = body:byte(4 + 2 * ns) or 0
			local ah, al = mfloor(ax / 16), ax % 16
			if not info.progressive then
				if seen_sos then
					return nil, "multi-scan jpg not supported"
				end
				if ns ~= #info.comps or ss ~= 0 or se ~= 63 or ah ~= 0 or al ~= 0 then
					return nil, "bad jpg scan"
				end
			else
				if ss > se or se > 63 or ah > 13 or al > 13 then
					return nil, "bad jpg scan"
				end
				if ns > 1 and (ss ~= 0 or se ~= 0) then
					return nil, "bad jpg scan"
				end
			end
			local sp = npos
			local ep = nil
			local q = sp
			while q <= n do
				if data:byte(q) == 0xFF then
					local r = q + 1
					while r <= n and data:byte(r) == 0xFF do
						r = r + 1
					end
					local mb = data:byte(r)
					if not mb then
						break
					end
					if mb ~= 0x00 and not (mb >= 0xD0 and mb <= 0xD7) then
						ep = q - 1
						break
					end
					q = r + 1
				else
					q = q + 1
				end
			end
			if not ep then
				if n < 2 or data:byte(n - 1) ~= 0xFF or data:byte(n) ~= 0xD9 then
					return nil, "truncated jpg scan"
				end
				ep = n - 2
			end
			local scan = data:sub(sp, ep)
			info.scans[#info.scans + 1] = {
				comps = scomps,
				ss = ss,
				se = se,
				ah = ah,
				al = al,
				data = scan,
			}
			if not seen_sos then
				info.scan = scan
				info.scan_comps = scomps
			end
			info.scan_end = ep
			pos = ep + 1
			seen_sos = true
		else
			local _, npos, err = seg(pos)
			if not _ then
				return nil, err
			end
			pos = npos
		end
	end

	if not seen_sof then
		return nil, "jpg missing frame"
	end
	if not seen_sos then
		return nil, "jpg missing scan"
	end
	local comps = info.comps
	if #comps == 3 then
		local rgb = false
		if info.adobe == 0 then
			rgb = true
		elseif info.adobe == 2 then
			return nil, "unsupported jpg colour transform (YCCK)"
		elseif info.adobe == nil and not info.jfif then
			if comps[1].id == 0x52 and comps[2].id == 0x47 and comps[3].id == 0x42 then
				rgb = true
			end
		end
		info.colorspace = rgb and "rgb" or "ycbcr"
	else
		info.colorspace = "gray"
	end
	return info
end

function M.natural_size(data_or_info)
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = M.parse(info)
		if not inf2 then
			return nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, "not a parsed jpg image"
	end
	local o = info.orientation or 1
	if o >= 5 then
		return info.height, info.width
	end
	return info.width, info.height
end

local IDCT_M = nil
local function idct_matrix()
	if IDCT_M then
		return IDCT_M
	end
	local sq = math.sqrt(8)
	local tm = {}
	for x = 0, 7 do
		for u = 0, 7 do
			local a = u == 0 and (1 / sq) or 0.5
			tm[x * 8 + u + 1] = a * math.cos((2 * x + 1) * u * math.pi / 16)
		end
	end
	IDCT_M = tm
	return tm
end

local function idct_block(blk, out, o)
	local tm = idct_matrix()
	local ac = false
	for i = 2, 64 do
		if blk[i] ~= 0 then
			ac = true
			break
		end
	end
	if not ac then
		local v = mfloor(blk[1] / 8 + 0.5) + 128
		if v < 0 then
			v = 0
		elseif v > 255 then
			v = 255
		end
		for i = 1, 64 do
			out[o + i] = v
		end
		return
	end
	local tmp = {}
	for y = 0, 7 do
		local r = y * 8
		for x = 0, 7 do
			local s = 0
			local b = r
			local m = x * 8
			s = s
				+ tm[m + 1] * blk[b + 1]
				+ tm[m + 2] * blk[b + 2]
				+ tm[m + 3] * blk[b + 3]
				+ tm[m + 4] * blk[b + 4]
				+ tm[m + 5] * blk[b + 5]
				+ tm[m + 6] * blk[b + 6]
				+ tm[m + 7] * blk[b + 7]
				+ tm[m + 8] * blk[b + 8]
			tmp[r + x + 1] = s
		end
	end
	for x = 0, 7 do
		for y = 0, 7 do
			local s = 0
			local m = y * 8
			s = s
				+ tm[m + 1] * tmp[0 * 8 + x + 1]
				+ tm[m + 2] * tmp[1 * 8 + x + 1]
				+ tm[m + 3] * tmp[2 * 8 + x + 1]
				+ tm[m + 4] * tmp[3 * 8 + x + 1]
				+ tm[m + 5] * tmp[4 * 8 + x + 1]
				+ tm[m + 6] * tmp[5 * 8 + x + 1]
				+ tm[m + 7] * tmp[6 * 8 + x + 1]
				+ tm[m + 8] * tmp[7 * 8 + x + 1]
			local v = mfloor(s + 0.5) + 128
			if v < 0 then
				v = 0
			elseif v > 255 then
				v = 255
			end
			out[o + y * 8 + x + 1] = v
		end
	end
end

local function clamp8(v)
	v = mfloor(v + 0.5)
	if v < 0 then
		return 0
	end
	if v > 255 then
		return 255
	end
	return v
end

local function make_bitreader(scan)
	local sn = #scan
	local bp, bb, bn = 1, 0, 0
	local eof, pending = false, nil
	local function fill()
		while bn <= 16 do
			if bp > sn then
				eof = true
				return bn > 0
			end
			local b = scan:byte(bp)
			if b == 0xFF then
				local r = bp + 1
				while r <= sn and scan:byte(r) == 0xFF do
					r = r + 1
				end
				local m = scan:byte(r)
				if not m then
					eof = true
					return bn > 0
				end
				if m == 0x00 then
					bp = r + 1
					b = 0xFF
				else
					pending = m
					if m >= 0xD0 and m <= 0xD7 then
						return bn > 0
					end
					eof = true
					return bn > 0
				end
			else
				bp = bp + 1
			end
			bb = bb * 256 + b
			bn = bn + 8
		end
		return true
	end
	local function getbit()
		if bn == 0 then
			if not fill() then
				return nil
			end
			if bn == 0 then
				return nil
			end
		end
		bn = bn - 1
		local v = mfloor(bb / (2 ^ bn)) % 2
		bb = bb % (2 ^ bn)
		return v
	end
	local function getbits(nb)
		local v = 0
		for _ = 1, nb do
			local b = getbit()
			if b == nil then
				return nil
			end
			v = v * 2 + b
		end
		return v
	end
	local function huffsym(tab)
		local code = 0
		for len = 1, 16 do
			local b = getbit()
			if b == nil then
				return nil
			end
			code = code * 2 + b
			local row = tab.map[len]
			if row then
				local sym = row[code]
				if sym ~= nil then
					return sym
				end
			end
		end
		return nil
	end
	local function extend(s)
		if s == 0 then
			return 0
		end
		local v = getbits(s)
		if v == nil then
			return nil
		end
		if v < 2 ^ (s - 1) then
			return v - 2 ^ s + 1
		end
		return v
	end
	local function restart()
		bb, bn = 0, 0
		local q = bp
		while scan:byte(q) == 0xFF do
			q = q + 1
		end
		local m = scan:byte(q)
		if not m or m < 0xD0 or m > 0xD7 then
			return nil, "missing restart marker"
		end
		bp = q + 1
		pending, eof = nil, false
		return true
	end
	local function pending_marker()
		return pending
	end
	return {
		getbit = getbit,
		getbits = getbits,
		huffsym = huffsym,
		extend = extend,
		restart = restart,
		pending = pending_marker,
	}
end

local function apply_orientation(w, h, buf, o)
	if not o or o == 1 then
		return w, h, buf
	end
	local swap = o >= 5
	local nw, nh = swap and h or w, swap and w or h
	local rowlen = w * 4
	local out = {}
	local src = {}
	for y = 0, h - 1 do
		src[y] = buf:sub(y * rowlen + 1, (y + 1) * rowlen)
	end
	local lines = {}
	for dy = 0, nh - 1 do
		local parts = {}
		for dx = 0, nw - 1 do
			local sx, sy
			if o == 2 then
				sx, sy = w - 1 - dx, dy
			elseif o == 3 then
				sx, sy = w - 1 - dx, h - 1 - dy
			elseif o == 4 then
				sx, sy = dx, h - 1 - dy
			elseif o == 5 then
				sx, sy = dy, dx
			elseif o == 6 then
				sx, sy = dy, h - 1 - dx
			elseif o == 7 then
				sx, sy = w - 1 - dy, h - 1 - dx
			else
				sx, sy = w - 1 - dy, dx
			end
			local i = sx * 4 + 1
			parts[dx + 1] = src[sy]:sub(i, i + 3)
		end
		lines[dy + 1] = table.concat(parts)
	end
	out = table.concat(lines)
	return nw, nh, out
end

local function decode_progressive(info)
	local w, h = info.width, info.height
	local hmax, vmax = info.hmax, info.vmax
	local comps = info.comps
	local mcu_w = mfloor((w + hmax * 8 - 1) / (hmax * 8))
	local mcu_h = mfloor((h + vmax * 8 - 1) / (vmax * 8))

	local cst = {}
	for ci, c in ipairs(comps) do
		local qt = info.qt[c.tq + 1]
		if not qt then
			return nil, nil, nil, "jpg missing quant table"
		end
		cst[ci] = {
			c = c,
			bw = mcu_w * c.h,
			bh = mcu_h * c.v,
			actw = mfloor((w * c.h + hmax * 8 - 1) / (hmax * 8)),
			acth = mfloor((h * c.v + vmax * 8 - 1) / (vmax * 8)),
			qt = qt,
			coef = {},
		}
	end

	local ri = info.restart or 0

	for _, scan in ipairs(info.scans) do
		local rd = make_bitreader(scan.data)
		local scs = {}
		for si, s in ipairs(scan.comps) do
			local ci
			for j, cc in ipairs(comps) do
				if cc.id == s.id then
					ci = j
					break
				end
			end
			if not ci then
				return nil, nil, nil, "bad jpg scan"
			end
			local dctab = s.dctab
			local actab = s.actab
			if not dctab then
				local derr
				dctab, derr = get_huff(info, 0, s.td)
				if not dctab then
					return nil, nil, nil, tostring(derr)
				end
			end
			if not actab then
				local derr
				actab, derr = get_huff(info, 1, s.ta)
				if not actab then
					return nil, nil, nil, tostring(derr)
				end
			end
			if s.qt then
				cst[ci].qt = s.qt
			end
			scs[si] = { st = cst[ci], dctab = dctab, actab = actab, pred = 0 }
		end
		local ss, se, ahh, all = scan.ss, scan.se, scan.ah, scan.al
		local kss, kse = ss + 1, se + 1
		local p1 = 1 << all
		local eobrun = 0

		local function decode_block(sc, off)
			local coef = sc.st.coef
			if ahh == 0 then
				if ss == 0 then
					local s = rd.huffsym(sc.dctab)
					if s == nil then
						return nil, "bad jpg huffman code"
					end
					if s > 11 then
						return nil, "bad jpg dc size"
					end
					local diff = rd.extend(s)
					if diff == nil then
						return nil, "truncated jpg scan"
					end
					sc.pred = sc.pred + diff
					coef[off + 1] = sc.pred * (1 << all)
					return true
				end
				if eobrun > 0 then
					eobrun = eobrun - 1
					return true
				end
				local k = kss
				while k <= kse do
					local rs = rd.huffsym(sc.actab)
					if rs == nil then
						return nil, "bad jpg huffman code"
					end
					local r, sw = rs // 16, rs % 16
					if sw == 0 then
						if r ~= 15 then
							local e = 1 << r
							if r > 0 then
								local x = rd.getbits(r)
								if x == nil then
									return nil, "truncated jpg scan"
								end
								e = e + x
							end
							eobrun = e - 1
							break
						end
						k = k + 16
					else
						k = k + r
						if k > kse then
							return nil, "bad jpg ac run"
						end
						local v = rd.extend(sw)
						if v == nil then
							return nil, "truncated jpg scan"
						end
						coef[off + ZZ[k]] = v * (1 << all)
						k = k + 1
					end
				end
				return true
			end

			local function refine_at(ci)
				local b = rd.getbit()
				if b == nil then
					return nil
				end
				if b == 1 then
					local v = coef[ci] or 0
					if (v & p1) == 0 then
						if v >= 0 then
							coef[ci] = v + p1
						else
							coef[ci] = v - p1
						end
					end
				end
				return true
			end
			if ss == 0 then
				local b = rd.getbit()
				if b == nil then
					return nil, "truncated jpg scan"
				end
				if b == 1 then
					coef[off + 1] = (coef[off + 1] or 0) | p1
				end
				return true
			end
			if eobrun > 0 then
				local k = kss
				while k <= kse do
					local ci = off + ZZ[k]
					if (coef[ci] or 0) ~= 0 then
						if not refine_at(ci) then
							return nil, "truncated jpg scan"
						end
					end
					k = k + 1
				end
				eobrun = eobrun - 1
				return true
			end
			local k = kss
			while k <= kse do
				local rs = rd.huffsym(sc.actab)
				if rs == nil then
					return nil, "bad jpg huffman code"
				end
				local r, sw = rs // 16, rs % 16
				local newval
				if sw ~= 0 then
					if sw ~= 1 then
						return nil, "bad jpg ac size"
					end
					local b = rd.getbit()
					if b == nil then
						return nil, "truncated jpg scan"
					end
					newval = (b == 1) and p1 or -p1
				elseif r ~= 15 then
					local e = 1 << r
					if r > 0 then
						local x = rd.getbits(r)
						if x == nil then
							return nil, "truncated jpg scan"
						end
						e = e + x
					end
					eobrun = e
					break
				end
				while k <= kse do
					local ci = off + ZZ[k]
					if (coef[ci] or 0) ~= 0 then
						if not refine_at(ci) then
							return nil, "truncated jpg scan"
						end
					else
						r = r - 1
						if r < 0 then
							break
						end
					end
					k = k + 1
				end
				if newval then
					if k > kse then
						return nil, "bad jpg ac run"
					end
					coef[off + ZZ[k]] = newval
				end
				k = k + 1
			end
			if eobrun > 0 then
				while k <= kse do
					local ci = off + ZZ[k]
					if (coef[ci] or 0) ~= 0 then
						if not refine_at(ci) then
							return nil, "truncated jpg scan"
						end
					end
					k = k + 1
				end
				eobrun = eobrun - 1
			end
			return true
		end

		local unit = 0
		local function do_restart()
			local ok, err = rd.restart()
			if not ok then
				return nil, err
			end
			for _, sc in ipairs(scs) do
				sc.pred = 0
			end
			eobrun = 0
			return true
		end

		if #scs > 1 then
			for my = 0, mcu_h - 1 do
				for mx = 0, mcu_w - 1 do
					if ri > 0 and unit > 0 and unit % ri == 0 then
						local ok, err = do_restart()
						if not ok then
							return nil, nil, nil, err
						end
					end
					for _, sc in ipairs(scs) do
						local st = sc.st
						for by = 0, st.c.v - 1 do
							for bx = 0, st.c.h - 1 do
								local off = ((my * st.c.v + by) * st.bw + (mx * st.c.h + bx)) * 64
								local ok, err = decode_block(sc, off)
								if not ok then
									return nil, nil, nil, err
								end
							end
						end
					end
					unit = unit + 1
				end
			end
		else
			local sc = scs[1]
			local st = sc.st
			for by = 0, st.acth - 1 do
				for bx = 0, st.actw - 1 do
					if ri > 0 and unit > 0 and unit % ri == 0 then
						local ok, err = do_restart()
						if not ok then
							return nil, nil, nil, err
						end
					end
					local ok, err = decode_block(sc, (by * st.bw + bx) * 64)
					if not ok then
						return nil, nil, nil, err
					end
					unit = unit + 1
				end
			end
		end
	end

	local bands = {}
	local px = {}
	for ci, st in ipairs(cst) do
		local b = {}
		local coef = st.coef
		for by = 0, st.bh - 1 do
			for bx = 0, st.bw - 1 do
				local off = (by * st.bw + bx) * 64
				for i = 1, 64 do
					px[i] = (coef[off + i] or 0) * st.qt[i]
				end
				idct_block(px, px, 0)
				local ox, oy = bx * 8, by * 8
				for y = 1, 8 do
					local dst = b[oy + y]
					if not dst then
						dst = {}
						b[oy + y] = dst
					end
					local src = (y - 1) * 8
					for x = 1, 8 do
						dst[ox + x] = px[src + x]
					end
				end
			end
		end
		bands[ci] = { buf = b }
		st.coef = nil
	end

	local out_rows = {}
	if #comps == 1 then
		local st = cst[1]
		for ry = 0, h - 1 do
			local src = bands[1].buf[mfloor(ry * st.c.v / vmax) + 1]
			local parts = {}
			for x = 0, w - 1 do
				local v = src[mfloor(x * st.c.h / hmax) + 1] or 0
				parts[x + 1] = string.char(v, v, v, 255)
			end
			out_rows[ry + 1] = table.concat(parts)
		end
	else
		local yst, cbst, crst = cst[1], cst[2], cst[3]
		local rgb = info.colorspace == "rgb"
		for ry = 0, h - 1 do
			local yb = bands[1].buf[mfloor(ry * yst.c.v / vmax) + 1]
			local cb = bands[2].buf[mfloor(ry * cbst.c.v / vmax) + 1]
			local cr = bands[3].buf[mfloor(ry * crst.c.v / vmax) + 1]
			local parts = {}
			for x = 0, w - 1 do
				local yv = yb[mfloor(x * yst.c.h / hmax) + 1] or 0
				local cbx = mfloor(x * cbst.c.h / hmax) + 1
				local crx = mfloor(x * crst.c.h / hmax) + 1
				if rgb then
					parts[x + 1] = string.char(yv, cb[cbx] or 0, cr[crx] or 0, 255)
				else
					local cbv = (cb[cbx] or 128) - 128
					local crv = (cr[crx] or 128) - 128
					parts[x + 1] = string.char(
						clamp8(yv + 1.40200 * crv),
						clamp8(yv - 0.344136 * cbv - 0.714136 * crv),
						clamp8(yv + 1.77200 * cbv),
						255
					)
				end
			end
			out_rows[ry + 1] = table.concat(parts)
		end
	end
	local buf = table.concat(out_rows)
	if info.orientation and info.orientation ~= 1 then
		return apply_orientation(w, h, buf, info.orientation)
	end
	return w, h, buf
end

function M.decode(data_or_info, opts)
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = M.parse(info)
		if not inf2 then
			return nil, nil, nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width or not info.scan then
		return nil, nil, nil, "not a parsed jpg image"
	end
	if info.progressive then
		return decode_progressive(info)
	end

	local w, h = info.width, info.height
	local hmax, vmax = info.hmax, info.vmax
	local scomps = info.scan_comps
	local comps = info.comps
	local rd = make_bitreader(info.scan)

	local cindex = {}
	for i, c in ipairs(comps) do
		cindex[c.id] = i
	end
	local scan_ci = {}
	for si, sc in ipairs(scomps) do
		local ci = cindex[sc.id]
		if not ci then
			return nil, nil, nil, "bad jpg scan"
		end
		scan_ci[si] = ci
		sc.dctab = sc.dctab or get_huff(info, 0, sc.td)
		sc.actab = sc.actab or get_huff(info, 1, sc.ta)
		sc.qt = sc.qt or info.qt[sc.comp.tq + 1]
		if not sc.dctab or not sc.actab or not sc.qt then
			return nil, nil, nil, "jpg missing table"
		end
		sc.pred = 0
	end

	local function decode_block(sc, coef)
		for i = 1, 64 do
			coef[i] = 0
		end
		local s = rd.huffsym(sc.dctab)
		if s == nil then
			return nil, "bad jpg huffman code"
		end
		if s > 11 then
			return nil, "bad jpg dc size"
		end
		local diff = rd.extend(s)
		if diff == nil then
			return nil, "truncated jpg scan"
		end
		sc.pred = sc.pred + diff
		coef[1] = sc.pred * sc.qt[1]
		local k = 2
		while k <= 64 do
			local rs = rd.huffsym(sc.actab)
			if rs == nil then
				return nil, "bad jpg huffman code"
			end
			if rs == 0x00 then
				break
			end
			if rs == 0xF0 then
				k = k + 16
			else
				local r, sz = mfloor(rs / 16), rs % 16
				if sz == 0 or sz > 10 then
					return nil, "bad jpg ac size"
				end
				k = k + r
				if k > 64 then
					return nil, "bad jpg ac run"
				end
				local v = rd.extend(sz)
				if v == nil then
					return nil, "truncated jpg scan"
				end
				coef[ZZ[k]] = v * sc.qt[ZZ[k]]
				k = k + 1
			end
		end
		if k > 64 + 16 then
			return nil, "bad jpg block"
		end
		return true
	end

	local mcu_w = mfloor((w + hmax * 8 - 1) / (hmax * 8))
	local mcu_h = mfloor((h + vmax * 8 - 1) / (vmax * 8))
	local total_mcu = mcu_w * mcu_h
	local ri = info.restart or 0

	local bands = {}
	for ci, c in ipairs(comps) do
		local bw, bh = c.h * 8, c.v * 8
		local b = {}
		for y = 1, bh do
			local row = {}
			for x = 1, mcu_w * bw do
				row[x] = 0
			end
			b[y] = row
		end
		bands[ci] = { buf = b }
	end

	local rgb = info.colorspace == "rgb"
	local out_rows = {}
	local coef = {}
	local px = {}
	local mcu_count = 0
	for my = 0, mcu_h - 1 do
		for mx = 0, mcu_w - 1 do
			if ri > 0 and mcu_count > 0 and mcu_count % ri == 0 then
				local ok, err = rd.restart()
				if not ok then
					return nil, nil, nil, err
				end
				for _, sc in ipairs(scomps) do
					sc.pred = 0
				end
			end
			for si, sc in ipairs(scomps) do
				local band = bands[scan_ci[si]]
				local ch, cv = sc.comp.h, sc.comp.v
				for by = 0, cv - 1 do
					for bx = 0, ch - 1 do
						local ok, err = decode_block(sc, coef)
						if not ok then
							return nil, nil, nil, err
						end
						idct_block(coef, px, 0)
						local ox = mx * ch * 8 + bx * 8
						local oy = by * 8
						for y = 1, 8 do
							local dst = band.buf[oy + y]
							local src = (y - 1) * 8
							for x = 1, 8 do
								dst[ox + x] = px[src + x]
							end
						end
					end
				end
			end
			mcu_count = mcu_count + 1
			if mcu_count > total_mcu then
				return nil, nil, nil, "bad jpg scan data"
			end
		end
		local base_y = my * vmax * 8
		for ry = 0, vmax * 8 - 1 do
			local yy = base_y + ry
			if yy >= h then
				break
			end
			local parts = {}
			if #comps == 1 then
				local c = comps[1]
				local src = bands[1].buf[mfloor(ry * c.v / vmax) + 1] or {}
				for x = 0, w - 1 do
					local v = src[mfloor(x * c.h / hmax) + 1] or 0
					parts[x + 1] = string.char(v, v, v, 255)
				end
			else
				local c1, c2, c3 = comps[1], comps[2], comps[3]
				local b1, b2, b3 = bands[1], bands[2], bands[3]
				local r1 = b1.buf[mfloor(ry * c1.v / vmax) + 1] or {}
				local r2 = b2.buf[mfloor(ry * c2.v / vmax) + 1] or {}
				local r3 = b3.buf[mfloor(ry * c3.v / vmax) + 1] or {}
				for x = 0, w - 1 do
					local v1 = r1[mfloor(x * c1.h / hmax) + 1] or 0
					local v2 = r2[mfloor(x * c2.h / hmax) + 1] or 0
					local v3 = r3[mfloor(x * c3.h / hmax) + 1] or 0
					if rgb then
						parts[x + 1] = string.char(v1, v2, v3, 255)
					else
						local cbv, crv = v2 - 128, v3 - 128
						parts[x + 1] = string.char(
							clamp8(v1 + 1.40200 * crv),
							clamp8(v1 - 0.344136 * cbv - 0.714136 * crv),
							clamp8(v1 + 1.77200 * cbv),
							255
						)
					end
				end
			end
			out_rows[yy + 1] = table.concat(parts)
		end
	end
	if mcu_count ~= total_mcu then
		return nil, nil, nil, "truncated jpg scan"
	end
	local buf = table.concat(out_rows)
	if info.orientation and info.orientation ~= 1 then
		return apply_orientation(w, h, buf, info.orientation)
	end
	return w, h, buf
end

M.render = M.decode

return M
