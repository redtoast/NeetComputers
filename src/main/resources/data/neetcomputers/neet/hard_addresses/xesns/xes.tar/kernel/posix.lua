local K = ...

local V, P, R = K.vfs, K.path, K.rawfs
local sys_ = K.sys
local argerr, str, int = K.argcheck.err, K.argcheck.str, K.argcheck.int

K.sysctl = { debug = false }
K.hostname = "xes"

local Pm = K.perm
local Cr = K.crypto
local function o(s) return tonumber(s, 8) end
K.sha256 = Cr.sha256

K.sec = { see_other_uids = 1, unprivileged_read_msgbuf = 0 }

local CONF_DEFAULT = {
    min_length = 8,
    max_length = 128,
    fail_threshold = 5,
    fail_lockout = 30,
    fail_lockout_max = 900,
    fail_delay = 1,
    hash_iterations = 5000,
    su_wheel_only = 1,
}
local function loginConf()
    local conf = {}
    for k, v in pairs(CONF_DEFAULT) do conf[k] = v end
    local data = V.readFile(K.rootdir .. "etc/login.conf")
    if data then
        for line in data:gmatch("[^\n]+") do
            local k, v = line:match("^%s*([%w_]+)%s*=%s*(%d+)")
            if k and CONF_DEFAULT[k] ~= nil then conf[k] = tonumber(v) end
        end
    end
    conf.min_length = math.max(conf.min_length, 6)
    conf.max_length = math.min(math.max(conf.max_length, conf.min_length), 1024)
    conf.fail_threshold = math.max(conf.fail_threshold, 1)
    conf.fail_lockout = math.max(conf.fail_lockout, 1)
    conf.fail_lockout_max = math.max(conf.fail_lockout_max, conf.fail_lockout)
    conf.hash_iterations = math.min(math.max(conf.hash_iterations, 1000), 1000000)
    return conf
end
K.loginConf = loginConf

local function ctxString()
    local p = K.current
    if not p then return "kernel" end
    return string.format("uid=%d pid=%d tty=%s", p.uid, p.pid, p.tty and p.tty.name or "-")
end

function K.authlog(fmt, ...)
    local line = string.format("%s %s\n", K.dateString(), string.format(fmt, ...))
    local full = K.rootdir .. "var/log/auth.log"
    if V.stat(K.rootdir .. "var/log") ~= "dir" then
        if V.stat(K.rootdir .. "var") ~= "dir" then V.mkdir(nil, K.rootdir .. "var") end
        V.mkdir(nil, K.rootdir .. "var/log")
    end
    local h = V.open(nil, full, "a", o "640")
    if not h then return end
    local size = h:seek("end") or 0
    h:write(line)
    h:close()
    if size > 65536 then
        local all = V.readFile(full) or ""
        local cut = all:find("\n", #all - 32768, true)
        if cut then V.writeFile(full, all:sub(cut + 1), o "640") end
    end
end

local function readDb(path)
    local data = V.readFile(K.rootdir:sub(1, -2) .. path) or ""
    local rows = {}
    for line in data:gmatch("[^\n]+") do
        if not line:match("^%s*#") then
            local f = K.split(line, ":", true)
            rows[#rows + 1] = f
        end
    end
    return rows
end

local function userFromRow(f)
    if #f ~= 7 or f[1] == nil or f[1] == "" then return nil end
    local uid, gid = tonumber(f[3]), tonumber(f[4])
    if not uid or not gid then return nil end
    return {
        name = f[1],
        uid = uid,
        gid = gid,
        gecos = f[5] or "",
        home = f[6] or "/",
        shell = f[7] or "/bin/sh"
    }
end

local function getpwnam(name)
    for _, f in ipairs(readDb("/etc/passwd")) do
        if f[1] == name then
            local u = userFromRow(f)
            if u then return u end
        end
    end
end

local function getpwuid(uid)
    for _, f in ipairs(readDb("/etc/passwd")) do
        local u = userFromRow(f)
        if u and u.uid == uid then return u end
    end
end

local function readGroups()
    local out = {}
    for _, f in ipairs(readDb("/etc/group")) do
        out[#out + 1] = {
            name = f[1],
            gid = tonumber(f[3]) or -1,
            members = (f[4] and f[4] ~= "") and K.split(f[4], ",", true) or {}
        }
    end
    return out
end

local function groupsFor(name, gid)
    local out = {}
    for _, g in ipairs(readGroups()) do
        if g.gid ~= gid then
            for _, m in ipairs(g.members) do
                if m == name then
                    out[#out + 1] = g.gid
                    break
                end
            end
        end
    end
    return out
end

local LOCK = "*LOCKED*"

local function hashState(stored)
    if stored == nil then return nil end
    if stored == "" or stored == "!" then return "unset" end
    if stored == "*" then return "disabled" end
    if stored:sub(1, #LOCK) == LOCK then return "locked" end
    if stored:match("^%$xes1%$%d+%$%x+%$%x+$") or stored:match("^%x+%$%x+$") then return "ok" end
    return "disabled"
end

local function newHash(pass, conf)
    local salt = Cr.random_bytes(16)
    local dk = Cr.pbkdf2(pass, salt, conf.hash_iterations, 32)
    return string.format("$xes1$%d$%s$%s", conf.hash_iterations, Cr.tohex(salt), Cr.tohex(dk))
end

local function checkHash(pass, stored)
    local iters, salthex, hashhex = stored:match("^%$xes1%$(%d+)%$(%x+)%$(%x+)$")
    if iters then
        iters = tonumber(iters)
        local salt = Cr.fromhex(salthex)
        if not salt or iters < 1 or iters > 5000000 then return false end
        local dk = Cr.pbkdf2(pass, salt, iters, #hashhex // 2)
        return Cr.ctequal(Cr.tohex(dk), hashhex:lower()), false
    end
    local salt, h = stored:match("^(%x+)%$(%x+)$")
    if salt then
        local x = pass
        for _ = 1, 64 do x = Cr.sha256(salt .. x) end
        return Cr.ctequal(x, h:lower()), true
    end
    return false, false
end

local COMMON = { "password", "passw0rd", "qwerty", "letmein", "welcome", "iloveyou", "123456",
    "000000", "111111", "abcdef", "xesns" }

local function policyCheck(name, pass, old, conf)
    if type(pass) ~= "string" then return nil, "invalid password" end
    if pass:find("%c") then return nil, "password may not contain control characters" end
    if #pass < conf.min_length then
        return nil, string.format("password too short (minimum %d characters)", conf.min_length)
    end
    if #pass > conf.max_length then
        return nil, string.format("password too long (maximum %d characters)", conf.max_length)
    end
    local low = pass:lower()
    if name and #name >= 3 then
        local ln = name:lower()
        if low:find(ln, 1, true) or low:find(ln:reverse(), 1, true) then
            return nil, "password may not contain the account name"
        end
    end
    for _, w in ipairs(COMMON) do
        if low:find(w, 1, true) then return nil, "password is too easy to guess" end
    end
    local seen, distinct = {}, 0
    for c in pass:gmatch(".") do if not seen[c] then
            seen[c] = true; distinct = distinct + 1
        end end
    if distinct < 5 then return nil, "password has too few different characters" end
    if old and pass == old then return nil, "new password must differ from the old one" end
    return true
end

local MASTER = "/etc/master.passwd"

local function writeMaster(text)
    local path = K.rootdir:sub(1, -2) .. MASTER
    local old = V.readFile(path)
    if old and #old > 0 then V.writeFile(path .. ".old", old, o "600") end
    local ok, err = V.writeFile(path, text)
    if not ok then return nil, err end
    if V.readFile(path) ~= text then
        if old then V.writeFile(path, old) end
        return nil, "could not write " .. MASTER
    end
    return true
end

local function updateMaster(name, fn)
    return K.sys(function()
        local out, done = {}, false
        for _, f in ipairs(readDb(MASTER)) do
            if f[1] == name then
                done = true
                local r, e = fn(f)
                if not r then return nil, e end
            end
            out[#out + 1] = table.concat(f, ":")
        end
        if not done then return nil, "no such user" end
        return writeMaster(table.concat(out, "\n") .. "\n")
    end)()
end

local function masterField(name)
    for _, f in ipairs(readDb(MASTER)) do if f[1] == name then return f[2] or "" end end
end

local failures = {}

local function verify(name, pass, via)
    local conf = loginConf()
    local now = K.now()
    pass = type(pass) == "string" and pass or ""
    local u = type(name) == "string" and getpwnam(name) or nil

    local fkey = name .. "/" .. ((via == "su" or via == "doas") and via or "login")
    local f = u and failures[fkey]
    if f and now - f.last > conf.fail_lockout_max then
        failures[fkey] = nil; f = nil
    end
    if f and f.lockedUntil and now < f.lockedUntil then
        K.authlog("LOCKED %s via=%s %s (%d s left)", name, via, ctxString(), math.ceil(f.lockedUntil - now))
        return nil, "locked"
    end

    local good, legacy = false, false
    local stored = u and masterField(name)
    if stored and hashState(stored) == "ok" then
        good, legacy = checkHash(pass, stored)
    else
        Cr.pbkdf2(pass, "xes-no-such-user", conf.hash_iterations, 32)
    end

    if good then
        K.sys(function() failures[fkey] = nil end)()
        K.authlog("OK %s via=%s %s", name, via, ctxString())
        if legacy then
            local nh = newHash(pass, conf)
            updateMaster(name, function(row)
                row[2] = nh
                return true
            end)
        end
        return u
    end

    K.sys(function()
        if u then
            local e = failures[fkey] or { n = 0 }
            e.n = e.n + 1
            e.last = K.now()
            if e.n >= conf.fail_threshold then
                local lock = math.min(conf.fail_lockout * 2 ^ (e.n - conf.fail_threshold), conf.fail_lockout_max)
                e.lockedUntil = e.last + lock
            end
            failures[fkey] = e
        end
    end)()
    K.authlog("FAILED %s via=%s %s", u and name or "<no such user>", via, ctxString())
    local me = K.current
    if me and conf.fail_delay > 0 then pcall(K.block, me, nil, K.now() + conf.fail_delay) end
    return nil, "invalid"
end

local function soft(f, ...)
    local ok, a, b = pcall(f, ...)
    if not ok then return nil, (tostring(a):gsub("^[^:]*:%d+:%s*", "")) end
    return a, b
end

local function rp(path)
    if type(path) ~= "string" then argerr(1, "path", "string", path) end
    return soft(P.resolve, path, K.current.cwd, 2)
end

local function isExecFile(full)
    return V.isFile(nil, full) or V.stat(full) == "link"
end

local function findProgram(name, penv)
    if name:find("/", 1, true) or name:find(":", 1, true) then
        local full = rp(name)
        return full and isExecFile(full) and full or nil
    end
    for dir in (penv.PATH or "/bin:/usr/bin:/sbin:/usr/sbin"):gmatch("[^:]+") do
        local full = soft(P.resolve, dir .. "/" .. name, K.rootdir, 2)
        if full and isExecFile(full) then return full end
    end
end

local function checkArgs(args)
    if args == nil then return {} end
    if type(args) ~= "table" then argerr(2, "args", "table", args) end
    local o = {}
    for i, v in ipairs(args) do o[i] = tostring(v) end
    o.n = #o
    return o
end

function K.readline(t, opts)
    opts = opts or {}
    local p = K.current
    local cols, rows = t.cols, t.rows
    local line, pos, lastlen = "", 0, 0
    local sx, sy = t.cx, t.cy
    if sx < 1 then sx = 1 end
    local ctrl = false
    local hist, hi, saved = opts.history, nil, ""
    local tabs = 0

    local function draw()
        local show = opts.noecho and "" or line
        local n = math.max(#show, lastlen)
        local needrows = (sx - 1 + #show) // cols + 1
        local over = sy + needrows - 1 - rows
        if over > 0 then
            t:scroll(over, p.bg); sy = sy - over
        end
        local text = show .. string.rep(" ", n - #show)
        lastlen = #show
        local i, x, y = 1, sx, sy
        while i <= #text do
            local seg = text:sub(i, i + (cols - x))
            t.cx, t.cy = x, y
            t:write(seg, p.fg, p.bg)
            i = i + #seg
            y = y + 1
            x = 1
        end
        local off = sx - 1 + (opts.noecho and 0 or pos)
        t.cx, t.cy = off % cols + 1, sy + off // cols
    end

    local function finish()
        local off = sx - 1 + (opts.noecho and 0 or #line)
        t.cx, t.cy = off % cols + 1, math.min(rows, sy + off // cols)
        t:printText("\n", p.fg, p.bg, false)
    end

    draw()
    while true do
        local name, a = K.evpull(p)
        if name == "char" then
            line = line:sub(1, pos) .. a .. line:sub(pos + 1)
            pos = pos + #a
            tabs = 0
            draw()
        elseif name == "key" then
            if a == "leftCtrl" or a == "rightCtrl" then
                ctrl = true
            elseif ctrl then
                if a == "d" then
                    if line == "" then
                        finish()
                        return nil
                    end
                    line = line:sub(1, pos) .. line:sub(pos + 2)
                elseif a == "u" then
                    line = line:sub(pos + 1); pos = 0
                elseif a == "k" then
                    line = line:sub(1, pos)
                elseif a == "w" then
                    local before = line:sub(1, pos):gsub("%s*%S*$", "")
                    line = before .. line:sub(pos + 1); pos = #before
                elseif a == "a" then
                    pos = 0
                elseif a == "e" then
                    pos = #line
                elseif a == "l" and opts.drawPrompt then
                    t:clear(p.bg); t.cx, t.cy = 1, 1
                    opts.drawPrompt()
                    sx, sy, lastlen = t.cx, t.cy, 0
                end
                draw()
            elseif a == "enter" then
                finish()
                return line
            elseif a == "backspace" then
                if pos > 0 then
                    line = line:sub(1, pos - 1) .. line:sub(pos + 1); pos = pos - 1
                end
                draw()
            elseif a == "delete" then
                line = line:sub(1, pos) .. line:sub(pos + 2)
                draw()
            elseif a == "left" then
                if pos > 0 then pos = pos - 1 end
                draw()
            elseif a == "right" then
                if pos < #line then pos = pos + 1 end
                draw()
            elseif a == "home" then
                pos = 0
                draw()
            elseif a == "end" then
                pos = #line
                draw()
            elseif (a == "up" or a == "down") and hist and #hist > 0 then
                if a == "up" then
                    if not hi then
                        saved = line; hi = #hist + 1
                    end
                    if hi > 1 then hi = hi - 1 end
                    line = hist[hi]
                elseif hi then
                    hi = hi + 1
                    line = hi > #hist and saved or hist[hi]
                    if hi > #hist then hi = nil end
                end
                pos = #line
                draw()
            elseif a == "tab" and opts.complete then
                local start, cands = opts.complete(line, pos)
                if start and cands and #cands > 0 then
                    local word = line:sub(start, pos)
                    local common = cands[1]
                    for _, c in ipairs(cands) do
                        while c:sub(1, #common) ~= common do common = common:sub(1, -2) end
                    end
                    if #common > #word or #cands == 1 then
                        local ins = common .. ((#cands == 1 and not common:match("/$")) and " " or "")
                        line = line:sub(1, start - 1) .. ins .. line:sub(pos + 1)
                        pos = start - 1 + #ins
                        tabs = 0
                    else
                        tabs = tabs + 1
                        if tabs >= 2 then
                            finish()
                            table.sort(cands)
                            local w = 0
                            for _, c in ipairs(cands) do w = math.max(w, #c) end
                            local per = math.max(1, cols // (w + 2))
                            for i = 1, #cands, per do
                                local row = {}
                                for j = i, math.min(#cands, i + per - 1) do row[#row + 1] = K.pad(cands[j], w + 2) end
                                t:printText(table.concat(row), p.fg, p.bg, true)
                            end
                            if opts.drawPrompt then opts.drawPrompt() end
                            sx, sy, lastlen = t.cx, t.cy, 0
                            tabs = 0
                        end
                    end
                end
                draw()
            end
        elseif name == "key_up" then
            if a == "leftCtrl" or a == "rightCtrl" then ctrl = false end
        elseif name == "terminate" then
            t:printText("^C\n", p.fg, p.bg, false)
            return nil, "interrupted"
        end
    end
end

function K.ttyread(t, fmt)
    local p = K.current
    fmt = fmt or "l"
    local function more()
        local l, e = K.readline(t, { history = nil })
        if l == nil then return nil, e end
        p.inbuf = (p.inbuf or "") .. l .. "\n"
        return true
    end
    if fmt == "l" then
        if not p.inbuf or p.inbuf == "" then
            local ok, e = more()
            if not ok then return nil, e end
        end
        local nl = p.inbuf:find("\n", 1, true)
        local line = p.inbuf:sub(1, nl - 1)
        p.inbuf = p.inbuf:sub(nl + 1)
        return line
    elseif fmt == "a" then
        local parts = { p.inbuf or "" }
        p.inbuf = ""
        while true do
            local l = K.readline(t, {})
            if l == nil then break end
            parts[#parts + 1] = l .. "\n"
        end
        return table.concat(parts)
    elseif type(fmt) == "number" then
        if not p.inbuf or p.inbuf == "" then
            local ok, e = more()
            if not ok then return nil, e end
        end
        local s = p.inbuf:sub(1, fmt)
        p.inbuf = p.inbuf:sub(#s + 1)
        return s
    end
    return nil, "invalid format"
end

local function globToLua(g)
    local out = { "^" }
    local i = 1
    while i <= #g do
        local c = g:sub(i, i)
        if c == "*" then
            out[#out + 1] = ".*"
        elseif c == "?" then
            out[#out + 1] = "."
        elseif c == "[" then
            local k = i + 1
            local neg = g:sub(k, k) == "!"
            if neg then k = k + 1 end
            if g:sub(k, k) == "]" then k = k + 1 end
            local j = g:find("]", k, true)
            if j then
                local content = g:sub(i + (neg and 2 or 1), j - 1)
                content = content:gsub("%%", "%%%%")
                local first = content:sub(1, 1)
                if first == "]" or (first == "^" and not neg) or first == "-" then
                    content = "%" .. content
                end
                if #content > 1 and content:sub(-1) == "-" then
                    content = content:sub(1, -2) .. "%-"
                end
                out[#out + 1] = "[" .. (neg and "^" or "") .. content .. "]"
                i = j
            else
                out[#out + 1] = "%["
            end
        else
            out[#out + 1] = c:gsub("%p", "%%%0")
        end
        i = i + 1
    end
    out[#out + 1] = "$"
    return table.concat(out)
end

local function hasMagic(s) return s:find("[%*%?%[]") ~= nil end

local function glob(pattern)
    if not hasMagic(pattern) then return { pattern } end
    local p = K.current
    local abs = pattern:sub(1, 1) == "/"
    local segs = {}
    for s in pattern:gmatch("[^/]+") do segs[#segs + 1] = s end
    local results = { abs and "/" or "" }
    for si, seg in ipairs(segs) do
        local nextr = {}
        for _, base in ipairs(results) do
            if hasMagic(seg) then
                local dirpath = base == "" and "." or base
                local full = soft(P.resolve, dirpath, p.cwd, 2)
                local names = full and V.list(p, full) or {}
                table.sort(names)
                local pat = globToLua(seg)
                for _, n in ipairs(names) do
                    if (n:sub(1, 1) ~= "." or seg:sub(1, 1) == ".") and n:match(pat) then
                        nextr[#nextr + 1] = base .. n .. (si < #segs and "/" or "")
                    end
                end
            else
                nextr[#nextr + 1] = base .. seg .. (si < #segs and "/" or "")
            end
        end
        results = nextr
    end
    local out = {}
    for _, r in ipairs(results) do
        local full = soft(P.resolve, r, p.cwd, 2)
        if full and V.stat(full) then out[#out + 1] = r end
    end
    return out
end

local posix = {}

function posix.getpid() return K.current.pid end

function posix.getppid() return K.current.ppid end

function posix.getpgrp() return K.current.pgid end

function posix.getuid() return K.current.uid end

function posix.geteuid() return K.current.uid end

function posix.getgroups() return K.copy(K.current.groups or {}) end

function posix.umask(m)
    local p = K.current
    local old = p.umask
    if m ~= nil then p.umask = int(m, 1, "umask") & o "777" end
    return old
end

function posix.getgid() return K.current.gid end

function posix.gethostname() return K.hostname end

function posix.yield() coroutine.yield() end

function posix.ttyname()
    local t = K.current.tty
    return t and t.name or nil
end

posix.kbdmap = sys_(function(map)
    if not K.kbd or type(K.kbd.loadmap) ~= "function" then
        return nil, "no keyboard driver"
    end
    if map == nil then return K.kbd.getmap() end
    if K.current.uid ~= 0 then return nil, "permission denied" end
    return K.kbd.loadmap(map)
end)

posix.kbdgrab = sys_(function(on)
    if not K.kbd or type(K.kbd.grab) ~= "function" then
        return nil, "no keyboard driver"
    end
    if on == nil then return K.kbd.grabbed and K.kbd.grabbed() or nil end
    local p = K.current
    if on then
        local t = p.tty
        if not t or t == K.nulltty then return nil, "no terminal" end
        if t ~= K.tty_active or t.fgpgid ~= p.pgid then
            return nil, "not the foreground terminal"
        end
        K.kbd.grab(p.pid)
    else
        K.kbd.release(p.pid)
    end
    return true
end)

posix.chvt = sys_(function(target)
    if not K.ttys or type(K.tty_show) ~= "function" then
        return nil, "no virtual consoles"
    end
    if target == nil then
        return K.tty_active and K.tty_active.name or nil
    end
    local s = str(target, 1, "chvt")
    local idx = (s:match("^ttyv([0-3])$") and tonumber(s:match("^ttyv([0-3])$")) + 1)
        or (s:match("^[1-4]$") and tonumber(s))
    if not idx then return nil, "no such console: " .. s end
    local t = K.ttys[idx]
    if not t then return nil, "no such console: " .. s end
    K.tty_show(t)
    return t.name
end)

-- Exclusive framebuffer ownership for a display server. While held, the
-- kernel stops scanning out the text consoles, injects the raw `screen`
-- table into the owner's environment, and routes raw keyboard and mouse
-- events to it. The display server is then free to composite windows.
posix.gfxgrab = sys_(function(on)
    local p = K.current
    if on == nil then return K.gfx == p end
    if on then
        if p.uid ~= 0 then return nil, "permission denied" end
        if K.gfx and K.gfx ~= p and K.gfx.state ~= "Z" then return nil, "display in use" end
        K.gfx = p
        p.gfx = true
        if p.envtbl then p.envtbl.screen = screen end
        if K.kbd and K.kbd.grab then K.kbd.grab(p.pid) end
        K.gfx_dirty = true
    elseif K.gfx == p then
        K.gfx, p.gfx = nil, nil
        if K.kbd and K.kbd.release then K.kbd.release(p.pid) end
        K.tty_dirty = true
    end
    return true
end)

-- Create an off-screen text console whose glyph output is painted into the
-- given screen-like surface (a layer created by the display server). Returns
-- an id for ttyinput/ttykey/ttyclose. Used to give windows a real terminal.
posix.newtty = sys_(function(surface)
    local p = K.current
    if p.uid ~= 0 then return nil, "permission denied" end
    if type(surface) ~= "table" or type(surface.getSize) ~= "function" then
        return nil, "invalid surface"
    end
    if not K.gfxfont then return nil, "no graphics font" end
    local W, H = surface.getSize()
    if type(W) ~= "number" or type(H) ~= "number" then return nil, "invalid surface" end
    K.gfx_tty_next = (K.gfx_tty_next or 0) + 1
    local id = K.gfx_tty_next
    local t = K.TTY.new("xgfx" .. id, K.gfxfont, surface)
    t.gfxid = id
    t.owner = p.pid
    K.extrattys[id] = t
    return id
end)

-- Deliver a raw key press/release to a windowed console. `mods` uses the
-- kernel's MOD_SHIFT/CTRL/ALT bits. Printable characters are also forwarded
-- as `char` events, matching what a process on a normal console receives.
posix.ttykey = sys_(function(id, down, name, code, mods)
    local p = K.current
    if p.uid ~= 0 then return nil, "permission denied" end
    local t = K.extrattys[int(id, 1, "ttykey")]
    if not t then return nil, "no such tty" end
    if type(name) ~= "string" then return nil, "invalid key name" end
    code = int(code, 4, "ttykey")
    mods = mods == nil and 0 or int(mods, 5, "ttykey")
    if down then
        K.tty_input(t, "key", name, false, code, mods)
        if code >= 32 and code < 127 and (mods & (2 | 4)) == 0 then
            K.tty_input(t, "char", string.char(code))
        end
    else
        K.tty_input(t, "key_up", name, code, 0)
    end
    return true
end)

-- Rebind a windowed console to a new surface and refit its grid. The
-- display server calls this when a terminal window is resized so the
-- console reflows instead of letterboxing. Returns the new cols, rows.
-- (Processes are not signalled; shells keep their old idea of the size.)
posix.ttyresize = sys_(function(id, surface)
    local p = K.current
    if p.uid ~= 0 then return nil, "permission denied" end
    local t = K.extrattys[int(id, 1, "ttyresize")]
    if not t then return nil, "no such tty" end
    if type(surface) ~= "table" or type(surface.getSize) ~= "function" then
        return nil, "invalid surface"
    end
    local W, H = surface.getSize()
    if type(W) ~= "number" or type(H) ~= "number" then return nil, "invalid surface" end
    return t:resize(surface)
end)

posix.ttyclose = sys_(function(id)
    if K.current.uid ~= 0 then return nil, "permission denied" end
    K.extrattys[int(id, 1, "ttyclose")] = nil
    return true
end)

posix.gfxdirty = function()
    local d = K.gfx_dirty
    K.gfx_dirty = false
    return d and true or false
end

posix.fork = K.fork

posix.exit = function(code) K.exit(K.current, code or 0) end

posix.exec = function(path, args, env)
    local p = K.current
    local full = findProgram(str(path, 1, "exec"), p.env)
    if not full then return nil, "command not found" end
    p.critical = p.critical + 1
    local ok, err = pcall(K.exec, p, full, checkArgs(args), env)
    p.critical = p.critical - 1
    if not ok then error(err, 0) end
    return nil, err
end

local spawnInner = sys_(function(path, args, opts)
    local p = K.current
    opts = opts or {}
    local full = findProgram(str(path, 1, "spawn"), opts.env or p.env)
    if not full then return nil, "command not found: " .. path end
    local o = {
        fds = opts.fds,
        env = opts.env,
        newpgrp = opts.newpgrp,
        foreground = opts.foreground,
        pgid = opts.pgid,
        nice = opts.nice
    }
    if opts.cwd then
        local c = rp(opts.cwd)
        if not c then return nil, "bad cwd" end
        o.cwd = c:sub(-1) == "/" and c or c .. "/"
    end
    if opts.tty or opts.ttyid or opts.setsid or opts.uid or opts.login then
        if opts.login then
            local u = opts.verifiedUser
            if not u then return nil, "authentication failed" end
            if u.shell == "/sbin/nologin" or u.shell == "/bin/false" then return nil, "account is not available" end
            o.uid, o.gid, o.home = u.uid, u.gid, u.home
            o.groups = groupsFor(u.name, u.gid)
        elseif p.uid ~= 0 then
            return nil, "permission denied"
        else
            o.uid, o.gid, o.home = opts.uid, opts.gid, opts.home
            o.groups = opts.groups or (opts.uid and (function()
                local u = getpwuid(opts.uid)
                return u and groupsFor(u.name, opts.gid or u.gid) or {}
            end)())
        end
        if opts.tty then
            if p.uid ~= 0 then return nil, "permission denied" end
            local idx = tonumber(tostring(opts.tty):match("^ttyv(%d+)$"))
            o.tty = idx and K.ttys[idx + 1]
            if not o.tty then return nil, "no such tty" end
        end
        if opts.ttyid then
            if p.uid ~= 0 then return nil, "permission denied" end
            local id = math.tointeger(tonumber(opts.ttyid))
            o.tty = id and K.extrattys[id]
            if not o.tty then return nil, "no such tty" end
        end
        o.setsid = opts.setsid
    end
    local child, err = K.spawn(p, full, checkArgs(args), o)
    if not child then return nil, err end
    return child.pid
end)

local DOAS_ENV = { PATH = "/bin:/sbin:/usr/bin:/usr/sbin" }
local DOAS_PERSIST_SECS = 300
local doasPersist = {}

local function words(line)
    local w = {}
    for t in (line:gsub("#.*", "")):gmatch("%S+") do w[#w + 1] = t end
    return w
end

local function doasRule(w)
    local r, i = {}, 2
    if w[1] == "permit" then
        r.permit = true
    elseif w[1] == "deny" then
        r.permit = false
    else
        return nil
    end
    while w[i] == "nopass" or w[i] == "persist" do
        r[w[i]] = true
        i = i + 1
    end
    if not w[i] then return nil end
    r.who = w[i]
    i = i + 1
    while w[i] do
        if w[i] == "as" and w[i + 1] then
            r.as = w[i + 1]
            i = i + 2
        elseif w[i] == "cmd" and w[i + 1] then
            r.cmd = w[i + 1]
            i = i + 2
            if w[i] == "args" then
                r.args = { table.unpack(w, i + 1) }
                i = #w + 1
            end
        else
            return nil
        end
    end
    return r
end

local function doasRules()
    local data = V.readFile(K.rootdir .. "etc/doas.conf")
    if not data then return {} end
    local rules, n = {}, 0
    for line in (data .. "\n"):gmatch("([^\n]*)\n") do
        n = n + 1
        local w = words(line)
        if #w > 0 then
            local r = doasRule(w)
            if not r then
                K.authlog("DOAS config error at line %d: all requests denied", n)
                return {}
            end
            rules[#rules + 1] = r
        end
    end
    return rules
end

local function inGroup(user, gname)
    for _, g in ipairs(readGroups()) do
        if g.name == gname then
            if g.gid == user.gid then return true end
            for _, m in ipairs(g.members) do if m == user.name then return true end end
        end
    end
    return false
end

local function doasMatch(r, user, target, full, args)
    if r.who:sub(1, 1) == ":" then
        if not inGroup(user, r.who:sub(2)) then return false end
    elseif r.who ~= user.name then
        return false
    end
    if r.as and r.as ~= target.name then return false end
    if r.cmd then
        if r.cmd ~= full then return false end
        if r.args then
            if #r.args ~= #args then return false end
            for i, a in ipairs(r.args) do if a ~= args[i] then return false end end
        end
    end
    return true
end

local function doasAuthorize(d, path, args)
    local me = K.current
    local user = getpwuid(me.uid)
    local target = getpwnam(type(d.as) == "string" and d.as or "root")
    if not user or not target then return nil, "permission denied" end
    if type(path) ~= "string" then return nil, "bad options" end
    args = checkArgs(args)

    local full = findProgram(path, DOAS_ENV)
    if not full then return nil, "command not found: " .. tostring(path) end

    local rule
    for _, r in ipairs(doasRules()) do
        if doasMatch(r, user, target, full, args) then rule = r end
    end
    if not rule or not rule.permit then
        K.authlog("DOAS DENIED %s as %s cmd=%s %s", user.name, target.name, full, ctxString())
        return nil, "permission denied"
    end

    if not rule.nopass then
        local key = me.uid .. "/" .. (me.tty and me.tty.name or "-")
        local open = rule.persist and doasPersist[key] and K.now() < doasPersist[key]
        if not open then
            if d.password == nil then return nil, "password required" end
            if not verify(user.name, d.password, "doas") then
                return nil, "authentication failed"
            end
        end
        if rule.persist then doasPersist[key] = K.now() + DOAS_PERSIST_SECS end
    end

    K.authlog("DOAS OK %s as %s cmd=%s %s", user.name, target.name, full, ctxString())
    return target, full, user
end

function posix.doasCheck(text)
    local bad, n = {}, 0
    for line in (tostring(text) .. "\n"):gmatch("([^\n]*)\n") do
        n = n + 1
        local w = words(line)
        if #w > 0 and not doasRule(w) then bad[#bad + 1] = n end
    end
    return bad
end

function posix.doasForget(uid)
    local me = K.current
    if uid ~= nil and me.uid ~= 0 and uid ~= me.uid then return nil, "operation not permitted" end
    uid = uid or me.uid
    for k in pairs(doasPersist) do
        if k:match("^(%d+)/") == tostring(uid) then doasPersist[k] = nil end
    end
    return true
end

posix.spawn = function(path, args, opts)
    if type(opts) == "table" then
        local o2 = {}
        for k, v in pairs(opts) do o2[k] = v end
        o2.verifiedUser = nil
        if o2.doas ~= nil then
            if o2.login ~= nil or type(o2.doas) ~= "table" then return nil, "bad options" end
            local target, full, user = doasAuthorize(o2.doas, path, args)
            if not target then return nil, full end
            o2.doas = nil
            o2.login = true
            o2.verifiedUser = target
            o2.env = {
                PATH = DOAS_ENV.PATH,
                HOME = target.home,
                USER = target.name,
                LOGNAME = target.name,
                SHELL = target.shell,
                TERM = K.current.env.TERM or "neat",
                DOAS_USER = user.name
            }
            path = full
        elseif o2.login ~= nil then
            local l = o2.login
            if type(l) ~= "table" then return nil, "bad login" end
            local target = type(l.user) == "string" and getpwnam(l.user) or nil
            if target and target.uid == 0 and K.current.uid ~= 0 and loginConf().su_wheel_only ~= 0 then
                local me = getpwuid(K.current.uid)
                local member = false
                for _, g in ipairs(readGroups()) do
                    if g.name == "wheel" then
                        for _, m in ipairs(g.members) do if me and m == me.name then member = true end end
                    end
                end
                if not member then
                    K.authlog("DENIED su to root: not in group wheel %s", ctxString())
                    return nil, "you are not in group wheel"
                end
            end
            local u, why = verify(l.user, l.password, "su")
            if not u then return nil, why == "locked" and "account temporarily locked" or "authentication failed" end
            o2.verifiedUser = u
        end
        opts = o2
    end
    return spawnInner(path, args, opts)
end

posix.wait = function(pid, nohang)
    if pid ~= nil and math.tointeger(pid) == nil then argerr(1, "wait", "integer", pid) end
    return K.wait(K.current, pid or -1, nohang)
end

posix.kill = sys_(function(pid, sig)
    local t = K.procs[int(pid, 1, "kill")]
    if not t then return nil, "no such process" end
    local me = K.current
    if me.uid ~= 0 and me.uid ~= t.uid then return nil, "operation not permitted" end
    if t.pid == 1 and me.uid ~= 0 then return nil, "operation not permitted" end
    sig = sig or K.SIG.TERM
    if t == me and (sig == K.SIG.KILL or sig == K.SIG.TERM or sig == K.SIG.QUIT) then K.exit(me, 128 + sig) end
    return K.signal(t, sig)
end)

posix.setpgid = sys_(function(pid, pgid)
    local me = K.current
    local t = (pid == 0 or pid == nil) and me or K.procs[pid]
    if not t or (t ~= me and t.ppid ~= me.pid) then return nil, "no such process" end
    local want = (pgid == 0 or pgid == nil) and t.pid or pgid
    if want ~= t.pid and not K.pgidAllowed(me, want) then return nil, "operation not permitted" end
    if t ~= me and t.sid ~= me.sid then return nil, "operation not permitted" end
    t.pgid = want
    return true
end)
posix.setsid = sys_(function()
    local p = K.current
    p.sid, p.pgid = p.pid, p.pid
    return p.pid
end)
posix.tcsetpgrp = sys_(function(pgid)
    local p = K.current
    if p.tty == K.nulltty then return nil, "no controlling terminal" end
    if not K.pgidAllowed(p, pgid) then return nil, "operation not permitted" end
    p.tty.fgpgid = pgid
    K.tty_deliverPending(p.tty)
    return true
end)
posix.tcgetpgrp = function() return K.current.tty.fgpgid end
posix.nice = sys_(function(n)
    local p = K.current
    n = int(n, 1, "nice")
    if n < 0 and p.uid ~= 0 then return nil, "permission denied" end
    p.nice = math.max(0, math.min(n, 20))
    return p.nice
end)
posix.open = sys_(function(path, flags)
    local p = K.current
    local full, err = rp(str(path, 1, "open"))
    if not full then return nil, err end
    flags = (flags or "r"):gsub("b$", "")
    if flags ~= "r" and flags ~= "w" and flags ~= "a" then return nil, "invalid flags" end
    local h, herr = V.open(p, full, flags)
    if not h then return nil, herr end
    return K.fdalloc(p, K.filefd(h))
end)
posix.close = sys_(function(fd) return K.fdcloseNum(K.current, int(fd, 1, "close")) end)
posix.read = function(fd, fmt)
    local o, err = K.fdget(K.current, int(fd, 1, "read"))
    if not o then return nil, err end
    if not o.read then return nil, "not open for reading" end
    return o:read(fmt)
end
posix.write = function(fd, s)
    local o, err = K.fdget(K.current, int(fd, 1, "write"))
    if not o then return nil, err end
    if not o.write then return nil, "not open for writing" end
    return o:write(str(s, 2, "write"))
end
posix.seek = sys_(function(fd, whence, off)
    local o, err = K.fdget(K.current, int(fd, 1, "seek"))
    if not o then return nil, err end
    if not o.seek then return nil, "illegal seek" end
    return o:seek(whence, off)
end)
posix.isatty = function(fd)
    local o = K.current.fds[fd]
    return o ~= nil and o:isatty()
end
posix.dup = sys_(function(fd)
    local p = K.current
    local o, err = K.fdget(p, int(fd, 1, "dup"))
    if not o then return nil, err end
    return K.fdalloc(p, K.fdref(o))
end)
posix.dup2 = sys_(function(old, new)
    local p = K.current
    local o, err = K.fdget(p, int(old, 1, "dup2"))
    if not o then return nil, err end
    new = int(new, 2, "dup2")
    if old == new then return new end
    if p.fds[new] then K.fdcloseNum(p, new) end
    p.fds[new] = K.fdref(o)
    return new
end)
posix.pipe = sys_(function()
    local p = K.current
    local r, w = K.pipe()
    return K.fdalloc(p, r), K.fdalloc(p, w)
end)

posix.getcwd = function() return K.current.cwd end
posix.pwd = function() return P.pretty(K.current.cwd) end
posix.pretty = function(full) return P.pretty(str(full, 1, "pretty")) end
posix.resolve = sys_(function(path) return rp(path) end)
posix.chdir = sys_(function(path)
    local full, err = rp(path)
    if not full then return nil, err end
    if not V.exists(K.current, full) then return nil, "no such file or directory" end
    if not V.isDir(K.current, full) then return nil, "not a directory" end
    if not V.perm(K.current, full, 1) then return nil, "permission denied" end
    K.current.cwd = full:sub(-1) == "/" and full or full .. "/"
    return true
end)
posix.stat = sys_(function(path)
    local p = K.current
    local full, err = rp(path)
    if not full then return nil, err end
    local info, serr = V.statx(p, full)
    if not info then return nil, serr or "no such file or directory" end
    info.path = full
    return info
end)
posix.access = sys_(function(path, want)
    local full, err = rp(path)
    if not full then return nil, err end
    if not V.stat(full) then return nil, "no such file or directory" end
    return V.perm(K.current, full, int(want or 0, 2, "access") & 7)
end)
posix.chmod = sys_(function(path, mode)
    local full, err = rp(path)
    if not full then return nil, err end
    return V.chmod(K.current, full, int(mode, 2, "chmod"))
end)
posix.chown = sys_(function(path, uid, gid)
    local full, err = rp(path)
    if not full then return nil, err end
    return V.chown(K.current, full, uid ~= nil and int(uid, 2, "chown") or nil,
        gid ~= nil and int(gid, 3, "chown") or nil)
end)
posix.readdir = sys_(function(path)
    local full, err = rp(path or ".")
    if not full then return nil, err end
    local names, lerr = V.list(K.current, full)
    if not names then return nil, lerr end
    table.sort(names)
    return names
end)
posix.mkdir = sys_(function(path)
    local full, err = rp(path)
    if not full then return nil, err end
    return V.mkdir(K.current, full)
end)
posix.unlink = sys_(function(path)
    local full, err = rp(path)
    if not full then return nil, err end
    return V.remove(K.current, full)
end)
posix.readfile = sys_(function(path)
    local full, err = rp(path)
    if not full then return nil, err end
    local h, herr = V.open(K.current, full, "r")
    if not h then return nil, herr end
    local d = h:read("a")
    h:close()
    return d
end)
posix.writefile = sys_(function(path, data, append)
    local full, err = rp(path)
    if not full then return nil, err end
    local h, herr = V.open(K.current, full, append and "a" or "w")
    if not h then return nil, herr end
    local ok, werr = h:write(data)
    h:close()
    return ok, werr
end)
posix.rename = sys_(function(a, b)
    local p = K.current
    local fa, e1 = rp(a)
    local fb, e2 = rp(b)
    if not fa then return nil, e1 end
    if not fb then return nil, e2 end
    if V.isDir(p, fb) then fb = fb .. P.basename(fa) end
    return V.move(p, fa, fb)
end)

posix.symlink = sys_(function(target, linkpath)
    local p = K.current
    local full, err = rp(str(linkpath, 2, "symlink"))
    if not full then return nil, err end
    return V.symlink(p, str(target, 1, "symlink"), full)
end)
posix.readlink = sys_(function(path)
    local full, err = rp(str(path, 1, "readlink"))
    if not full then return nil, err end
    return V.readlink(K.current, full)
end)

posix.mkfifo = sys_(function(path)
    local full, err = rp(str(path, 1, "mkfifo"))
    if not full then return nil, err end
    return V.mkfifo(K.current, full)
end)

posix.mknod = sys_(function(path, kind)
    if (kind == nil and "p" or str(kind, 2, "mknod")) ~= "p" then
        return nil, "not supported (only 'p' for FIFO)"
    end
    local full, err = rp(str(path, 1, "mknod"))
    if not full then return nil, err end
    return V.mkfifo(K.current, full)
end)

posix.utime = sys_(function(path, mt)
    local full, err = rp(str(path, 1, "utime"))
    if not full then return nil, err end
    if mt ~= nil and math.type(mt) ~= "integer" then
        mt = math.tointeger(tonumber(mt))
        if mt == nil then return nil, "invalid time" end
    end
    return V.utime(K.current, full, mt)
end)
posix.glob = sys_(function(pattern) return glob(str(pattern, 1, "glob")) end)
posix.mounts = function()
    local out = {}
    for _, d in ipairs(R.disks()) do
        for _, part in ipairs(R.partitions(d.slot) or {}) do
            local isroot = d.id == K.root.id and part == K.root.part
            out[#out + 1] = {
                slot = d.slot,
                disk = d.id,
                partition = part,
                root = isroot,
                mountpoint = isroot and "/" or ("/mnt/" .. part),
                fstype = "xesfs",
                opts = "rw"
            }
        end
    end

    for _, m in ipairs(V.mountlist()) do
        out[#out + 1] = {
            slot = m.slot,
            disk = m.disk,
            partition = m.part,
            root = false,
            mountpoint = m.mpfp,
            fstype = m.fstype or "xesfs",
            opts = m.opts or "rw",
            mounted = true
        }
    end
    return out
end

posix.mount = sys_(function(mp, device, fstype, opts)
    if K.current.uid ~= 0 then return nil, "permission denied" end
    local full, err = rp(str(mp, 1, "mount"))
    if not full then return nil, err end
    device = str(device, 2, "mount")
    local dref, part = device:match("^([^:]+):([^:/]+)")
    if not dref or not part then return nil, "bad device: " .. device end
    local slot
    if dref == "any" then
        for _, d in ipairs(R.disks()) do
            if R.hasPartition(d.slot, part) then
                slot = d.slot
                break
            end
        end
        if not slot then return nil, "no disk has a partition named '" .. part .. "'" end
    else
        local d = R.diskByRef(dref)
        if not d then return nil, "no such disk: " .. dref end
        slot = d.slot
    end
    return V.mount(K.current, full, slot, part,
        fstype == nil and "xesfs" or str(fstype, 3, "mount"),
        opts == nil and "rw" or str(opts, 4, "mount"))
end)
posix.unmount = sys_(function(mp, force)
    if K.current.uid ~= 0 then return nil, "permission denied" end
    local full, err = rp(str(mp, 1, "unmount"))
    if not full then return nil, err end
    return V.unmount(K.current, full, force)
end)

posix.getenv = function(k) return K.current.env[str(k, 1, "getenv")] end
posix.setenv = function(k, v)
    K.current.env[str(k, 1, "setenv")] = str(v, 2, "setenv")
    return true
end
posix.unsetenv = function(k)
    K.current.env[str(k, 1, "unsetenv")] = nil
    return true
end
posix.environ = function() return K.copy(K.current.env) end

posix.uname = function()
    return {
        sysname = K.NAME,
        nodename = K.hostname,
        release = K.RELEASE,
        version = string.format("%s %s (%s)", K.NAME, K.RELEASE, K.KERNEL),
        machine = tostring(chip.getMachine and chip.getMachine() or "neet")
    }
end
posix.time = function() return K.now() end
posix.uptime = function() return K.uptime() end
posix.date = function(ts) return K.date(ts or K.now()) end
posix.dateString = function(ts) return K.dateString(ts) end
posix.loadavg = function() return K.loadavg() end
posix.dmesg = function()
    if K.current.uid ~= 0 and K.sec.unprivileged_read_msgbuf == 0 then return nil, "permission denied" end
    return K.copy(K.klog_lines())
end

local function procMem(p)
    if p.co and coroutine.memoryused then
        local ok, m = pcall(coroutine.memoryused, p.co)
        if ok and type(m) == "number" then return math.tointeger(m) or m end
    end
    return 0
end

local function procMemDeep(p)
    if p.co and coroutine.memoryused then
        local ok, m = pcall(coroutine.memoryused, p.co, true)
        if ok and type(m) == "number" then return math.tointeger(m) or m end
    end
    return procMem(p)
end

local function gcBytes()
    if collectgarbage then
        local ok, v = pcall(collectgarbage, "count")
        if ok and type(v) == "number" then return math.floor(v * 1024) end
    end
    return 0
end
posix.ps = sys_(function()
    local me = K.current
    local out = {}
    for pid, p in pairs(K.procs) do
        local mem = procMem(p)
        out[#out + 1] = {
            pid = pid,
            ppid = p.ppid,
            pgid = p.pgid,
            sid = p.sid,
            uid = p.uid,
            name = p.name,
            state = p.state,
            tty = p.tty ~= K.nulltty and p.tty.name or nil,
            cputime = p.cputime,
            slices = p.slices,
            nice = p.nice,
            started = p.started - K.boottime,
            args = (me.uid == 0 or me.uid == p.uid) and p.args or {},
            mem = mem,
            cwd = (me.uid == 0 or me.uid == p.uid) and p.cwd or nil
        }
    end
    table.sort(out, function(a, b) return a.pid < b.pid end)
    return out
end)

posix.meminfo = sys_(function()
    local total, n = 0, 0
    for _, p in pairs(K.procs) do total, n = total + procMem(p), n + 1 end
    return { gc_bytes = gcBytes(), procs_bytes = total, nprocs = n }
end)

posix.memdeep = sys_(function(pid)
    local p = K.procs[int(pid, 1, "memdeep")]
    if not p then return nil, "no such process" end
    return procMemDeep(p)
end)
posix.sysctl = sys_(function(key, value)
    local T = {}
    local function def(name, desc, get, set)
        T[#T + 1] = { name = name, desc = desc, get = get, set = set }
        T[name] = T[#T]
    end
    def("kern.ostype", "operating system type",
        function() return K.NAME end)
    def("kern.osrelease", "operating system release",
        function() return K.RELEASE end)
    def("kern.version", "kernel version string",
        function() return string.format("%s %s (%s)", K.NAME, K.RELEASE, K.KERNEL) end)
    def("kern.hostname", "system hostname",
        function() return K.hostname end,
        function(v) K.hostname = tostring(v) end)
    def("kern.quantum", "scheduler quantum (VM instructions)",
        function() return K.quantum end,
        function(v)
            local q = math.tointeger(tonumber(v))
            if not q or q < 500 or q > 1000000 then return nil, "out of range" end
            K.quantum = q
        end)
    def("kern.maxrounds", "scheduler rounds per host tick",
        function() return K.maxrounds end,
        function(v)
            local m = math.tointeger(tonumber(v))
            if not m or m < 1 or m > 1000 then return nil, "out of range" end
            K.maxrounds = m
        end)
    def("kern.debug", "kernel debug output enabled",
        function() return K.debug and 1 or 0 end,
        function(v) K.debug = tonumber(v) ~= 0 end)
    def("kern.securelevel", "system securelevel (may only be raised)",
        function() return K.securelevel or 0 end,
        function(v)
            local lv = math.tointeger(tonumber(v))
            if not lv or lv < (K.securelevel or 0) or lv > 2 then return nil, "securelevel can only be raised" end
            K.securelevel = lv
            K.authlog("securelevel raised to %d %s", lv, ctxString())
        end)
    def("kern.boottime", "boot time (kernel clock)",
        function() return K.boottime end)
    def("kern.uptime", "seconds since boot",
        function() return K.uptime() end)
    def("kern.ticks", "scheduler host ticks since boot",
        function() return K.ticks end)
    def("kern.nprocs", "number of processes",
        function() return K.nprocs() end)
    def("kern.booting", "system is booting (cleared by init)",
        function() return K.booting and 1 or 0 end,
        function(v)
            local on = tonumber(v) ~= 0
            if on and (K.securelevel or 0) >= 1 then return nil, "operation not permitted at this securelevel" end
            K.booting = on
        end)
    def("hw.machine", "machine type",
        function() return tostring(chip.getMachine and chip.getMachine() or "neet") end)
    def("hw.vm", "scripting VM",
        function() return "YSLua " .. _VERSION end)
    def("hw.ncpu", "number of CPUs",
        function() return 1 end)
    def("hw.pagesize", "memory page size in bytes",
        function() return 4096 end)
    def("hw.screen", "console size in pixels (WxH)",
        function()
            local w, h = screen.getSize()
            return w .. "x" .. h
        end)
    def("vm.loadavg", "run-queue load average (1 5 15 min)",
        function()
            local a, b, c = K.loadavg()
            return string.format("%.2f %.2f %.2f", a, b, c)
        end)
    def("vm.nprocs", "number of processes (alias of kern.nprocs)",
        function() return K.nprocs() end)
    def("vm.gc_bytes", "whole Lua heap in bytes (collectgarbage count; each object once)",
        function() return gcBytes() end)
    def("vm.procs_bytes", "sum of exclusive per-thread RAM (stack/call-frames owned by each process)",
        function()
            local total = 0
            for _, p in pairs(K.procs) do total = total + procMem(p) end
            return total
        end)
    def("hw.physmem", "physical memory in bytes (Lua heap total; alias of vm.gc_bytes)",
        function() return gcBytes() end)
    def("security.bsd.unprivileged_read_msgbuf", "any user may read the kernel message buffer",
        function() return K.sec.unprivileged_read_msgbuf end,
        function(v) K.sec.unprivileged_read_msgbuf = tonumber(v) ~= 0 and 1 or 0 end)
    def("security.bsd.see_other_uids", "unprivileged users may inspect other users' processes",
        function() return K.sec.see_other_uids end,
        function(v) K.sec.see_other_uids = tonumber(v) ~= 0 and 1 or 0 end)
    local function get(k)
        local e = k ~= nil and T[k] or nil
        if e then return e.get() end
    end
    if key == nil then
        local out = {}
        for _, e in ipairs(T) do out[#out + 1] = { e.name, e.get() } end
        return out
    end
    if value == nil then return get(key) end
    if K.current.uid ~= 0 then return nil, "permission denied" end
    local e = T[key]
    if not e or not e.set then return nil, "read-only or unknown variable" end
    local r, err = e.set(value)
    if r == nil and err ~= nil then return nil, err end
    return get(key)
end)

posix.sysctldesc = sys_(function(key)
    local all = posix.sysctl()
    local descs = {
        ["kern.ostype"] = "operating system type",
        ["kern.osrelease"] = "operating system release",
        ["kern.version"] = "kernel version string",
        ["kern.hostname"] = "system hostname",
        ["kern.quantum"] = "scheduler quantum (VM instructions)",
        ["kern.maxrounds"] = "scheduler rounds per host tick",
        ["kern.debug"] = "kernel debug output enabled",
        ["kern.securelevel"] = "system securelevel (may only be raised)",
        ["kern.boottime"] = "boot time (kernel clock)",
        ["kern.uptime"] = "seconds since boot",
        ["kern.ticks"] = "scheduler host ticks since boot",
        ["kern.nprocs"] = "number of processes",
        ["kern.booting"] = "system is booting (cleared by init)",
        ["hw.machine"] = "machine type",
        ["hw.vm"] = "scripting VM",
        ["hw.ncpu"] = "number of CPUs",
        ["hw.pagesize"] = "memory page size in bytes",
        ["hw.screen"] = "console size in pixels (WxH)",
        ["vm.loadavg"] = "run-queue load average (1 5 15 min)",
        ["vm.nprocs"] = "number of processes (alias of kern.nprocs)",
        ["vm.gc_bytes"] = "whole Lua heap in bytes (collectgarbage count; each object once)",
        ["vm.procs_bytes"] = "sum of exclusive per-thread RAM (stack/call-frames owned by each process)",
        ["hw.physmem"] = "physical memory in bytes (Lua heap total; alias of vm.gc_bytes)",
        ["security.bsd.unprivileged_read_msgbuf"] = "any user may read the kernel message buffer",
        ["security.bsd.see_other_uids"] = "unprivileged users may inspect other users' processes",
    }
    if key == nil then
        local out = {}
        for _, kv in ipairs(all) do out[#out + 1] = { kv[1], kv[2], descs[kv[1]] or "" } end
        return out
    end
    for _, kv in ipairs(all) do
        if kv[1] == key then return { kv[1], kv[2], descs[kv[1]] or "" } end
    end
    return nil
end)
posix.reboot = sys_(function()
    if K.current.uid ~= 0 then return nil, "permission denied" end
    K.shutdownRequested = "reboot"
    return true
end)
posix.halt = sys_(function()
    if K.current.uid ~= 0 then return nil, "permission denied" end
    K.shutdownRequested = "halt"
    return true
end)

posix.getpwnam = sys_(function(n) return getpwnam(str(n, 1, "getpwnam")) end)
posix.getpwuid = sys_(function(u) return getpwuid(int(u, 1, "getpwuid")) end)

posix.authenticate = function(name, pass)
    if K.current.uid ~= 0 then return nil, "permission denied" end
    local u, why = verify(str(name, 1, "authenticate"), pass, "login")
    return u, why
end

posix.pwstatus = sys_(function(name)
    if K.current.uid ~= 0 then return nil, "permission denied" end
    local st = masterField(str(name, 1, "pwstatus"))
    return st and hashState(st) or nil
end)

posix.passwd = function(name, old, new)
    local me = K.current
    str(name, 1, "passwd")
    if me.uid ~= 0 then
        local u = getpwuid(me.uid)
        if not u or u.name ~= name then return nil, "permission denied" end
        local good, why = verify(name, old or "", "passwd")
        if not good then return nil, why == "locked" and "account temporarily locked" or "authentication failed" end
    elseif not getpwnam(name) then
        return nil, "no such user"
    end
    local conf = loginConf()
    local okp, perr = policyCheck(name, new, me.uid ~= 0 and old or nil, conf)
    if not okp then return nil, perr end
    local nh = newHash(new, conf)
    local r, e = updateMaster(name, function(row)
        row[2] = nh
        return true
    end)
    if r then K.authlog("PASSWORD changed for %s %s", name, ctxString()) end
    return r, e
end

posix.pwlock = sys_(function(name, lock)
    if K.current.uid ~= 0 then return nil, "permission denied" end
    local r, e = updateMaster(str(name, 1, "pwlock"), function(row)
        local cur = row[2] or ""
        if lock then
            if cur:sub(1, #LOCK) ~= LOCK then row[2] = LOCK .. cur end
        else
            if cur:sub(1, #LOCK) == LOCK then
                row[2] = cur:sub(#LOCK + 1)
                if row[2] == "" then row[2] = "!" end
            end
        end
        return true
    end)
    if r then K.authlog("%s %s %s", lock and "LOCKED account" or "UNLOCKED account", name, ctxString()) end
    return r, e
end)
posix.getusers = sys_(function()
    local out = {}
    for _, f in ipairs(readDb("/etc/passwd")) do out[#out + 1] = userFromRow(f) end
    return out
end)

posix.readline = function(opts)
    local p = K.current
    if p.tty == K.nulltty then return nil, "no terminal" end
    return K.readline(p.tty, opts or {})
end

posix.loadlib = function(name)
    local p = K.current
    str(name, 1, "loadlib")
    if not name:match("^[%w_%.%-]+$") then error("bad library name", 2) end
    p.libs = p.libs or {}
    if p.libs[name] ~= nil then return p.libs[name] end
    return K.doloadlib(p, name)
end

-- Load (or reload) usr/lib/xes/<name>.lua in an environment that falls
-- back to the calling program's own globals, so libraries see the same
-- posix/event/spp surface as their caller without polluting it. Results
-- are cached in p.libs; see posix.unloadlib / posix.reloadlib /
-- posix.listlibs below.
function K.doloadlib(p, name)
    local full = K.rootdir .. "usr/lib/xes/" .. name .. ".lua"
    local src, err = V.readFile(full)
    if not src then error("library '" .. name .. "' not found", 2) end
    -- The program image lives in p.envtbl (see sched.loadprog); fall back
    -- to a fresh sandbox for contexts that never exec'd one.
    local penv = p.envtbl or K.makeEnv(p)
    local lenv = setmetatable({}, { __index = penv })
    lenv._G = lenv
    local chunk, cerr = load(src, "=" .. name, "t", lenv)
    if not chunk then error(cerr, 2) end
    local lib = chunk(name)
    p.libs[name] = lib == nil and true or lib
    return p.libs[name]
end

posix.unloadlib = function(name)
    local p = K.current
    str(name, 1, "unloadlib")
    p.libs = p.libs or {}
    if p.libs[name] == nil then return nil, "not loaded" end
    p.libs[name] = nil
    return true
end

posix.reloadlib = function(name)
    local p = K.current
    str(name, 1, "reloadlib")
    if not name:match("^[%w_%.%-]+$") then error("bad library name", 2) end
    p.libs = p.libs or {}
    p.libs[name] = nil
    return K.doloadlib(p, name)
end

posix.listlibs = function()
    local p = K.current
    local out = {}
    for n in pairs(p.libs or {}) do out[#out + 1] = n end
    table.sort(out)
    return out
end

function K.posixtable(p)
    local t = {}
    for k, v in pairs(posix) do t[k] = v end
    return t
end

K.posix = posix
K.getpwuid = getpwuid
