local u = require("util")

local A = {}

A.PASSWD = "/etc/passwd"
A.MASTER = "/etc/master.passwd"
A.GROUP = "/etc/group"
A.LOCK = "/var/run/auth.lock"
A.TABS = "/var/cron/tabs"
A.CHSH = "/var/auth/chsh"
A.CHSHRESULT = "/var/auth/chsh.result"

A.MAX_ID = 65534
A.MODES = { [A.PASSWD] = 420, [A.MASTER] = 384, [A.GROUP] = 420 }
A.NAMES = { [A.PASSWD] = "passwd", [A.MASTER] = "master.passwd", [A.GROUP] = "group" }

local function now()
	return u.wall() or 0
end

local function dirOf(p)
	local d = tostring(p):match("^(.*)/[^/]+$")
	if not d or d == "" then
		return "/"
	end
	return d
end
A.dirOf = dirOf

function A.ensureDir(path, mode, uid, gid)
	local st, err = u.lstat(path)
	if st then
		if st.type == "link" then
			return nil, path .. ": is a symbolic link"
		end
		if st.type ~= "dir" then
			return nil, path .. ": not a directory"
		end
	else
		if err and err ~= "no such file or directory" then
			return nil, err
		end
		local ok, e = u.mkdir(path)
		if not ok then
			st = u.lstat(path)
			if not st or st.type ~= "dir" then
				return nil, path .. ": " .. tostring(e or "cannot create directory")
			end
		end
	end
	if mode then
		local tok, te = u.chmod(path, mode & 4095)
		if not tok then
			return nil, path .. ": " .. tostring(te)
		end
	end
	if uid or gid then
		local tok, te = u.chown(path, uid or 0, gid or 0)
		if not tok then
			return nil, path .. ": " .. tostring(te)
		end
	end
	return true
end

function A.read(path)
	return u.readFile(path)
end

function A.authlog(msg)
	local line = (u.dateStr() or "") .. " " .. tostring(msg) .. "\n"
	A.ensureDir("/var/log", 493, 0, 0)
	return u.writeFile("/var/log/auth.log", line, true)
end

local locked = false

function A.lock(seconds)
	seconds = seconds or 5
	if locked then
		return true
	end
	A.ensureDir("/var/run", 493, 0, 0)
	local deadline = now() + seconds
	while true do
		local ok = u.mkdir(A.LOCK)
		if ok then
			u.writeFile(A.LOCK .. "/pid", tostring(u.getpid() or 0) .. "\n")
			locked = true
			return true
		end
		local st = u.lstat(A.LOCK)
		if not st then
			return nil, "cannot create lock " .. A.LOCK
		end
		if st.type ~= "dir" then
			return nil, A.LOCK .. ": exists and is not a lock directory"
		end
		local pid = tonumber((u.readFile(A.LOCK .. "/pid") or ""):match("%d+") or "")
		local alive = false
		if pid and pid > 0 then
			alive = proc.signal(pid, 0) == true
		end
		if not alive then
			local age = now() - (tonumber(st.mtime) or 0)
			if pid or age > 10 then
				u.rmtree(A.LOCK)
			end
		end
		if now() >= deadline then
			return nil, "account database is locked by pid " .. tostring(pid or "?")
		end
		u.sleep(0.2)
	end
end

function A.unlock()
	if not locked then
		return true
	end
	u.rmtree(A.LOCK)
	locked = false
	return true
end

function A.checkUnlocked()
	local st = u.lstat(A.LOCK)
	if not st then
		return true
	end
	if st.type ~= "dir" then
		return nil, A.LOCK .. ": exists and is not a lock directory"
	end
	local pid = tonumber((u.readFile(A.LOCK .. "/pid") or ""):match("%d+") or "")
	if pid and proc.signal(pid, 0) == true then
		return nil, "account database is locked by pid " .. pid .. "; try again"
	end
	return true
end

function A.withLock(fn, seconds)
	local ok, err = A.lock(seconds)
	if not ok then
		return nil, err
	end
	local r = table.pack(pcall(fn))
	A.unlock()
	if not r[1] then
		return nil, tostring(r[2])
	end
	return table.unpack(r, 2, r.n)
end

local function split(line)
	local f = {}
	for s in (line .. ":"):gmatch("([^:]*):") do
		f[#f + 1] = s
	end
	return f
end
A.split = split

local function cleanRows(text, want)
	local rows, errs = {}, {}
	local n = 0
	for line in (text or ""):gmatch("[^\n]*") do
		n = n + 1
		if line ~= "" and not line:match("^%s*#") then
			local f = split(line)
			if #f ~= want then
				errs[#errs + 1] = "line " .. n .. ": want " .. want .. " fields, got " .. #f
			else
				rows[#rows + 1] = f
			end
		end
	end
	return rows, errs
end

function A.parseUsers(text)
	local rows, errs = cleanRows(text, 7)
	return rows, errs
end

function A.parseGroups(text)
	local rows, errs = cleanRows(text, 4)
	return rows, errs
end

function A.serialize(rows)
	local out = {}
	for i, r in ipairs(rows) do
		out[i] = table.concat(r, ":")
	end
	if #out == 0 then
		return ""
	end
	return table.concat(out, "\n") .. "\n"
end

function A.findUser(rows, name)
	for i, r in ipairs(rows) do
		if r[1] == name then
			return r, i
		end
	end
end

function A.findUid(rows, uid)
	for i, r in ipairs(rows) do
		if tonumber(r[3]) == uid then
			return r, i
		end
	end
end

function A.validName(n)
	return type(n) == "string" and #n >= 1 and #n <= 32 and n:match("^[a-z_][a-z0-9_%-]*$") ~= nil
end

function A.validPath(p)
	if type(p) ~= "string" or p == "" or #p > 1024 then
		return false
	end
	if p:sub(1, 1) ~= "/" then
		return false
	end
	if p:find("[%c ]") then
		return false
	end
	return true
end

function A.validShellPath(p)
	return A.validPath(p) and p:find(":") == nil
end

local function checkId(s)
	if type(s) ~= "string" or not s:match("^%d+$") then
		return nil
	end
	local n = tonumber(s)
	if not n or n < 0 or n > A.MAX_ID then
		return nil
	end
	return n
end

function A.validateUsers(rows)
	local errs, names, uids = {}, {}, {}
	if #rows == 0 then
		errs[#errs + 1] = "no accounts"
	end
	for i, r in ipairs(rows) do
		local where = "line " .. i .. " (" .. tostring(r[1]) .. "): "
		if #r ~= 7 then
			errs[#errs + 1] = where .. "want 7 fields"
		else
			if not A.validName(r[1]) then
				errs[#errs + 1] = where .. "invalid name"
			elseif names[r[1]] then
				errs[#errs + 1] = where .. "duplicate name"
			end
			names[r[1]] = true
			if r[2] == "" then
				errs[#errs + 1] = where .. "empty password field"
			end
			local uid, gid = checkId(r[3]), checkId(r[4])
			if not uid then
				errs[#errs + 1] = where .. "uid must be 0.." .. A.MAX_ID
			elseif uids[uid] then
				errs[#errs + 1] = where .. "duplicate uid " .. uid
			end
			if uid then
				uids[uid] = true
			end
			if not gid then
				errs[#errs + 1] = where .. "gid must be 0.." .. A.MAX_ID
			end
			if not A.validPath(r[6]) then
				errs[#errs + 1] = where .. "home must be an absolute path"
			end
			if not A.validShellPath(r[7]) then
				errs[#errs + 1] = where .. "shell must be an absolute path"
			end
		end
	end
	return errs
end

function A.validateGroups(rows)
	local errs, names, gids = {}, {}, {}
	for i, r in ipairs(rows) do
		local where = "line " .. i .. " (" .. tostring(r[1]) .. "): "
		if #r ~= 4 then
			errs[#errs + 1] = where .. "want 4 fields"
		else
			if not A.validName(r[1]) then
				errs[#errs + 1] = where .. "invalid group name"
			elseif names[r[1]] then
				errs[#errs + 1] = where .. "duplicate group name"
			end
			names[r[1]] = true
			local gid = checkId(r[3])
			if not gid then
				errs[#errs + 1] = where .. "gid must be 0.." .. A.MAX_ID
			elseif gids[gid] then
				errs[#errs + 1] = where .. "duplicate gid " .. gid
			end
			if gid then
				gids[gid] = true
			end
			if r[4] ~= "" then
				for m in (r[4] .. ","):gmatch("([^,]*),") do
					if m ~= "" and not A.validName(m) then
						errs[#errs + 1] = where .. "invalid member name '" .. m .. "'"
					end
				end
			end
		end
	end
	return errs
end

function A.mergeMaster(prows, mrows)
	local byName, byUid = {}, {}
	for _, m in ipairs(mrows) do
		if not byName[m[1]] then
			byName[m[1]] = m
		end
		local id = tonumber(m[3])
		if id and not byUid[id] then
			byUid[id] = m
		end
	end
	local present = {}
	for _, p in ipairs(prows) do
		present[p[1]] = true
	end
	local out, added = {}, {}
	for _, p in ipairs(prows) do
		local old = byName[p[1]]
		if not old then
			local same = byUid[tonumber(p[3])]
			if same and not present[same[1]] then
				old = same
			end
		end
		local hash = old and old[2] or nil
		if not hash or hash == "" then
			hash = "!"
			if not old then
				added[#added + 1] = p[1]
			end
		end
		out[#out + 1] = { p[1], hash, p[3], p[4], p[5], p[6], p[7] }
	end
	return out, added
end

function A.writeAtomic(path, text, mode)
	local st, err = u.lstat(path)
	if st then
		if st.type == "link" then
			return nil, path .. ": refusing to write through a symbolic link"
		end
		if st.type == "dir" then
			return nil, path .. ": is a directory"
		end
	elseif err and err ~= "no such file or directory" then
		return nil, err
	end
	local dir = dirOf(path)
	local tmp, terr = u.createExclusive(dir, ".authdb-")
	if not tmp then
		return nil, terr
	end
	local ok, werr = u.writeFile(tmp, text)
	if not ok then
		u.unlink(tmp)
		return nil, tostring(werr)
	end
	local cok, cerr = u.chmod(tmp, mode or 384)
	if not cok then
		u.unlink(tmp)
		return nil, tostring(cerr)
	end
	local rok, rerr = u.renameRaw(tmp, path)
	if not rok then
		u.unlink(tmp)
		return nil, tostring(rerr)
	end
	return true
end

function A.save(plan)
	local old = {}
	for i, item in ipairs(plan) do
		local data = u.readFile(item.path)
		old[i] = data
		if data and data ~= "" then
			local bmode = (item.path == A.MASTER) and 384 or 420
			local ok, err = A.writeAtomic(item.path .. ".old", data, bmode)
			if not ok then
				return nil, err
			end
		end
	end
	local done = {}
	for i, item in ipairs(plan) do
		local ok, err = A.writeAtomic(item.path, item.text, item.mode)
		if not ok then
			for j = #done, 1, -1 do
				A.writeAtomic(plan[done[j]].path, old[done[j]] or "", plan[done[j]].mode)
			end
			return nil, err
		end
		done[#done + 1] = i
	end
	for i, item in ipairs(plan) do
		if (u.readFile(item.path) or "") ~= item.text then
			for j = #done, 1, -1 do
				A.writeAtomic(plan[done[j]].path, old[done[j]] or "", plan[done[j]].mode)
			end
			return nil, item.path .. ": verification failed"
		end
	end
	return true
end

function A.loadUsers()
	local ptext = u.readFile(A.PASSWD)
	local mtext = u.readFile(A.MASTER)
	if not ptext then
		return nil, nil, nil, nil, A.PASSWD .. ": cannot read"
	end
	if not mtext then
		return nil, nil, nil, nil, A.MASTER .. ": cannot read"
	end
	local prows, perr = A.parseUsers(ptext)
	local mrows, merr = A.parseUsers(mtext)
	if #perr > 0 then
		return nil, nil, nil, nil, perr[1]
	end
	if #merr > 0 then
		return nil, nil, nil, nil, merr[1]
	end
	return prows, mrows, ptext, mtext
end

local function userPlan(prows, mrows)
	local perrs = A.validateUsers(prows)
	if #perrs > 0 then
		return nil, perrs
	end
	local merrs = A.validateUsers(mrows)
	if #merrs > 0 then
		return nil, merrs
	end
	return {
		{ path = A.MASTER, text = A.serialize(mrows), mode = 384 },
		{ path = A.PASSWD, text = A.serialize(prows), mode = 420 },
	}
end

function A.updateUser(name, fields)
	local prows, mrows, _, _, err = A.loadUsers()
	if not prows then
		return nil, err
	end
	local p = A.findUser(prows, name)
	local m = A.findUser(mrows, name)
	if not p or not m then
		return nil, name .. ": no such user"
	end
	if fields.uid then
		p[3], m[3] = tostring(fields.uid), tostring(fields.uid)
	end
	if fields.gid then
		p[4], m[4] = tostring(fields.gid), tostring(fields.gid)
	end
	if fields.gecos then
		p[5], m[5] = fields.gecos, fields.gecos
	end
	if fields.home then
		p[6], m[6] = fields.home, fields.home
	end
	if fields.shell then
		p[7], m[7] = fields.shell, fields.shell
	end
	local plan, perrs = userPlan(prows, mrows)
	if not plan then
		return nil, perrs[1]
	end
	local ok, serr = A.save(plan)
	if not ok then
		return nil, serr
	end
	return true
end

function A.addUser(prow, mrow)
	local prows, mrows, _, _, err = A.loadUsers()
	if not prows then
		return nil, err
	end
	if A.findUser(prows, prow[1]) or A.findUser(mrows, prow[1]) then
		return nil, prow[1] .. ": user already exists"
	end
	prows[#prows + 1] = prow
	mrows[#mrows + 1] = mrow
	local plan, perrs = userPlan(prows, mrows)
	if not plan then
		return nil, perrs[1]
	end
	local ok, serr = A.save(plan)
	if not ok then
		return nil, serr
	end
	return true
end

function A.removeUser(name)
	local prows, mrows, _, _, err = A.loadUsers()
	if not prows then
		return nil, err
	end
	local _, pi = A.findUser(prows, name)
	local _, mi = A.findUser(mrows, name)
	if not pi and not mi then
		return nil, name .. ": no such user"
	end
	if pi then
		table.remove(prows, pi)
	end
	if mi then
		table.remove(mrows, mi)
	end
	local plan, perrs = userPlan(prows, mrows)
	if not plan then
		return nil, perrs[1]
	end
	local ok, serr = A.save(plan)
	if not ok then
		return nil, serr
	end
	return true
end

function A.checkUsers()
	local prows, mrows, _, _, err = A.loadUsers()
	if not prows then
		return { err }
	end
	local errs = {}
	for _, e in ipairs(A.validateUsers(prows)) do
		errs[#errs + 1] = "passwd: " .. e
	end
	for _, e in ipairs(A.validateUsers(mrows)) do
		errs[#errs + 1] = "master.passwd: " .. e
	end
	local byName = {}
	for _, m in ipairs(mrows) do
		byName[m[1]] = m
	end
	for _, p in ipairs(prows) do
		local m = byName[p[1]]
		if not m then
			errs[#errs + 1] = p[1] .. ": has no master.passwd entry (cannot authenticate)"
		else
			for _, i in ipairs({ 3, 4, 6, 7 }) do
				if p[i] ~= m[i] then
					errs[#errs + 1] = p[1] .. ": passwd and master.passwd disagree in field " .. i
					break
				end
			end
		end
		if p[2] ~= "*" then
			errs[#errs + 1] = p[1] .. ": public password field is not '*'"
		end
	end
	local seen = {}
	for _, p in ipairs(prows) do
		seen[p[1]] = true
	end
	for _, m in ipairs(mrows) do
		if not seen[m[1]] then
			errs[#errs + 1] = m[1] .. ": master.passwd entry has no passwd entry"
		end
	end
	return errs
end

function A.shellRequestPath(user)
	return A.CHSH .. "/" .. user
end
function A.shellResultPath(user)
	return A.CHSHRESULT .. "/" .. user
end

function A.queueShellChange(user, shell, token)
	for _, d in ipairs({ "/var/auth", A.CHSH }) do
		local st, err = u.lstat(d)
		if not st then
			return nil, d .. ": " .. tostring(err or "missing") .. " (cron(8) prepares this queue)"
		end
		if st.type ~= "dir" then
			return nil, d .. ": not a directory"
		end
	end
	if not u.access(A.CHSH, "w") or not u.access(A.CHSH, "x") then
		return nil, A.CHSH .. ": not writable (cron(8) prepares this queue)"
	end
	local slot = A.shellRequestPath(user)
	local sst = u.lstat(slot)
	if sst and sst.uid ~= u.getUid() then
		return nil, slot .. ": reserved slot is owned by uid " .. tostring(sst.uid) .. "; ask root to remove it"
	end
	token = token or u.randomName(12)
	local tmp, terr = u.createExclusive(A.CHSH, ".req-")
	if not tmp then
		return nil, terr
	end
	local wok, werr = u.writeFile(tmp, token .. " " .. shell .. "\n")
	if not wok then
		u.unlink(tmp)
		return nil, werr
	end
	u.chmod(tmp, 384)
	local rok, rerr = u.renameRaw(tmp, A.shellRequestPath(user))
	if not rok then
		u.unlink(tmp)
		return nil, rerr
	end
	return true, token
end

local function writeResult(user, uid, text)
	A.ensureDir("/var/auth", 493, 0, 0)
	A.ensureDir(A.CHSHRESULT, 493, 0, 0)
	local tmp, terr = u.createExclusive(A.CHSHRESULT, ".res-")
	if not tmp then
		return nil, terr
	end
	local ok, err = u.writeFile(tmp, text)
	if not ok then
		u.unlink(tmp)
		return nil, err
	end
	u.chmod(tmp, 384)
	u.chown(tmp, uid, uid)
	local rok, rerr = u.renameRaw(tmp, A.shellResultPath(user))
	if not rok then
		u.unlink(tmp)
		return nil, rerr
	end
	return true
end

local function validRequestFile(path, user)
	local st, err = u.lstat(path)
	if not st then
		return nil, err
	end
	if st.type ~= "file" then
		return nil, "not a regular file"
	end
	if st.uid ~= user.id then
		return nil, "owned by uid " .. tostring(st.uid) .. ", not " .. user.name
	end
	if (st.mode or 0) % 64 ~= 0 then
		return nil, string.format("mode 0%o grants group/other access", st.mode or 0)
	end
	if st.size and st.size > 256 then
		return nil, "request too large"
	end
	return st
end

local function shellUsable(shell)
	if not A.validShellPath(shell) then
		return nil, "not an absolute shell path"
	end
	local st = u.stat(shell)
	if not st or st.type ~= "file" then
		return nil, "no such shell"
	end
	if not u.access(shell, "x") then
		return nil, "shell is not executable"
	end
	return true
end
A.shellUsable = shellUsable

local function resetSlot(path, user)
	if u.writeFile(path, "") then
		u.chmod(path, 384)
		u.chown(path, user.id, user.groups[1])
		return true
	end
	pcall(u.unlink, path)
	return false
end

function A.applyShellRequests()
	local names = u.readdir(A.CHSH)
	if not names then
		return 0
	end
	local applied, seen = 0, 0
	for _, name in ipairs(names) do
		if seen >= 32 then
			break
		end
		if name ~= "." and name ~= ".." and name:sub(1, 1) ~= "." then
			seen = seen + 1
			local path = A.CHSH .. "/" .. name
			local user = user.byName(name)
			local st, verr
			if not user then
				verr = "no such user"
			else
				st, verr = validRequestFile(path, user)
			end
			if not st then
				A.authlog("chsh request " .. path .. " rejected: " .. tostring(verr or "bad request"))
				if user then
					writeResult(name, user.id, "error: " .. tostring(verr) .. "\n")
				end
				pcall(u.unlink, path)
			elseif st.size == 0 then
			else
				local data = u.readFile(path) or ""
				local token, shell = data:match("^%s*(%S+)%s+(%S+)%s*$")
				local okc, cerr
				if not token or #token > 32 or not token:match("^[A-Za-z0-9]+$") then
					okc, cerr = nil, "malformed request"
				else
					okc, cerr = shellUsable(shell)
				end
				if not okc then
					A.authlog("chsh request " .. path .. " rejected: " .. tostring(cerr))
					writeResult(name, user.id, tostring(token or "-") .. " error: " .. tostring(cerr) .. "\n")
					resetSlot(path, user)
				else
					local res, rerr = A.withLock(function()
						return A.updateUser(name, { shell = shell })
					end)
					if res then
						A.authlog("chsh changed shell for " .. name .. " to " .. shell .. " (queued request)")
						writeResult(name, user.id, token .. " ok\n")
						resetSlot(path, user)
						applied = applied + 1
					else
						writeResult(name, user.id, token .. " error: " .. tostring(rerr) .. "\n")
						A.authlog("chsh request " .. path .. " failed: " .. tostring(rerr))
						resetSlot(path, user)
					end
				end
			end
		end
	end
	return applied
end

return A
