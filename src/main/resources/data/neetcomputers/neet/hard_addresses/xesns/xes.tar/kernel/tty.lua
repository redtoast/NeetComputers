local K = ...

local TTY = {}
TTY.__index = TTY
K.TTY = TTY
K.ttys = {}
K.extrattys = {}
K.tty_active = nil
K.gfx_dirty = false
K.gfx = nil
K.gfxfont = nil

local WHITE, BLACK = 0xFFFFFF, 0x000000
K.WHITE, K.BLACK = WHITE, BLACK

TTY.SCROLLBACK_MAX = 256

function K.rgb(r, g, b)
	return (r << 16) | (g << 8) | b
end

function K.unrgb(c)
	return (c >> 16) & 255, (c >> 8) & 255, c & 255
end

local function newRow(cols, bg)
	local ch, fg, bgr = {}, {}, {}
	for x = 1, cols do
		ch[x] = 32
		fg[x] = WHITE
		bgr[x] = bg
	end
	return { ch = ch, fg = fg, bg = bgr, dmin = 1, dmax = cols }
end

local function rowToText(row, cols)
	local t = {}
	local ch = row and row.ch
	for x = 1, cols do
		local c = ch and ch[x]
		if type(c) ~= "number" then
			t[x] = " "
		else
			t[x] = (c >= 32 and c < 127) and string.char(c) or (c >= 127 and "?" or " ")
		end
	end
	return (table.concat(t):gsub("%s+$", ""))
end

function TTY.new(name, font, surface)
	local W, H = screen.getSize()
	if surface then
		W, H = surface.getSize()
	end
	local cols, rows = W // font.cellW, H // font.cellH
	local t = setmetatable({
		name = name,
		font = font,
		surface = surface,
		cols = cols,
		rows = rows,
		cx = 1,
		cy = 1,
		pendingScroll = 0,
		needFull = true,
		blinkOn = true,
		blinkVisible = true,
		lastBlink = K.monotonic(),
		cursorHidden = false,
		curX = nil,
		curY = nil,
		fgpid = nil,
		session = nil,
		ansi = true,
		sgrFg = nil,
		sgrBg = nil,
		sgrBright = false,
		sgrFgBoldable = nil,
		sgrBgBoldable = nil,
		scrollback = {},
		view = 0,
	}, TTY)
	t.rowsd = {}
	for y = 1, rows do
		t.rowsd[y] = newRow(cols, BLACK)
	end
	return t
end

local function mark(row, x1, x2)
	if not row.dmin or x1 < row.dmin then
		row.dmin = x1
	end
	if not row.dmax or x2 > row.dmax then
		row.dmax = x2
	end
end

local function snapRow(row, cols)
	local ch, fg, bg = {}, {}, {}
	for x = 1, cols do
		ch[x] = row.ch[x]
		fg[x] = row.fg[x]
		bg[x] = row.bg[x]
	end
	return { ch = ch, fg = fg, bg = bg }
end

function TTY:resetView()
	if self.view ~= 0 then
		self.view = 0
		self.needFull = true
		self.pendingScroll = 0
	end
end

function TTY:scrollView(n)
	if n == 0 then
		return self.view
	end
	local v = self.view + n
	if v < 0 then
		v = 0
	end
	local max = #self.scrollback
	if v > max then
		v = max
	end
	if v ~= self.view then
		self.view = v
		self.needFull = true
		self.pendingScroll = 0
		K.tty_dirty = true
	end
	return self.view
end

function TTY:getSize()
	return self.cols, self.rows
end

function TTY:clearRaw()
	self.rawpid, self.rawpgid = nil, nil
end

function TTY:rawActive()
	local pid = self.rawpid
	if not pid then
		return false
	end
	local p = K.procs and K.procs[pid]
	if not p or p.state == "Z" or p.tty ~= self or (self.fgpgid and p.pgid ~= self.fgpgid) then
		self:clearRaw()
		return false
	end
	return true
end

function TTY:isRaw()
	return self:rawActive()
end

function TTY:inputPgid()
	if self.fgpgid then
		return self.fgpgid
	end
	local lead = self.session and K.procs[self.session]
	if lead and lead.state ~= "Z" and lead.tty == self then
		return lead.pgid
	end
	return nil
end

function TTY:releaseForeground(p)
	if not p or self.fgpgid == nil or self.fgpgid ~= p.pgid then
		return
	end
	for _, q in pairs(K.procs or {}) do
		if q ~= p and q.state ~= "Z" and q.tty == self and q.pgid == p.pgid then
			return
		end
	end
	local lead = self.session and K.procs[self.session]
	if lead and lead.state ~= "Z" and lead.tty == self then
		self.fgpgid = lead.pgid
	else
		self.fgpgid = nil
	end
end

function TTY:ownsForeground(p)
	if self.fgpgid == p.pgid then
		return true
	end
	return self.fgpgid == nil and self.session ~= nil and p.sid == self.session
end

function TTY:setRaw(p, on)
	if not p or p.tty ~= self or self == K.nulltty then
		return nil, "ENODEV", "no terminal"
	end
	if not self:ownsForeground(p) then
		return nil, "EPERM", "not the foreground terminal"
	end
	if on then
		self.rawpid, self.rawpgid = p.pid, p.pgid
	else
		if self:rawActive() and self.rawpid ~= p.pid and self.rawpgid ~= p.pgid then
			return nil, "EPERM", "raw mode is owned by another process group"
		end
		self:clearRaw()
	end
	return true
end

function TTY:inputPending(p)
	p = p or K.current
	if self.pending and #self.pending > 0 then
		if not p or not self.fgpgid or p.pgid == self.fgpgid then
			return true
		end
	end
	if not p then
		for _, q in pairs(K.procs or {}) do
			if q.tty == self and q.state ~= "Z" and q.eh and q.eh <= q.et then
				return true
			end
		end
		return false
	end
	return p.eh ~= nil and p.eh <= p.et
end

local function fitRow(row, cols)
	if type(row) ~= "table" then
		return row
	end
	local nch, nfg, nbg = {}, {}, {}
	for x = 1, cols do
		nch[x] = row.ch[x] or 32
		nfg[x] = row.fg[x] or WHITE
		nbg[x] = row.bg[x] or BLACK
	end
	row.ch, row.fg, row.bg = nch, nfg, nbg
	return row
end

function TTY:resize(surface)
	local W, H = surface.getSize()
	local oldcols, oldrows = self.cols, self.rows
	local cw, chh = self.font.cellW, self.font.cellH
	local cols = math.max(1, W // cw)
	local rows = math.max(1, H // chh)
	if cols ~= self.cols then
		for y = 1, self.rows do
			fitRow(self.rowsd[y], cols)
		end
		for _, row in ipairs(self.scrollback) do
			fitRow(row, cols)
		end
		self.cols = cols
	end
	if rows > self.rows then
		for y = self.rows + 1, rows do
			self.rowsd[y] = newRow(cols, BLACK)
		end
	elseif rows < self.rows then
		for y = rows + 1, self.rows do
			self.rowsd[y] = nil
		end
	end
	self.rows = rows
	self.surface = surface
	self.cx = math.min(math.max(self.cx, 1), self.cols)
	self.cy = math.min(math.max(self.cy, 1), self.rows)
	self.curX, self.curY = nil, nil
	self.view = 0
	self.needFull = true
	self.pendingScroll = 0
	if self.cols ~= oldcols or self.rows ~= oldrows then
		K.tty_notifyResize(self, self.cols, self.rows)
	end
	return self.cols, self.rows
end

function K.tty_notifyResize(t, cols, rows)
	if not t or t == K.nulltty then
		return
	end
	for _, p in pairs(K.procs or {}) do
		if
			p.state ~= "Z"
			and ((t.fgpgid and p.tty == t and p.pgid == t.fgpgid) or p.pid == t.owner)
		then
			K.pushEvent(p, "resize", cols, rows)
		end
	end
end

function K.ready.tty(fd, writing)
	if writing then
		return true
	end
	local t = fd and fd.tty
	if not t then
		return false, "EBADF"
	end
	return t:inputPending(K.current)
end

function TTY:getCursorPos()
	return self.cx, self.cy
end

function TTY:setCursorPos(x, y)
	self.cx, self.cy = x, y
end

function TTY:write(text, fg, bg)
	self:resetView()
	local cy, cx = self.cy, self.cx
	local row = self.rowsd[cy]
	local n = #text
	if row and n > 0 and cx <= self.cols and cx + n - 1 >= 1 then
		local a, b = math.max(1, cx), math.min(self.cols, cx + n - 1)
		local ch, fgr, bgr = row.ch, row.fg, row.bg
		for x = a, b do
			local c = text:byte(x - cx + 1)
			if ch[x] ~= c or fgr[x] ~= fg or bgr[x] ~= bg then
				ch[x], fgr[x], bgr[x] = c, fg, bg
				mark(row, x, x)
			end
		end
	end
	self.cx = cx + n
end

function TTY:clear(bg)
	self:resetView()
	for y = 1, self.rows do
		local row = self.rowsd[y]
		local ch, fgr, bgr = row.ch, row.fg, row.bg
		for x = 1, self.cols do
			ch[x] = 32
			fgr[x] = WHITE
			bgr[x] = bg
		end
		row.dmin, row.dmax = 1, self.cols
	end
	self.pendingScroll = 0
	self.needFull = true
end

function TTY:clearLine(bg)
	self:resetView()
	local row = self.rowsd[self.cy]
	if not row then
		return
	end
	local ch, fgr, bgr = row.ch, row.fg, row.bg
	for x = 1, self.cols do
		ch[x] = 32
		fgr[x] = WHITE
		bgr[x] = bg
	end
	row.dmin, row.dmax = 1, self.cols
end

function TTY:scroll(n, bg)
	if n == 0 then
		return
	end
	self:resetView()
	if self.curX and self.rowsd[self.curY] then
		mark(self.rowsd[self.curY], self.curX, self.curX)
	end
	self.curX = nil
	local rows = self.rows
	if n >= rows or -n >= rows then
		return self:clear(bg)
	end
	local rd = self.rowsd
	if n > 0 then
		for _ = 1, n do
			local r = table.remove(rd, 1)
			if #self.scrollback >= TTY.SCROLLBACK_MAX then
				table.remove(self.scrollback, 1)
			end
			self.scrollback[#self.scrollback + 1] = snapRow(r, self.cols)
			local ch, fgr, bgr = r.ch, r.fg, r.bg
			for x = 1, self.cols do
				ch[x] = 32
				fgr[x] = WHITE
				bgr[x] = bg
			end
			r.dmin, r.dmax = 1, self.cols
			rd[#rd + 1] = r
		end
	else
		for _ = 1, -n do
			local r = table.remove(rd)
			local ch, fgr, bgr = r.ch, r.fg, r.bg
			for x = 1, self.cols do
				ch[x] = 32
				fgr[x] = WHITE
				bgr[x] = bg
			end
			r.dmin, r.dmax = 1, self.cols
			table.insert(rd, 1, r)
		end
	end
	if not self.needFull then
		self.pendingScroll = self.pendingScroll + n
		if self.pendingScroll >= rows or -self.pendingScroll >= rows then
			self.needFull = true
			self.pendingScroll = 0
		end
	end
end

local function clampCursor(self)
	if self.cx < 1 then
		self.cx = 1
	elseif self.cx > self.cols then
		self.cx = self.cols
	end
	if self.cy < 1 then
		self.cy = 1
	elseif self.cy > self.rows then
		self.cy = self.rows
	end
end

local function newline(self, bg)
	self.cx = 1
	self.cy = self.cy + 1
	if self.cy > self.rows then
		self:scroll(1, bg)
		self.cy = self.rows
	end
end

function TTY:printText(text, fg, bg, final)
	self:resetView()
	if self.cx < 1 or self.cx > self.cols or self.cy < 1 or self.cy > self.rows then
		clampCursor(self)
	end
	local cols = self.cols
	local i, n = 1, #text
	while i <= n do
		local c = text:byte(i)
		if c == 27 and self.ansi then
			i = self:doEscape(text, i, bg)
		elseif c == 10 then
			newline(self, bg)
			i = i + 1
		elseif c == 13 then
			self.cx = 1
			i = i + 1
		elseif c == 8 then
			if self.cx > 1 then
				self.cx = self.cx - 1
			end
			i = i + 1
		elseif c == 7 then
			i = i + 1
		else
			if self.cx > cols then
				newline(self, bg)
			end
			local efg, ebg = self.sgrFg or fg, self.sgrBg or bg
			local room = cols - self.cx + 1
			local j = i
			local run = {}
			local used = 0
			while j <= n and used < room do
				local d = text:byte(j)
				if d == 10 or d == 13 or d == 8 or d == 7 or (d == 27 and self.ansi) then
					break
				end
				if d == 9 then
					local stop = 8 - ((self.cx + used - 1) % 8)
					local k = 0
					while k < stop and used < room do
						used = used + 1
						run[used] = 32
						k = k + 1
					end
				else
					used = used + 1
					run[used] = d
				end
				j = j + 1
			end
			local row = self.rowsd[self.cy]
			local ch, fgr, bgr = row.ch, row.fg, row.bg
			local x0 = self.cx
			for k = 1, used do
				local x = x0 + k - 1
				local v = run[k]
				if ch[x] ~= v or fgr[x] ~= efg or bgr[x] ~= ebg then
					ch[x], fgr[x], bgr[x] = v, efg, ebg
					mark(row, x, x)
				end
			end
			self.cx = x0 + used
			i = j
		end
	end
	if final then
		newline(self, bg)
	end
end

function TTY:print(text, fg, bg)
	self:printText(text, fg, bg, true)
end

function TTY:rowText(y)
	local row = self.rowsd[y]
	if not row then
		return ""
	end
	return rowToText(row, self.cols)
end

function TTY:viewText(y1, y2)
	local S = #self.scrollback
	local out = {}
	for y = y1, y2 do
		local idx = S + y - self.view
		local src = idx <= S and self.scrollback[idx] or self.rowsd[idx - S]
		if type(src) ~= "table" then
			out[#out + 1] = ""
		else
			out[#out + 1] = rowToText(src, self.cols)
		end
	end
	return table.concat(out, "\n")
end

function TTY:getScrollback(n)
	n = n or #self.scrollback
	local out = {}
	for i = math.max(1, #self.scrollback - n + 1), #self.scrollback do
		local e = self.scrollback[i]
		out[#out + 1] = type(e) == "string" and e or rowToText(e, self.cols)
	end
	return out
end

local ANSI_BASE = { 0x000000, 0xAA0000, 0x00AA00, 0xAA5500, 0x0000AA, 0xAA00AA, 0x00AAAA, 0xAAAAAA }
local ANSI_BRIGHT = { 0x555555, 0xFF5555, 0x55FF55, 0xFFFF55, 0x5555FF, 0xFF55FF, 0x55FFFF, 0xFFFFFF }

local function xterm256(n)
	if n < 0 or n > 255 then
		return nil
	end
	if n < 8 then
		return ANSI_BASE[n + 1]
	end
	if n < 16 then
		return ANSI_BRIGHT[n - 7]
	end
	if n < 232 then
		local m = n - 16
		local r = (m // 36) % 6
		local g = (m // 6) % 6
		local b = m % 6
		local function comp(x)
			if x == 0 then
				return 0
			end
			return 95 + 40 * (x - 1)
		end
		return (comp(r) << 16) | (comp(g) << 8) | comp(b)
	end
	local g = 8 + 10 * (n - 232)
	return (g << 16) | (g << 8) | g
end

function TTY:doCsi(params, final, bg)
	if final == "m" then
		local nums = {}
		if params == "" then
			nums[1] = 0
		else
			for tok in (params .. ";"):gmatch("([^;]*);") do
				nums[#nums + 1] = tonumber(tok) or 0
			end
		end
		local i = 1
		while i <= #nums do
			local p = nums[i]
			if p == 0 then
				self.sgrFg, self.sgrBg, self.sgrBright = nil, nil, false
				self.sgrFgBoldable, self.sgrBgBoldable = nil, nil
			elseif p == 1 then
				self.sgrBright = true
				if self.sgrFgBoldable then
					for b = 1, 8 do
						if self.sgrFg == ANSI_BASE[b] then
							self.sgrFg = ANSI_BRIGHT[b]
							break
						end
					end
				end
				if self.sgrBgBoldable then
					for b = 1, 8 do
						if self.sgrBg == ANSI_BASE[b] then
							self.sgrBg = ANSI_BRIGHT[b]
							break
						end
					end
				end
			elseif p == 22 then
				self.sgrBright = false
			elseif p >= 30 and p <= 37 then
				self.sgrFg = (self.sgrBright and ANSI_BRIGHT or ANSI_BASE)[p - 29]
				self.sgrFgBoldable = true
			elseif p >= 90 and p <= 97 then
				self.sgrFg = ANSI_BRIGHT[p - 89]
				self.sgrFgBoldable = false
			elseif p == 39 then
				self.sgrFg = nil
				self.sgrFgBoldable = nil
			elseif p >= 40 and p <= 47 then
				self.sgrBg = (self.sgrBright and ANSI_BRIGHT or ANSI_BASE)[p - 39]
				self.sgrBgBoldable = true
			elseif p >= 100 and p <= 107 then
				self.sgrBg = ANSI_BRIGHT[p - 99]
				self.sgrBgBoldable = false
			elseif p == 49 then
				self.sgrBg = nil
				self.sgrBgBoldable = nil
			elseif p == 38 or p == 48 then
				local isFg = (p == 38)
				local mode = nums[i + 1]
				if mode == 5 then
					local n = nums[i + 2]
					if n ~= nil and n >= 0 and n <= 255 then
						local c = xterm256(n)
						if isFg then
							self.sgrFg = c
						else
							self.sgrBg = c
						end
					end
					if isFg then
						self.sgrFgBoldable = false
					else
						self.sgrBgBoldable = false
					end
					i = i + 2
				elseif mode == 2 then
					local r, g, b = nums[i + 2], nums[i + 3], nums[i + 4]
					if r ~= nil and g ~= nil and b ~= nil then
						local c = K.rgb(
							math.max(0, math.min(255, r)),
							math.max(0, math.min(255, g)),
							math.max(0, math.min(255, b))
						)
						if isFg then
							self.sgrFg = c
						else
							self.sgrBg = c
						end
					end
					if isFg then
						self.sgrFgBoldable = false
					else
						self.sgrBgBoldable = false
					end
					i = i + 4
				end
			end
			i = i + 1
		end
	elseif final == "A" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cy = math.max(1, self.cy - n)
	elseif final == "B" or final == "e" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cy = math.min(self.rows, self.cy + n)
	elseif final == "C" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cx = math.min(self.cols, self.cx + n)
	elseif final == "D" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cx = math.max(1, self.cx - n)
	elseif final == "E" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cx = 1
		self.cy = math.min(self.rows, self.cy + n)
	elseif final == "F" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cx = 1
		self.cy = math.max(1, self.cy - n)
	elseif final == "G" or final == "`" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cx = math.max(1, math.min(self.cols, n))
	elseif final == "d" then
		local n = tonumber(params) or 1
		if n < 1 then
			n = 1
		end
		self.cy = math.max(1, math.min(self.rows, n))
	elseif final == "H" or final == "f" then
		local row, col = params:match("^(%d*);?(%d*)$")
		if row == nil then
			row, col = "", ""
		end
		local r = tonumber(row) or 1
		local c = tonumber(col) or 1
		if r < 1 then
			r = 1
		end
		if c < 1 then
			c = 1
		end
		self.cy = math.max(1, math.min(self.rows, r))
		self.cx = math.max(1, math.min(self.cols, c))
	elseif final == "J" then
		local p = tonumber(params) or 0
		if p == 2 then
			self:clear(bg)
		elseif p == 3 then
			self:clear(bg)
			self.scrollback = {}
		elseif p == 1 then
			local row = self.rowsd[self.cy]
			for y = 1, self.cy - 1 do
				local r = self.rowsd[y]
				if r then
					for x = 1, self.cols do
						r.ch[x] = 32
						r.fg[x] = WHITE
						r.bg[x] = bg
					end
					r.dmin, r.dmax = 1, self.cols
				end
			end
			if row then
				for x = 1, self.cx do
					row.ch[x] = 32
					row.fg[x] = WHITE
					row.bg[x] = bg
				end
				mark(row, 1, self.cx)
			end
		else
			local row = self.rowsd[self.cy]
			if row then
				for x = self.cx, self.cols do
					row.ch[x] = 32
					row.fg[x] = WHITE
					row.bg[x] = bg
				end
				mark(row, self.cx, self.cols)
			end
			for y = self.cy + 1, self.rows do
				local r = self.rowsd[y]
				if r then
					for x = 1, self.cols do
						r.ch[x] = 32
						r.fg[x] = WHITE
						r.bg[x] = bg
					end
					r.dmin, r.dmax = 1, self.cols
				end
			end
		end
		if p == 3 then
			self.scrollback = {}
		end
	elseif final == "K" then
		local p = tonumber(params) or 0
		local row = self.rowsd[self.cy]
		if row then
			local a, b
			if p == 1 then
				a, b = 1, self.cx
			elseif p == 2 then
				a, b = 1, self.cols
			else
				a, b = self.cx, self.cols
			end
			a = math.max(1, a)
			b = math.min(self.cols, b)
			if b >= a then
				for x = a, b do
					row.ch[x] = 32
					row.fg[x] = WHITE
					row.bg[x] = bg
				end
				mark(row, a, b)
			end
		end
	elseif final == "h" or final == "l" then
		local show = (final == "h")
		for tok in (params .. ";"):gmatch("([^;]*);") do
			if tok == "?25" then
				self.cursorHidden = not show
			end
		end
	end
end

function TTY:doEscape(text, i, bg)
	if text:byte(i + 1) == 91 then
		local j = i + 2
		while j <= #text do
			local b = text:byte(j)
			if b >= 64 and b <= 126 then
				self:doCsi(text:sub(i + 2, j - 1), string.char(b), bg)
				return j + 1
			elseif not (b >= 48 and b <= 57 or b == 59 or b == 63) then
				return j + 1
			end
			j = j + 1
		end
		return #text + 1
	end
	return math.min(i + 2, #text + 1)
end

function TTY:dump()
	local out = {}
	local last = 0
	for y = 1, self.rows do
		out[y] = self:rowText(y)
		if out[y] ~= "" then
			last = y
		end
	end
	return table.concat(out, "\n", 1, math.max(last, 1)) .. "\n"
end

function K.tty_show(t)
	K.tty_active = t
	t.needFull = true
	t.pendingScroll = 0
	t.curX = nil
	K.tty_dirty = true
end

function TTY:paint(force)
	local font = self.font
	local gfx = self.surface or screen
	local cw, chh = font.cellW, font.cellH
	local rd = self.rowsd
	local changed = false

	if force then
		self.needFull = true
	end

	if self.curX then
		local row = rd[self.curY]
		if row then
			mark(row, self.curX, self.curX)
		end
		self.curX = nil
	end

	if self.view ~= 0 then
		self.pendingScroll = 0
		self.needFull = false
		for y = 1, self.rows do
			local row = rd[y]
			if row then
				row.dmin, row.dmax = nil, nil
			end
		end
		local S, k = #self.scrollback, self.view
		local writeData = gfx.writeData
		for y = 1, self.rows do
			local idx = S + y - k
			local src = idx <= S and self.scrollback[idx] or rd[idx - S]
			local py = (y - 1) * chh
			if type(src) ~= "table" then
				src = nil
			end
			local ch, fgr, bgr = src and src.ch, src and src.fg, src and src.bg
			for x = 1, self.cols do
				local c = ch and ch[x]
				local fg = fgr and fgr[x]
				local bg = bgr and bgr[x]
				if type(c) ~= "number" then
					c = 32
				end
				if type(fg) ~= "number" then
					fg = WHITE
				end
				if type(bg) ~= "number" then
					bg = BLACK
				end
				writeData((x - 1) * cw, py, font:cell(c, fg, bg), cw)
			end
		end
		return true
	end

	if self.needFull then
		for y = 1, self.rows do
			if rd[y] then
				mark(rd[y], 1, self.cols)
			end
		end
		self.needFull, self.pendingScroll = false, 0
		changed = true
	elseif self.pendingScroll ~= 0 then
		local n = self.pendingScroll
		local W = self.cols * cw
		local H = self.rows * chh
		if n > 0 then
			local data = gfx.readData(0, n * chh, W - 1, H - 1)
			gfx.writeData(0, 0, data, W)
		else
			local data = gfx.readData(0, 0, W - 1, H + n * chh - 1)
			gfx.writeData(0, -n * chh, data, W)
		end
		self.pendingScroll = 0
		changed = true
	end

	local writeData = gfx.writeData
	for y = 1, self.rows do
		local row = rd[y]
		if row then
			local a = row.dmin
			if a then
				changed = true
				local b = row.dmax
				if type(a) ~= "number" or a < 1 then
					a = 1
				end
				if type(b) ~= "number" or b > self.cols then
					b = self.cols
				end
				local py = (y - 1) * chh
				local ch, fgr, bgr = row.ch, row.fg, row.bg
				for x = a, b do
					local c = ch and ch[x]
					local fg = fgr and fgr[x]
					local bg = bgr and bgr[x]
					if type(c) ~= "number" then
						c = 32
					end
					if type(fg) ~= "number" then
						fg = WHITE
					end
					if type(bg) ~= "number" then
						bg = BLACK
					end
					writeData((x - 1) * cw, py, font:cell(c, fg, bg), cw)
				end
				row.dmin, row.dmax = nil, nil
			end
		end
	end

	if
		self.blinkOn
		and self.blinkVisible
		and not self.cursorHidden
		and self.cx >= 1
		and self.cx <= self.cols
		and self.cy >= 1
		and self.cy <= self.rows
	then
		local px, py = (self.cx - 1) * cw, (self.cy - 1) * chh
		local currow = rd[self.cy]
		local fg = currow and currow.fg and currow.fg[self.cx]
		if type(fg) ~= "number" then
			fg = WHITE
		end
		local r, g, b = K.unrgb(fg == BLACK and WHITE or fg)
		gfx.fill(px, py + chh - 2, px + cw - 1, py + chh - 1, r, g, b, 255)
		self.curX, self.curY = self.cx, self.cy
		changed = true
	end
	return changed
end

function K.tty_flush_one(t, force)
	if not t then
		return
	end
	if K.gfx and not t.surface then
		return
	end
	do
		local rd, rows, bad = t.rowsd, t.rows, 0
		for y = 1, rows do
			if rd[y] == nil then
				rd[y] = newRow(t.cols, BLACK)
				bad = bad + 1
			end
		end
		local extra = #rd - rows
		if extra > 0 then
			for y = #rd, rows + 1, -1 do
				rd[y] = nil
			end
			bad = bad + extra
		end
		if bad > 0 then
			K.klog(
				"tty %s rowsd short: rows=%s missing=%s cx=%s cy=%s fgpgid=%s needFull=%s pendingScroll=%s nprocs=%s",
				tostring(t.name),
				tostring(rows),
				tostring(bad),
				tostring(t.cx),
				tostring(t.cy),
				tostring(t.fgpgid),
				tostring(t.needFull),
				tostring(t.pendingScroll),
				tostring(K.nprocs())
			)
			t.needFull = true
		end
	end

	local now = K.monotonic()
	if t.blinkOn and now - t.lastBlink >= 0.5 then
		t.lastBlink = now
		t.blinkVisible = not t.blinkVisible
		if t.view == 0 then
			force = force or "blink"
		end
	end
	if t.curX and (t.cx ~= t.curX or t.cy ~= t.curY) then
		force = force or "cursor"
	end
	local dirty = force or K.tty_dirty
	if not dirty then
		if t.needFull or t.pendingScroll ~= 0 then
			dirty = true
		else
			for y = 1, t.rows do
				local r = t.rowsd[y]
				if r and r.dmin then
					dirty = true
					break
				end
			end
		end
	end
	if not dirty then
		return
	end
	K.tty_dirty = false
	if t:paint(force == true) then
		if t.surface then
			K.gfx_dirty = true
		else
			screen.draw()
		end
	end
end

function K.tty_flush(force)
	K.tty_flush_one(K.tty_active, force)
	if K.extrattys then
		for _, t in pairs(K.extrattys) do
			K.tty_flush_one(t, force)
		end
	end
end

function K.tty_kick(t)
	if not t then
		return
	end
	t.blinkVisible, t.lastBlink = true, K.monotonic()
end
