local K = ...

local TTY = {}
TTY.__index = TTY
K.TTY = TTY
K.ttys = {}
K.extrattys = {}
K.tty_active = nil
K.gfx_dirty = false
K.gfx = nil
K.gfxfont = nil

local WHITE, BLACK = 0xFFFFFF, 0x000000
K.WHITE, K.BLACK = WHITE, BLACK

TTY.SCROLLBACK_MAX = 256

function K.rgb(r, g, b) return (r << 16) | (g << 8) | b end

function K.unrgb(c) return (c >> 16) & 255, (c >> 8) & 255, c & 255 end

local function newRow(cols, bg)
    local ch, fg, bgr = {}, {}, {}
    for x = 1, cols do
        ch[x] = 32; fg[x] = WHITE; bgr[x] = bg
    end
    return { ch = ch, fg = fg, bg = bgr, dmin = 1, dmax = cols }
end

local function rowToText(row, cols)
    local t = {}
    for x = 1, cols do
        local c = row.ch[x]
        t[x] = (c >= 32 and c < 127) and string.char(c) or (c >= 127 and "?" or " ")
    end
    return (table.concat(t):gsub("%s+$", ""))
end

function TTY.new(name, font, surface)
    local W, H = screen.getSize()
    if surface then W, H = surface.getSize() end
    local cols, rows = W // font.cellW, H // font.cellH
    local t = setmetatable({
        name = name,
        font = font,
        surface = surface,
        cols = cols,
        rows = rows,
        cx = 1,
        cy = 1,
        pendingScroll = 0,
        needFull = true,
        blinkOn = true,
        blinkVisible = true,
        lastBlink = K.now(),
        cursorHidden = false,
        curX = nil,
        curY = nil,
        fgpid = nil,
        session = nil,
        ansi = true,
        sgrFg = nil,
        sgrBg = nil,
        sgrBright = false,
        scrollback = {},
        view = 0,
    }, TTY)
    t.rowsd = {}
    for y = 1, rows do t.rowsd[y] = newRow(cols, BLACK) end
    return t
end

local function mark(row, x1, x2)
    if not row.dmin or x1 < row.dmin then row.dmin = x1 end
    if not row.dmax or x2 > row.dmax then row.dmax = x2 end
end

local function snapRow(row, cols)
    local ch, fg, bg = {}, {}, {}
    for x = 1, cols do
        ch[x] = row.ch[x]; fg[x] = row.fg[x]; bg[x] = row.bg[x]
    end
    return { ch = ch, fg = fg, bg = bg }
end

function TTY:resetView()
    if self.view ~= 0 then
        self.view = 0
        self.needFull = true
        self.pendingScroll = 0
    end
end

function TTY:scrollView(n)
    if n == 0 then return self.view end
    local v = self.view + n
    if v < 0 then v = 0 end
    local max = #self.scrollback
    if v > max then v = max end
    if v ~= self.view then
        self.view = v
        self.needFull = true
        self.pendingScroll = 0
        K.tty_dirty = true
    end
    return self.view
end

function TTY:getSize() return self.cols, self.rows end

-- Rebind to a new surface and refit the grid, keeping whatever content
-- and cursor position still fits. Growing adds blank cells/rows; shrinking
-- drops cells on the right and rows at the bottom. Used when a terminal
-- window is resized so a maximised xterm reflows instead of letterboxing.
function TTY:resize(surface)
    local W, H = surface.getSize()
    local cw, chh = self.font.cellW, self.font.cellH
    local cols = math.max(1, W // cw)
    local rows = math.max(1, H // chh)
    if cols ~= self.cols then
        for y = 1, self.rows do
            local row = self.rowsd[y]
            if row then
                local nch, nfg, nbg = {}, {}, {}
                for x = 1, cols do
                    nch[x] = row.ch[x] or 32
                    nfg[x] = row.fg[x] or WHITE
                    nbg[x] = row.bg[x] or BLACK
                end
                row.ch, row.fg, row.bg = nch, nfg, nbg
            end
        end
        self.cols = cols
    end
    if rows > self.rows then
        for y = self.rows + 1, rows do self.rowsd[y] = newRow(cols, BLACK) end
    elseif rows < self.rows then
        for y = rows + 1, self.rows do self.rowsd[y] = nil end
    end
    self.rows = rows
    self.surface = surface
    self.cx = math.min(math.max(self.cx, 1), self.cols)
    self.cy = math.min(math.max(self.cy, 1), self.rows)
    self.curX, self.curY = nil, nil
    self.view = 0
    self.needFull = true
    self.pendingScroll = 0
    return self.cols, self.rows
end

function TTY:getCursorPos() return self.cx, self.cy end

function TTY:setCursorPos(x, y) self.cx, self.cy = x, y end

function TTY:write(text, fg, bg)
    self:resetView()
    local cy, cx = self.cy, self.cx
    local row = self.rowsd[cy]
    local n = #text
    if row and n > 0 and cx <= self.cols and cx + n - 1 >= 1 then
        local a, b = math.max(1, cx), math.min(self.cols, cx + n - 1)
        local ch, fgr, bgr = row.ch, row.fg, row.bg
        for x = a, b do
            local c = text:byte(x - cx + 1)
            if ch[x] ~= c or fgr[x] ~= fg or bgr[x] ~= bg then
                ch[x], fgr[x], bgr[x] = c, fg, bg
                mark(row, x, x)
            end
        end
    end
    self.cx = cx + n
end

function TTY:clear(bg)
    self:resetView()
    for y = 1, self.rows do
        local row = self.rowsd[y]
        local ch, fgr, bgr = row.ch, row.fg, row.bg
        for x = 1, self.cols do
            ch[x] = 32; fgr[x] = WHITE; bgr[x] = bg
        end
        row.dmin, row.dmax = 1, self.cols
    end
    self.pendingScroll = 0
    self.needFull = true
end

function TTY:clearLine(bg)
    self:resetView()
    local row = self.rowsd[self.cy]
    if not row then return end
    local ch, fgr, bgr = row.ch, row.fg, row.bg
    for x = 1, self.cols do
        ch[x] = 32; fgr[x] = WHITE; bgr[x] = bg
    end
    row.dmin, row.dmax = 1, self.cols
end

function TTY:scroll(n, bg)
    if n == 0 then return end
    self:resetView()
    if self.curX and self.rowsd[self.curY] then
        mark(self.rowsd[self.curY], self.curX, self.curX)
    end
    self.curX = nil
    local rows = self.rows
    if n >= rows or -n >= rows then return self:clear(bg) end
    local rd = self.rowsd
    if n > 0 then
        for _ = 1, n do
            local r = table.remove(rd, 1)
            if #self.scrollback >= TTY.SCROLLBACK_MAX then table.remove(self.scrollback, 1) end
            self.scrollback[#self.scrollback + 1] = snapRow(r, self.cols)
            local ch, fgr, bgr = r.ch, r.fg, r.bg
            for x = 1, self.cols do
                ch[x] = 32; fgr[x] = WHITE; bgr[x] = bg
            end
            r.dmin, r.dmax = 1, self.cols
            rd[#rd + 1] = r
        end
    else
        for _ = 1, -n do
            local r = table.remove(rd)
            local ch, fgr, bgr = r.ch, r.fg, r.bg
            for x = 1, self.cols do
                ch[x] = 32; fgr[x] = WHITE; bgr[x] = bg
            end
            r.dmin, r.dmax = 1, self.cols
            table.insert(rd, 1, r)
        end
    end
    if K.tty_active == self and not self.needFull then
        self.pendingScroll = self.pendingScroll + n
        if self.pendingScroll >= rows or -self.pendingScroll >= rows then
            self.needFull = true; self.pendingScroll = 0
        end
    end
end

local function clampCursor(self)
    if self.cx < 1 then self.cx = 1 elseif self.cx > self.cols then self.cx = self.cols end
    if self.cy < 1 then self.cy = 1 elseif self.cy > self.rows then self.cy = self.rows end
end

local function newline(self, bg)
    self.cx = 1
    self.cy = self.cy + 1
    if self.cy > self.rows then
        self:scroll(1, bg)
        self.cy = self.rows
    end
end

function TTY:printText(text, fg, bg, final)
    self:resetView()
    if self.cx < 1 or self.cx > self.cols or self.cy < 1 or self.cy > self.rows then
        clampCursor(self)
    end
    local cols = self.cols
    local i, n = 1, #text
    while i <= n do
        local c = text:byte(i)
        if c == 27 and self.ansi then
            i = self:doEscape(text, i, bg)
        elseif c == 10 then
            newline(self, bg)
            i = i + 1
        elseif c == 13 then
            self.cx = 1
            i = i + 1
        else
            if self.cx > cols then newline(self, bg) end
            local efg, ebg = self.sgrFg or fg, self.sgrBg or bg
            local room = cols - self.cx + 1
            local j = i
            local run = {}
            local used = 0
            while j <= n and used < room do
                local d = text:byte(j)
                if d == 10 or d == 13 or (d == 27 and self.ansi) then break end
                if d == 9 then
                    local stop = 8 - ((self.cx + used - 1) % 8)
                    local k = 0
                    while k < stop and used < room do
                        used = used + 1; run[used] = 32; k = k + 1
                    end
                else
                    used = used + 1
                    run[used] = d
                end
                j = j + 1
            end
            local row = self.rowsd[self.cy]
            local ch, fgr, bgr = row.ch, row.fg, row.bg
            local x0 = self.cx
            for k = 1, used do
                local x = x0 + k - 1
                local v = run[k]
                if ch[x] ~= v or fgr[x] ~= efg or bgr[x] ~= ebg then
                    ch[x], fgr[x], bgr[x] = v, efg, ebg
                    mark(row, x, x)
                end
            end
            self.cx = x0 + used
            i = j
        end
    end
    if final then newline(self, bg) end
end

function TTY:print(text, fg, bg) self:printText(text, fg, bg, true) end

function TTY:rowText(y)
    local row = self.rowsd[y]
    if not row then return "" end
    return rowToText(row, self.cols)
end

function TTY:getScrollback(n)
    n = n or #self.scrollback
    local out = {}
    for i = math.max(1, #self.scrollback - n + 1), #self.scrollback do
        local e = self.scrollback[i]
        out[#out + 1] = type(e) == "string" and e or rowToText(e, self.cols)
    end
    return out
end

local ANSI_BASE = { 0x000000, 0xAA0000, 0x00AA00, 0xAA5500, 0x0000AA, 0xAA00AA, 0x00AAAA, 0xAAAAAA }
local ANSI_BRIGHT = { 0x555555, 0xFF5555, 0x55FF55, 0xFFFF55, 0x5555FF, 0xFF55FF, 0x55FFFF, 0xFFFFFF }

function TTY:doCsi(params, final, bg)
    if final == "m" then
        local nums = {}
        for num in (params == "" and "0" or params):gmatch("[^;]+") do nums[#nums + 1] = tonumber(num) or 0 end
        for _, p in ipairs(nums) do
            if p == 0 then
                self.sgrFg, self.sgrBg, self.sgrBright = nil, nil, false
            elseif p == 1 then
                self.sgrBright = true
            elseif p == 22 then
                self.sgrBright = false
            elseif p >= 30 and p <= 37 then
                self.sgrFg = (self.sgrBright and ANSI_BRIGHT or ANSI_BASE)[p - 29]
            elseif p >= 90 and p <= 97 then
                self.sgrFg = ANSI_BRIGHT[p - 89]
            elseif p == 39 then
                self.sgrFg = nil
            elseif p >= 40 and p <= 47 then
                self.sgrBg = (self.sgrBright and ANSI_BRIGHT or ANSI_BASE)[p - 39]
            elseif p >= 100 and p <= 107 then
                self.sgrBg = ANSI_BRIGHT[p - 99]
            elseif p == 49 then
                self.sgrBg = nil
            end
        end
    elseif final == "H" or final == "f" then
        local row, col = params:match("^(%d*);?(%d*)$")
        self.cy = math.max(1, math.min(self.rows, tonumber(row) ~= nil and tonumber(row) or 1))
        self.cx = math.max(1, math.min(self.cols, tonumber(col) ~= nil and tonumber(col) or 1))
        if row == "" and col == "" then self.cx, self.cy = 1, 1 end
    elseif final == "J" then
        local p = tonumber(params) or 0
        self:clear(bg)
        if p == 3 then self.scrollback = {} end
    elseif final == "K" then
        self:clearLine(bg)
    end
end

function TTY:doEscape(text, i, bg)
    if text:byte(i + 1) == 91 then
        local j = i + 2
        while j <= #text do
            local b = text:byte(j)
            if b >= 64 and b <= 126 then
                self:doCsi(text:sub(i + 2, j - 1), string.char(b), bg)
                return j + 1
            elseif not (b >= 48 and b <= 57 or b == 59 or b == 63) then
                return j + 1
            end
            j = j + 1
        end
        return #text + 1
    end
    return math.min(i + 2, #text + 1)
end

function TTY:dump()
    local out = {}
    local last = 0
    for y = 1, self.rows do
        out[y] = self:rowText(y)
        if out[y] ~= "" then last = y end
    end
    return table.concat(out, "\n", 1, math.max(last, 1)) .. "\n"
end

function K.tty_show(t)
    K.tty_active = t
    t.needFull = true
    t.pendingScroll = 0
    t.curX = nil
    K.tty_dirty = true
end

function TTY:paint(force)
    local font = self.font
    local gfx = self.surface or screen
    local cw, chh = font.cellW, font.cellH
    local rd = self.rowsd
    local changed = false

    if force then self.needFull = true end

    if self.curX then
        local row = rd[self.curY]
        if row then mark(row, self.curX, self.curX) end
        self.curX = nil
    end

    if self.view ~= 0 then
        self.pendingScroll = 0
        self.needFull = false
        for y = 1, self.rows do
            local row = rd[y]
            if row then row.dmin, row.dmax = nil, nil end
        end
        local S, k = #self.scrollback, self.view
        local writeData = gfx.writeData
        for y = 1, self.rows do
            local idx = S + y - k
            local src = idx <= S and self.scrollback[idx] or rd[idx - S]
            local py = (y - 1) * chh
            local ch, fgr, bgr = src.ch, src.fg, src.bg
            for x = 1, self.cols do
                writeData((x - 1) * cw, py, font:cell(ch[x], fgr[x], bgr[x]), cw)
            end
        end
        return true
    end

    if self.needFull then
        for y = 1, self.rows do if rd[y] then mark(rd[y], 1, self.cols) end end
        self.needFull, self.pendingScroll = false, 0
        changed = true
    elseif self.pendingScroll ~= 0 then
        local n = self.pendingScroll
        local W = self.cols * cw
        local H = self.rows * chh
        if n > 0 then
            local data = gfx.readData(0, n * chh, W - 1, H - 1)
            gfx.writeData(0, 0, data, W)
        else
            local data = gfx.readData(0, 0, W - 1, H + n * chh - 1)
            gfx.writeData(0, -n * chh, data, W)
        end
        self.pendingScroll = 0
        changed = true
    end

    local writeData = gfx.writeData
    for y = 1, self.rows do
        local row = rd[y]
        if row then
            local a = row.dmin
            if a then
                changed = true
                local b = row.dmax
                local py = (y - 1) * chh
                local ch, fgr, bgr = row.ch, row.fg, row.bg
                for x = a, b do
                    writeData((x - 1) * cw, py, font:cell(ch[x], fgr[x], bgr[x]), cw)
                end
                row.dmin, row.dmax = nil, nil
            end
        end
    end

    if self.blinkOn and self.blinkVisible and not self.cursorHidden
        and self.cx >= 1 and self.cx <= self.cols and self.cy >= 1 and self.cy <= self.rows then
        local px, py = (self.cx - 1) * cw, (self.cy - 1) * chh
        local fg = rd[self.cy].fg[self.cx]
        local r, g, b = K.unrgb(fg == BLACK and WHITE or fg)
        gfx.fill(px, py + chh - 2, px + cw - 1, py + chh - 1, r, g, b, 255)
        self.curX, self.curY = self.cx, self.cy
        changed = true
    end
    return changed
end

function K.tty_flush_one(t, force)
    if not t then return end
    if K.gfx and not t.surface then return end
    do
        local rd, rows, bad = t.rowsd, t.rows, 0
        for y = 1, rows do
            if rd[y] == nil then
                rd[y] = newRow(t.cols, BLACK); bad = bad + 1
            end
        end
        if bad > 0 then
            K.klog("tty %s rowsd short: rows=%d missing=%d cx=%d cy=%d fgpgid=%s needFull=%s pendingScroll=%d nprocs=%d",
                t.name, rows, bad, t.cx, t.cy, tostring(t.fgpgid),
                tostring(t.needFull), t.pendingScroll, K.nprocs())
            t.needFull = true
        end
    end

    local now = K.now()
    if t.blinkOn and now - t.lastBlink >= 0.5 then
        t.lastBlink = now
        t.blinkVisible = not t.blinkVisible
        if t.view == 0 then force = force or "blink" end
    end
    if t.curX and (t.cx ~= t.curX or t.cy ~= t.curY) then force = force or "cursor" end
    local dirty = force or K.tty_dirty
    if not dirty then
        if t.needFull or t.pendingScroll ~= 0 then
            dirty = true
        else
            for y = 1, t.rows do
                local r = t.rowsd[y]
                if r and r.dmin then
                    dirty = true
                    break
                end
            end
        end
    end
    if not dirty then return end
    K.tty_dirty = false
    if t:paint(force == true) then
        if t.surface then K.gfx_dirty = true else screen.draw() end
    end
end

function K.tty_flush(force)
    K.tty_flush_one(K.tty_active, force)
    if K.extrattys then
        for _, t in pairs(K.extrattys) do K.tty_flush_one(t, force) end
    end
end

function K.tty_kick(t)
    t.blinkVisible, t.lastBlink = true, K.now()
end
