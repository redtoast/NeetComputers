local M = {}

M.PORT = 6000
M.PROTOCOL = 1

local Client = {}
Client.__index = Client
M.Client = Client

local SEL_CHUNK = 16384

function M.connect(opts)
	opts = opts or {}
	local timeout = opts.timeout or 5
	local port = opts.port or M.PORT

	local deadline = time.monotonic() + timeout
	local conn, cerr
	repeat
		conn, cerr = spp.connect(port, { timeout = timeout })
		if conn then
			break
		end
		if time.monotonic() >= deadline then
			return nil,
				"cannot connect to xesd on port "
					.. port
					.. " ("
					.. tostring(cerr)
					.. "); is it running? try: service -f xesd start"
		end
		sys.sleep(0.05)
	until false

	local c = setmetatable({
		conn = conn,
		nextid = 1,
		windows = {},
		events = {},
	}, Client)

	conn:send({
		op = "hello",
		protocol = M.PROTOCOL,
		name = opts.name or "client",
		wm = opts.wm and true or nil,
	})

	local w, werr = c:await("welcome", timeout, true)
	if not w then
		c:close()
		return nil, werr or "no welcome from xesd"
	end
	c.protocol = w.protocol or M.PROTOCOL
	c.screen = { w = w.w, h = w.h, panelh = w.panelh or 0, bw = w.bw or 2 }
	c.font = { w = w.fw, h = w.fh, titleh = w.titleh or (w.fh + 4) }
	c.supports_batch = w.batch == true
	c.caps = {}
	for _, k in ipairs({ "batch", "hints", "selections", "ownership", "desktops" }) do
		c.caps[k] = w[k] == true
	end

	if opts.wm then
		local m, merr = c:await("wm_ok", timeout, true)
		if not m then
			c:close()
			return nil, merr or "wm registration failed"
		end
		c.iswm = true
	end
	return c
end

function Client:send(msg, timeout)
	local ok, err = self.conn:send(msg, timeout or 0.5)
	if not ok then
		return nil, err
	end
	return true
end

function Client:drain()
	local out = {}
	while true do
		local m = self.conn:recv(0)
		if m == nil then
			break
		end
		if type(m) == "table" then
			out[#out + 1] = m
		end
	end
	return out
end

function Client:_serve_selection(m)
	local sel = (m.sel == "primary") and "primary" or "clipboard"
	local text = ""
	local p = self._providers and self._providers[sel]
	if p then
		local ok, v = pcall(p, sel)
		if ok and type(v) == "string" then
			text = v
		end
	end
	local n = #text
	local i = 1
	repeat
		local chunk = text:sub(i, i + SEL_CHUNK - 1)
		i = i + SEL_CHUNK
		if
			not self:send({
				op = "selection_data",
				id = m.id,
				sel = sel,
				chunk = chunk,
				more = i <= n,
			})
		then
			return
		end
	until i > n
end

function Client:_pump()
	for _, m in ipairs(self:drain()) do
		if type(m) == "table" and m.op == "selection_request" then
			self:_serve_selection(m)
		elseif type(m) == "table" then
			self.events[#self.events + 1] = m
		end
	end
end

function Client:await(op, timeout, failon)
	self:flush()
	local deadline = time.monotonic() + (timeout or 5)
	while true do
		self:_pump()
		for i, m in ipairs(self.events) do
			if m.op == op then
				table.remove(self.events, i)
				return m
			elseif failon and m.op == "error" then
				table.remove(self.events, i)
				return nil, tostring(m.message or "error")
			end
		end
		if time.monotonic() >= deadline then
			return nil
		end
		spp.poll({ self.conn }, 0.05)
	end
end

function Client:poll(timeout)
	self:flush()
	local out = self.events
	self.events = {}
	spp.poll({ self.conn }, timeout or 0)
	self:_pump()
	for _, m in ipairs(self.events) do
		if type(m) == "table" then
			out[#out + 1] = m
		end
	end
	self.events = {}
	local n = 0
	for i = 1, #out do
		local m = out[i]
		if type(m) == "table" then
			n = n + 1
			out[n] = m
		end
	end
	for i = #out, n + 1, -1 do
		out[i] = nil
	end
	return out
end

function Client:window(opts)
	self:flush()
	local id = self.nextid
	self.nextid = id + 1
	local r = self:send({
		op = "create",
		id = id,
		w = opts.w,
		h = opts.h,
		title = opts.title,
		kind = opts.kind,
		x = opts.x,
		y = opts.y,
		hints = opts.hints,
	})
	if not r then
		return nil, "send failed"
	end
	local m = self:await_created(id, 5)
	if not m then
		return nil, "window creation failed"
	end
	self.windows[m.win] = true
	return m.win, m.w, m.h
end

function Client:await_created(id, timeout)
	self:flush()
	local deadline = time.monotonic() + (timeout or 5)
	while true do
		self:_pump()
		for i, m in ipairs(self.events) do
			if m.op == "created" and m.id == id then
				table.remove(self.events, i)
				return m
			end
		end
		if time.monotonic() >= deadline then
			return nil
		end
		spp.poll({ self.conn }, 0.05)
	end
end

function Client:close()
	pcall(function()
		self:flush()
	end)
	pcall(function()
		self.conn:close()
	end)
end

local BATCH_BUDGET = 49152

local function batch_op_size(op)
	local n = 128
	if type(op.text) == "string" then
		n = n + #op.text
	end
	if type(op.data) == "string" then
		n = n + #op.data
	end
	return n
end

function Client:begin()
	self._batch_depth = (self._batch_depth or 0) + 1
	self._batch = self._batch or {}
	return true
end

function Client:commit()
	local depth = (self._batch_depth or 0) - 1
	if depth < 0 then
		depth = 0
	end
	self._batch_depth = depth
	if depth > 0 then
		return true
	end
	return self:flush()
end

function Client:flush()
	local ops = self._batch
	self._batch = {}
	if not ops or #ops == 0 then
		return true
	end
	if not self.supports_batch then
		for _, op in ipairs(ops) do
			local ok, err = self:send(op)
			if not ok then
				return nil, err
			end
		end
		return true
	end
	local chunk, bytes = {}, 0
	for _, op in ipairs(ops) do
		if #chunk > 0 and bytes + batch_op_size(op) > BATCH_BUDGET then
			local ok, err = self:send({ op = "batch", ops = chunk })
			if not ok then
				return nil, err
			end
			chunk, bytes = {}, 0
		end
		chunk[#chunk + 1] = op
		bytes = bytes + batch_op_size(op)
	end
	if #chunk > 0 then
		local ok, err = self:send({ op = "batch", ops = chunk })
		if not ok then
			return nil, err
		end
	end
	return true
end

function Client:batch(fn)
	self:begin()
	local ok, err = pcall(fn)
	local _, cerr = self:commit()
	if not ok then
		return nil, err
	end
	if cerr then
		return nil, cerr
	end
	return true
end

local function buffered(self, msg)
	if (self._batch_depth or 0) > 0 then
		self._batch[#self._batch + 1] = msg
		return true
	end
	return self:send(msg)
end

function Client:fill(win, x, y, w, h, color)
	return buffered(self, { op = "fill", win = win, x = x, y = y, w = w, h = h, color = color })
end

function Client:text(win, x, y, text, fg, bg)
	return buffered(self, { op = "text", win = win, x = x, y = y, text = text, fg = fg, bg = bg })
end

function Client:image(win, x, y, w, data)
	return buffered(self, { op = "image", win = win, x = x, y = y, w = w, data = data })
end

function Client:map(win, x, y, cmd, args)
	self:flush()
	return self:send({ op = "map", win = win, x = x, y = y, cmd = cmd, args = args })
end

function Client:move(win, x, y)
	self:flush()
	return self:send({ op = "move", win = win, x = x, y = y })
end

function Client:resize(win, w, h)
	self:flush()
	return self:send({ op = "configure", win = win, w = w, h = h })
end

function Client:set_hints(win, hints)
	self:flush()
	return self:send({ op = "hints", win = win, hints = hints })
end

function Client:title(win, text)
	self:flush()
	return self:send({ op = "title", win = win, title = text })
end

function Client:raise(win)
	self:flush()
	return self:send({ op = "raise", win = win })
end

function Client:destroy(win)
	self:flush()
	return self:send({ op = "destroy", win = win })
end

function Client:clip_set(text, kind)
	self:flush()
	local ok, err = self:send({
		op = "clipboard",
		text = text or "",
		sel = (kind == "primary") and "primary" or nil,
	})
	if ok and self._providers then
		self._providers[(kind == "primary") and "primary" or "clipboard"] = nil
	end
	return ok, err
end

function Client:clip_own(kind, provider)
	if not self.caps.ownership then
		return nil, "server did not announce ownership support"
	end
	if type(provider) ~= "function" then
		return nil, "provider must be a function"
	end
	self:flush()
	self._providers = self._providers or {}
	self._providers[(kind == "primary") and "primary" or "clipboard"] = provider
	if not self:send({
		op = "clipboard_own",
		sel = (kind == "primary") and "primary" or nil,
	}) then
		return nil, "send failed"
	end
	local m = self:await("owned", 2)
	if not m then
		return nil, "no owned reply from xesd"
	end
	return true
end

function Client:clip_unown(kind)
	if not self.caps.ownership then
		return nil, "server did not announce ownership support"
	end
	self:flush()
	local sel = (kind == "primary") and "primary" or "clipboard"
	if
		not self:send({
			op = "clipboard_own",
			sel = (sel == "primary") and "primary" or nil,
			owner = false,
		})
	then
		return nil, "send failed"
	end
	local m = self:await("owned", 2)
	if not m then
		return nil, "no owned reply from xesd"
	end
	if self._providers then
		self._providers[sel] = nil
	end
	return true
end

function Client:clip_get(kind, timeout)
	self:flush()
	local id = self.nextid
	self.nextid = id + 1
	local ok, err = self:send({
		op = "clipboard_get",
		id = id,
		sel = (kind == "primary") and "primary" or nil,
	})
	if not ok then
		return nil, err
	end
	local deadline = time.monotonic() + (timeout or 2)
	while true do
		self:_pump()
		for i, m in ipairs(self.events) do
			if m.op == "clipboard" and m.id == id then
				table.remove(self.events, i)
				return m.text or ""
			end
		end
		if time.monotonic() >= deadline then
			return nil
		end
		spp.poll({ self.conn }, 0.05)
	end
end

function Client:pointer_get(win, timeout)
	self:flush()
	local id = self.nextid
	self.nextid = id + 1
	local ok, err = self:send({ op = "pointer_get", id = id, win = win })
	if not ok then
		return nil, err
	end
	local deadline = time.monotonic() + (timeout or 2)
	while true do
		self:_pump()
		for i, m in ipairs(self.events) do
			if m.op == "pointer" and m.id == id then
				table.remove(self.events, i)
				if type(m.x) == "number" and type(m.y) == "number" then
					return m.x, m.y, m.sx, m.sy
				end
				return nil, "bad pointer reply"
			end
		end
		if time.monotonic() >= deadline then
			return nil, "pointer query timed out"
		end
		spp.poll({ self.conn }, 0.05)
	end
end

function Client:list_windows(timeout)
	self:flush()
	local ok, err = self:send({ op = "list_windows" })
	if not ok then
		return nil, err
	end
	local w = self:await("windows", timeout or 2)
	if not w then
		return nil, "windows query timed out"
	end
	return w
end

function M.rgb(r, g, b)
	return (r << 16) | (g << 8) | b
end

return M
