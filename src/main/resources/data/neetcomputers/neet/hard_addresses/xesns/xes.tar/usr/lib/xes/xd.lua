local M = {}

M.PORT = 6000
M.PROTOCOL = 1

local Client = {}
Client.__index = Client
M.Client = Client

function M.connect(opts)
    opts = opts or {}
    local timeout = opts.timeout or 5
    local port = opts.port or M.PORT

    local deadline = posix.time() + timeout
    local conn, cerr
    repeat
        conn, cerr = spp.connect(port, { timeout = timeout })
        if conn then break end
        if posix.time() >= deadline then
            return nil, "cannot connect to xesd on port " .. port ..
                " (" .. tostring(cerr) .. "); is it running? try: service -f xesd start"
        end
        sys.sleep(0.05)
    until false

    local c = setmetatable({
        conn = conn,
        nextid = 1,
        windows = {},
        events = {},
    }, Client)

    conn:send({
        op = "hello",
        protocol = M.PROTOCOL,
        name = opts.name or "client",
        wm = opts.wm and true or nil
    })

    local w = c:await("welcome", timeout)
    if not w then return nil, "no welcome from xesd" end
    c.screen = { w = w.w, h = w.h, panelh = w.panelh or 0, bw = w.bw or 2 }
    c.font = { w = w.fw, h = w.fh, titleh = w.titleh or (w.fh + 4) }
    c.supports_batch = w.batch == true

    if opts.wm then
        if not c:await("wm_ok", timeout) then return nil, "wm registration failed" end
        c.iswm = true
    end
    return c
end

function Client:send(msg, timeout)
    local ok, err = self.conn:send(msg, timeout or 0.5)
    if not ok then return nil, err end
    return true
end

function Client:drain()
    local out = {}
    while true do
        local m = self.conn:recv(0)
        if m == nil then break end
        out[#out + 1] = m
    end
    return out
end

function Client:await(op, timeout)
    self:flush()
    local deadline = posix.time() + (timeout or 5)
    while true do
        for _, m in ipairs(self:drain()) do self.events[#self.events + 1] = m end
        for i, m in ipairs(self.events) do
            if m.op == op then
                table.remove(self.events, i)
                return m
            end
        end
        if posix.time() >= deadline then return nil end
        spp.poll({ self.conn }, 0.05)
    end
end

function Client:poll(timeout)
    self:flush()
    local out = self.events
    self.events = {}
    spp.poll({ self.conn }, timeout or 0)
    for _, m in ipairs(self:drain()) do out[#out + 1] = m end
    return out
end

function Client:window(opts)
    self:flush()
    local id = self.nextid
    self.nextid = id + 1
    local r = self:send({
        op = "create",
        id = id,
        w = opts.w,
        h = opts.h,
        title = opts.title,
        kind = opts.kind,
        x = opts.x,
        y = opts.y
    })
    if not r then return nil, "send failed" end
    local m = self:await_created(id, 5)
    if not m then return nil, "window creation failed" end
    self.windows[m.win] = true
    return m.win, m.w, m.h
end

function Client:await_created(id, timeout)
    self:flush()
    local deadline = posix.time() + (timeout or 5)
    while true do
        for _, m in ipairs(self:drain()) do self.events[#self.events + 1] = m end
        for i, m in ipairs(self.events) do
            if m.op == "created" and m.id == id then
                table.remove(self.events, i)
                return m
            end
        end
        if posix.time() >= deadline then return nil end
        spp.poll({ self.conn }, 0.05)
    end
end

function Client:close()
    pcall(function() self:flush() end)
    pcall(function() self.conn:close() end)
end

local BATCH_BUDGET = 49152

local function batch_op_size(op)
    local n = 128
    if type(op.text) == "string" then n = n + #op.text end
    if type(op.data) == "string" then n = n + #op.data end
    return n
end

function Client:begin()
    self._batch_depth = (self._batch_depth or 0) + 1
    self._batch = self._batch or {}
    return true
end

function Client:commit()
    local depth = (self._batch_depth or 0) - 1
    if depth < 0 then depth = 0 end
    self._batch_depth = depth
    if depth > 0 then return true end
    return self:flush()
end

function Client:flush()
    local ops = self._batch
    self._batch = {}
    if not ops or #ops == 0 then return true end
    if not self.supports_batch then
        for _, op in ipairs(ops) do
            local ok, err = self:send(op)
            if not ok then return nil, err end
        end
        return true
    end
    local chunk, bytes = {}, 0
    for _, op in ipairs(ops) do
        if #chunk > 0 and bytes + batch_op_size(op) > BATCH_BUDGET then
            local ok, err = self:send({ op = "batch", ops = chunk })
            if not ok then return nil, err end
            chunk, bytes = {}, 0
        end
        chunk[#chunk + 1] = op
        bytes = bytes + batch_op_size(op)
    end
    if #chunk > 0 then
        local ok, err = self:send({ op = "batch", ops = chunk })
        if not ok then return nil, err end
    end
    return true
end

function Client:batch(fn)
    self:begin()
    local ok, err = pcall(fn)
    local _, cerr = self:commit()
    if not ok then return nil, err end
    if cerr then return nil, cerr end
    return true
end

local function buffered(self, msg)
    if (self._batch_depth or 0) > 0 then
        self._batch[#self._batch + 1] = msg
        return true
    end
    return self:send(msg)
end

function Client:fill(win, x, y, w, h, color)
    return buffered(self, { op = "fill", win = win, x = x, y = y, w = w, h = h, color = color })
end

function Client:text(win, x, y, text, fg, bg)
    return buffered(self, { op = "text", win = win, x = x, y = y, text = text, fg = fg, bg = bg })
end

function Client:image(win, x, y, w, data)
    return buffered(self, { op = "image", win = win, x = x, y = y, w = w, data = data })
end

function Client:map(win, x, y, cmd)
    self:flush()
    return self:send({ op = "map", win = win, x = x, y = y, cmd = cmd })
end

function Client:move(win, x, y)
    self:flush()
    return self:send({ op = "move", win = win, x = x, y = y })
end

function Client:resize(win, w, h)
    self:flush()
    return self:send({ op = "configure", win = win, w = w, h = h })
end

function Client:title(win, text)
    self:flush()
    return self:send({ op = "title", win = win, title = text })
end

function Client:raise(win)
    self:flush()
    return self:send({ op = "raise", win = win })
end

function Client:destroy(win)
    self:flush()
    return self:send({ op = "destroy", win = win })
end

function Client:clip_set(text)
    self:flush()
    return self:send({ op = "clipboard", text = text or "" })
end

function Client:clip_get(timeout)
    self:flush()
    local id = self.nextid
    self.nextid = id + 1
    local ok, err = self:send({ op = "clipboard_get", id = id })
    if not ok then return nil, err end
    local deadline = posix.time() + (timeout or 2)
    while true do
        for _, m in ipairs(self:drain()) do self.events[#self.events + 1] = m end
        for i, m in ipairs(self.events) do
            if m.op == "clipboard" and m.id == id then
                table.remove(self.events, i)
                return m.text or ""
            end
        end
        if posix.time() >= deadline then return nil end
        spp.poll({ self.conn }, 0.05)
    end
end

function Client:pointer_get(win, timeout)
    self:flush()
    local id = self.nextid
    self.nextid = id + 1
    local ok, err = self:send({ op = "pointer_get", id = id, win = win })
    if not ok then return nil, err end
    local deadline = posix.time() + (timeout or 2)
    while true do
        for _, m in ipairs(self:drain()) do self.events[#self.events + 1] = m end
        for i, m in ipairs(self.events) do
            if m.op == "pointer" and m.id == id then
                table.remove(self.events, i)
                if type(m.x) == "number" and type(m.y) == "number" then
                    return m.x, m.y, m.sx, m.sy
                end
                return nil, "bad pointer reply"
            end
        end
        if posix.time() >= deadline then return nil, "pointer query timed out" end
        spp.poll({ self.conn }, 0.05)
    end
end

function M.rgb(r, g, b) return (r << 16) | (g << 8) | b end

return M
