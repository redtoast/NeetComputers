local M = {}

M.VERSION = "0.2.0"

local mfloor = math.floor

local MAX_DIM = 2048
local MAX_BYTES = 8 * 1024 * 1024

local function is_ws(b)
	return b == 32 or b == 9 or b == 10 or b == 13 or b == 11 or b == 12
end

local function skip_space(data, pos)
	local n = #data
	while pos <= n do
		local b = data:byte(pos)
		if b == 0x23 then
			pos = pos + 1
			while pos <= n and data:byte(pos) ~= 10 do
				pos = pos + 1
			end
		elseif is_ws(b) then
			pos = pos + 1
		else
			break
		end
	end
	return pos
end

local function next_token(data, pos)
	pos = skip_space(data, pos)
	if pos > #data then
		return nil, pos
	end
	local s = pos
	while s <= #data do
		local b = data:byte(s)
		if is_ws(b) or b == 0x23 then
			break
		end
		s = s + 1
	end
	return data:sub(pos, s - 1), s
end

local function bad_header()
	return nil, "bad ppm header"
end

local function header(data)
	if type(data) ~= "string" or #data == 0 then
		return nil, "empty ppm data"
	end
	if #data > MAX_BYTES then
		return nil, "ppm too large"
	end
	if #data < 2 then
		return nil, "not a ppm image"
	end
	local a, b = data:byte(1, 2)
	if a ~= 0x50 or b < 0x31 or b > 0x36 then
		return nil, "not a ppm image"
	end
	local subtype = data:sub(1, 2)
	if #data >= 3 then
		local c = data:byte(3)
		if not is_ws(c) and c ~= 0x23 then
			return nil, "bad ppm header"
		end
	end
	local stok, pos = next_token(data, 3)
	if not stok or not stok:match("^%d+$") then
		return bad_header()
	end
	local w = tonumber(stok)
	stok, pos = next_token(data, pos)
	if not stok or not stok:match("^%d+$") then
		return bad_header()
	end
	local h = tonumber(stok)
	if not w or w < 1 or w > MAX_DIM or not h or h < 1 or h > MAX_DIM then
		return nil, "bad ppm dimensions"
	end
	if w * h * 4 > MAX_BYTES then
		return nil, "ppm too large"
	end
	local maxval = 1
	if subtype ~= "P1" and subtype ~= "P4" then
		stok, pos = next_token(data, pos)
		if not stok or not stok:match("^%d+$") then
			return bad_header()
		end
		maxval = tonumber(stok)
		if not maxval or maxval < 1 or maxval > 65535 then
			return nil, "bad ppm maxval"
		end
	end
	local raster
	if subtype == "P4" or subtype == "P5" or subtype == "P6" then
		if pos > #data then
			return nil, "truncated ppm data"
		end
		if not is_ws(data:byte(pos)) then
			return nil, "bad ppm header"
		end
		raster = pos + 1
	else
		raster = skip_space(data, pos)
	end
	return {
		subtype = subtype,
		width = w,
		height = h,
		maxval = maxval,
		raster = raster,
		data = data,
	}
end

function M.detect(data, path)
	if type(data) == "string" and #data >= 2 then
		local a, b = data:byte(1, 2)
		if a == 0x50 and b >= 0x31 and b <= 0x36 then
			if #data < 3 then
				return true
			end
			local c = data:byte(3)
			if is_ws(c) or c == 0x23 then
				return true
			end
		end
	end
	if type(path) == "string" then
		local lp = path:lower()
		if lp:match("%.ppm$") or lp:match("%.pgm$") or lp:match("%.pbm$") or lp:match("%.pnm$") then
			return true
		end
	end
	return false
end

function M.parse(data)
	return header(data)
end

function M.natural_size(data_or_info)
	local info = data_or_info
	if type(info) == "string" then
		local inf2, err = header(info)
		if not inf2 then
			return nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width then
		return nil, "not a parsed ppm image"
	end
	return info.width, info.height
end

function M.decode(data_or_info, opts)
	local info = data_or_info
	local data = nil
	if type(info) == "string" then
		data = info
		local inf2, err = header(data)
		if not inf2 then
			return nil, nil, nil, err
		end
		info = inf2
	end
	if type(info) ~= "table" or not info.width or not info.raster then
		return nil, nil, nil, "not a parsed ppm image"
	end
	data = data or info.data
	if type(data) ~= "string" then
		return nil, nil, nil, "not a parsed ppm image"
	end
	if #data > MAX_BYTES then
		return nil, nil, nil, "ppm too large"
	end

	local subtype, w, h, maxval = info.subtype, info.width, info.height, info.maxval
	local npix = w * h

	local function scale(v)
		if maxval == 255 then
			return v
		end
		return mfloor(v * 255 / maxval + 0.5)
	end

	local schar = string.char
	local parts = {}

	if subtype == "P6" then
		local wide = maxval > 255
		local step = wide and 6 or 3
		if info.raster + npix * step - 1 > #data then
			return nil, nil, nil, "truncated ppm data"
		end
		local p = info.raster
		for _ = 1, npix do
			local r, g, b
			if wide then
				local b1, b2, b3, b4, b5, b6 = data:byte(p, p + 5)
				if not b6 then
					return nil, nil, nil, "truncated ppm data"
				end
				r = scale(b1 * 256 + b2)
				g = scale(b3 * 256 + b4)
				b = scale(b5 * 256 + b6)
			else
				r, g, b = data:byte(p, p + 2)
				if not b then
					return nil, nil, nil, "truncated ppm data"
				end
				r, g, b = scale(r), scale(g), scale(b)
			end
			parts[#parts + 1] = schar(r, g, b, 255)
			p = p + step
		end
	elseif subtype == "P5" then
		local wide = maxval > 255
		local step = wide and 2 or 1
		if info.raster + npix * step - 1 > #data then
			return nil, nil, nil, "truncated ppm data"
		end
		local p = info.raster
		for _ = 1, npix do
			local v
			if wide then
				local hi, lo = data:byte(p, p + 1)
				if not lo then
					return nil, nil, nil, "truncated ppm data"
				end
				v = scale(hi * 256 + lo)
			else
				v = data:byte(p)
				if not v then
					return nil, nil, nil, "truncated ppm data"
				end
				v = scale(v)
			end
			parts[#parts + 1] = schar(v, v, v, 255)
			p = p + step
		end
	elseif subtype == "P4" then
		local rowbytes = mfloor((w + 7) / 8)
		if info.raster + rowbytes * h - 1 > #data then
			return nil, nil, nil, "truncated ppm data"
		end
		local p = info.raster
		for _ = 1, h do
			for x = 0, w - 1 do
				local by = data:byte(p + mfloor(x / 8))
				local bit = mfloor(by / (2 ^ (7 - (x % 8)))) % 2
				if bit == 1 then
					parts[#parts + 1] = schar(0, 0, 0, 255)
				else
					parts[#parts + 1] = schar(255, 255, 255, 255)
				end
			end
			p = p + rowbytes
		end
	elseif subtype == "P3" or subtype == "P2" then
		local pos = info.raster
		local need = (subtype == "P3") and npix * 3 or npix
		for _ = 1, need do
			local tok
			tok, pos = next_token(data, pos)
			if not tok or not tok:match("^%d+$") then
				return nil, nil, nil, "truncated ppm data"
			end
			local v = tonumber(tok)
			if v > maxval then
				return nil, nil, nil, "bad ppm sample"
			end
			parts[#parts + 1] = scale(v)
		end
		local out = {}
		if subtype == "P3" then
			for i = 1, npix do
				out[i] = schar(parts[(i - 1) * 3 + 1], parts[(i - 1) * 3 + 2], parts[(i - 1) * 3 + 3], 255)
			end
		else
			for i = 1, npix do
				local v = parts[i]
				out[i] = schar(v, v, v, 255)
			end
		end
		return w, h, table.concat(out)
	else
		local pos = info.raster
		for _ = 1, npix do
			pos = skip_space(data, pos)
			local b = data:byte(pos)
			if b ~= 0x30 and b ~= 0x31 then
				return nil, nil, nil, "truncated ppm data"
			end
			if b == 0x31 then
				parts[#parts + 1] = schar(0, 0, 0, 255)
			else
				parts[#parts + 1] = schar(255, 255, 255, 255)
			end
			pos = pos + 1
		end
	end
	return w, h, table.concat(parts)
end

M.render = M.decode

return M
