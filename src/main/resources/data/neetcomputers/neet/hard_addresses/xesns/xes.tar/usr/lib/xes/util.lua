local u = {}

function u.err(msg) posix.write(2, msg .. "\n") end

function u.die(name, msg, code)
    posix.write(2, name .. ": " .. msg .. "\n")
    posix.exit(code or 1)
end

function u.opts(args, spec, name)
    local flags, operands = {}, {}
    local takes = {}
    for l, colon in spec:gmatch("(%a)(:?)") do takes[l] = colon == ":" end
    local i = 1
    while i <= #args do
        local a = args[i]
        if a == "--" then
            for j = i + 1, #args do operands[#operands + 1] = args[j] end
            break
        elseif a:sub(1, 1) == "-" and #a > 1 and not a:match("^%-%d") then
            local k = 2
            while k <= #a do
                local l = a:sub(k, k)
                if takes[l] == nil then u.die(name or "?", "illegal option -- " .. l, 2) end
                if takes[l] then
                    local v = a:sub(k + 1)
                    if v == "" then
                        i = i + 1; v = args[i]
                    end
                    if v == nil then u.die(name or "?", "option requires an argument -- " .. l, 2) end
                    flags[l] = v
                    break
                end
                flags[l] = true
                k = k + 1
            end
        else
            operands[#operands + 1] = a
        end
        i = i + 1
    end
    return flags, operands
end

function u.readAll(fd)
    local parts = {}
    while true do
        local d = posix.read(fd, 4096)
        if not d then break end
        parts[#parts + 1] = d
    end
    return table.concat(parts)
end

function u.openIn(path, name)
    if path == nil or path == "-" then return 0, false end
    local fd, e = posix.open(path, "r")
    if not fd then
        u.err((name or "?") .. ": " .. path .. ": " .. tostring(e))
        return nil
    end
    return fd, true
end

function u.lines(fd)
    local buf = ""
    local eof = false
    return function()
        while true do
            local nl = buf:find("\n", 1, true)
            if nl then
                local l = buf:sub(1, nl - 1)
                buf = buf:sub(nl + 1)
                return l
            end
            if eof then
                if buf ~= "" then
                    local l = buf; buf = ""; return l
                end
                return nil
            end
            local d = posix.read(fd, 4096)
            if not d then eof = true else buf = buf .. d end
        end
    end
end

function u.human(n)
    local units = { "B", "K", "M", "G" }
    local i = 1
    while n >= 1024 and i < #units do
        n = n / 1024; i = i + 1
    end
    if i == 1 then return tostring(math.floor(n)) .. "B" end
    return string.format("%.1f%s", n, units[i])
end

function u.pad(s, n, right)
    s = tostring(s)
    if #s >= n then return s end
    if right then return string.rep(" ", n - #s) .. s end
    return s .. string.rep(" ", n - #s)
end

function u.isdir(p)
    local s = posix.stat(p)
    return s ~= nil and s.type == "dir"
end

function u.basename(p)
    p = p:gsub("/+$", "")
    return p:match("([^/]*)$")
end

function u.rmtree(path)
    local s = posix.stat(path)
    if not s then return nil, "no such file or directory" end
    if s.type == "dir" then
        for _, n in ipairs(posix.readdir(path) or {}) do
            local ok, e = u.rmtree(path .. "/" .. n)
            if not ok then return nil, e end
        end
    end
    return posix.unlink(path)
end

function u.copyFile(src, dst)
    local data, e = posix.readfile(src)
    if not data then return nil, e end
    local existed = posix.stat(dst) ~= nil
    local ok, werr = posix.writefile(dst, data)
    if ok and not existed then
        local st = posix.stat(src)
        if st and st.mode then posix.chmod(dst, st.mode & ~posix.umask() & 511) end
    end
    return ok, werr
end

function u.copyTree(src, dst)
    local s = posix.stat(src)
    if not s then return nil, "no such file or directory" end
    if s.type == "dir" then
        if not posix.stat(dst) then
            local ok, e = posix.mkdir(dst)
            if not ok then return nil, e end
        end
        for _, n in ipairs(posix.readdir(src) or {}) do
            local ok, e = u.copyTree(src .. "/" .. n, dst .. "/" .. n)
            if not ok then return nil, e end
        end
        return true
    end
    return u.copyFile(src, dst)
end

function u.plural(n, w) return n .. " " .. w .. (n == 1 and "" or "s") end

return u
