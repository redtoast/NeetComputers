local u = {}

local _posix = (type(posix) == "table") and posix or nil
local _fs = (type(fs) == "table" and type(fs.open) == "function") and fs or nil
local _stdio = (type(stdio) == "table") and stdio or nil
local _proc = (type(proc) == "table") and proc or nil
local _env = (type(env) == "table") and env or nil

local function stdoutHandle()
	if _stdio and _stdio.stdout then
		return _stdio.stdout
	end
	return nil
end

local function stderrHandle()
	if _stdio and _stdio.stderr then
		return _stdio.stderr
	end
	return nil
end

local function stdinHandle()
	if _stdio and _stdio.stdin then
		return _stdio.stdin
	end
	return nil
end

local function errmsg(...)
	for i = 1, select("#", ...) do
		local v = select(i, ...)
		if type(v) == "string" and v ~= "" then
			return v
		end
	end
	return nil
end

function u.writeOut(s)
	s = tostring(s)
	local h = stdoutHandle()
	if h then
		local ok, r = pcall(h.write, h, s)
		if ok and r then
			return true
		end
	end
	return nil, "no output"
end

function u.writeErr(s)
	s = tostring(s)
	local h = stderrHandle()
	if h then
		local ok, r = pcall(h.write, h, s)
		if ok and r then
			return true
		end
	end
	return nil, "no output"
end

function u.err(msg)
	u.writeErr(tostring(msg) .. "\n")
end

function u.die(name, msg, code)
	u.err(tostring(name) .. ": " .. tostring(msg))
	code = code or 1
	if _proc and _proc.exit then
		_proc.exit(code)
	end
	error(tostring(name) .. ": " .. tostring(msg), 0)
end

function u.opts(args, spec, name)
	local flags, operands = {}, {}
	local takes = {}
	for l, colon in spec:gmatch("(%a)(:?)") do
		takes[l] = colon == ":"
	end
	local i = 1
	while i <= #args do
		local a = args[i]
		if a == "--" then
			for j = i + 1, #args do
				operands[#operands + 1] = args[j]
			end
			break
		elseif a:sub(1, 1) == "-" and #a > 1 and not a:match("^%-%d") then
			local k = 2
			while k <= #a do
				local l = a:sub(k, k)
				if takes[l] == nil then
					u.die(name or "?", "illegal option -- " .. l, 2)
				end
				if takes[l] then
					local v = a:sub(k + 1)
					if v == "" then
						i = i + 1
						v = args[i]
					end
					if v == nil then
						u.die(name or "?", "option requires an argument -- " .. l, 2)
					end
					flags[l] = v
					break
				end
				flags[l] = true
				k = k + 1
			end
		else
			operands[#operands + 1] = a
		end
		i = i + 1
	end
	return flags, operands
end

local function isFd(v)
	return type(v) == "number"
end

function u.read(h, n)
	n = n or 4096
	if isFd(h) then
		if _posix and _posix.read then
			return _posix.read(h, n)
		end
		return nil, "no posix"
	end
	if type(h) == "table" and type(h.read) == "function" then
		local ok, r, c, m = pcall(h.read, h, n)
		if not ok then
			return nil, tostring(r)
		end
		return r, c, m
	end
	return nil, "bad handle"
end

function u.write(h, s)
	s = tostring(s)
	if isFd(h) then
		if _posix and _posix.write then
			return _posix.write(h, s)
		end
		return nil, "no posix"
	end
	if type(h) == "table" and type(h.write) == "function" then
		local ok, r, c, m = pcall(h.write, h, s)
		if not ok then
			return nil, tostring(r)
		end
		if r then
			return true
		end
		return nil, c, m
	end
	return nil, "bad handle"
end

function u.close(h)
	if isFd(h) then
		if _posix and _posix.close then
			return _posix.close(h)
		end
		return nil, "no posix"
	end
	if type(h) == "table" and type(h.close) == "function" then
		local ok, r, c, m = pcall(h.close, h)
		if not ok then
			return nil, tostring(r)
		end
		return r, c, m
	end
	return nil, "bad handle"
end

function u.open(path, mode)
	mode = mode or "r"
	if _fs then
		local ok, h, code, msg = pcall(_fs.open, path, mode)
		if ok and h then
			return h
		end
		if ok and h == nil then
			return nil, msg or code
		end
	end
	return nil, "cannot open"
end

function u.seek(h, whence, off)
	if isFd(h) then
		if _posix and _posix.seek then
			return _posix.seek(h, whence, off)
		end
		return nil, "no posix"
	end
	if type(h) == "table" and type(h.seek) == "function" then
		local ok, r, c, m = pcall(h.seek, h, whence, off)
		if not ok then
			return nil, tostring(r)
		end
		return r, c, m
	end
	return nil, "bad handle"
end

function u.readAll(h)
	local parts = {}
	while true do
		local d = u.read(h, 4096)
		if not d then
			break
		end
		parts[#parts + 1] = d
	end
	return table.concat(parts)
end

function u.openIn(path, name)
	if path == nil or path == "-" then
		local h = stdinHandle()
		if h then
			return h, false
		end
		return 0, false
	end
	if _fs then
		local ok, h, code, msg = pcall(_fs.open, path, "r")
		if ok and h then
			return h, true
		end
		if ok and h == nil then
			u.err((name or "?") .. ": " .. path .. ": " .. tostring(msg or code))
			return nil
		end
	end
	u.err((name or "?") .. ": " .. path .. ": cannot open")
	return nil
end

function u.lines(h)
	local buf = ""
	local eof = false
	return function()
		while true do
			local nl = buf:find("\n", 1, true)
			if nl then
				local l = buf:sub(1, nl - 1)
				buf = buf:sub(nl + 1)
				return l
			end
			if eof then
				if buf ~= "" then
					local l = buf
					buf = ""
					return l
				end
				return nil
			end
			local d = u.read(h, 4096)
			if not d then
				eof = true
			else
				buf = buf .. d
			end
		end
	end
end

function u.human(n)
	local units = { "B", "K", "M", "G" }
	local i = 1
	while n >= 1024 and i < #units do
		n = n / 1024
		i = i + 1
	end
	if i == 1 then
		return tostring(math.floor(n)) .. "B"
	end
	return string.format("%.1f%s", n, units[i])
end

function u.pad(s, n, right)
	s = tostring(s)
	if #s >= n then
		return s
	end
	if right then
		return string.rep(" ", n - #s) .. s
	end
	return s .. string.rep(" ", n - #s)
end

function u.stat(p)
	if _fs and _fs.stat then
		local ok, st, code, msg = pcall(_fs.stat, p)
		if ok and type(st) == "table" then
			return st
		end
		local ferr = ok and errmsg(msg, code) or tostring(st)
		return nil, ferr or "no such file or directory"
	end
	return nil, "no such file or directory"
end

function u.lstat(p)
	if _fs and _fs.lstat then
		local ok, st, code, msg = pcall(_fs.lstat, p)
		if ok and type(st) == "table" then
			return st
		end
		local ferr = ok and errmsg(msg, code) or tostring(st)
		if ok then
			return nil, ferr or "no such file or directory"
		end
	end
	return u.stat(p)
end

function u.islink(p)
	local st = u.lstat(p)
	return st ~= nil and st.type == "link"
end

function u.isdir(p)
	local s = u.stat(p)
	return s ~= nil and s.type == "dir"
end

function u.readdir(p)
	local ferr
	if _fs and _fs.list then
		local ok, names, code, msg = pcall(_fs.list, p)
		if ok and type(names) == "table" then
			table.sort(names)
			return names
		end
		ferr = ok and errmsg(msg, code) or tostring(names)
	end
	if _posix and _posix.readdir then
		local ok, names, e, m = pcall(_posix.readdir, p)
		if ok and type(names) == "table" then
			table.sort(names)
			return names
		end
		if not ok then
			return nil, tostring(names)
		end
		return nil, errmsg(m, e, ferr) or "cannot read directory"
	end
	return nil, ferr or "cannot read directory"
end

function u.getenv(k)
	if _env and _env.get then
		local ok, v = pcall(_env.get, k)
		if ok then
			return v
		end
	end
	return nil
end

function u.environ()
	if _env and _env.all then
		local ok, e = pcall(_env.all)
		if ok and type(e) == "table" then
			return e
		end
	end
	return {}
end

function u.basename(p)
	p = p:gsub("/+$", "")
	return p:match("([^/]*)$")
end

function u.resolve(p)
	if _fs and _fs.resolve then
		local ok, full = pcall(_fs.resolve, p)
		if ok and type(full) == "string" then
			return full
		end
	end
	return nil
end

function u.pretty(full)
	local root = u.resolve("/")
	local out = full
	if type(root) == "string" and type(full) == "string" then
		local p = root:gsub("/+$", "")
		if full == p then
			out = "/"
		elseif full:sub(1, #p + 1) == p .. "/" then
			out = full:sub(#p + 1)
		end
	end
	if type(out) == "string" and #out > 1 and out:sub(-1) == "/" then
		out = out:sub(1, -2)
	end
	return out
end

function u.mkdir(p)
	if _fs and _fs.makeDir then
		local ok, r, c, m = pcall(_fs.makeDir, p)
		if ok and r then
			return true
		end
		if not ok then
			return nil, tostring(r)
		end
		return nil, m or c or "cannot create directory", c
	end
	return nil, "cannot create directory"
end

function u.chmod(p, mode)
	mode = tonumber(mode)
	if mode == nil then
		return nil, "invalid mode"
	end
	if _fs and _fs.chmod and mode >= 0 and math.type(mode) == "integer" then
		local ok, r, c, m = pcall(_fs.chmod, p, mode & 1023)
		if ok and r then
			return true
		end
		return nil, m or c, c
	end
	return nil, "cannot chmod"
end

function u.chown(p, uid, gid)
	if _fs and _fs.chown then
		local ok, r, c, m = pcall(_fs.chown, p, uid, gid)
		if ok and r then
			return true
		end
		return nil, m or c, c
	end
	return nil, "cannot chown"
end

function u.readlink(p)
	local st = u.lstat(p)
	if st and type(st.link) == "string" then
		return st.link
	end
	return nil
end

function u.rename(a, b)
	if _fs and _fs.rename then
		if _fs.isDir and _fs.isDir(b) then
			local base = u.basename(tostring(u.resolve(a) or a))
			if base ~= "" then
				b = tostring(b):gsub("/+$", "") .. "/" .. base
			end
		end
		local ok, r, c, m = pcall(_fs.rename, a, b)
		if ok and r then
			return true
		end
		local ferr = ok and (m or c) or tostring(r)
		return nil, ferr or "cannot rename", c
	end
	return nil, "cannot rename"
end

function u.ask(msg)
	u.writeErr(tostring(msg) .. " (y/n [n])? ")
	local ans
	if _stdio and type(_stdio.readLine) == "function" then
		local ok, line = pcall(_stdio.readLine)
		if ok then
			ans = line
		end
	end
	return ans ~= nil and ans:match("^%s*[yY]") ~= nil
end

function u.unlink(p)
	if _fs and _fs.delete then
		local ok, r, c, m = pcall(_fs.delete, p)
		if ok and r then
			return true
		end
		local ferr = ok and (m or c) or tostring(r)
		return nil, ferr or "cannot delete", c
	end
	return nil, "cannot delete"
end

local function normKey(p)
	local r = u.resolve(p)
	if type(r) ~= "string" then
		return nil
	end
	r = u.pretty(r)
	r = r:gsub("/+$", "")
	if r == "" then
		r = "/"
	end
	return r
end

function u.rmtree(path, seen)
	local st, e = u.lstat(path)
	if not st then
		return nil, e or "no such file or directory"
	end
	local tail = tostring(path):gsub("/+$", ""):match("([^/]*)$")
	if tail == "." or tail == ".." then
		return nil, "refusing to remove '.' or '..'"
	end
	local key = normKey(path)
	if not key then
		return nil, "cannot resolve " .. tostring(path)
	end
	if key == "/" then
		return nil, "refusing to remove the root directory"
	end
	local cwd = normKey(".")
	if cwd and key == cwd then
		return nil, "refusing to remove the current directory"
	end
	if st.type == "link" then
		local ok, ue = u.unlink(path)
		if not ok then
			return nil, ue
		end
		return true
	end
	if st.type == "dir" then
		seen = seen or {}
		if seen[key] then
			return nil, "directory loop detected at " .. tostring(path)
		end
		seen[key] = true
		local names, re = u.readdir(path)
		if not names then
			return nil, re or "cannot read directory"
		end
		for _, n in ipairs(names) do
			local ok, ce = u.rmtree(path .. "/" .. n, seen)
			if not ok then
				return nil, ce
			end
		end
		seen[key] = nil
	end
	local ok, ue = u.unlink(path)
	if not ok then
		return nil, ue
	end
	return true
end

local function readWhole(path)
	if _fs then
		local ok, h, code, msg = pcall(_fs.open, path, "r")
		if ok and h then
			local parts = {}
			while true do
				local rs = table.pack(pcall(h.read, h, 4096))
				if not rs[1] then
					break
				end
				local got
				for i = 2, rs.n do
					if type(rs[i]) == "string" then
						got = rs[i]
						break
					end
				end
				if not got then
					break
				end
				parts[#parts + 1] = got
			end
			pcall(h.close, h)
			return table.concat(parts)
		end
		if not ok then
			return nil, tostring(h)
		end
	end
	return nil, "cannot read"
end

local function writeWhole(path, data, append)
	if _fs then
		local ok, h, code, msg = pcall(_fs.open, path, append and "a" or "w")
		if ok and h then
			local ok2, r, c, m = pcall(h.write, h, tostring(data))
			pcall(h.close, h)
			if ok2 and r then
				return true
			end
			return nil, errmsg(m, c) or "write failed"
		end
		if not ok then
			return nil, tostring(h)
		end
	end
	return nil, "cannot write"
end

local function writeWholeNoFollow(path, data, append)
	local st, e = u.lstat(path)
	if st then
		if st.type == "link" then
			return nil, "refusing to write through symbolic link"
		end
		if st.type == "dir" then
			return nil, "is a directory"
		end
	elseif e and e ~= "no such file or directory" then
		return nil, e
	end
	return writeWhole(path, data, append)
end

function u.readFile(path)
	return readWhole(path)
end
function u.writeFile(path, data, append)
	return writeWholeNoFollow(path, data, append)
end
function u.writeFileFollow(path, data, append)
	return writeWhole(path, data, append)
end

function u.copyFile(src, dst)
	local sst = u.lstat(src)
	if sst and sst.type == "fifo" then
		return nil, "cannot copy a fifo (would block reading it)"
	end
	local data, e = readWhole(src)
	if not data then
		return nil, e
	end
	local existed = u.lstat(dst) ~= nil
	local ok, werr = writeWhole(dst, data)
	if ok and not existed then
		local st = sst or u.stat(src)
		if st and st.mode then
			local mask = 511
			if _fs and _fs.umask then
				local okm, m = pcall(_fs.umask)
				if okm and type(m) == "number" then
					mask = 511 & ~m & 511
				end
			end
			local mode = st.mode & mask & 511
			if _fs and _fs.chmod then
				pcall(_fs.chmod, dst, mode)
			end
		end
	end
	return ok, werr
end

local function copyTreeInto(src, dst, opts, seen, depth)
	depth = depth or 0
	if depth > 64 then
		return nil, "too many levels of symbolic links (or directories nested too deeply)"
	end
	local s
	if opts.follow then
		local ferr
		s, ferr = u.stat(src)
		if not s then
			return nil, ferr or "cannot follow symbolic link"
		end
	else
		s = u.lstat(src)
	end
	if not s then
		return nil, "no such file or directory"
	end

	if s.type == "link" and not opts.follow then
		local tgt = s.link
		if tgt == nil then
			tgt = u.readlink(src)
		end
		if tgt == nil then
			return nil, "cannot read symbolic link"
		end
		local d = u.lstat(dst)
		if d then
			if d.type == "dir" then
				return nil, "cannot replace a directory with a symbolic link"
			end
			if opts.noClobber then
				return true
			end
			local ok, e = u.unlink(dst)
			if not ok then
				return nil, e
			end
		end
		if not (_fs and _fs.symlink) then
			return nil, "symbolic links are not supported"
		end
		local ok, code, e = _fs.symlink(tgt, dst)
		if not ok then
			return nil, e or code
		end
		return true
	end

	if s.type == "dir" then
		local key = normKey(src)
		if key then
			if seen[key] then
				return nil, "symbolic link loop (or mount cycle) at " .. src
			end
			seen[key] = true
		end
		local d = u.lstat(dst)
		if d and d.type == "link" then
			if opts.follow then
				local ds = u.stat(dst)
				if not ds or ds.type ~= "dir" then
					return nil, "not a directory"
				end
				d = ds
			else
				local ok, e = u.unlink(dst)
				if not ok then
					return nil, e
				end
				d = nil
			end
		end
		if d and d.type ~= "dir" then
			return nil, "not a directory"
		end
		local created = false
		if not d then
			local ok, e = u.mkdir(dst)
			if not ok then
				return nil, e
			end
			created = true
			if s.mode then
				u.chmod(dst, (s.mode & 4095) | 448)
			end
		end
		local names, re = u.readdir(src)
		if not names then
			if key then
				seen[key] = nil
			end
			return nil, re or "cannot read directory"
		end
		for _, n in ipairs(names) do
			local ok, e = copyTreeInto(src .. "/" .. n, dst .. "/" .. n, opts, seen, depth + 1)
			if not ok then
				if key then
					seen[key] = nil
				end
				return nil, e
			end
		end
		if key then
			seen[key] = nil
		end
		if (created or opts.preserve) and s.mode then
			u.chmod(dst, s.mode & 4095)
		end
		if opts.preserve then
			if s.uid and s.gid then
				pcall(u.chown, dst, s.uid, s.gid)
			end
			if s.mtime ~= nil and _fs and _fs.utimes then
				pcall(_fs.utimes, dst, s.mtime)
			end
		end
		return true
	end

	if s.type == "fifo" then
		local d = u.lstat(dst)
		if d then
			if d.type == "dir" then
				return nil, "cannot replace a directory with a fifo"
			end
			if opts.noClobber then
				return true
			end
			local ok, e = u.unlink(dst)
			if not ok then
				return nil, e
			end
		end
		if not (_fs and _fs.mkfifo) then
			return nil, "fifos are not supported"
		end
		local ok, code, msg = _fs.mkfifo(dst)
		if not ok then
			return nil, msg or code
		end
		if s.mode then
			u.chmod(dst, s.mode & 4095)
		end
		if opts.preserve and s.mtime ~= nil and _fs and _fs.utimes then
			pcall(_fs.utimes, dst, s.mtime)
		end
		return true
	end

	if s.type ~= "file" then
		return nil, "unsupported file type (" .. tostring(s.type) .. ")"
	end
	local d = u.lstat(dst)
	if d then
		if d.type == "dir" then
			return nil, "is a directory"
		end
		if opts.noClobber then
			return true
		end
		if d.type == "link" then
			local ok, e = u.unlink(dst)
			if not ok then
				return nil, e
			end
		end
	end
	local ok, e = u.copyFile(src, dst)
	if not ok then
		return nil, e
	end
	if opts.preserve and s.mode then
		u.chmod(dst, s.mode & 4095)
		if s.mtime ~= nil and _fs and _fs.utimes then
			pcall(_fs.utimes, dst, s.mtime)
		end
	end
	return true
end

function u.copyTree(src, dst, opts)
	opts = opts or {}
	local ls = u.lstat(src)
	if ls and ls.type == "dir" then
		local rs, rd = normKey(src), normKey(dst)
		if rs and rd and (rd == rs or (rs ~= "/" and rd:sub(1, #rs + 1) == rs .. "/")) then
			return nil, "cannot copy a directory into itself"
		end
	end
	return copyTreeInto(src, dst, opts, {})
end

function u.joinPath(base, name)
	if base == nil or base == "" or base == "." then
		return name
	end
	if base:sub(-1) == "/" then
		return base .. name
	end
	return base .. "/" .. name
end

function u.safeRel(rel)
	if type(rel) ~= "string" then
		return nil, "invalid name"
	end
	if rel == "" then
		return nil, "empty name"
	end
	if rel:find("%z") then
		return nil, "NUL in name"
	end
	if rel:sub(1, 1) == "/" then
		return nil, "absolute name"
	end
	if rel:find(":", 1, true) then
		return nil, "':' in name"
	end
	local segs = {}
	for seg in rel:gmatch("[^/]+") do
		if seg == "." then
		elseif seg == ".." then
			return nil, "'..' component"
		else
			segs[#segs + 1] = seg
		end
	end
	if #segs == 0 then
		return nil, "empty name"
	end
	return table.concat(segs, "/")
end

function u.safePath(base, rel)
	local clean, e = u.safeRel(rel)
	if not clean then
		return nil, e
	end
	local segs = {}
	for seg in clean:gmatch("[^/]+") do
		segs[#segs + 1] = seg
	end
	local cur, st = base, nil
	for i, seg in ipairs(segs) do
		cur = u.joinPath(cur, seg)
		st = u.lstat(cur)
		if st == nil then
			return cur, nil
		end
		if st.type == "link" then
			return nil, "path traverses a symbolic link (" .. cur .. ")"
		end
		if i < #segs and st.type ~= "dir" then
			return nil, "not a directory (" .. cur .. ")"
		end
	end
	return cur, st
end

function u.safeMkdirs(base, rel)
	local clean, e = u.safeRel(rel)
	if not clean then
		return nil, e
	end
	local cur = base
	for seg in clean:gmatch("[^/]+") do
		cur = u.joinPath(cur, seg)
		local st = u.lstat(cur)
		if st then
			if st.type == "link" then
				return nil, "path traverses a symbolic link (" .. cur .. ")"
			end
			if st.type ~= "dir" then
				return nil, "not a directory (" .. cur .. ")"
			end
		else
			local ok, me = u.mkdir(cur)
			if not ok then
				local s2 = u.lstat(cur)
				if not s2 or s2.type ~= "dir" then
					return nil, me or "cannot create directory"
				end
			end
		end
	end
	return cur
end

function u.safeWriteFile(base, rel, data, mode)
	local clean, e = u.safeRel(rel)
	if not clean then
		return nil, e
	end
	local dir = clean:match("^(.*)/[^/]+$")
	if dir then
		local ok, de = u.safeMkdirs(base, dir)
		if not ok then
			return nil, de
		end
	end
	local path, st = u.safePath(base, clean)
	if not path then
		return nil, st
	end
	if st then
		if st.type == "dir" then
			return nil, "is a directory"
		end
		if st.type ~= "file" then
			local ok, ue = u.unlink(path)
			if not ok then
				return nil, ue
			end
		end
	end
	local ok, we = u.writeFile(path, data)
	if ok and mode then
		u.chmod(path, mode & 4095)
	end
	return ok, we
end

function u.safeSymlink(base, rel, target)
	local clean, e = u.safeRel(rel)
	if not clean then
		return nil, e
	end
	local dir = clean:match("^(.*)/[^/]+$")
	if dir then
		local ok, de = u.safeMkdirs(base, dir)
		if not ok then
			return nil, de
		end
	end
	local path, st = u.safePath(base, clean)
	if not path then
		return nil, st
	end
	if st then
		if st.type == "dir" then
			return nil, "file exists (directory)"
		end
		local ok, ue = u.unlink(path)
		if not ok then
			return nil, ue
		end
	end
	if not (_fs and _fs.symlink) then
		return nil, "symbolic links are not supported"
	end
	local ok, code, e = _fs.symlink(target, path)
	if not ok then
		return nil, e or code
	end
	return true
end

function u.safeMkfifo(base, rel)
	local clean, e = u.safeRel(rel)
	if not clean then
		return nil, e
	end
	local dir = clean:match("^(.*)/[^/]+$")
	if dir then
		local ok, de = u.safeMkdirs(base, dir)
		if not ok then
			return nil, de
		end
	end
	local path, st = u.safePath(base, clean)
	if not path then
		return nil, st
	end
	if st then
		if st.type == "dir" then
			return nil, "file exists (directory)"
		end
		local ok, ue = u.unlink(path)
		if not ok then
			return nil, ue
		end
	end
	if not (_fs and _fs.mkfifo) then
		return nil, "fifos are not supported"
	end
	local ok, code, msg = _fs.mkfifo(path)
	if ok then
		return true
	end
	return nil, msg or code
end

function u.renameRaw(a, b)
	if _fs and _fs.rename then
		local ok, r, c, m = pcall(_fs.rename, a, b)
		if ok and r then
			return true
		end
		if ok then
			return nil, m or c or "cannot rename"
		end
		return nil, tostring(r)
	end
	return nil, "cannot rename"
end

local rngState = nil
local RND_CHARS = "abcdefghijklmnopqrstuvwxyz0123456789"
function u.randomName(n)
	if not rngState then
		local seed = ((u.wall() or 1) * 1000003 + (u.getpid() or 1) * 2654435761) & 0x7fffffff
		if seed == 0 then
			seed = 2463534242
		end
		rngState = seed
	end
	local out = {}
	for i = 1, (n or 10) do
		rngState = (rngState ~ (rngState << 13)) & 0xffffffff
		rngState = (rngState ~ (rngState >> 17)) & 0xffffffff
		rngState = (rngState ~ (rngState << 5)) & 0xffffffff
		local k = (rngState % #RND_CHARS) + 1
		out[i] = RND_CHARS:sub(k, k)
	end
	return table.concat(out)
end

function u.createExclusive(dir, prefix, isdir)
	prefix = prefix or "tmp."
	for _ = 1, 200 do
		local path = u.joinPath(dir, prefix .. u.randomName(10))
		if not u.lstat(path) then
			if isdir then
				local ok = u.mkdir(path)
				if ok then
					u.chmod(path, 448)
					return path
				end
			else
				local ok = u.writeFile(path, "")
				if ok then
					u.chmod(path, 384)
					local st = u.lstat(path)
					if st and st.type == "file" then
						return path
					end
				end
			end
		end
	end
	return nil, "cannot create a unique name in " .. tostring(dir)
end

local _sys = (type(sys) == "table") and sys or nil
local _time = (type(time) == "table") and time or nil
local _user = (type(user) == "table") and user or nil
local _system = (type(system) == "table") and system or nil

function u.plural(n, w)
	return n .. " " .. w .. (n == 1 and "" or "s")
end

function u.isatty(fd)
	if _stdio and type(_stdio.isatty) == "function" then
		local h = nil
		if type(fd) == "table" then
			h = fd
		elseif fd == 0 or fd == nil then
			h = _stdio.stdin
		elseif fd == 1 then
			h = _stdio.stdout
		elseif fd == 2 then
			h = _stdio.stderr
		end
		if h then
			local ok, r = pcall(_stdio.isatty, h)
			if ok then
				return r and true or false
			end
		end
	end
	return false
end

function u.access(path, want)
	local ways = nil
	if type(want) == "string" then
		ways = want
	elseif type(want) == "number" then
		local s = ""
		if (want & 4) ~= 0 then
			s = s .. "r"
		end
		if (want & 2) ~= 0 then
			s = s .. "w"
		end
		if (want & 1) ~= 0 then
			s = s .. "x"
		end
		ways = s == "" and "r" or s
	else
		ways = "r"
	end
	if _fs and type(_fs.access) == "function" then
		local ok, r = pcall(_fs.access, path, ways)
		if ok then
			return r and true or false
		end
	end
	return false
end

function u.exists(path)
	if _fs and type(_fs.exists) == "function" then
		local ok, r = pcall(_fs.exists, path)
		if ok then
			return r and true or false
		end
	end
	return u.stat(path) ~= nil
end

function u.isfile(path)
	if _fs and type(_fs.isFile) == "function" then
		local ok, r = pcall(_fs.isFile, path)
		if ok then
			return r and true or false
		end
	end
	local s = u.stat(path)
	return s ~= nil and s.type == "file"
end

function u.getHost()
	if _system and type(_system.hostname) == "function" then
		local ok, v = pcall(_system.hostname)
		if ok and type(v) == "string" then
			return v
		end
	end
	return nil
end

function u.getUid()
	if _user and type(_user.current) == "function" then
		local ok, me = pcall(_user.current)
		if ok and type(me) == "table" and me.id ~= nil then
			return me.id
		end
	end
	return nil
end

function u.userName(uid)
	if _user then
		if uid == nil and type(_user.current) == "function" then
			local ok, me = pcall(_user.current)
			if ok and type(me) == "table" and me.name then
				return me.name
			end
		elseif uid ~= nil and type(_user.byId) == "function" then
			local ok, person = pcall(_user.byId, uid)
			if ok and type(person) == "table" and person.name then
				return person.name
			end
		end
	end
	return nil
end

function u.unameInfo()
	if _sys and type(_sys.getOSName) == "function" and _system and type(_system.hostname) == "function" then
		local ok1, sn = pcall(_sys.getOSName)
		if ok1 and type(sn) == "string" then
			local _, sv = pcall(_sys.getOSVersion)
			local _, hn = pcall(_system.hostname)
			local mc = nil
			if type(_system.machine) == "function" then
				local okm, m = pcall(_system.machine)
				if okm and type(m) == "string" then
					mc = m
				end
			end
			return {
				sysname = tostring(sn),
				nodename = tostring(type(hn) == "string" and hn or "unknown"),
				release = tostring(type(sv) == "string" and sv or "unknown"),
				version = tostring(type(sv) == "string" and sv or "unknown"),
				machine = tostring(type(mc) == "string" and mc or "unknown"),
			}
		end
	end
	return nil
end

function u.wall()
	if _time and type(_time.wall) == "function" then
		local ok, v = pcall(_time.wall)
		if ok and type(v) == "number" then
			return v
		end
	end
	if _time and type(_time.monotonic) == "function" then
		local ok, v = pcall(_time.monotonic)
		if ok and type(v) == "number" then
			return v
		end
	end
	return nil
end

function u.dateParts(ts)
	if _time and type(_time.date) == "function" then
		local t = ts
		if t == nil then
			t = u.wall()
		end
		if type(t) == "number" then
			t = math.floor(t)
		end
		local ok, d = pcall(_time.date, t)
		if ok and type(d) == "table" and d.month then
			return d
		end
	end
	return nil
end

function u.dateStr(ts)
	local d = u.dateParts(ts)
	if type(d) == "table" and d.month then
		local wd = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" }
		local mo = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }
		return string.format(
			"%s %s %2d %02d:%02d:%02d UTC %d",
			wd[(d.wday or 0) + 1] or "???",
			mo[d.month] or "???",
			d.day or 0,
			d.hour or 0,
			d.min or 0,
			d.sec or 0,
			d.year or 1970
		)
	end
	return nil
end

function u.uptime()
	if _system and type(_system.uptime) == "function" then
		local ok, v = pcall(_system.uptime)
		if ok and type(v) == "number" then
			return v
		end
	end
	if _time and type(_time.monotonic) == "function" then
		local ok, v = pcall(_time.monotonic)
		if ok and type(v) == "number" then
			return v
		end
	end
	return nil
end

function u.sleep(t)
	if _sys and type(_sys.sleep) == "function" then
		return _sys.sleep(t)
	end
	if type(sys) == "table" and type(sys.sleep) == "function" then
		return sys.sleep(t)
	end
	return nil, "cannot sleep"
end

function u.getpid()
	if _proc and type(_proc.getpid) == "function" then
		local ok, v = pcall(_proc.getpid)
		if ok and v ~= nil then
			return v
		end
	end
	return nil
end

function u.spawnSimple(path, args)
	args = args or {}
	if _proc and type(_proc.spawn) == "function" then
		local ok, pid, code, msg = pcall(_proc.spawn, path, args)
		if ok and pid then
			if type(_proc.wait) == "function" then
				local ok2, cpid, st = pcall(_proc.wait, pid)
				if ok2 then
					return cpid, st
				end
			end
			return pid
		elseif ok and pid == nil then
			return nil, code, msg
		end
	end
	return nil, "cannot spawn"
end

function u.readline(opts)
	if _stdio and type(_stdio.readLine) == "function" then
		local ok, line = pcall(_stdio.readLine, opts or {})
		if ok then
			return line
		end
	end
	return nil
end

function u.setenv(k, v)
	if _env and type(_env.set) == "function" then
		local ok, r = pcall(_env.set, k, v)
		if ok then
			return r
		end
	end
	return nil
end

return u
