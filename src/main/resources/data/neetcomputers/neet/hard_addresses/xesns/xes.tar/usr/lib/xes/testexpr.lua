local u = require("util")

local M = {}

function M.run(me, argv)
	if #argv > 0 and argv[1] == "--" then
		table.remove(argv, 1)
	end
	if #argv == 0 then
		return 1
	end
	if #argv == 1 then
		return argv[1] ~= "" and 0 or 1
	end

	local pos = 1
	local function peek()
		return argv[pos]
	end
	local function next()
		local v = argv[pos]
		pos = pos + 1
		return v
	end
	local function perr(m)
		u.die(me, m, 2)
	end

	local UN1 = {
		["-e"] = 1,
		["-f"] = 1,
		["-d"] = 1,
		["-r"] = 1,
		["-w"] = 1,
		["-x"] = 1,
		["-s"] = 1,
		["-z"] = 1,
		["-n"] = 1,
		["-L"] = 1,
		["-h"] = 1,
		["-t"] = 1,
		["-v"] = 1,
	}

	local BIN = {
		["="] = 1,
		["=="] = 1,
		["!="] = 1,
		["<"] = 1,
		[">"] = 1,
		["-eq"] = 1,
		["-ne"] = 1,
		["-lt"] = 1,
		["-gt"] = 1,
		["-le"] = 1,
		["-ge"] = 1,
	}

	local function unary(op, v)
		if v == nil then
			perr("`" .. op .. "' needs an argument")
		end
		if op == "-e" then
			return u.exists(v)
		end
		if op == "-f" then
			local s = u.stat(v)
			return s ~= nil and s.type == "file"
		end
		if op == "-d" then
			local s = u.stat(v)
			return s ~= nil and s.type == "dir"
		end
		if op == "-r" or op == "-w" or op == "-x" then
			local s = u.stat(v)
			if s == nil then
				return false
			end
			local want = op == "-r" and "r" or op == "-w" and "w" or "x"
			return u.access(v, want)
		end
		if op == "-s" then
			local s = u.stat(v)
			return s ~= nil and (s.size or 0) > 0
		end
		if op == "-z" then
			return v == ""
		end
		if op == "-n" then
			return v ~= ""
		end
		if op == "-L" or op == "-h" then
			return u.readlink(v) ~= nil
		end
		if op == "-t" then
			local fd = tonumber(v)
			if fd == nil then
				return false
			end
			return u.isatty(fd)
		end
		if op == "-v" then
			return u.getenv(v) ~= nil
		end
		perr("unknown unary: " .. op)
	end

	local function binary(l, op, r)
		if r == nil then
			perr("`" .. op .. "' needs an argument")
		end
		if op == "=" or op == "==" then
			return l == r
		end
		if op == "!=" then
			return l ~= r
		end
		if op == "<" then
			return l < r
		end
		if op == ">" then
			return l > r
		end
		local x = l:match("^%s*[-+]?%d+%s*$") and tonumber(l)
		local y = r:match("^%s*[-+]?%d+%s*$") and tonumber(r)
		if not x or not y then
			perr("integer expected: `" .. l .. "' `" .. r .. "'")
		end
		if op == "-eq" then
			return x == y
		elseif op == "-ne" then
			return x ~= y
		elseif op == "-lt" then
			return x < y
		elseif op == "-gt" then
			return x > y
		elseif op == "-le" then
			return x <= y
		elseif op == "-ge" then
			return x >= y
		end
		perr("unknown operator: " .. op)
	end

	local pOr, pAnd, pNot, pPrim
	function pPrim()
		local t = peek()
		if t == nil then
			perr("missing argument")
		end
		if t == "(" then
			next()
			local v = pOr()
			if peek() ~= ")" then
				perr("expected `)'")
			end
			next()
			return v
		end
		if UN1[t] then
			next()
			return unary(t, next())
		end
		local l = next()
		if l == ")" then
			perr("unexpected `)'")
		end
		if l == "-a" or l == "-o" or l == "!" then
			perr("unexpected `" .. l .. "'")
		end
		local o = peek()
		if o and BIN[o] then
			next()
			return binary(l, o, next())
		end
		return l ~= ""
	end

	function pNot()
		if peek() == "!" then
			next()
			return not pNot()
		end
		return pPrim()
	end

	function pAnd()
		local v = pNot()
		while true do
			local t = peek()
			if t == nil or t == ")" or t == "-o" then
				return v
			end
			if t == "-a" then
				next()
			end
			local r = pNot()
			v = v and r
		end
	end

	function pOr()
		local v = pAnd()
		while peek() == "-o" do
			next()
			local r = pAnd()
			v = v or r
		end
		return v
	end

	local ok, res = pcall(pOr)
	if not ok then
		local m = tostring(res)
		if m == "<exit>" then
			return 2
		end
	if m:find(me .. ": ", 1, true) or (me == "[" and m:find("missing", 1, true)) then
			return 2
		end
		u.err(me .. ": " .. m)
		return 2
	end
	if pos <= #argv then
		perr("extra argument `" .. tostring(peek()) .. "'")
	end
	return res and 0 or 1
end

return M
