local K = ...

K.NAME = "XesNS"
K.VERSION = "0.1.0"
K.KERNEL = "GENERIC"
K.RELEASE = "0.1.0-beta.1"

local getUnix = chip.getUnixTime
function K.now()
    if getUnix then return getUnix() end
    return chip.getTime()
end

K.boottime = K.now()
K.ticks = 0

function K.uptime() return K.now() - K.boottime end

local ring, RING_MAX = {}, 500
K.logsink = nil

function K.klog(fmt, ...)
    local msg = fmt
    if select("#", ...) > 0 then msg = string.format(fmt, ...) end
    ring[#ring + 1] = msg
    if #ring > RING_MAX then table.remove(ring, 1) end
    if K.logsink then K.logsink(msg) end
    return msg
end

function K.klog_lines() return ring end

function K.trim(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end

function K.split(s, sep, plain)
    local out, i = {}, 1
    sep = sep or "%s+"
    while true do
        local a, b = s:find(sep, i, plain)
        if not a or b < a then
            out[#out + 1] = s:sub(i); break
        end
        out[#out + 1] = s:sub(i, a - 1)
        i = b + 1
    end
    return out
end

function K.startswith(s, p) return s:sub(1, #p) == p end

function K.endswith(s, p) return p == "" or s:sub(- #p) == p end

function K.copy(t)
    local o = {}
    for k, v in pairs(t) do o[k] = v end
    return o
end

function K.sortedKeys(t)
    local ks = {}
    for k in pairs(t) do ks[#ks + 1] = k end
    table.sort(ks, function(a, b)
        if type(a) == type(b) then return a < b end
        return tostring(a) < tostring(b)
    end)
    return ks
end

function K.pad(s, n, right)
    s = tostring(s)
    if #s >= n then return s end
    if right then return string.rep(" ", n - #s) .. s end
    return s .. string.rep(" ", n - #s)
end

function K.date(ts)
    ts = math.floor(ts)
    local days, rem = ts // 86400, ts % 86400
    local hh, mm, ss = rem // 3600, (rem % 3600) // 60, rem % 60
    local z = days + 719468
    local era = z // 146097
    local doe = z - era * 146097
    local yoe = (doe - doe // 1460 + doe // 36524 - doe // 146096) // 365
    local y = yoe + era * 400
    local doy = doe - (365 * yoe + yoe // 4 - yoe // 100)
    local mp = (5 * doy + 2) // 153
    local d = doy - (153 * mp + 2) // 5 + 1
    local m = mp < 10 and mp + 3 or mp - 9
    if m <= 2 then y = y + 1 end
    local wday = (days + 4) % 7
    return { year = y, month = m, day = d, hour = hh, min = mm, sec = ss, wday = wday }
end

local WD = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" }
local MO = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }
function K.dateString(ts)
    local d = K.date(ts or K.now())
    return string.format("%s %s %2d %02d:%02d:%02d UTC %d", WD[d.wday + 1], MO[d.month],
        d.day, d.hour, d.min, d.sec, d.year)
end

local function makeBit32()
    local M = 0xFFFFFFFF
    local b = {}
    local function n(x) return math.tointeger(x // 1) & M end
    function b.band(...)
        local r = M
        for _, v in ipairs({ ... }) do r = r & n(v) end
        return r
    end

    function b.bor(...)
        local r = 0
        for _, v in ipairs({ ... }) do r = r | n(v) end
        return r
    end

    function b.bxor(...)
        local r = 0
        for _, v in ipairs({ ... }) do r = r ~ n(v) end
        return r
    end

    function b.bnot(x) return (~n(x)) & M end

    function b.btest(...) return b.band(...) ~= 0 end

    function b.lshift(x, d)
        d = math.tointeger(d)
        if d >= 32 or d <= -32 then return 0 end
        if d < 0 then return n(x) >> -d end
        return (n(x) << d) & M
    end

    function b.rshift(x, d) return b.lshift(x, -d) end

    function b.arshift(x, d)
        x = n(x); d = math.tointeger(d)
        if d < 0 then return b.lshift(x, -d) end
        if d >= 32 then return (x & 0x80000000) ~= 0 and M or 0 end
        local r = x >> d
        if (x & 0x80000000) ~= 0 then r = r | ((M << (32 - d)) & M) end
        return r
    end

    function b.lrotate(x, d)
        x = n(x); d = math.tointeger(d) % 32
        if d == 0 then return x end
        return ((x << d) | (x >> (32 - d))) & M
    end

    function b.rrotate(x, d) return b.lrotate(x, -math.tointeger(d)) end

    function b.extract(x, f, w)
        w = w or 1
        if f < 0 or w < 1 or f + w > 32 then error("field out of range", 2) end
        return (n(x) >> f) & ((1 << w) - 1)
    end

    function b.replace(x, v, f, w)
        w = w or 1
        if f < 0 or w < 1 or f + w > 32 then error("field out of range", 2) end
        local mask = ((1 << w) - 1) << f
        return (n(x) & ~mask & M) | ((n(v) << f) & mask)
    end

    return b
end
K.bit32 = rawget(_G, "bit32") or makeBit32()

function K.panic(msg)
    msg = "panic: " .. tostring(msg)
    ring[#ring + 1] = msg
    local hostprint = rawget(_G, "print")
    if hostprint then pcall(hostprint, msg) end
    if K.tty0 and K.tty_show then
        pcall(function()
            local t = K.tty0
            t:setCursorPos(1, math.min(t.rows, select(2, t:getCursorPos())))
            t:print("", 255, 90, 90, 0, 0, 0)
            for line in (msg .. "\n"):gmatch("([^\n]*)\n") do
                t:print(line, 255, 90, 90, 0, 0, 0)
            end
            t:print("halted.", 255, 90, 90, 0, 0, 0)
            K.tty_show(t)
            K.tty_flush(true)
        end)
    end
    chip.crash(msg)
    while true do coroutine.yield() end
end
