local K = ...

local psf = {}
K.psf = psf

local Font = {}
Font.__index = Font

local function parse(data)
    if #data < 4 then return nil, "font too short" end
    local b1, b2 = data:byte(1, 2)
    local glyphs, w, h, bpr = {}, 8, 0, 1
    local uni = nil
    if b1 == 0x36 and b2 == 0x04 then
        local mode, size = data:byte(3, 4)
        h = size
        local n = (mode % 4 >= 2) and 512 or 256
        for i = 0, n - 1 do
            local off = 4 + i * size
            if off + size > #data then break end
            glyphs[i] = data:sub(off + 1, off + size)
        end
    elseif b1 == 0x72 and b2 == 0xb5 then
        local _, headersize, flags, num, bpg, gh, gw = string.unpack("<I4I4I4I4I4I4I4", data, 5)
        w, h = gw, gh
        bpr = (w + 7) // 8
        for i = 0, num - 1 do
            local off = headersize + i * bpg
            if off + bpg > #data then break end
            glyphs[i] = data:sub(off + 1, off + bpg)
        end
        if (flags & 1) ~= 0 then
            local map, gi = {}, 0
            local seq, start = {}, headersize + num * bpg + 1
            local function flush()
                for _, s in ipairs(seq) do
                    local ok, cp = pcall(utf8.codepoint, s, 1)
                    if ok and cp ~= nil and map[cp] == nil then map[cp] = gi end
                end
                seq = {}
            end
            local i = start
            while i <= #data and gi < num do
                local b = data:byte(i)
                if b == 0xFE then
                    if i > start then seq[#seq + 1] = data:sub(start, i - 1) end
                    flush()
                    gi = gi + 1
                    i = i + 1
                    start = i
                elseif b == 0xFF then
                    if i > start then seq[#seq + 1] = data:sub(start, i - 1) end
                    i = i + 1
                    start = i
                else
                    i = i + 1
                end
            end
            if gi < num and start <= #data then
                seq[#seq + 1] = data:sub(start)
                flush()
            end
            if next(map) ~= nil then uni = map end
        end
    else
        return nil, string.format("not a PSF file (magic %02x %02x)", b1 or 0, b2 or 0)
    end
    return { glyphs = glyphs, w = w, h = h, bpr = bpr, uni = uni }
end

function psf.load(data, padY)
    local f, err = parse(data)
    if not f then return nil, err end
    f.padY = padY or 0
    f.cellW, f.cellH = f.w, f.h + f.padY
    f.cache, f.ncache = {}, 0
    f.rowBits = {}
    return setmetatable(f, Font)
end

local strchar = string.char

function Font:cell(code, fg, bg)
    local key = code * 281474976710656 + fg * 16777216 + bg
    local buf = self.cache[key]
    if buf then return buf end
    if self.ncache > 3000 then self.cache, self.ncache = {}, 0 end

    local fgs = strchar((fg >> 16) & 255, (fg >> 8) & 255, fg & 255, 255)
    local bgs = strchar((bg >> 16) & 255, (bg >> 8) & 255, bg & 255, 255)

    local gi = (self.uni and self.uni[code]) or code
    local gl = (code > 32) and (self.glyphs[gi] or self.glyphs[63]) or nil
    local parts, n = {}, 0
    local w, bpr = self.w, self.bpr
    for y = 0, self.h - 1 do
        if gl then
            for x = 0, w - 1 do
                local byte = gl:byte(y * bpr + (x >> 3) + 1) or 0
                n = n + 1
                parts[n] = ((byte >> (7 - (x & 7))) & 1) == 1 and fgs or bgs
            end
        else
            n = n + 1
            parts[n] = string.rep(bgs, w)
        end
    end
    if self.padY > 0 then
        n = n + 1
        parts[n] = string.rep(bgs, w * self.padY)
    end
    buf = table.concat(parts)
    self.cache[key] = buf
    self.ncache = self.ncache + 1
    return buf
end
