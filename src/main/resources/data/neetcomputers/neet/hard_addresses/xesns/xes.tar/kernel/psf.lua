local K = ...

local psf = {}
K.psf = psf

local Font = {}
Font.__index = Font

local MAX_GLYPHS = 8192
local MAX_W = 256
local MAX_H = 512
local MAX_BPG = 8192

local function utf8_at(s, i)
	local b = s:byte(i)
	if not b then
		return nil, i + 1
	end
	if b < 0x80 then
		return b, i + 1
	end
	local n, min
	if b >= 0xC2 and b <= 0xDF then
		n, min = 1, 0x80
	elseif b >= 0xE0 and b <= 0xEF then
		n, min = 2, 0x800
	elseif b >= 0xF0 and b <= 0xF4 then
		n, min = 3, 0x10000
	else
		return nil, i + 1
	end
	local cp = b & ((1 << (6 - n)) - 1)
	for k = 1, n do
		local c = s:byte(i + k)
		if not c or c < 0x80 or c > 0xBF then
			return nil, i + 1
		end
		cp = (cp << 6) | (c & 0x3F)
	end
	if cp < min or cp > 0x10FFFF or (cp >= 0xD800 and cp <= 0xDFFF) then
		return nil, i + 1
	end
	return cp, i + n + 1
end

local function parse_psf1(data)
	local mode, size = data:byte(3, 4)
	if mode > 5 then
		return nil, "bad PSF1 mode"
	end
	if size < 1 or size > 128 then
		return nil, "bad PSF1 character size"
	end
	local declared = (mode % 2 == 1) and 512 or 256
	local avail = (#data - 4) // size
	if avail < 1 then
		return nil, "truncated PSF1 bitmaps"
	end
	local n = declared < avail and declared or avail
	local glyphs = {}
	for i = 0, n - 1 do
		local off = 4 + i * size
		glyphs[i] = data:sub(off + 1, off + size)
	end
	local uni = nil
	if (mode & 2) ~= 0 then
		local p = 4 + declared * size + 1
		local map, gi = {}, 0
		while p + 1 <= #data and gi < n do
			local a, b = data:byte(p, p + 1)
			local v = a + b * 256
			p = p + 2
			if v == 0xFFFF then
				gi = gi + 1
			elseif v == 0xFFFE then
			elseif v < 0xFFFE then
				if map[v] == nil then
					map[v] = gi
				end
			end
		end
		if next(map) ~= nil then
			uni = map
		end
	end
	return { glyphs = glyphs, w = 8, h = size, bpr = 1, uni = uni, n = n }
end

local function parse_psf2(data)
	local ver, headersize, flags, num, bpg, gh, gw = string.unpack("<I4I4I4I4I4I4I4", data, 5)
	if ver ~= 0 then
		return nil, "unsupported PSF2 version"
	end
	if headersize < 32 or headersize > #data then
		return nil, "bad PSF2 header size"
	end
	if num < 1 or num > MAX_GLYPHS then
		return nil, "bad PSF2 glyph count"
	end
	if gw < 1 or gw > MAX_W or gh < 1 or gh > MAX_H then
		return nil, "bad PSF2 glyph dimensions"
	end
	local bpr = (gw + 7) // 8
	if bpg < gh * bpr or bpg > MAX_BPG then
		return nil, "bad PSF2 character size"
	end
	local avail = (#data - headersize) // bpg
	if avail < 1 then
		return nil, "truncated PSF2 bitmaps"
	end
	local n = num < avail and num or avail
	local glyphs = {}
	for i = 0, n - 1 do
		local off = headersize + i * bpg
		glyphs[i] = data:sub(off + 1, off + bpg)
	end
	local uni = nil
	if (flags & 1) ~= 0 then
		local map, gi = {}, 0
		local start = headersize + num * bpg + 1
		local function flush(stop)
			local i = start
			while i < stop do
				local cp, ni = utf8_at(data, i)
				if cp ~= nil and map[cp] == nil then
					map[cp] = gi
				end
				i = ni
			end
		end
		local i = start
		while i <= #data and gi < n do
			local b = data:byte(i)
			if b == 0xFF then
				flush(i)
				gi = gi + 1
				i = i + 1
				start = i
			elseif b == 0xFE then
				flush(i)
				i = i + 1
				start = i
			else
				i = i + 1
			end
		end
		if gi < n and start <= #data then
			flush(#data + 1)
		end
		if next(map) ~= nil then
			uni = map
		end
	end
	return { glyphs = glyphs, w = gw, h = gh, bpr = bpr, uni = uni, n = n }
end

local PSF2_MAGIC = "\114\181\74\134"

local function parse(data)
	if type(data) ~= "string" or #data < 4 then
		return nil, "font too short"
	end
	local b1, b2 = data:byte(1, 2)
	if b1 == 0x36 and b2 == 0x04 then
		return parse_psf1(data)
	elseif data:sub(1, 4) == PSF2_MAGIC then
		if #data < 32 then
			return nil, "PSF2 data too short"
		end
		return parse_psf2(data)
	end
	return nil, string.format("not a PSF file (magic %02x %02x)", b1 or 0, b2 or 0)
end

function psf.load(data, padY)
	local f, err = parse(data)
	if not f then
		return nil, err
	end
	f.padY = padY or 0
	f.cellW, f.cellH = f.w, f.h + f.padY
	f.cache, f.ncache = {}, 0
	f.rowBits = {}
	return setmetatable(f, Font)
end

local strchar = string.char

function Font:cell(code, fg, bg)
	local c = self.cache[code]
	local k2 = fg * 16777216 + bg
	if c then
		local buf = c[k2]
		if buf then
			return buf
		end
	end
	if self.ncache > 3000 then
		self.cache, self.ncache = {}, 0
		c = nil
	end

	local fgs = strchar((fg >> 16) & 255, (fg >> 8) & 255, fg & 255, 255)
	local bgs = strchar((bg >> 16) & 255, (bg >> 8) & 255, bg & 255, 255)

	local gi = (self.uni and self.uni[code]) or code
	local gl = (code > 32) and (self.glyphs[gi] or self.glyphs[63]) or nil
	local parts, n = {}, 0
	local w, bpr = self.w, self.bpr
	for y = 0, self.h - 1 do
		if gl then
			for x = 0, w - 1 do
				local byte = gl:byte(y * bpr + (x >> 3) + 1) or 0
				n = n + 1
				parts[n] = ((byte >> (7 - (x & 7))) & 1) == 1 and fgs or bgs
			end
		else
			n = n + 1
			parts[n] = string.rep(bgs, w)
		end
	end
	if self.padY > 0 then
		n = n + 1
		parts[n] = string.rep(bgs, w * self.padY)
	end
	local buf = table.concat(parts)
	if not c then
		c = {}
		self.cache[code] = c
	end
	c[k2] = buf
	self.ncache = self.ncache + 1
	return buf
end
