local K, API, X = ...
local T = {}

local function int(v, idx, fname)
	return K.argcheck.int(v, idx, fname)
end

local function groupLive(jid)
	for _, q in pairs(K.procs) do
		if q.pgid == jid and q.state ~= "Z" then
			return true
		end
	end
	return false
end

local function known(me, jid)
	return (K.jobs and K.jobs[jid] ~= nil) or jid == me.pgid or groupLive(jid)
end

local function owned(me, jid)
	local j = K.jobs and K.jobs[jid]
	return (j ~= nil and j.owner == me.pid) or jid == me.pgid
end

function T.create(p)
	return API.job.create()
end

function T.enter(p, jid)
	jid = int(jid, 1, "job.enter")
	if not known(p, jid) then
		return nil, "EINVAL", "no such job"
	end
	if p.uid ~= 0 and not owned(p, jid) then
		return nil, "EACCES", "permission denied"
	end
	p.pgid = jid
	return true
end

function T.current(p)
	return p.pgid
end

function T.newSession(p)
	local jid, code, msg = API.job.create()
	if not jid then
		return nil, code or "ELIMIT", msg or "cannot create session"
	end
	local oldpgid = p.pgid
	p.pgid, p.sid = jid, jid
	local j = K.jobs and K.jobs[jid]
	if j then
		j.session = true
	end
	local tty = p.tty
	if tty and tty ~= K.nulltty and tty.fgpgid == oldpgid then
		tty.fgpgid = nil
	end
	return jid
end

function T.getSession(p, pid)
	if X.proc and X.proc.getsid then
		return X.proc.getsid(p, pid)
	end
	local t = (pid == nil or pid == 0) and p or K.procs[pid]
	if not t or t.state == "Z" then
		return nil, "ESRCH", "no such process"
	end
	return t.sid
end

function T.getForeground(p)
	local tty = p.tty
	return tty and tty.fgpgid or nil
end

function T.setForeground(p, jid)
	jid = int(jid, 1, "job.setForeground")
	if not known(p, jid) then
		return nil, "EINVAL", "no such job"
	end
	if p.uid ~= 0 and not owned(p, jid) then
		return nil, "EACCES", "permission denied"
	end
	local tty = p.tty
	if tty and tty ~= K.nulltty then
		tty.fgpgid = jid
		if K.tty_deliverPending then
			K.tty_deliverPending(tty)
		end
	end
	return true
end

function T.setBackground(p, jid)
	jid = int(jid, 1, "job.setBackground")
	if not known(p, jid) then
		return nil, "EINVAL", "no such job"
	end
	if p.uid ~= 0 and not owned(p, jid) then
		return nil, "EACCES", "permission denied"
	end
	local tty = p.tty
	if tty and tty.fgpgid == jid then
		tty.fgpgid = nil
	end
	return true
end

function T.kill(p, jid, how)
	jid = int(jid, 1, "job.kill")
	if not known(p, jid) then
		return nil, "EINVAL", "no such job"
	end
	if p.uid ~= 0 and not owned(p, jid) then
		return nil, "EACCES", "permission denied"
	end
	how = how or "term"
	if X.proc and X.proc.signal then
		return X.proc.signal(p, -jid, how)
	end
	local sig
	if how == "term" then
		sig = K.SIG.TERM
	elseif how == "kill" then
		sig = K.SIG.KILL
	else
		return nil, "EINVAL", "invalid kill mode"
	end
	for _, q in pairs(K.procs) do
		if q.pgid == jid and q.state ~= "Z" then
			K.signal(q, sig)
		end
	end
	return true
end

function T.wait(p, jid, nohang)
	jid = int(jid, 1, "job.wait")
	local r, code, msg = X.proc.waitStatus(p, -jid, nohang and true or false)
	if not r then
		if code then
			return nil, code, msg
		end
		return nil
	end
	return r.pid, r.status, r.signal
end

function T.members(p, jid)
	jid = int(jid, 1, "job.members")
	if not known(p, jid) then
		return nil, "EINVAL", "no such job"
	end
	if p.uid ~= 0 and not owned(p, jid) then
		return nil, "EACCES", "permission denied"
	end
	local out, seen = {}, {}
	for _, q in pairs(K.procs) do
		if q.pgid == jid and q.state ~= "Z" and not seen[q.pid] then
			seen[q.pid] = true
			out[#out + 1] = q.pid
		end
	end
	table.sort(out)
	return out
end

return T
