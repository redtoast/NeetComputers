return {
    extensions = { "json" },
    words = {
        ["true"] = "constant", ["false"] = "constant", ["null"] = "constant",
    },
    rules = {
        { "string", '"[^"]*"', "'[^']*'" },
        { "number", "%-?%f[%d]%d+%.?%d*[eE]?[%+%-]?%d*" },
    },
}
