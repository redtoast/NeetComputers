-- zlib.lua - DEFLATE/zlib compression and decompression.
--
-- Copyright (c) 2026, XesHuman
-- All rights reserved.
--
-- Redistribution and use in source and binary forms, with or without
-- modification, are permitted provided that the following conditions are met:
--
-- 1. Redistributions of source code must retain the above copyright notice,
--    this list of conditions and the following disclaimer.
--
-- 2. Redistributions in binary form must reproduce the above copyright notice,
--    this list of conditions and the following disclaimer in the documentation
--    and/or other materials provided with the distribution.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS "AS IS"
-- AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
-- IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
-- DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
-- FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
-- DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
-- SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
-- CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
-- OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
-- OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
--
-- API
--   zlib.crc32(data)                          -> crc     CRC-32 checksum (unsigned)
--   zlib.adler32(data)                        -> adler   Adler-32 checksum (unsigned)
--   zlib.compress(data [, level])             -> zlib    zlib stream (header, deflate, adler32)
--   zlib.uncompress(comp [, maxout])          -> raw     inverse of compress
--   zlib.deflate(data [, level])              -> raw     raw DEFLATE stream (no wrapper)
--   zlib.deflate_stored(data)                 -> raw     DEFLATE stored (uncompressed) blocks
--   zlib.inflate_raw(s [, pos, stop, maxout]) -> raw, nextpos   raw DEFLATE decode

local M = {}

M.VERSION = "0.3.0"

local CRC = {}
for i = 0, 255 do
	local c = i
	for _ = 1, 8 do
		if (c & 1) == 1 then
			c = (0xEDB88320 ~ (c >> 1)) & 0xFFFFFFFF
		else
			c = c >> 1
		end
	end
	CRC[i] = c
end

function M.crc32(data)
	local crc, n = 0xFFFFFFFF, #data
	for i = 1, n, 4096 do
		local t = { data:byte(i, math.min(i + 4095, n)) }
		for j = 1, #t do
			crc = (CRC[(crc ~ t[j]) & 0xFF] ~ (crc >> 8)) & 0xFFFFFFFF
		end
	end
	return (crc ~ 0xFFFFFFFF) & 0xFFFFFFFF
end

function M.adler32(data)
	local a, b, n = 1, 0, #data
	for i = 1, n, 4096 do
		local t = { data:byte(i, math.min(i + 4095, n)) }
		for j = 1, #t do
			a = a + t[j]
			b = b + a
		end
		a, b = a % 65521, b % 65521
	end
	return ((b % 65521) * 65536 + (a % 65521)) & 0xFFFFFFFF
end

local function reverse(code, len)
	local r = 0
	for _ = 1, len do
		r = (r << 1) | (code & 1)
		code = code >> 1
	end
	return r
end

local function build_huff(lens, n)
	local counts, syms, max, left = {}, {}, 0, 1
	for i = 0, 15 do
		counts[i] = 0
	end
	for i = 1, n do
		local L = lens[i] or 0
		counts[L] = counts[L] + 1
	end
	for i = 1, 15 do
		left = left * 2 - counts[i]
		if left < 0 then
			return nil
		end
		if counts[i] > 0 then
			max = i
		end
	end
	local offs, off = {}, 0
	for i = 1, max do
		offs[i] = off
		off = off + counts[i]
	end
	for i = 1, n do
		local L = lens[i] or 0
		if L ~= 0 then
			offs[L] = offs[L] + 1
			syms[offs[L]] = i - 1
		end
	end
	local bits = max < 10 and max or 10
	local size, tab = 1 << bits, {}
	if left > 0 or max > bits then
		for i = 0, size - 1 do
			tab[i] = 0
		end
	end
	local code, idx = 0, 1
	for len = 1, max do
		if len <= bits then
			for _ = 1, counts[len] do
				local e = (syms[idx] << 4) | len
				for i = reverse(code, len), size - 1, 1 << len do
					tab[i] = e
				end
				idx = idx + 1
				code = code + 1
			end
		else
			idx = idx + counts[len]
			code = code + counts[len]
		end
		code = code << 1
	end
	return { counts = counts, syms = syms, max = max, left = left, tab = tab, mask = size - 1 }
end

local LBASE = {
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	13,
	15,
	17,
	19,
	23,
	27,
	31,
	35,
	43,
	51,
	59,
	67,
	83,
	99,
	115,
	131,
	163,
	195,
	227,
	258,
}
local LEXT = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 }
local DBASE = {
	1,
	2,
	3,
	4,
	5,
	7,
	9,
	13,
	17,
	25,
	33,
	49,
	65,
	97,
	129,
	193,
	257,
	385,
	513,
	769,
	1025,
	1537,
	2049,
	3073,
	4097,
	6145,
	8193,
	12289,
	16385,
	24577,
}
local DEXT = { 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 }
local CORDER = { 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 }

local _fl, _fd = {}, {}
for i = 1, 144 do
	_fl[i] = 8
end
for i = 145, 256 do
	_fl[i] = 9
end
for i = 257, 280 do
	_fl[i] = 7
end
for i = 281, 288 do
	_fl[i] = 8
end
for i = 1, 32 do
	_fd[i] = 5
end
local FIXLIT = build_huff(_fl, 288)
local FIXDIST = build_huff(_fd, 32)

local W, WM, WIN, TAIL = 65536, 65535, 32768, 258

local function inflate_core(s, pos, stop, maxout)
	local p, b, n = pos, 0, 0
	local out, olen, base = {}, 0, 0
	local parts = {}
	local function fill(k)
		if n >= k then
			return
		end
		if p + 3 <= stop then
			local a, c, d, e = s:byte(p, p + 3)
			b = b | ((a | (c << 8) | (d << 16) | (e << 24)) << n)
			p = p + 4
			n = n + 32
		else
			while p <= stop and n < k do
				b = b | (s:byte(p) << n)
				p = p + 1
				n = n + 8
			end
		end
	end
	local function take(k)
		fill(k)
		if n < k then
			error("truncated input", 0)
		end
		local v = b & ((1 << k) - 1)
		b = b >> k
		n = n - k
		return v
	end
	local function dsym(h)
		local code, first, index = 0, 0, 0
		local counts, syms = h.counts, h.syms
		for len = 1, h.max do
			if n == 0 then
				if p > stop then
					error("truncated input", 0)
				end
				b = s:byte(p)
				p = p + 1
				n = 8
			end
			code = code | (b & 1)
			b = b >> 1
			n = n - 1
			local count = counts[len]
			if code - count < first then
				return syms[index + (code - first) + 1]
			end
			index = index + count
			first = (first + count) * 2
			code = code * 2
		end
		error("invalid compressed data (bad code)", 0)
	end
	local function dec(h)
		fill(10)
		local e = h.tab[b & h.mask]
		local k = e & 15
		if k == 0 or k > n then
			return dsym(h)
		end
		b = b >> k
		n = n - k
		return e >> 4
	end
	local function emit(a, k)
		for j = a, a + k - 1, 8192 do
			parts[#parts + 1] = string.char(table.unpack(out, j, math.min(j + 8191, a + k - 1)))
		end
	end
	local function flush()
		if olen >= 61440 then
			emit(1, 28672)
			base = base + 28672
			olen = olen - 28672
			table.move(out, 28673, 28672 + olen, 1, out)
		end
	end
	local last = false
	while not last do
		last = take(1) == 1
		local typ = take(2)
		if typ == 0 then
			local drop = n & 7
			b = b >> drop
			n = n - drop
			local len = take(16)
			if (len ~ take(16)) & 0xFFFF ~= 0xFFFF then
				error("invalid compressed data (stored length mismatch)", 0)
			end
			if base + olen + len > maxout then
				error("inflate output too large", 0)
			end
			local q = p - (n >> 3)
			b, n, p = 0, 0, q + len
			if p - 1 > stop then
				error("truncated input", 0)
			end
			while len > 0 do
				flush()
				local k = len > 4096 and 4096 or len
				table.move({ s:byte(q, q + k - 1) }, 1, k, olen + 1, out)
				olen = olen + k
				q = q + k
				len = len - k
			end
		elseif typ == 1 or typ == 2 then
			local lit, dist
			if typ == 1 then
				lit, dist = FIXLIT, FIXDIST
			else
				local hl, hd, hc = take(5) + 257, take(5) + 1, take(4) + 4
				local cl = {}
				for i = 1, 19 do
					cl[CORDER[i] + 1] = 0
				end
				for i = 1, hc do
					cl[CORDER[i] + 1] = take(3)
				end
				local clh = build_huff(cl, 19)
				if not clh or clh.left ~= 0 then
					error("invalid compressed data (bad code lengths)", 0)
				end
				local total = hl + hd
				local lens, i = {}, 1
				while i <= total do
					local v = dec(clh)
					if v < 16 then
						lens[i] = v
						i = i + 1
					else
						local rep
						if v == 16 then
							if i == 1 then
								error("invalid compressed data (bad lengths)", 0)
							end
							rep = take(2) + 3
						elseif v == 17 then
							rep = take(3) + 3
						else
							rep = take(7) + 11
						end
						for _ = 1, rep do
							lens[i] = v == 16 and lens[i - 1] or 0
							i = i + 1
						end
						if i > total + 1 then
							error("invalid compressed data (bad lengths)", 0)
						end
					end
				end
				local ll, dd = {}, {}
				for k = 1, hl do
					ll[k] = lens[k] or 0
				end
				for k = 1, hd do
					dd[k] = lens[hl + k] or 0
				end
				lit = build_huff(ll, hl)
				dist = build_huff(dd, hd)
				if not lit or (lit.left ~= 0 and lit.max > 1) or not dist or (dist.left ~= 0 and dist.max > 1) then
					error("invalid compressed data (bad code set)", 0)
				end
			end
			local tab, mask = lit.tab, lit.mask
			local dtab, dmask = dist.tab, dist.mask
			while true do
				if n < 10 then
					fill(10)
				end
				local e = tab[b & mask]
				local k = e & 15
				local v
				if k == 0 or k > n then
					v = dsym(lit)
				else
					v = e >> 4
					b = b >> k
					n = n - k
				end
				if v == 256 then
					break
				end
				if v < 256 then
					olen = olen + 1
					out[olen] = v
				else
					if v > 285 then
						error("invalid compressed data (bad length code)", 0)
					end
					local li = v - 256
					local ln = LBASE[li] + (LEXT[li] > 0 and take(LEXT[li]) or 0)
					if n < 10 then
						fill(10)
					end
					e = dtab[b & dmask]
					k = e & 15
					local d
					if k == 0 or k > n then
						d = dsym(dist)
					else
						d = e >> 4
						b = b >> k
						n = n - k
					end
					if d > 29 then
						error("invalid compressed data (bad distance)", 0)
					end
					local dn = DBASE[d + 1] + (DEXT[d + 1] > 0 and take(DEXT[d + 1]) or 0)
					if dn > base + olen then
						error("invalid compressed data (distance too far back)", 0)
					end
					for _ = 1, ln do
						olen = olen + 1
						out[olen] = out[olen - dn]
					end
				end
				if base + olen > maxout then
					error("inflate output too large", 0)
				end
				if olen >= 65536 then
					flush()
				end
			end
		else
			error("invalid compressed data (bad block type)", 0)
		end
	end
	if olen > 0 then
		emit(1, olen)
	end
	return table.concat(parts), p - (n >> 3)
end

function M.inflate_raw(s, pos, stop, maxout)
	if type(s) ~= "string" then
		return nil, "bad input"
	end
	pos = pos or 1
	stop = stop or #s
	maxout = maxout or math.huge
	if pos < 1 or stop > #s or pos > stop + 1 then
		return nil, "bad input range"
	end
	local ok, out, nextpos = pcall(inflate_core, s, pos, stop, maxout)
	if not ok then
		return nil, out
	end
	return out, nextpos
end

local function u32be(s, p)
	local a, b, c, d = s:byte(p, p + 3)
	if not d then
		return nil
	end
	return ((a * 256 + b) * 256 + c) * 256 + d
end

function M.uncompress(comp, maxout)
	if type(comp) ~= "string" then
		return nil, "bad input"
	end
	local n = #comp
	if n < 6 then
		return nil, "zlib data too short"
	end
	local cmf, flg = comp:byte(1, 2)
	if cmf % 16 ~= 8 then
		return nil, "not deflate data"
	end
	if (cmf * 256 + flg) % 31 ~= 0 then
		return nil, "bad zlib header check"
	end
	if math.floor(flg / 32) % 2 == 1 then
		return nil, "zlib preset dictionary unsupported"
	end
	local raw, npos = M.inflate_raw(comp, 3, n - 4, maxout)
	if not raw then
		return nil, npos
	end
	if npos ~= n - 3 then
		return nil, "bad zlib stream end"
	end
	if M.adler32(raw) ~= u32be(comp, n - 3) then
		return nil, "zlib checksum mismatch"
	end
	return raw
end

local FIX, DFIX, LCODE, DCODE = {}, {}, {}, {}
for sym = 0, 287 do
	local code, len
	if sym < 144 then
		code, len = 0x30 + sym, 8
	elseif sym < 256 then
		code, len = 0x190 + sym - 144, 9
	elseif sym < 280 then
		code, len = sym - 256, 7
	else
		code, len = 0xC0 + sym - 280, 8
	end
	FIX[sym] = reverse(code, len) | (len << 16)
end
for d = 0, 29 do
	DFIX[d] = reverse(d, 5) | (5 << 16)
end
for i = 1, 29 do
	for l = LBASE[i], LBASE[i] + (1 << LEXT[i]) - 1 do
		LCODE[l] = 256 + i
	end
end
for i = 1, 30 do
	local top = DBASE[i] + (1 << DEXT[i]) - 1
	for d = DBASE[i], top < 256 and top or 255 do
		DCODE[d] = i
	end
	for k = (DBASE[i] - 1) >> 7, (top - 1) >> 7 do
		DCODE[256 + k] = i
	end
end

local function huff(freq, nsym, maxbits)
	local keys, k, hi = {}, 0, -1
	for s = 0, nsym - 1 do
		local f = freq[s]
		if f and f > 0 then
			k = k + 1
			keys[k] = (f << 9) | s
			if s > hi then
				hi = s
			end
		end
	end
	local lens = {}
	if k == 0 then
		return lens, -1
	end
	if k == 1 then
		local s, other = keys[1] & 511, 0
		if s == 0 then
			other = 1
		end
		lens[s], lens[other] = 1, 1
		if other > hi then
			hi = other
		end
		return lens, hi
	end
	while true do
		table.sort(keys)
		local w, par = {}, {}
		for i = 1, k do
			w[i] = keys[i] >> 9
		end
		local l, r, top = 1, k + 1, k + 1
		for _ = 1, k - 1 do
			local a
			if r >= top or (l <= k and w[l] <= w[r]) then
				a, l = l, l + 1
			else
				a, r = r, r + 1
			end
			local c
			if r >= top or (l <= k and w[l] <= w[r]) then
				c, l = l, l + 1
			else
				c, r = r, r + 1
			end
			w[top] = w[a] + w[c]
			par[a], par[c] = top, top
			top = top + 1
		end
		local dep = {}
		for j = 2 * k - 1, k + 1, -1 do
			local pj = par[j]
			dep[j] = pj and dep[pj] + 1 or 0
		end
		local bl, over = {}, 0
		for i = 1, maxbits do
			bl[i] = 0
		end
		for j = k + 1, 2 * k - 1 do
			if dep[j] > maxbits then
				over = over + 1
			end
		end
		for i = 1, k do
			local d = dep[par[i]] + 1
			if d > maxbits then
				over, d = over + 1, maxbits
			end
			bl[d] = bl[d] + 1
			lens[keys[i] & 511] = d
		end
		if over == 0 then
			return lens, hi
		end
		repeat
			local bits = maxbits - 1
			while bl[bits] == 0 do
				bits = bits - 1
			end
			bl[bits] = bl[bits] - 1
			bl[bits + 1] = bl[bits + 1] + 2
			bl[maxbits] = bl[maxbits] - 1
			over = over - 2
		until over <= 0
		local full, i = 0, 1
		for bits = maxbits, 1, -1 do
			full = full + (bl[bits] << (maxbits - bits))
			for _ = 1, bl[bits] do
				lens[keys[i] & 511] = bits
				i = i + 1
			end
		end
		if full == (1 << maxbits) then
			return lens, hi
		end
		for j = 1, k do
			keys[j] = (((keys[j] >> 9) + 1) >> 1) << 9 | keys[j] & 511
		end
	end
end

local function codes(lens, nsym)
	local cnt = {}
	for s = 0, nsym - 1 do
		local L = lens[s]
		if L then
			cnt[L] = (cnt[L] or 0) + 1
		end
	end
	local nextc, enc, code = {}, {}, 0
	for len = 1, 15 do
		nextc[len] = code
		code = (code + (cnt[len] or 0)) << 1
	end
	for s = 0, nsym - 1 do
		local L = lens[s]
		if L then
			enc[s] = reverse(nextc[L], L) | (L << 16)
			nextc[L] = nextc[L] + 1
		end
	end
	return enc
end

local MAXTOK, MAXSPAN = 32768, 65535

function M.deflate(data, level)
	level = math.tointeger(tonumber(level or 6)) or 6
	if level < 1 then
		return M.deflate_stored(data)
	end
	if level > 9 then
		level = 9
	end
	local n = #data
	local b, prev, head = {}, {}, {}
	local loaded = 0
	local lazy = level >= 4
	local tok, dtok, lf, df = {}, {}, {}, {}
	local nt, nd, xbits = 0, 0, 0
	local buf, nbuf, out, chunk = 0, 0, {}, {}

	local function load()
		local upto = math.min(n, ((loaded >> 12) + 1) << 12)
		table.move({ data:byte(loaded + 1, upto) }, 1, upto - loaded, loaded & WM, b)
		if (loaded & WM) == 0 then
			for j = 0, TAIL - 1 do
				b[W + j] = b[j]
			end
		end
		loaded = upto
	end
	local function find(p)
		if p + 2 > n then
			return 0, 0
		end
		local B, P, H = b, prev, head
		local chainMax = 1 << (level + 1)
		local nice = lazy and 128 or 32
		if loaded < p + 259 and loaded < n then
			load()
		end
		local i = (p - 1) & WM
		local h = (B[i] << 16) | (B[i + 1] << 8) | B[i + 2]
		local cand = H[h]
		P[i] = cand
		H[h] = p
		local limit = p > WIN and p - WIN or 1
		local maxlen = n - p + 1
		if maxlen > 258 then
			maxlen = 258
		end
		if not cand or cand < limit then
			return 0, 0
		end
		local mlen, mdist, best = 0, 0, 2
		local ib = B[i + 2]
		for _ = 1, chainMax do
			local ci = (cand - 1) & WM
			if B[ci + best] == ib then
				local l = 3
				while l < maxlen and B[ci + l] == B[i + l] do
					l = l + 1
				end
				if l > best then
					best, mlen, mdist = l, l, p - cand
					if l >= nice or l >= maxlen then
						break
					end
					ib = B[i + best]
				end
			end
			cand = P[ci]
			if not cand or cand < limit then
				break
			end
		end
		if mlen == 3 and mdist > 4096 then
			return 0, 0
		end
		return mlen, mdist
	end
	local function rebuild(p)
		head = {}
		local last = n - 2
		if last > p then
			last = p
		end
		for q = p > WIN and p - WIN or 1, last do
			local j = (q - 1) & WM
			head[(b[j] << 16) | (b[j + 1] << 8) | b[j + 2]] = q
		end
	end

	local function put(v, k)
		buf = buf | (v << nbuf)
		nbuf = nbuf + k
		if nbuf >= 48 then
			chunk[#chunk + 1] = string.char(
				buf & 255,
				(buf >> 8) & 255,
				(buf >> 16) & 255,
				(buf >> 24) & 255,
				(buf >> 32) & 255,
				(buf >> 40) & 255
			)
			buf = buf >> 48
			nbuf = nbuf - 48
			if #chunk >= 2048 then
				out[#out + 1] = table.concat(chunk)
				chunk = {}
			end
		end
	end
	local function addmatch(len, dist)
		local li = LCODE[len]
		local eb = LEXT[li - 256]
		nt = nt + 1
		tok[nt] = li | ((len - LBASE[li - 256]) << 9) | (eb << 22)
		lf[li] = (lf[li] or 0) + 1
		local di = dist < 256 and DCODE[dist] or DCODE[256 + ((dist - 1) >> 7)]
		local db = DEXT[di]
		nd = nd + 1
		dtok[nd] = (di - 1) | ((dist - DBASE[di]) << 5) | (db << 18)
		df[di - 1] = (df[di - 1] or 0) + 1
		xbits = xbits + eb + db
	end
	local function emit(enc, denc)
		local di = 0
		for i = 1, nt do
			local t = tok[i]
			if t < 256 then
				local v = enc[t]
				put(v & 0xFFFF, v >> 16)
			elseif t > 256 then
				local v = enc[t & 511]
				put(v & 0xFFFF, v >> 16)
				local eb = t >> 22
				if eb > 0 then
					put((t >> 9) & 8191, eb)
				end
				di = di + 1
				local d = dtok[di]
				v = denc[d & 31]
				put(v & 0xFFFF, v >> 16)
				eb = d >> 18
				if eb > 0 then
					put((d >> 5) & 8191, eb)
				end
			else
				local v = enc[256]
				put(v & 0xFFFF, v >> 16)
			end
		end
	end
	local function store(bs, be, last)
		while bs < be do
			local len = be - bs
			if len > 65535 then
				len = 65535
			end
			bs = bs + len
			put(bs == be and last and 1 or 0, 1)
			put(0, 2)
			if nbuf % 8 ~= 0 then
				put(0, 8 - nbuf % 8)
			end
			put(len, 16)
			put(len ~ 0xFFFF, 16)
			while nbuf >= 8 do
				chunk[#chunk + 1] = string.char(buf & 255)
				buf = buf >> 8
				nbuf = nbuf - 8
			end
			chunk[#chunk + 1] = data:sub(bs - len, bs - 1)
		end
	end
	local function flush(bs, be, last)
		nt = nt + 1
		tok[nt] = 256
		lf[256] = (lf[256] or 0) + 1
		local span = be - bs
		local sbits = 3 + (8 - nbuf % 8) % 8 + 32 + span * 8
		if span > 65535 then
			sbits = sbits + ((span - 1) // 65535) * 40
		end
		local fbits = 3 + xbits
		for s = 0, 287 do
			local f = lf[s]
			if f then
				fbits = fbits + f * (FIX[s] >> 16)
			end
		end
		for s = 0, 29 do
			local f = df[s]
			if f then
				fbits = fbits + f * 5
			end
		end
		local hlens, hi = huff(lf, 286, 15)
		local dlens, dhi = huff(df, 30, 15)
		local hlit = hi < 256 and 257 or hi + 1
		local hdist = dhi + 1
		if hdist < 1 then
			hdist = 1
		end
		local seq, total = {}, hlit + hdist
		for s = 0, hlit - 1 do
			seq[s + 1] = hlens[s] or 0
		end
		for s = 0, hdist - 1 do
			seq[hlit + s + 1] = dlens[s] or 0
		end
		local rle, cf, m = {}, {}, 0
		local i = 1
		while i <= total do
			local L, j = seq[i], i + 1
			while j <= total and seq[j] == L do
				j = j + 1
			end
			local run = j - i
			i = j
			if L == 0 then
				while run >= 11 do
					local k = run > 138 and 138 or run
					m = m + 1
					rle[m] = 18 | (7 << 5) | ((k - 11) << 8)
					run = run - k
				end
				if run >= 3 then
					m = m + 1
					rle[m] = 17 | (3 << 5) | ((run - 3) << 8)
					run = 0
				end
				while run > 0 do
					m = m + 1
					rle[m] = 0
					run = run - 1
				end
			else
				m = m + 1
				rle[m] = L
				run = run - 1
				while run >= 3 do
					local k = run > 6 and 6 or run
					m = m + 1
					rle[m] = 16 | (2 << 5) | ((k - 3) << 8)
					run = run - k
				end
				while run > 0 do
					m = m + 1
					rle[m] = L
					run = run - 1
				end
			end
		end
		for j = 1, m do
			local c = rle[j] & 31
			cf[c] = (cf[c] or 0) + 1
		end
		local clens = huff(cf, 19, 7)
		local cnt, rbits = 4, 0
		for j = 1, m do
			rbits = rbits + clens[rle[j] & 31] + ((rle[j] >> 5) & 7)
		end
		for j = 5, 19 do
			if (clens[CORDER[j]] or 0) > 0 then
				cnt = j
			end
		end
		local dbits = 3 + 14 + 3 * cnt + rbits + xbits
		for s = 0, 285 do
			local f = lf[s]
			if f then
				dbits = dbits + f * hlens[s]
			end
		end
		for s = 0, 29 do
			local f = df[s]
			if f then
				dbits = dbits + f * dlens[s]
			end
		end
		if sbits <= fbits and sbits <= dbits then
			store(bs, be, last)
		elseif fbits <= dbits then
			put(last and 1 or 0, 1)
			put(1, 2)
			emit(FIX, DFIX)
		else
			put(last and 1 or 0, 1)
			put(2, 2)
			put(hlit - 257, 5)
			put(hdist - 1, 5)
			put(cnt - 4, 4)
			for j = 1, cnt do
				put(clens[CORDER[j]] or 0, 3)
			end
			local cenc = codes(clens, 19)
			for j = 1, m do
				local v = rle[j]
				local c = cenc[v & 31]
				put(c & 0xFFFF, c >> 16)
				local eb = (v >> 5) & 7
				if eb > 0 then
					put(v >> 8, eb)
				end
			end
			emit(codes(hlens, 286), codes(dlens, 30))
		end
		tok, dtok, lf, df = {}, {}, {}, {}
		nt, nd, xbits = 0, 0, 0
	end

	local pos, mlen, mdist = 1, find(1)
	local bstart, pruneAt = 1, W
	while pos <= n do
		if loaded < pos then
			load()
		end
		if mlen >= 3 then
			local nlen, ndist = 0, 0
			if lazy and pos < n then
				nlen, ndist = find(pos + 1)
			end
			if nlen > mlen then
				local c = b[(pos - 1) & WM]
				nt = nt + 1
				tok[nt] = c
				lf[c] = (lf[c] or 0) + 1
				pos = pos + 1
				mlen, mdist = nlen, ndist
			else
				addmatch(mlen, mdist)
				local q, last = pos + (lazy and 2 or 1), pos + mlen - 1
				local B, P, H = b, prev, head
				while q <= last do
					if q + 2 <= n then
						local j = (q - 1) & WM
						local h = (B[j] << 16) | (B[j + 1] << 8) | B[j + 2]
						P[j] = H[h]
						H[h] = q
					end
					q = q + 1
				end
				pos = pos + mlen
				if pos <= n then
					mlen, mdist = find(pos)
				end
			end
		else
			local c = b[(pos - 1) & WM]
			nt = nt + 1
			tok[nt] = c
			lf[c] = (lf[c] or 0) + 1
			pos = pos + 1
			if pos <= n then
				mlen, mdist = find(pos)
			end
		end
		if pos <= n and (nt >= MAXTOK or pos - bstart >= MAXSPAN) then
			flush(bstart, pos, false)
			bstart = pos
			if pos >= pruneAt then
				rebuild(pos)
				pruneAt = pos + W
			end
		end
	end
	flush(bstart, pos, true)
	while nbuf >= 8 do
		chunk[#chunk + 1] = string.char(buf & 255)
		buf = buf >> 8
		nbuf = nbuf - 8
	end
	if nbuf > 0 then
		chunk[#chunk + 1] = string.char(buf & 255)
	end
	out[#out + 1] = table.concat(chunk)
	return table.concat(out)
end

function M.compress(data, level)
	local a = M.adler32(data)
	return "\120\156"
		.. M.deflate(data, level)
		.. string.char((a >> 24) & 255, (a >> 16) & 255, (a >> 8) & 255, a & 255)
end

local function p16(n)
	return string.char(n & 255, (n >> 8) & 255)
end

function M.deflate_stored(data)
	if #data == 0 then
		return "\1\0\0\255\255"
	end
	local out, pos = {}, 1
	while pos <= #data do
		local n = math.min(65535, #data - pos + 1)
		local last = (pos + n - 1) >= #data
		out[#out + 1] = (last and "\1" or "\0") .. p16(n) .. p16(0xFFFF - n)
		out[#out + 1] = data:sub(pos, pos + n - 1)
		pos = pos + n
	end
	return table.concat(out)
end

return M
