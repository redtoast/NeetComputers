local K, API, X = ...

local T = {}

local argerr = K.argcheck.err

local ZERO_ADDRESS = "000000000000"
local BROADCAST = "ffffffffffff"

local MAX_FRAME_VALUES = 16
local MAX_FRAME_CHARS = 4608
local MAX_FRAME_STRING = 4096
local MAX_TRANSPORT_VALUES = 11
local MAX_INT = 2147483647
local MIN_INT = -2147483648

local MAX_TTL = 256
local WITHHELD_METRIC = 256
local MAX_HEARD = 300
local MAX_VECTOR_ENTRIES = 136
local HELLO_INTERVAL = 30
local HELLO_JITTER = 0.25
local FIRST_HELLO_MAX = 2
local EXTRA_HELLO_MAX = 1
local NEIGHBOR_TIMEOUT = 120
local VECTOR_INTERVAL = 30
local TRIGGERED_VECTOR_MIN = 5
local ROUTE_TIMEOUT = 180
local ADDRESS_CHANGE_MAX = 5
local PING_TIMEOUT = 5
local PING_MAX_ID = 16

local neighbours = { wired = {}, wireless = {} }
local routes = {}
local withdrawals = {}
local tasks = {}
local echoes = {}
local vectorState = {
	wired = { at = -1e9, dirty = false },
	wireless = { at = -1e9, dirty = false },
}

local routerSet = nil
local netAddress = nil
local nextHelloAt = 0
local nextVectorAt = 0
local triggeredAt = -1e9
local addressChangeAt = nil

local function hostIo()
	return rawget(_G, "io")
end

local function isAddress(s)
	return type(s) == "string" and #s == 12 and s:match("^[0-9a-f]+$") ~= nil
end

local function stringFits(s)
	if #s > MAX_FRAME_STRING then
		return false
	end
	for i = 1, #s do
		local b = s:byte(i)
		if b < 0x01 or b > 0x7f then
			return false
		end
	end
	return true
end

local function frameError(values)
	local n = #values
	if n < 1 then
		return "EINVAL", "a frame holds at least one value"
	end
	if n > MAX_FRAME_VALUES then
		return "EMSGSIZE", ("a frame holds at most %d values"):format(MAX_FRAME_VALUES)
	end
	local chars = 0
	for i = 1, n do
		local v = values[i]
		local tv = type(v)
		if tv == "string" then
			if not stringFits(v) then
				return "EINVAL", "a frame string is 1 to 4096 bytes from 0x01 to 0x7f"
			end
			chars = chars + #v
		elseif tv == "number" then
			if v ~= v then
				return "EINVAL", "a frame value cannot be nan"
			end
			if math.type(v) == "integer" and (v < MIN_INT or v > MAX_INT) then
				return "ERANGE", "a frame integer must fit in 32 bits"
			end
		elseif tv ~= "boolean" then
			return "EINVAL", "a frame value is a boolean, number or string"
		end
	end
	if chars > MAX_FRAME_CHARS then
		return "EMSGSIZE", ("a frame holds at most %d string characters"):format(MAX_FRAME_CHARS)
	end
	return nil
end

local function randomUnit()
	local ok, bytes = pcall(K.crypto.random_bytes, 4)
	if not ok or type(bytes) ~= "string" or #bytes < 4 then
		return 0.5
	end
	return string.unpack(">I4", bytes:sub(1, 4)) / 4294967296
end

local function newAddress()
	for _ = 1, 16 do
		local ok, bytes = pcall(K.crypto.random_bytes, 6)
		if ok and type(bytes) == "string" and #bytes >= 6 then
			local a = K.crypto.tohex(bytes:sub(1, 6))
			if a ~= ZERO_ADDRESS and a ~= BROADCAST then
				return a
			end
		end
	end
	local a = K.crypto.tohex(K.crypto.sha256raw(("rpp:%.6f"):format(K.monotonic())):sub(1, 6))
	if a == ZERO_ADDRESS or a == BROADCAST then
		a = "000000000001"
	end
	return a
end

local ADDRESS_FILE = "var/db/rpp.address"

local function readAddress()
	local V, root = K.vfs, K.rootdir
	if not V or not root then
		return nil
	end
	local ok, data = pcall(V.readFile, root .. ADDRESS_FILE)
	if not ok or type(data) ~= "string" then
		return nil
	end
	local a = data:match("([0-9a-f]+)")
	if a and isAddress(a) and a ~= ZERO_ADDRESS and a ~= BROADCAST then
		return a
	end
	return nil
end

local function writeAddress(a)
	local V, root = K.vfs, K.rootdir
	if not V or not root then
		return false
	end
	pcall(function()
		if V.stat(root .. "var/db") ~= "dir" then
			if V.stat(root .. "var") ~= "dir" then
				V.mkdir(nil, root .. "var")
			end
			V.mkdir(nil, root .. "var/db")
		end
	end)
	local ok, wrote = pcall(V.writeFile, root .. ADDRESS_FILE, a .. "\n", 384)
	return ok and wrote and true or false
end

netAddress = readAddress() or newAddress()
writeAddress(netAddress)

local apCache = { at = -1e9, uuid = nil }

local function accessPoint(now)
	if now - apCache.at < 1 then
		return apCache.uuid
	end
	local host, uuid = hostIo(), nil
	if type(host) == "table" and type(host.queryType) == "function" then
		local ok, list = pcall(host.queryType, "access_point")
		if ok and type(list) == "table" then
			for _, u in ipairs(list) do
				if type(u) == "string" then
					uuid = u
					break
				end
			end
		end
	end
	apCache.at, apCache.uuid = now, uuid
	return uuid
end

local function interfaces(now)
	local host = hostIo()
	return {
		{ name = "wired", up = type(host) == "table" and type(host.broadcastLocal) == "function" },
		{ name = "wireless", up = accessPoint(now) ~= nil },
	}
end

local function upInterfaces(now)
	local out = {}
	for _, iface in ipairs(interfaces(now)) do
		if iface.up then
			out[#out + 1] = iface
		end
	end
	return out
end

local function isRouter(now)
	if routerSet ~= nil then
		return routerSet
	end
	return #upInterfaces(now) >= 2
end

local function emit(iface, values, now)
	local host = hostIo()
	if type(host) ~= "table" then
		return false
	end
	if iface == "wired" then
		if type(host.broadcastLocal) ~= "function" then
			return false
		end
		return (pcall(host.broadcastLocal, table.unpack(values, 1, #values)))
	end
	if iface == "wireless" then
		local uuid = accessPoint(now)
		if not uuid or type(host.callFunction) ~= "function" then
			return false
		end
		return (pcall(host.callFunction, uuid, "broadcast", table.unpack(values, 1, #values)))
	end
	return false
end

local sendHello, sendVectors, expire

local inService = false

local function pump(now)
	local i = 1
	while i <= #tasks do
		local task = tasks[i]
		if now >= task.at then
			table.remove(tasks, i)
			local ok, err = pcall(task.fn)
			if not ok then
				K.klog("rpp: a timer failed: %s", tostring(err))
			end
		else
			i = i + 1
		end
	end
	if addressChangeAt and now >= addressChangeAt then
		addressChangeAt = nil
		netAddress = newAddress()
		writeAddress(netAddress)
		K.klog("rpp: a duplicate address was heard, this host is now %s", netAddress)
		sendHello(now)
	end
	if now >= nextHelloAt then
		sendHello(now)
		nextHelloAt = now + HELLO_INTERVAL * (1 - HELLO_JITTER + 2 * HELLO_JITTER * randomUnit())
	end
	if isRouter(now) then
		local dirty = false
		for _, st in pairs(vectorState) do
			dirty = dirty or st.dirty
		end
		if now >= nextVectorAt then
			nextVectorAt = now + VECTOR_INTERVAL * (1 - HELLO_JITTER + 2 * HELLO_JITTER * randomUnit())
			sendVectors(now)
		elseif dirty and now - triggeredAt >= TRIGGERED_VECTOR_MIN then
			sendVectors(now)
		end
	end
	expire(now)
end

local function service(now)
	if inService then
		return
	end
	inService = true
	local ok, err = pcall(pump, now)
	inService = false
	if not ok then
		K.klog("rpp: the timer pass failed: %s", tostring(err))
	end
end

local function schedule(delay, fn)
	tasks[#tasks + 1] = { at = K.monotonic() + delay, fn = fn }
end

local function sendPacket(iface, destination, source, ttl, nextv, transport, now)
	local values = { "rpp", destination, source, ttl, nextv }
	for i = 1, #transport do
		values[#values + 1] = transport[i]
	end
	local code, msg = frameError(values)
	if code then
		return nil, code, msg
	end
	if not emit(iface, values, now) then
		return nil, "EHOSTUNREACH", "interface '" .. iface .. "' is not up"
	end
	return true
end

local function routeFor(destination, now)
	for _, iface in ipairs(interfaces(now)) do
		local nb = iface.up and neighbours[iface.name][destination]
		if nb and nb.bidirectional then
			return iface.name, destination
		end
	end
	local r = routes[destination]
	if r then
		return r.interface, r.next
	end
	return nil
end

local function sendTransport(destination, transport, opts)
	local now = K.monotonic()
	service(now)
	if not isAddress(destination) or destination == ZERO_ADDRESS then
		return nil, "EINVAL", "destination is not an address"
	end
	if type(transport) ~= "table" or #transport < 1 or #transport > MAX_TRANSPORT_VALUES then
		return nil, "EINVAL", ("a transport frame holds 1 to %d values"):format(MAX_TRANSPORT_VALUES)
	end
	if type(transport[1]) ~= "string" then
		return nil, "EINVAL", "a transport frame starts with its protocol name"
	end
	if destination == netAddress then
		return nil, "EHOSTUNREACH", "this host's own address is never a destination"
	end
	local control = transport[1] == "rcp"
	local ttl = (opts and opts.ttl) or MAX_TTL
	if control and destination == BROADCAST then
		ttl = 1
	end
	if destination == BROADCAST then
		local sent = false
		for _, iface in ipairs(upInterfaces(now)) do
			if sendPacket(iface.name, BROADCAST, netAddress, ttl, BROADCAST, transport, now) then
				sent = true
			end
		end
		if not sent then
			return nil, "EHOSTUNREACH", "no interface is up"
		end
		return true
	end
	local iface, nextv = routeFor(destination, now)
	if not iface then
		return nil, "EHOSTUNREACH", "no route to " .. destination
	end
	return sendPacket(iface, destination, netAddress, ttl, nextv, transport, now)
end

local function heardList(iface, now)
	local t, out = neighbours[iface], {}
	if not t then
		return ""
	end
	for addr, nb in pairs(t) do
		if now - nb.lastHeard <= NEIGHBOR_TIMEOUT and #out < MAX_HEARD then
			out[#out + 1] = addr
		end
	end
	table.sort(out)
	return table.concat(out, ",")
end

local function listsHeard(heard, addr)
	for part in heard:gmatch("([^,]+)") do
		if part == addr then
			return true
		end
	end
	return false
end

local function routesChanged()
	for _, st in pairs(vectorState) do
		st.dirty = true
	end
end

local function installRoute(dest, nextv, iface, metric, now)
	local have = routes[dest]
	if not have or have.next ~= nextv or have.metric ~= metric or have.interface ~= iface then
		routesChanged()
	end
	routes[dest] = {
		address = dest,
		next = nextv,
		interface = iface,
		metric = metric,
		refreshed = now,
	}
end

local function removeRoute(dest, now)
	local r = routes[dest]
	if not r then
		return
	end
	routes[dest] = nil
	if isRouter(now) then
		withdrawals[#withdrawals + 1] = { address = dest, via = r.next }
	end
	routesChanged()
end

local function routesThrough(nextv, now)
	for dest, r in pairs(routes) do
		if r.next == nextv then
			removeRoute(dest, now)
		end
	end
end

sendHello = function(now, only)
	local role = isRouter(now) and "r" or "h"
	for _, iface in ipairs(upInterfaces(now)) do
		if not only or only == iface.name then
			sendPacket(iface.name, BROADCAST, netAddress, 1, BROADCAST, {
				"rcp",
				"hello",
				role,
				heardList(iface.name, now),
			}, now)
		end
	end
end

sendVectors = function(now)
	if not isRouter(now) then
		return
	end
	local entries = {}
	for dest, r in pairs(routes) do
		entries[#entries + 1] = ("%s:%d:%s"):format(dest, r.metric, r.next)
	end
	for _, w in ipairs(withdrawals) do
		entries[#entries + 1] = ("%s:%d:%s"):format(w.address, WITHHELD_METRIC, w.via)
	end
	table.sort(entries)
	for _, iface in ipairs(upInterfaces(now)) do
		local chunk, chars = {}, 0
		for _, e in ipairs(entries) do
			if #chunk >= MAX_VECTOR_ENTRIES or chars + #e + 1 > MAX_FRAME_STRING then
				sendPacket(iface.name, BROADCAST, netAddress, 1, BROADCAST, {
					"rcp",
					"vector",
					table.concat(chunk, ","),
				}, now)
				chunk, chars = {}, 0
			end
			chunk[#chunk + 1] = e
			chars = chars + #e + 1
		end
		if #chunk > 0 then
			sendPacket(iface.name, BROADCAST, netAddress, 1, BROADCAST, {
				"rcp",
				"vector",
				table.concat(chunk, ","),
			}, now)
		end
		local st = vectorState[iface.name]
		if st then
			st.at, st.dirty = now, false
		end
	end
	withdrawals = {}
	triggeredAt = now
end

local function validEchoId(id)
	return type(id) == "string" and #id >= 1 and #id <= PING_MAX_ID and id:match("^[0-9a-f]+$") ~= nil
end

local function parsePacket(frame)
	if type(frame) ~= "table" then
		return nil
	end
	local n = #frame
	if n < 6 or n > MAX_FRAME_VALUES then
		return nil
	end
	if frame[1] ~= "rpp" then
		return nil
	end
	local destination, source, ttl, nextv = frame[2], frame[3], frame[4], frame[5]
	if not isAddress(destination) or not isAddress(source) or source == BROADCAST then
		return nil
	end
	if not isAddress(nextv) then
		return nil
	end
	if (nextv == BROADCAST) ~= (destination == BROADCAST) then
		return nil
	end
	if math.type(ttl) ~= "integer" or ttl < 1 or ttl > MAX_TTL then
		return nil
	end
	local transport = {}
	for i = 6, n do
		transport[#transport + 1] = frame[i]
	end
	if frameError(transport) then
		return nil
	end
	return { destination = destination, source = source, ttl = ttl, next = nextv, transport = transport }
end

local function parseVector(text)
	if type(text) ~= "string" then
		return nil
	end
	local out = {}
	for part in text:gmatch("([^,]+)") do
		local a, m, via = part:match("^([0-9a-f]+):([0-9]+):([0-9a-f]+)$")
		if not a or not isAddress(a) or not isAddress(via) then
			return nil
		end
		local metric = math.tointeger(tonumber(m))
		if not metric or metric < 0 or metric > WITHHELD_METRIC then
			return nil
		end
		out[#out + 1] = { address = a, metric = metric, via = via }
	end
	return out
end

local function handleHello(packet, iface, distance, now)
	local role, heard = packet.transport[3], packet.transport[4]
	if role ~= "h" and role ~= "r" then
		return
	end
	if type(heard) ~= "string" then
		return
	end
	local source = packet.source
	if source == netAddress then
		if not addressChangeAt then
			addressChangeAt = now + randomUnit() * ADDRESS_CHANGE_MAX
		end
		return
	end
	local t = neighbours[iface]
	if not t then
		return
	end
	local fresh = t[source] == nil
	local wasBidirectional = not fresh and t[source].bidirectional
	t[source] = {
		address = source,
		interface = iface,
		role = role,
		bidirectional = iface == "wired" or listsHeard(heard, netAddress),
		lastHeard = now,
		distance = iface == "wireless" and distance or nil,
	}
	if t[source].bidirectional then
		installRoute(source, source, iface, 1, now)
	elseif wasBidirectional then
		removeRoute(source, now)
		routesThrough(source, now)
	end
	if fresh then
		schedule(randomUnit() * EXTRA_HELLO_MAX, function()
			sendHello(K.monotonic(), iface)
		end)
	end
end

local function handleVector(packet, iface, now)
	local nb = neighbours[iface][packet.source]
	if not nb or not nb.bidirectional then
		return
	end
	local entries = parseVector(packet.transport[3])
	if not entries then
		return
	end
	for _, e in ipairs(entries) do
		if e.address ~= netAddress and e.via ~= netAddress then
			local metric = e.metric + 1
			local have = routes[e.address]
			if metric >= WITHHELD_METRIC then
				if have and have.next == packet.source then
					removeRoute(e.address, now)
				end
			elseif not have or metric < have.metric or have.next == packet.source then
				installRoute(e.address, packet.source, iface, metric, now)
			elseif have then
				have.refreshed = now
			end
		end
	end
end

local function handleControl(packet, iface, distance, now)
	local kind = packet.transport[2]
	if kind == "hello" then
		return handleHello(packet, iface, distance, now)
	elseif kind == "vector" then
		return handleVector(packet, iface, now)
	elseif kind == "echo" then
		local id = packet.transport[3]
		if validEchoId(id) then
			sendTransport(packet.source, { "rcp", "echoreply", id })
		end
		return
	elseif kind == "echoreply" then
		local id = packet.transport[3]
		local pend = validEchoId(id) and echoes[id]
		if pend and not pend.replied then
			pend.replied, pend.replyAt = true, now
			if pend.proc and pend.proc.state == "S" then
				pend.proc.wakeup = true
			end
		end
		return
	end
end

local function deliverTransport(packet, iface, distance, now)
	local transport = packet.transport
	local name = transport[1]
	if name == "rcp" then
		if type(transport[2]) ~= "string" then
			return
		end
		return handleControl(packet, iface, distance, now)
	end
	if name == "spp" then
		local remote = X.sppremote
		if type(remote) == "table" and type(remote.on_segment) == "function" then
			remote.on_segment(K.current, transport, packet)
		end
		return
	end
end

local function handlePacket(packet, iface, distance, now)
	local source, destination, nextv, ttl = packet.source, packet.destination, packet.next, packet.ttl
	local transport = packet.transport
	local isHello = transport[1] == "rcp" and transport[2] == "hello"
	if source == netAddress and not isHello then
		return
	end
	if nextv ~= netAddress and nextv ~= BROADCAST then
		return
	end
	if destination == netAddress or (destination == BROADCAST and nextv == BROADCAST) then
		deliverTransport(packet, iface, distance, now)
		return
	end
	if not isRouter(now) or ttl <= 1 or destination == BROADCAST then
		return
	end
	local r = routes[destination]
	if not r then
		return
	end
	sendPacket(r.interface, destination, source, ttl - 1, r.next, transport, now)
end

expire = function(now)
	for iface, t in pairs(neighbours) do
		for addr, nb in pairs(t) do
			if now - nb.lastHeard > NEIGHBOR_TIMEOUT then
				t[addr] = nil
				removeRoute(addr, now)
				routesThrough(addr, now)
				local st = vectorState[iface]
				if st then
					st.dirty = true
				end
			end
		end
	end
	for dest, r in pairs(routes) do
		if now - r.refreshed > ROUTE_TIMEOUT then
			removeRoute(dest, now)
		end
	end
	for id, pend in pairs(echoes) do
		if pend.proc and pend.proc.state == "Z" then
			echoes[id] = nil
		end
	end
end

nextHelloAt = K.monotonic() + randomUnit() * FIRST_HELLO_MAX
nextVectorAt = K.monotonic() + randomUnit() * VECTOR_INTERVAL

function K.rppFrame(frame, iface, distance)
	local now = K.monotonic()
	service(now)
	local packet = parsePacket(frame)
	if not packet then
		return false
	end
	handlePacket(packet, iface or "wired", distance, now)
	return true
end

function K.rppSend(destination, transport, opts)
	return sendTransport(destination, transport, opts)
end

local function accessPointHook(e)
	if type(e) ~= "table" or e[3] ~= "received" then
		return
	end
	local now = K.monotonic()
	local uuid = accessPoint(now)
	if not uuid or e[2] ~= uuid then
		return
	end
	local values = {}
	for i = 5, #e do
		values[#values + 1] = e[i]
	end
	T.on_frame(K.current, values, "wireless", e[4])
end

function T.getAddress(p)
	service(K.monotonic())
	return netAddress
end

function T.getInterfaces(p)
	local now = K.monotonic()
	service(now)
	local out = {}
	for _, iface in ipairs(interfaces(now)) do
		out[#out + 1] = { name = iface.name, up = iface.up }
	end
	return out
end

function T.getNeighbors(p)
	local now = K.monotonic()
	service(now)
	local out = {}
	for iface, t in pairs(neighbours) do
		for _, nb in pairs(t) do
			out[#out + 1] = {
				address = nb.address,
				interface = iface,
				role = nb.role,
				bidirectional = nb.bidirectional,
				age = now - nb.lastHeard,
				distance = nb.distance,
			}
		end
	end
	table.sort(out, function(a, b)
		return a.address < b.address
	end)
	return out
end

function T.getRoutes(p)
	local now = K.monotonic()
	service(now)
	local out = {}
	for _, r in pairs(routes) do
		out[#out + 1] = {
			address = r.address,
			next = r.next,
			interface = r.interface,
			metric = r.metric,
			age = now - r.refreshed,
		}
	end
	table.sort(out, function(a, b)
		return a.address < b.address
	end)
	return out
end

function T.isRouter(p)
	return isRouter(K.monotonic())
end

function T.setRouter(p, enabled)
	if type(enabled) ~= "boolean" then
		argerr(1, "setRouter", "boolean", enabled)
	end
	if p and p.uid ~= nil and p.uid ~= 0 then
		return nil, "EACCES", "only an administrative program may change routing"
	end
	routerSet = enabled
	local now = K.monotonic()
	if enabled then
		sendVectors(now)
	else
		for dest, r in pairs(routes) do
			withdrawals[#withdrawals + 1] = { address = dest, via = r.next }
		end
		if #withdrawals > 0 then
			sendVectors(now)
		end
		withdrawals = {}
	end
	return true
end

function T.ping(p, target, timeout)
	if not isAddress(target) or target == ZERO_ADDRESS then
		return nil, "EINVAL", "ping needs an address"
	end
	if timeout ~= nil and type(timeout) ~= "number" then
		argerr(2, "ping", "number", timeout)
	end
	if timeout ~= nil and (timeout ~= timeout or timeout < 0) then
		return nil, "EINVAL", "invalid timeout"
	end
	if timeout == 0 then
		return nil, "ETIMEDOUT", "no time to wait for an answer"
	end
	local now = K.monotonic()
	service(now)
	if target == netAddress then
		return nil, "EHOSTUNREACH", "this host's own address is never a destination"
	end
	if target == BROADCAST then
		if #upInterfaces(now) == 0 then
			return nil, "EHOSTUNREACH", "no interface is up"
		end
	elseif not routeFor(target, now) then
		return nil, "EHOSTUNREACH", "no route to " .. target
	end
	local id = K.crypto.tohex(K.crypto.random_bytes(4))
	local sentAt = now
	local ok, code, msg = sendTransport(target, { "rcp", "echo", id })
	if not ok then
		return nil, code, msg
	end
	local pend = { proc = p, sentAt = sentAt, replied = false, replyAt = nil }
	echoes[id] = pend
	local deadline = sentAt + (timeout or PING_TIMEOUT)
	while not pend.replied do
		if K.monotonic() >= deadline then
			echoes[id] = nil
			return nil, "ETIMEDOUT", "no answer from " .. target
		end
		if not p or type(K.block) ~= "function" then
			echoes[id] = nil
			return nil, "ETIMEDOUT", "no answer from " .. target
		end
		K.block(p, function()
			return pend.replied
		end, deadline)
	end
	echoes[id] = nil
	return pend.replyAt - sentAt
end

T.__hooks = { peripheral = accessPointHook }

T.__ext = { ["ext.rpp"] = 1 }

return T
