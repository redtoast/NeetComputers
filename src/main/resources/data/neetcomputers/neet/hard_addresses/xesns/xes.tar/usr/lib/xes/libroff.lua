local M = {}
M._NAME = "libroff"
M._VERSION = "libroff 0.1.0"

local P_IND = 2
local TAG_IND = 2
local BODY_IND = 6
local NF_IND = 2
local MIN_WIDTH = 20

local function toint(v)
	local n = tonumber(v)
	if not n then
		return nil
	end
	local f = math.floor(n)
	if f == n then
		return f
	end
	return nil
end

local function colwidth(s)
	if not s:find("[\128-\255]") then
		return #s
	end
	if type(utf8) == "table" and type(utf8.len) == "function" then
		local ok, n = pcall(utf8.len, s)
		if ok and type(n) == "number" then
			return n
		end
	end
	return #s
end

local function splitword(w, width)
	local chunks, cur, curw = {}, "", 0
	local i, n = 1, #w
	while i <= n do
		local b = w:byte(i)
		local len = 1
		if b >= 240 then
			len = 4
		elseif b >= 224 then
			len = 3
		elseif b >= 192 then
			len = 2
		end
		if i + len - 1 > n then
			len = n - i + 1
		end
		if curw + 1 > width then
			chunks[#chunks + 1] = cur
			cur, curw = "", 0
		end
		cur = cur .. w:sub(i, i + len - 1)
		curw = curw + 1
		i = i + len
	end
	if cur ~= "" then
		chunks[#chunks + 1] = cur
	end
	return chunks
end

local function reflow(wl, indent, width)
	local avail = width - indent
	if avail < 1 then
		avail = 1
	end
	local pad = string.rep(" ", indent)
	local lines, cur, curw = {}, "", 0
	local function flush()
		if cur ~= "" then
			lines[#lines + 1] = pad .. cur
			cur, curw = "", 0
		end
	end
	for _, w in ipairs(wl) do
		local ww = colwidth(w)
		if cur == "" then
			if ww <= avail then
				cur, curw = w, ww
			else
				for _, c in ipairs(splitword(w, avail)) do
					lines[#lines + 1] = pad .. c
				end
			end
		elseif curw + 1 + ww <= avail then
			local gap = cur:match("..[%.%?!]$") and "  " or " "
			if curw + #gap + ww > avail then
				flush()
				cur, curw = w, ww
			else
				cur, curw = cur .. gap .. w, curw + #gap + ww
			end
		else
			flush()
			if ww <= avail then
				cur, curw = w, ww
			else
				for _, c in ipairs(splitword(w, avail)) do
					lines[#lines + 1] = pad .. c
				end
			end
		end
	end
	flush()
	return lines
end

local function esc(s)
	if not s:find("\\", 1, true) then
		return s
	end
	s = (s:gsub("\\&", ""))
	s = (s:gsub("\\%-", "-"))
	return s
end

local function macargs(rest)
	local args = {}
	local i, n = 1, #rest
	while i <= n do
		local c = rest:sub(i, i)
		if c == " " or c == "\t" then
			i = i + 1
		elseif c == '"' then
			local j = rest:find('"', i + 1, true)
			if not j then
				return nil, "unterminated quote"
			end
			args[#args + 1] = rest:sub(i + 1, j - 1)
			i = j + 1
		else
			local j = rest:find("[ \t]", i)
			local e = (j or n + 1) - 1
			args[#args + 1] = rest:sub(i, e)
			i = j or n + 1
		end
	end
	return args
end

local FONT1 = { B = "B", I = "I", R = "R", SM = "R", SB = "B" }
local FONT2 = {
	BI = { "B", "I" },
	BR = { "B", "R" },
	IB = { "I", "B" },
	IR = { "I", "R" },
	RB = { "R", "B" },
	RI = { "R", "I" },
	RN = { "R", "I" },
}

local function font_runs(m, rest)
	local args, qerr = macargs(rest)
	if not args then
		return nil, "." .. m .. ": " .. qerr
	end
	if #args == 0 then
		return nil, "." .. m .. " needs an argument"
	end
	local runs = {}
	if FONT2[m] then
		local f1, f2 = FONT2[m][1], FONT2[m][2]
		for i, a in ipairs(args) do
			runs[#runs + 1] = { f = (i % 2 == 1) and f1 or f2, s = esc(a) }
		end
	else
		local f = FONT1[m]
		local sm = (m == "SM" or m == "SB")
		for i, a in ipairs(args) do
			if i > 1 then
				runs[#runs + 1] = { f = f, s = " ", sm = sm }
			end
			runs[#runs + 1] = { f = f, s = esc(a), sm = sm }
		end
	end
	return runs
end

local function seg_words(seg)
	local buf = {}
	for _, r in ipairs(seg) do
		buf[#buf + 1] = r.s
	end
	local out = {}
	for w in table.concat(buf):gmatch("%S+") do
		out[#out + 1] = w
	end
	return out
end

local function runs_text(runs)
	local buf = {}
	for _, r in ipairs(runs) do
		buf[#buf + 1] = r.s
	end
	return table.concat(buf)
end

function M.parse(text)
	local doc = { th = nil, blocks = {} }
	local para = nil
	local nf = nil
	local lineno = 0

	local function fail(msg)
		return nil, "line " .. lineno .. ": " .. msg
	end
	local function close_para()
		para = nil
	end

	local function open_p()
		if not para then
			para = { t = "p", segs = {} }
			doc.blocks[#doc.blocks + 1] = para
		end
		return para
	end

	local function append_runs(runs)
		local p = open_p()
		if p.t == "tp" and p.tag == nil then
			p.tag = runs
			return
		end
		local seg = p.segs[#p.segs]
		if not seg then
			seg = {}
			p.segs[#p.segs + 1] = seg
		elseif #seg > 0 then
			seg[#seg + 1] = { f = "R", s = " " }
		end
		for _, r in ipairs(runs) do
			seg[#seg + 1] = r
		end
	end

	for raw in (text .. "\n"):gmatch("([^\n]*)\n") do
		lineno = lineno + 1
		local line = raw:gsub("\r$", "")
		if nf then
			local cm = line:match("^%.(%a+)%s*$")
			if cm == "FI" or cm == "fi" then
				nf = nil
			else
				nf[#nf + 1] = esc(line)
			end
		elseif line:match('^%.\\"') then
		else
			local m, rest = line:match("^%.(%a+)[ \t]*(.-)[ \t]*$")
			if m then
				if para and para.t == "tp" and para.tag == nil and not FONT1[m] and not FONT2[m] then
					return fail(".TP without tag")
				end
				if m == "TH" then
					if doc.th then
						return fail("duplicate .TH")
					end
					local title, sect, manual = rest:match("^(%S+)[ \t]+(%S+)[ \t]*(.-)[ \t]*$")
					if not title or not sect then
						return fail("usage: .TH title section manual")
					end
					manual = (manual:gsub('^"(.-)"$', "%1"))
					doc.th = { title = esc(title), sect = sect, manual = esc(manual) }
					close_para()
				elseif m == "SH" or m == "SS" then
					if rest == "" then
						return fail("." .. m .. " needs a heading")
					end
					close_para()
					doc.blocks[#doc.blocks + 1] = { t = (m == "SH") and "sh" or "ss", s = esc(rest) }
				elseif m == "TP" then
					if rest ~= "" then
						return fail(".TP takes no arguments")
					end
					close_para()
					para = { t = "tp", tag = nil, segs = {} }
					doc.blocks[#doc.blocks + 1] = para
				elseif m == "PP" then
					close_para()
				elseif m == "NF" or m == "nf" then
					if rest ~= "" then
						return fail("." .. m .. " takes no arguments")
					end
					close_para()
					nf = {}
					doc.blocks[#doc.blocks + 1] = { t = "nf", lines = nf }
				elseif m == "FI" or m == "fi" then
					return fail(".FI without .NF")
				elseif m == "br" then
					local p = open_p()
					p.segs[#p.segs + 1] = {}
				elseif m == "sp" then
					local n = 1
					if rest ~= "" then
						n = toint(rest)
						if not n or n < 1 then
							return fail(".sp expects a positive integer")
						end
					end
					close_para()
					doc.blocks[#doc.blocks + 1] = { t = "sp", n = n }
				elseif FONT2[m] or FONT1[m] then
					local runs, ferr = font_runs(m, rest)
					if not runs then
						return fail(ferr)
					end
					append_runs(runs)
				else
					return fail("unknown macro ." .. m)
				end
			elseif line:match("^%s*$") then
				if not (para and para.t == "tp" and para.tag == nil) then
					close_para()
				end
			else
				append_runs({ { f = "R", s = esc(line) } })
			end
		end
	end
	if para and para.t == "tp" and para.tag == nil then
		return nil, "line " .. lineno .. ": .TP without tag"
	end
	if not doc.th then
		return nil, "missing .TH"
	end
	return doc
end

local function header_line(th, width)
	local lr = th.title .. "(" .. th.sect .. ")"
	local manual = th.manual or ""
	if width < MIN_WIDTH then
		width = MIN_WIDTH
	end
	if #lr * 2 + #manual + 2 > width or manual == "" then
		return lr
	end
	local mid = math.floor((width - colwidth(manual)) / 2)
	if mid < #lr + 1 then
		mid = #lr + 1
	end
	if mid + colwidth(manual) > width - #lr then
		return lr
	end
	return lr
		.. string.rep(" ", mid - #lr)
		.. manual
		.. string.rep(" ", width - #lr - (mid - #lr) - colwidth(manual) - #lr)
		.. lr
end

function M.render(doc, width)
	width = toint(width) or 80
	if width < MIN_WIDTH then
		width = MIN_WIDTH
	end
	local out = {}
	local function emit(s)
		out[#out + 1] = s
	end

	emit(header_line(doc.th, width))
	for _, b in ipairs(doc.blocks) do
		if b.t == "sh" then
			emit("")
			emit(b.s)
		elseif b.t == "ss" then
			emit("")
			emit(b.s)
		elseif b.t == "p" then
			emit("")
			for _, seg in ipairs(b.segs) do
				local wl = seg_words(seg)
				if #wl > 0 then
					for _, l in ipairs(reflow(wl, P_IND, width)) do
						emit(l)
					end
				end
			end
		elseif b.t == "tp" then
			emit(string.rep(" ", TAG_IND) .. table.concat(seg_words(b.tag), " "))
			for _, seg in ipairs(b.segs) do
				local wl = seg_words(seg)
				if #wl > 0 then
					for _, l in ipairs(reflow(wl, BODY_IND, width)) do
						emit(l)
					end
				end
			end
		elseif b.t == "nf" then
			emit("")
			local pad = string.rep(" ", NF_IND)
			for _, l in ipairs(b.lines) do
				emit(pad .. l)
			end
		elseif b.t == "sp" then
			for _ = 1, b.n do
				emit("")
			end
		end
	end
	return out
end

function M.format(text, width)
	local doc, err = M.parse(text)
	if not doc then
		return nil, err
	end
	return M.render(doc, width)
end

function M.nameline(doc)
	local in_name = false
	for _, b in ipairs(doc.blocks) do
		if b.t == "sh" then
			in_name = (b.s == "NAME")
		elseif in_name and b.t == "p" then
			for _, seg in ipairs(b.segs) do
				local wl = seg_words(seg)
				if #wl > 0 then
					return table.concat(wl, " ")
				end
			end
			return nil
		end
	end
	return nil
end

return M
