local args = { ... }
local benv = rawget(_G, "ENV") or {}

local K = { boot = { args = args, env = benv } }
local kenv = setmetatable({ K = K }, { __index = _G })

local function diskList()
    local out = {}
    local ok, raw = pcall(files.getDisks)
    if not ok or type(raw) ~= "table" then return out end
    for _, d in ipairs(raw) do
        local slot = type(d) == "table" and (d.slot or d[1]) or d
        local okid, id = pcall(files.getDiskID, slot)
        out[#out + 1] = { slot = slot, id = okid and id or tostring(slot) }
    end
    table.sort(out, function(a, b) return a.slot < b.slot end)
    return out
end

local function hasPartition(slot, name)
    local ok, parts = pcall(files.getPartitions, slot)
    if not ok or type(parts) ~= "table" then return false end
    for _, p in ipairs(parts) do
        if (type(p) == "table" and p.name or p) == name then return true end
    end
    return false
end

local rootspec = tostring(benv.XES_ROOT or "any:xes")
local rdisk, rpart = rootspec:match("^([^:]+):([^:/]+)$")
if not rdisk then rdisk, rpart = "any", "xes" end

local root
for _, d in ipairs(diskList()) do
    if (rdisk == "any" or d.id == rdisk or tostring(d.slot) == rdisk) and hasPartition(d.slot, rpart) then
        root = { slot = d.slot, id = d.id, part = rpart }
        break
    end
end
if not root then
    chip.crash("XesNS: root partition '" .. rootspec .. "' not found")
    return
end
K.root = root

local function rawRead(path)
    local ok, h = pcall(files.open, root.part .. ":" .. path, "r", root.slot)
    if not ok or not h then return nil, "cannot open " .. path end
    local data = h.read("a")
    h.close()
    return data or ""
end
K.rawRead = rawRead

function K.loadModule(name)
    local path = "/kernel/" .. name .. ".lua"
    local src, err = rawRead(path)
    if not src then error("kernel: " .. tostring(err), 0) end
    local chunk, cerr = load(src, "=" .. root.part .. ":" .. path, "t", kenv)
    if not chunk then error("kernel: " .. tostring(cerr), 0) end
    return chunk(K)
end

local order = {
    "klib", "crypto", "rawfs", "path", "perm", "psf", "tty", "kbd", "vfs",
    "proc", "sched", "neato", "posix", "main",
}
local ok, err = pcall(function()
    for _, name in ipairs(order) do K.loadModule(name) end
    K.main()
end)
if not ok then
    local msg = "XesNS boot failed: " .. tostring(err)
    if K.panic then K.panic(msg) else chip.crash(msg) end
end
