local K = ...

local KBD = {}
K.kbd = KBD

local NAMES = {
	[13] = "enter",
	[10] = "enter",
	[9] = "tab",
	[8] = "backspace",
	[127] = "delete",
	[27] = "escape",
	[128] = "left",
	[129] = "right",
	[130] = "up",
	[131] = "down",
	[14] = "leftShift",
	[132] = "leftCtrl",
	[133] = "leftAlt",
	[32] = "space",
	[158] = "home",
	[159] = "end",
	[160] = "pageup",
	[161] = "pagedown",
}
local MODIFIER = { [14] = true, [132] = true, [133] = true }

local UNSHIFT = {}
do
	local from, to = ")!@#$%^&*(", "0123456789"
	for i = 1, #from do
		UNSHIFT[from:byte(i)] = to:byte(i)
	end
	local a, b = '~_+{}|:"<>?', "`-=[]\\;',./"
	for i = 1, #a do
		UNSHIFT[a:byte(i)] = b:byte(i)
	end
end

KBD.keymap = { keys = {}, unshift = {} }

function KBD.loadmap(map)
	if type(map) ~= "table" then
		return nil, "invalid keymap"
	end
	local keys, unshift = map.keys, map.unshift
	if keys == nil then
		keys = {}
	end
	if unshift == nil then
		unshift = {}
	end
	if type(keys) ~= "table" or type(unshift) ~= "table" then
		return nil, "invalid keymap"
	end
	for code, name in pairs(keys) do
		if type(code) ~= "number" or math.tointeger(code) ~= code or code < 0 or code > 255 then
			return nil, "bad key code " .. tostring(code)
		end
		if type(name) ~= "string" or name == "" or name:find("%c") then
			return nil, "bad key name for code " .. tostring(code)
		end
	end
	for from, to in pairs(unshift) do
		for _, b in ipairs({ from, to }) do
			if type(b) ~= "number" or math.tointeger(b) ~= b or b < 0 or b > 255 then
				return nil, "bad unshift byte " .. tostring(b)
			end
		end
	end
	local nk, nu = {}, {}
	for code, name in pairs(keys) do
		nk[code] = name
	end
	for from, to in pairs(unshift) do
		nu[from] = to
	end
	KBD.keymap = { keys = nk, unshift = nu }
	return true
end

function KBD.getmap()
	local nk, nu = {}, {}
	for code, name in pairs(KBD.keymap.keys) do
		nk[code] = name
	end
	for from, to in pairs(KBD.keymap.unshift) do
		nu[from] = to
	end
	return { keys = nk, unshift = nu }
end

local MOD_SHIFT, MOD_CTRL, MOD_ALT = 1, 2, 4

function KBD.keyName(code)
	local n = KBD.keymap.keys[code] or NAMES[code]
	if n then
		return n
	end
	if code >= 134 and code <= 145 then
		return "f" .. (code - 133)
	end
	if code >= 146 and code <= 157 then
		return "x.f" .. (code - 133)
	end
	if code >= 65 and code <= 90 then
		return string.char(code + 32)
	end
	if code >= 97 and code <= 122 then
		return string.char(code)
	end
	if code >= 48 and code <= 57 then
		return string.char(code)
	end
	if code > 32 and code < 127 then
		return string.char(KBD.keymap.unshift[code] or UNSHIFT[code] or code)
	end
	return "x.key" .. tostring(code)
end

local held = {}
local rep = nil
local rawpid = nil
local swallowed = {}
KBD.softRepeat = true
KBD.repeatDelay, KBD.repeatRate = 0.45, 0.035

function KBD.grab(pid)
	rawpid = pid
	held = {}
	swallowed = {}
	rep = nil
end

function KBD.release(pid)
	if pid == nil or rawpid == pid then
		rawpid = nil
	end
end

function KBD.grabbed()
	return rawpid
end

local RAW_SEQ = {
	enter = "\r",
	tab = "\t",
	backspace = "\127",
	escape = "\27",
	space = " ",
	up = "\27[A",
	down = "\27[B",
	right = "\27[C",
	left = "\27[D",
	home = "\27[H",
	["end"] = "\27[F",
	pageup = "\27[5~",
	pagedown = "\27[6~",
	insert = "\27[2~",
	delete = "\27[3~",
	f1 = "\27OP",
	f2 = "\27OQ",
	f3 = "\27OR",
	f4 = "\27OS",
	f5 = "\27[15~",
	f6 = "\27[17~",
	f7 = "\27[18~",
	f8 = "\27[19~",
	f9 = "\27[20~",
	f10 = "\27[21~",
	f11 = "\27[23~",
	f12 = "\27[24~",
}

local function rawBytes(code, name, mods)
	mods = mods or 0
	local s
	if (mods & MOD_CTRL) ~= 0 then
		if name == "space" then
			s = "\0"
		elseif #name == 1 then
			local b = name:byte()
			if b >= 63 and b <= 95 then
				s = string.char(b == 63 and 127 or (b & 31))
			elseif b >= 97 and b <= 122 then
				s = string.char(b & 31)
			end
		end
	end
	s = s or RAW_SEQ[name]
	if not s and (mods & MOD_CTRL) == 0 then
		if code >= 32 and code < 127 then
			s = string.char(code)
		else
			return nil
		end
	end
	if not s then
		return nil
	end
	if (mods & MOD_ALT) ~= 0 then
		s = "\27" .. s
	end
	return s
end

local function rawPress(t, code, name, mods)
	local s = rawBytes(code, name, mods)
	if not s then
		return false
	end
	for i = 1, #s do
		K.tty_input(t, "char", s:sub(i, i))
	end
	return true
end

local function emitKey(name, ch, isRepeat)
	K.input("key", name, isRepeat and true or false)
	if ch then
		K.input("char", ch)
	end
end

local function onPress(code, letter, mods)
	mods = mods or 0

	if rawpid then
		local p = K.procs[rawpid]
		if p and p.state ~= "Z" then
			K.pushEvent(p, "key", KBD.keyName(code), false, code, mods)
		end
		return
	end

	local name = KBD.keyName(code)

	local rt = K.tty_active
	if rt and rt.rawActive and rt:rawActive() then
		rawPress(rt, code, name, mods)
		return
	end

	if (mods & MOD_ALT) ~= 0 then
		local n
		if (mods & MOD_CTRL) == 0 and name:match("^[1-4]$") then
			n = tonumber(name)
		elseif name:match("^f[1-4]$") then
			n = tonumber(name:sub(2))
		end
		if n then
			local t = K.ttys[n]
			if t then
				K.tty_show(t)
			end
			return
		end
	end

	if (mods & MOD_SHIFT) ~= 0 and (mods & MOD_CTRL) == 0 and (mods & MOD_ALT) == 0 then
		local t = K.tty_active
		if name == "pageup" then
			if t then
				t:scrollView(t.rows)
				K.tty_kick(t)
			end
			return
		elseif name == "pagedown" then
			if t then
				t:scrollView(-t.rows)
				K.tty_kick(t)
			end
			return
		elseif name == "home" then
			if t then
				t:scrollView(#t.scrollback)
				K.tty_kick(t)
			end
			return
		elseif name == "end" then
			if t then
				t:scrollView(-t.view)
				K.tty_kick(t)
			end
			return
		end
	end
	if (mods & MOD_CTRL) ~= 0 and name == "c" then
		if not swallowed[code] then
			swallowed[code] = true
			K.interrupt(false)
		end
		return
	end
	if (mods & MOD_CTRL) ~= 0 and name == "\\" then
		if not swallowed[code] then
			swallowed[code] = true
			K.interrupt(true)
		end
		return
	end

	local ch = nil
	if code >= 32 and code < 127 and (mods & (MOD_CTRL | MOD_ALT)) == 0 then
		ch = string.char(code)
	end
	K.tty_kick(K.tty_active)

	if held[code] then
		KBD.softRepeat = false
		emitKey(name, ch, true)
		return
	end
	held[code] = true
	emitKey(name, ch, false)
	if not MODIFIER[code] and KBD.softRepeat then
		rep = { code = code, name = name, ch = ch, since = K.monotonic(), last = K.monotonic() }
	end
end

local function onRelease(code)
	if rawpid then
		local p = K.procs[rawpid]
		if p and p.state ~= "Z" then
			K.pushEvent(p, "key_up", KBD.keyName(code), code, 0)
		end
		return
	end
	local rt = K.tty_active
	if rt and rt.rawActive and rt:rawActive() then
		return
	end
	held[code] = nil
	if swallowed[code] then
		swallowed[code] = nil
		return
	end
	if rep and rep.code == code then
		rep = nil
	end
	K.input("key_up", KBD.keyName(code))
end

function KBD.feed(code, letter, mods)
	if type(code) ~= "number" then
		return nil, "bad key code"
	end
	onPress(code, letter, mods)
	return true
end

function KBD.feedRelease(code)
	if type(code) ~= "number" then
		return nil, "bad key code"
	end
	onRelease(code)
	return true
end

local function onMouse(e)
	if not rawpid then
		return
	end
	local p = K.procs[rawpid]
	if not p or p.state == "Z" then
		return
	end
	local kind = e[1]
	if kind == "mouseMoved" then
		K.pushEvent(p, "mouseMoved", e[2], e[3])
	elseif kind == "mouseScrolled" then
		K.pushEvent(p, "mouseScrolled", e[2], e[3], e[4] or 0, e[5] or 0)
	else
		K.pushEvent(p, kind, e[2], e[3], e[4] or 0)
	end
end

function KBD.pump()
	for _, t in pairs(K.ttys or {}) do
		if t.rawpid then
			t:rawActive()
		end
	end
	for _, t in pairs(K.extrattys or {}) do
		if t.rawpid then
			t:rawActive()
		end
	end
	for _, queue in ipairs({ "User", "System", "Peripheral", "Compatibility", "Unlabeled" }) do
		local events = event.getQueue(queue)
		for i = 1, #events do
			local e = events[i]
			local kind = e[1]
			if queue == "User" and kind == "keyPressed" then
				onPress(e[2], e[3], e[4])
			elseif queue == "User" and kind == "keyReleased" then
				onRelease(e[2])
			elseif queue == "User"
				and (kind == "mouseMoved" or kind == "mouseClicked" or kind == "mouseDragged"
					or kind == "mouseReleased" or kind == "mouseScrolled")
			then
				onMouse(e)
			end
			if type(K.extensionHooks) == "table" then
				local sink = K.extensionHooks[queue:lower()] or K.extensionHooks[kind]
				if type(sink) == "function" then
					pcall(sink, e)
				end
			end
		end
	end
	if K.on_network then
		local net = event.getQueue("Network")
		for i = 1, #net do
			K.on_network(net[i])
		end
	end

	if rep then
		local now = K.monotonic()
		if now - rep.since >= KBD.repeatDelay then
			local n = 0
			while now - rep.last >= KBD.repeatRate and n < 3 do
				rep.last = rep.last + KBD.repeatRate
				emitKey(rep.name, rep.ch, true)
				n = n + 1
			end
			if now - rep.last > 0.5 then
				rep.last = now
			end
		end
	end
end
