local M = {}

M.VERSION = "0.2.0"

local mfloor, mceil, mabs, msqrt, msin, mcos, mtan, atan2, pi =
	math.floor, math.ceil, math.abs, math.sqrt, math.sin, math.cos, math.tan, math.atan2 or math.atan, math.pi

local function trim(s)
	return s:match("^%s*(.-)%s*$")
end

local function clamp(v, lo, hi)
	if v < lo then
		return lo
	end
	if v > hi then
		return hi
	end
	return v
end

local NAMED = {
	black = { 0, 0, 0 },
	silver = { 192, 192, 192 },
	gray = { 128, 128, 128 },
	grey = { 128, 128, 128 },
	white = { 255, 255, 255 },
	maroon = { 128, 0, 0 },
	red = { 255, 0, 0 },
	purple = { 128, 0, 128 },
	fuchsia = { 255, 0, 255 },
	magenta = { 255, 0, 255 },
	green = { 0, 128, 0 },
	lime = { 0, 255, 0 },
	olive = { 128, 128, 0 },
	yellow = { 255, 255, 0 },
	navy = { 0, 0, 128 },
	blue = { 0, 0, 255 },
	teal = { 0, 128, 128 },
	aqua = { 0, 255, 255 },
	cyan = { 0, 255, 255 },
	orange = { 255, 165, 0 },
	aliceblue = { 240, 248, 255 },
	antiquewhite = { 250, 235, 215 },
	aquamarine = { 127, 255, 212 },
	azure = { 240, 255, 255 },
	beige = { 245, 245, 220 },
	bisque = { 255, 228, 196 },
	blanchedalmond = { 255, 235, 205 },
	blueviolet = { 138, 43, 226 },
	brown = { 165, 42, 42 },
	burlywood = { 222, 184, 135 },
	cadetblue = { 95, 158, 160 },
	chartreuse = { 127, 255, 0 },
	chocolate = { 210, 105, 30 },
	coral = { 255, 127, 80 },
	cornflowerblue = { 100, 149, 237 },
	cornsilk = { 255, 248, 220 },
	crimson = { 220, 20, 60 },
	darkblue = { 0, 0, 139 },
	darkcyan = { 0, 139, 139 },
	darkgoldenrod = { 184, 134, 11 },
	darkgray = { 169, 169, 169 },
	darkgreen = { 0, 100, 0 },
	darkgrey = { 169, 169, 169 },
	darkkhaki = { 189, 183, 107 },
	darkmagenta = { 139, 0, 139 },
	darkolivegreen = { 85, 107, 47 },
	darkorange = { 255, 140, 0 },
	darkorchid = { 153, 50, 204 },
	darkred = { 139, 0, 0 },
	darksalmon = { 233, 150, 122 },
	darkseagreen = { 143, 188, 143 },
	darkslateblue = { 72, 61, 139 },
	darkslategray = { 47, 79, 79 },
	darkslategrey = { 47, 79, 79 },
	darkturquoise = { 0, 206, 209 },
	darkviolet = { 148, 0, 211 },
	deeppink = { 255, 20, 147 },
	deepskyblue = { 0, 191, 255 },
	dimgray = { 105, 105, 105 },
	dimgrey = { 105, 105, 105 },
	dodgerblue = { 30, 144, 255 },
	firebrick = { 178, 34, 34 },
	floralwhite = { 255, 250, 240 },
	forestgreen = { 34, 139, 34 },
	gainsboro = { 220, 220, 220 },
	ghostwhite = { 248, 248, 255 },
	gold = { 255, 215, 0 },
	goldenrod = { 218, 165, 32 },
	greenyellow = { 173, 255, 47 },
	honeydew = { 240, 255, 240 },
	hotpink = { 255, 105, 180 },
	indianred = { 205, 92, 92 },
	indigo = { 75, 0, 130 },
	ivory = { 255, 255, 240 },
	khaki = { 240, 230, 140 },
	lavender = { 230, 230, 250 },
	lavenderblush = { 255, 240, 245 },
	lawngreen = { 124, 252, 0 },
	lemonchiffon = { 255, 250, 205 },
	lightblue = { 173, 216, 230 },
	lightcoral = { 240, 128, 128 },
	lightcyan = { 224, 255, 255 },
	lightgoldenrodyellow = { 250, 250, 210 },
	lightgray = { 211, 211, 211 },
	lightgreen = { 144, 238, 144 },
	lightgrey = { 211, 211, 211 },
	lightpink = { 255, 182, 193 },
	lightsalmon = { 255, 160, 122 },
	lightseagreen = { 32, 178, 170 },
	lightskyblue = { 135, 206, 250 },
	lightslategray = { 119, 136, 153 },
	lightslategrey = { 119, 136, 153 },
	lightsteelblue = { 176, 196, 222 },
	lightyellow = { 255, 255, 224 },
	limegreen = { 50, 205, 50 },
	linen = { 250, 240, 230 },
	mediumaquamarine = { 102, 205, 170 },
	mediumblue = { 0, 0, 205 },
	mediumorchid = { 186, 85, 211 },
	mediumpurple = { 147, 112, 219 },
	mediumseagreen = { 60, 179, 113 },
	mediumslateblue = { 123, 104, 238 },
	mediumspringgreen = { 0, 250, 154 },
	mediumturquoise = { 72, 209, 204 },
	mediumvioletred = { 199, 21, 133 },
	midnightblue = { 25, 25, 112 },
	mintcream = { 245, 255, 250 },
	mistyrose = { 255, 228, 225 },
	moccasin = { 255, 228, 181 },
	navajowhite = { 255, 222, 173 },
	oldlace = { 253, 245, 230 },
	olivedrab = { 107, 142, 35 },
	orangered = { 255, 69, 0 },
	orchid = { 218, 112, 214 },
	palegoldenrod = { 238, 232, 170 },
	palegreen = { 152, 251, 152 },
	paleturquoise = { 175, 238, 238 },
	palevioletred = { 219, 112, 147 },
	papayawhip = { 255, 239, 213 },
	peachpuff = { 255, 218, 185 },
	peru = { 205, 133, 63 },
	pink = { 255, 192, 203 },
	plum = { 221, 160, 221 },
	powderblue = { 176, 224, 230 },
	rosybrown = { 188, 143, 143 },
	royalblue = { 65, 105, 225 },
	saddlebrown = { 139, 69, 19 },
	salmon = { 250, 128, 114 },
	sandybrown = { 244, 164, 96 },
	seagreen = { 46, 139, 87 },
	seashell = { 255, 245, 238 },
	sienna = { 160, 82, 45 },
	skyblue = { 135, 206, 235 },
	slateblue = { 106, 90, 205 },
	slategray = { 112, 128, 144 },
	slategrey = { 112, 128, 144 },
	snow = { 255, 250, 250 },
	springgreen = { 0, 255, 127 },
	steelblue = { 70, 130, 180 },
	tan = { 210, 180, 140 },
	thistle = { 216, 191, 216 },
	tomato = { 255, 99, 71 },
	turquoise = { 64, 224, 208 },
	violet = { 238, 130, 238 },
	wheat = { 245, 222, 179 },
	whitesmoke = { 245, 245, 245 },
	yellowgreen = { 154, 205, 50 },
}

local function parse_color(s)
	if type(s) ~= "string" then
		return nil
	end
	s = trim(s):lower()
	if s == "" or s == "none" then
		return nil
	end
	if s == "transparent" then
		return { 0, 0, 0, 0 }
	end
	if NAMED[s] then
		local c = NAMED[s]
		return { c[1], c[2], c[3], 255 }
	end
	if s:sub(1, 1) == "#" then
		local h = s:sub(2)
		if #h == 3 or #h == 4 then
			local r = tonumber(h:sub(1, 1), 16)
			local g = tonumber(h:sub(2, 2), 16)
			local b = tonumber(h:sub(3, 3), 16)
			if not r or not g or not b then
				return nil
			end
			local a = 255
			if #h == 4 then
				a = tonumber(h:sub(4, 4), 16)
				if not a then
					return nil
				end
				a = a * 17
			end
			return { r * 17, g * 17, b * 17, a }
		elseif #h == 6 or #h == 8 then
			local r = tonumber(h:sub(1, 2), 16)
			local g = tonumber(h:sub(3, 4), 16)
			local b = tonumber(h:sub(5, 6), 16)
			if not r or not g or not b then
				return nil
			end
			local a = 255
			if #h == 8 then
				a = tonumber(h:sub(7, 8), 16)
				if not a then
					return nil
				end
			end
			return { r, g, b, a }
		end
		return nil
	end
	local fn, inner = s:match("^(rgba?)%((.-)%)$")
	if fn then
		local parts = {}
		for p in (inner:gsub("/", " ")):gmatch("[^,%s]+") do
			parts[#parts + 1] = p
		end
		if #parts >= 3 then
			local function chan(v)
				if v:sub(-1) == "%" then
					local n = tonumber(v:sub(1, -2))
					if not n then
						return nil
					end
					return clamp(mfloor(n * 2.55 + 0.5), 0, 255)
				end
				local n = tonumber(v)
				if not n then
					return nil
				end
				return clamp(mfloor(n + 0.5), 0, 255)
			end
			local r, g, b = chan(parts[1]), chan(parts[2]), chan(parts[3])
			if not r or not g or not b then
				return nil
			end
			local a = 255
			if parts[4] then
				local av
				if parts[4]:sub(-1) == "%" then
					local n = tonumber(parts[4]:sub(1, -2))
					if not n then
						return nil
					end
					av = clamp(n / 100, 0, 1)
				else
					av = tonumber(parts[4])
					if not av then
						return nil
					end
					if av > 1 then
						av = av / 255
					end
					av = clamp(av, 0, 1)
				end
				a = mfloor(av * 255 + 0.5)
			end
			return { r, g, b, a }
		end
		return nil
	end
	return nil
end

local function parse_alpha(v)
	if type(v) == "number" then
		if v > 1 then
			return clamp(v / 255, 0, 1)
		end
		return clamp(v, 0, 1)
	end
	if type(v) ~= "string" then
		return 1
	end
	v = trim(v)
	if v == "" then
		return 1
	end
	if v:sub(-1) == "%" then
		local n = tonumber(v:sub(1, -2))
		if not n then
			return 1
		end
		return clamp(n / 100, 0, 1)
	end
	local n = tonumber(v)
	if not n then
		return 1
	end
	if n > 1 then
		n = n / 255
	end
	return clamp(n, 0, 1)
end

local UNIT_PX = { px = 1, pt = 96 / 72, pc = 16, mm = 96 / 25.4, cm = 96 / 2.54, ["in"] = 96, q = 96 / 2.54 / 40 }

local function parse_length(s, ref)
	if type(s) == "number" then
		return s
	end
	if type(s) ~= "string" then
		return nil
	end
	s = trim(s)
	if s == "" then
		return nil
	end
	local num, unit = s:match("^([%+%-]?%d*%.?%d+[eE][%+%-]?%d+)(.-)$")
	if not num then
		num, unit = s:match("^([%+%-]?%d*%.?%d+)(.-)$")
	end
	if not num then
		return nil
	end
	local v = tonumber(num)
	if not v then
		return nil
	end
	unit = trim(unit or ""):lower()
	if unit == "" then
		return v
	end
	if unit == "%" then
		return v / 100 * (ref or 0)
	end
	local k = UNIT_PX[unit]
	if k then
		return v * k
	end
	return nil
end

local function scan_numbers(s)
	local nums = {}
	local exp = {}
	local masked = s:gsub("[%+%-]?%d*%.?%d+[eE][%+%-]?%d+", function(m)
		exp[#exp + 1] = tonumber(m)
		return " E" .. #exp .. " "
	end)
	for tok in masked:gmatch("[^,%s]+") do
		local k = tok:match("^E(%d+)$")
		if k then
			local v = exp[tonumber(k)]
			if v then
				nums[#nums + 1] = v
			end
		else
			local clean = tok:gsub("^[^%d%.%+%-]*", ""):gsub("[^%d%.]+$", "")
			local v = tonumber(clean)
			if v then
				nums[#nums + 1] = v
			end
		end
	end
	return nums
end

local function mat_identity()
	return { 1, 0, 0, 1, 0, 0 }
end

local function mat_mul(m1, m2)
	local a1, b1, c1, d1, e1, f1 = m1[1], m1[2], m1[3], m1[4], m1[5], m1[6]
	local a2, b2, c2, d2, e2, f2 = m2[1], m2[2], m2[3], m2[4], m2[5], m2[6]
	return {
		a1 * a2 + c1 * b2,
		b1 * a2 + d1 * b2,
		a1 * c2 + c1 * d2,
		b1 * c2 + d1 * d2,
		a1 * e2 + c1 * f2 + e1,
		b1 * e2 + d1 * f2 + f1,
	}
end

local function mat_apply(m, x, y)
	return m[1] * x + m[3] * y + m[5], m[2] * x + m[4] * y + m[6]
end

local function parse_transform(s)
	local m = mat_identity()
	if type(s) ~= "string" or trim(s) == "" then
		return m
	end
	for fn_raw, args in s:gmatch("([%a]+)%s*%(([^%)]*)%)") do
		local fn = fn_raw:lower()
		local nums = scan_numbers(args)
		local t = nil
		if fn == "matrix" and #nums == 6 then
			t = { nums[1], nums[2], nums[3], nums[4], nums[5], nums[6] }
		elseif fn == "translate" then
			local tx = nums[1] or 0
			t = { 1, 0, 0, 1, tx, nums[2] or 0 }
		elseif fn == "scale" then
			local sx = nums[1] or 1
			t = { sx, 0, 0, nums[2] or sx, 0, 0 }
		elseif fn == "rotate" then
			local a = (nums[1] or 0) * pi / 180
			local ca, sa = mcos(a), msin(a)
			t = { ca, sa, -sa, ca, 0, 0 }
			if nums[2] and nums[3] then
				local cx, cy = nums[2], nums[3]
				t = mat_mul({ 1, 0, 0, 1, cx, cy }, mat_mul(t, { 1, 0, 0, 1, -cx, -cy }))
			end
		elseif fn == "skewx" then
			local a = (nums[1] or 0) * pi / 180
			t = { 1, 0, mtan(a), 1, 0, 0 }
		elseif fn == "skewy" then
			local a = (nums[1] or 0) * pi / 180
			t = { 1, mtan(a), 0, 1, 0, 0 }
		end
		if t then
			m = mat_mul(m, t)
		end
	end
	return m
end

local function parse_style(s, out)
	out = out or {}
	if type(s) ~= "string" then
		return out
	end
	for decl in s:gmatch("[^;]+") do
		local k, v = decl:match("^%s*([%-%w]+)%s*:%s*(.-)%s*$")
		if k and v then
			out[k:lower()] = trim(v)
		end
	end
	return out
end

local INHERITED = {
	fill = true,
	["fill-rule"] = true,
	["fill-opacity"] = true,
	stroke = true,
	["stroke-width"] = true,
	["stroke-opacity"] = true,
	["stroke-linecap"] = true,
	["stroke-linejoin"] = true,
	["stroke-miterlimit"] = true,
	opacity = true,
	visibility = true,
}

local DEFAULTS = {
	fill = "black",
	["fill-rule"] = "nonzero",
	["fill-opacity"] = "1",
	stroke = "none",
	["stroke-width"] = "1",
	["stroke-opacity"] = "1",
	["stroke-linecap"] = "butt",
	["stroke-linejoin"] = "miter",
	["stroke-miterlimit"] = "4",
	opacity = "1",
	visibility = "visible",
}

local function resolve_style(attrs, parent)
	local st = {}
	if parent then
		for k in pairs(INHERITED) do
			st[k] = parent[k]
		end
	else
		for k, v in pairs(DEFAULTS) do
			st[k] = v
		end
	end
	local inline = attrs and attrs.style
	for k in pairs(INHERITED) do
		if attrs and attrs[k] ~= nil and attrs[k] ~= "" then
			st[k] = attrs[k]
		end
	end
	if inline then
		local m = parse_style(inline)
		for k, v in pairs(m) do
			if INHERITED[k] or k == "display" or k == "visibility" then
				st[k] = v
			end
		end
	end
	if attrs then
		if attrs.display then
			st.display = attrs.display
		end
		if attrs.visibility then
			st.visibility = attrs.visibility
		end
	end
	local own_op = 1
	if attrs and attrs.opacity ~= nil and attrs.opacity ~= "" then
		own_op = parse_alpha(attrs.opacity)
	end
	if inline then
		local m = parse_style(inline)
		if m.opacity then
			own_op = parse_alpha(m.opacity)
		end
	end
	st._op = (parent and parent._op or 1) * clamp(own_op, 0, 1)
	return st
end

local function parse_attrs(s)
	local attrs = {}
	local i, n = 1, #s
	while i <= n do
		while i <= n and s:sub(i, i):match("%s") do
			i = i + 1
		end
		if i > n then
			break
		end
		local ks, ke, name = s:find("^([%w_:%-%.]+)%s*=%s*", i)
		if not ks then
			break
		end
		i = ke + 1
		local q = s:sub(i, i)
		if q ~= '"' and q ~= "'" then
			break
		end
		local j = s:find(q, i + 1, true)
		if not j then
			break
		end
		attrs[name] = s:sub(i + 1, j - 1)
		i = j + 1
	end
	return attrs
end

local MAX_ELEMENTS = 100000
local MAX_DEPTH = 96
local MAX_SHAPES = 8192
local MAX_WORK = 128 * 1024 * 1024

local function parse_xml(s)
	local pos, n = 1, #s
	local root = { tag = "!root", attrs = {}, kids = {} }
	local stack = { root }
	local elements = 0
	local function top()
		return stack[#stack]
	end
	while pos <= n do
		local lt = s:find("<", pos, true)
		if not lt then
			break
		end
		pos = lt
		if s:sub(pos, pos + 3) == "<!--" then
			local e = s:find("-->", pos + 4, true)
			if not e then
				return nil, "unterminated comment"
			end
			pos = e + 3
		elseif s:sub(pos, pos + 1) == "<?" then
			local e = s:find("?>", pos + 2, true)
			if not e then
				return nil, "unterminated processing instruction"
			end
			pos = e + 2
		elseif s:sub(pos, pos + 8):upper() == "<!DOCTYPE" then
			local depth, i = 0, pos
			local instr = false
			local quote = nil
			while i <= n do
				local c = s:sub(i, i)
				if quote then
					if c == quote then
						quote = nil
					end
				elseif c == '"' or c == "'" then
					quote = c
				elseif c == "[" then
					depth = depth + 1
				elseif c == "]" then
					depth = depth + 1 - 2
					if depth < 0 then
						depth = 0
					end
				elseif c == ">" and depth == 0 then
					break
				end
				instr = false
				i = i + 1
			end
			if i > n then
				return nil, "unterminated doctype"
			end
			pos = i + 1
		elseif s:sub(pos, pos + 1) == "</" then
			local e = s:find(">", pos + 2, true)
			if not e then
				return nil, "unterminated close tag"
			end
			local name = trim(s:sub(pos + 2, e - 1)):match("^([%w_:%-%.]+)")
			if name then
				name = name:lower()
				local colon = name:find(":", 1, true)
				if colon then
					name = name:sub(colon + 1)
				end
				for k = #stack, 2, -1 do
					if stack[k].tag == name then
						while #stack >= k do
							stack[#stack] = nil
						end
						break
					end
				end
			end
			pos = e + 1
		elseif s:sub(pos, pos + 1) == "<!" then
			if s:sub(pos, pos + 8) == "<![CDATA[" then
				local e = s:find("]]>", pos + 9, true)
				if not e then
					return nil, "unterminated cdata"
				end
				pos = e + 3
			else
				local e = s:find(">", pos + 2, true)
				if not e then
					return nil, "unterminated declaration"
				end
				pos = e + 1
			end
		else
			local e = s:find(">", pos + 1, true)
			if not e then
				return nil, "unterminated tag"
			end
			local body = s:sub(pos + 1, e - 1)
			local selfclose = body:sub(-1) == "/"
			if selfclose then
				body = body:sub(1, -2)
			end
			local rawname = body:match("^%s*([%w_:%-%.]+)")
			if not rawname then
				return nil, "bad tag name"
			end
			local name = rawname:lower()
			local colon = name:find(":", 1, true)
			if colon then
				name = name:sub(colon + 1)
			end
			local attrs = parse_attrs(body:sub(#rawname + 1))
			local norm = {}
			for k, v in pairs(attrs) do
				local lk = k:lower()
				local c2 = lk:find(":", 1, true)
				if c2 then
					lk = lk:sub(c2 + 1)
				end
				norm[lk] = v
			end
			local node = { tag = name, attrs = norm, kids = {} }
			elements = elements + 1
			if elements > MAX_ELEMENTS then
				return nil, "svg too complex (element limit)"
			end
			if #stack > MAX_DEPTH then
				return nil, "svg too deeply nested"
			end
			top().kids[#top().kids + 1] = node
			if not selfclose then
				stack[#stack + 1] = node
			end
			pos = e + 1
		end
	end
	return root
end

local function find_svg(root)
	local function walk(node)
		if node.tag == "svg" then
			return node
		end
		for _, k in ipairs(node.kids or {}) do
			local f = walk(k)
			if f then
				return f
			end
		end
		return nil
	end
	for _, k in ipairs(root.kids or {}) do
		local f = walk(k)
		if f then
			return f
		end
	end
	return nil
end

function M.detect(data, path)
	if type(data) == "string" and #data > 0 then
		local head = data:sub(1, 2048):lower()
		if head:find("<svg[%s>]", 1) then
			return true
		end
	end
	if type(path) == "string" and path:lower():match("%.svgz?$") then
		return true
	end
	return false
end

local function tokenize_path(d)
	local toks = {}
	local i, n = 1, #d
	while i <= n do
		local c = d:sub(i, i)
		if c:match("[%s,]") then
			i = i + 1
		elseif c:match("[AaCcHhLlMmQqSsTtVvZz]") then
			toks[#toks + 1] = c
			i = i + 1
		else
			local m = d:match("^[%+%-]?%d*%.?%d+[eE][%+%-]?%d+", i)
				or d:match("^[%+%-]?%d*%.?%d+", i)
				or d:match("^[%+%-]?%.%d+", i)
			if not m then
				if c == "." or c == "+" or c == "-" then
					return nil, "bad number in path data near offset " .. i
				end
				i = i + 1
			else
				toks[#toks + 1] = tonumber(m)
				i = i + #m
			end
		end
	end
	return toks
end

local arc_to_cubics

local function parse_path_data(d)
	local toks, terr = tokenize_path(d or "")
	if not toks then
		return nil, terr
	end
	local subs = {}
	local cur = nil
	local cx, cy = 0, 0
	local sx, sy = 0, 0
	local i, n = 1, #toks
	local cmd = nil
	local prev_cubic_ctrl = nil
	local prev_quad_ctrl = nil

	local function need_sub()
		if not cur then
			cur = { closed = false, segs = {} }
			subs[#subs + 1] = cur
			sx, sy = cx, cy
		end
	end

	local function line_to(x, y)
		need_sub()
		cur.segs[#cur.segs + 1] = { kind = "line", x = x, y = y }
		cx, cy = x, y
	end

	local function finish_cmd_default()
		prev_cubic_ctrl, prev_quad_ctrl = nil, nil
	end

	while i <= n do
		local t = toks[i]
		if type(t) == "string" then
			cmd = t
			i = i + 1
			if cmd == "Z" or cmd == "z" then
				if cur then
					cur.closed = true
					cx, cy = sx, sy
					cur = nil
				end
				cmd = nil
				finish_cmd_default()
			end
		elseif cmd == nil then
			return nil, "path data must start with a moveto"
		end

		if cmd == nil then
		elseif cmd == "M" or cmd == "m" then
			if i + 1 > n or type(toks[i]) == "string" then
				return nil, "moveto needs a coordinate pair"
			end
			local x, y = toks[i], toks[i + 1]
			if type(x) ~= "number" or type(y) ~= "number" then
				return nil, "moveto needs a coordinate pair"
			end
			if cmd == "m" then
				x, y = cx + x, cy + y
			end
			cx, cy = x, y
			sx, sy = x, y
			cur = { closed = false, segs = {} }
			subs[#subs + 1] = cur
			cur.mx, cur.my = x, y
			i = i + 2
			cmd = (cmd == "m") and "l" or "L"
			finish_cmd_default()
		elseif cmd == "L" or cmd == "l" then
			if type(toks[i]) == "string" or i + 1 > n then
				return nil, "lineto needs coordinates"
			end
			local x, y = toks[i], toks[i + 1]
			if type(x) ~= "number" or type(y) ~= "number" then
				break
			end
			if cmd == "l" then
				x, y = cx + x, cy + y
			end
			line_to(x, y)
			i = i + 2
			finish_cmd_default()
		elseif cmd == "H" or cmd == "h" then
			local v = toks[i]
			if type(v) ~= "number" then
				return nil, "hlineto needs a coordinate"
			end
			local x = (cmd == "h") and (cx + v) or v
			line_to(x, cy)
			i = i + 1
			finish_cmd_default()
		elseif cmd == "V" or cmd == "v" then
			local v = toks[i]
			if type(v) ~= "number" then
				return nil, "vlineto needs a coordinate"
			end
			local y = (cmd == "v") and (cy + v) or v
			line_to(cx, y)
			i = i + 1
			finish_cmd_default()
		elseif cmd == "C" or cmd == "c" then
			if i + 5 > n then
				return nil, "curveto needs 6 numbers"
			end
			local x1, y1, x2, y2, x, y = toks[i], toks[i + 1], toks[i + 2], toks[i + 3], toks[i + 4], toks[i + 5]
			for _, v in ipairs({ x1, y1, x2, y2, x, y }) do
				if type(v) ~= "number" then
					return nil, "curveto needs numbers"
				end
			end
			if cmd == "c" then
				x1, y1 = cx + x1, cy + y1
				x2, y2 = cx + x2, cy + y2
				x, y = cx + x, cy + y
			end
			need_sub()
			cur.segs[#cur.segs + 1] = { kind = "cubic", x1 = x1, y1 = y1, x2 = x2, y2 = y2, x = x, y = y }
			prev_cubic_ctrl = { x2, y2 }
			prev_quad_ctrl = nil
			cx, cy = x, y
			i = i + 6
		elseif cmd == "S" or cmd == "s" then
			if i + 3 > n then
				return nil, "smooth curveto needs 4 numbers"
			end
			local x2, y2, x, y = toks[i], toks[i + 1], toks[i + 2], toks[i + 3]
			for _, v in ipairs({ x2, y2, x, y }) do
				if type(v) ~= "number" then
					return nil, "smooth curveto needs numbers"
				end
			end
			local x1, y1
			if prev_cubic_ctrl then
				x1, y1 = 2 * cx - prev_cubic_ctrl[1], 2 * cy - prev_cubic_ctrl[2]
			else
				x1, y1 = cx, cy
			end
			if cmd == "s" then
				x2, y2 = cx + x2, cy + y2
				x, y = cx + x, cy + y
			end
			need_sub()
			cur.segs[#cur.segs + 1] = { kind = "cubic", x1 = x1, y1 = y1, x2 = x2, y2 = y2, x = x, y = y }
			prev_cubic_ctrl = { x2, y2 }
			prev_quad_ctrl = nil
			cx, cy = x, y
			i = i + 4
		elseif cmd == "Q" or cmd == "q" then
			if i + 3 > n then
				return nil, "quad needs 4 numbers"
			end
			local x1, y1, x, y = toks[i], toks[i + 1], toks[i + 2], toks[i + 3]
			for _, v in ipairs({ x1, y1, x, y }) do
				if type(v) ~= "number" then
					return nil, "quad needs numbers"
				end
			end
			if cmd == "q" then
				x1, y1 = cx + x1, cy + y1
				x, y = cx + x, cy + y
			end
			need_sub()
			cur.segs[#cur.segs + 1] = { kind = "quad", x1 = x1, y1 = y1, x = x, y = y }
			prev_quad_ctrl = { x1, y1 }
			prev_cubic_ctrl = nil
			cx, cy = x, y
			i = i + 4
		elseif cmd == "T" or cmd == "t" then
			if i + 1 > n then
				return nil, "smooth quad needs 2 numbers"
			end
			local x, y = toks[i], toks[i + 1]
			if type(x) ~= "number" or type(y) ~= "number" then
				return nil, "smooth quad needs numbers"
			end
			local x1, y1
			if prev_quad_ctrl then
				x1, y1 = 2 * cx - prev_quad_ctrl[1], 2 * cy - prev_quad_ctrl[2]
			else
				x1, y1 = cx, cy
			end
			if cmd == "t" then
				x, y = cx + x, cy + y
			end
			need_sub()
			cur.segs[#cur.segs + 1] = { kind = "quad", x1 = x1, y1 = y1, x = x, y = y }
			prev_quad_ctrl = { x1, y1 }
			prev_cubic_ctrl = nil
			cx, cy = x, y
			i = i + 2
		elseif cmd == "A" or cmd == "a" then
			if i + 6 > n then
				return nil, "arc needs 7 numbers"
			end
			local rx, ry, rot, large, sweep, x, y =
				toks[i], toks[i + 1], toks[i + 2], toks[i + 3], toks[i + 4], toks[i + 5], toks[i + 6]
			if
				type(rx) ~= "number"
				or type(ry) ~= "number"
				or type(rot) ~= "number"
				or type(x) ~= "number"
				or type(y) ~= "number"
			then
				return nil, "arc needs numbers"
			end
			if type(large) ~= "number" or type(sweep) ~= "number" then
				return nil, "arc flags must be 0 or 1"
			end
			if cmd == "a" then
				x, y = cx + x, cy + y
			end
			local beziers, berr = arc_to_cubics(cx, cy, rx, ry, rot, large ~= 0, sweep ~= 0, x, y)
			if not beziers then
				return nil, berr
			end
			need_sub()
			for _, b in ipairs(beziers) do
				cur.segs[#cur.segs + 1] = b
			end
			prev_cubic_ctrl = nil
			prev_quad_ctrl = nil
			cx, cy = x, y
			i = i + 7
		else
			return nil, "unsupported path command '" .. tostring(cmd) .. "'"
		end
		if i <= n and type(toks[i]) ~= "string" then
			if cmd == "M" then
				cmd = "L"
			elseif cmd == "m" then
				cmd = "l"
			end
		end
	end
	return subs
end

arc_to_cubics = function(x1, y1, rx, ry, phi_deg, large, sweep, x2, y2)
	rx, ry = mabs(rx), mabs(ry)
	if rx < 1e-9 or ry < 1e-9 then
		return { { kind = "line", x = x2, y = y2 } }
	end
	local phi = phi_deg * pi / 180
	local cp, sp = mcos(phi), msin(phi)
	local dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
	local x1p, y1p = cp * dx + sp * dy, -sp * dx + cp * dy
	local lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
	if lam > 1 then
		local s = msqrt(lam)
		rx, ry = rx * s, ry * s
	end
	local num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
	local den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
	local co = 0
	if den > 1e-12 then
		co = num / den
		if co < 0 then
			co = 0
		end
		co = msqrt(co)
	end
	if large == sweep then
		co = -co
	end
	local cxp = co * rx * y1p / ry
	local cyp = -co * ry * x1p / rx
	local cx = cp * cxp - sp * cyp + (x1 + x2) / 2
	local cy = sp * cxp + cp * cyp + (y1 + y2) / 2
	local function angle(ux, uy, vx, vy)
		local dot = ux * vx + uy * vy
		local len = msqrt(ux * ux + uy * uy) * msqrt(vx * vx + vy * vy)
		local a = 0
		if len > 1e-12 then
			a = clamp(dot / len, -1, 1)
		end
		a = math.acos(a)
		if ux * vy - uy * vx < 0 then
			a = -a
		end
		return a
	end
	local t1 = angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
	local dt = angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
	if not sweep and dt > 0 then
		dt = dt - 2 * pi
	elseif sweep and dt < 0 then
		dt = dt + 2 * pi
	end
	local n = mceil(mabs(dt) / (pi / 2))
	if n < 1 then
		n = 1
	end
	if n > 64 then
		n = 64
	end
	local out = {}
	for k = 0, n - 1 do
		local a1 = t1 + dt * k / n
		local a2 = t1 + dt * (k + 1) / n
		local half = (a2 - a1) / 2
		local alpha = 4 / 3 * mtan(half / 2)
		local function pt(a)
			local px, py = rx * mcos(a), ry * msin(a)
			return cx + cp * px - sp * py, cy + sp * px + cp * py
		end
		local function der(a)
			local px, py = -rx * msin(a), ry * mcos(a)
			return cp * px - sp * py, sp * px + cp * py
		end
		local ex1, ey1 = pt(a1)
		local ex2, ey2 = pt(a2)
		local d1x, d1y = der(a1)
		local d2x, d2y = der(a2)
		out[#out + 1] = {
			kind = "cubic",
			x1 = ex1 + alpha * d1x,
			y1 = ey1 + alpha * d1y,
			x2 = ex2 - alpha * d2x,
			y2 = ey2 - alpha * d2y,
			x = ex2,
			y = ey2,
		}
	end
	return out
end

local function points_attr(s)
	local pts = {}
	if type(s) ~= "string" then
		return pts
	end
	local nums = scan_numbers(s)
	for k = 1, mfloor(#nums / 2) * 2, 2 do
		pts[#pts + 1] = { nums[k], nums[k + 1] }
	end
	return pts
end

local function shape_to_subs(tag, attrs, vp)
	vp = vp or {}
	local vw, vh = vp.w or 0, vp.h or 0
	local vdiag = msqrt(vw * vw + vh * vh) / msqrt(2)
	local function num(k, ref, def)
		local v = parse_length(attrs[k], ref)
		if v == nil then
			return def
		end
		return v
	end
	if tag == "rect" then
		local x, y = num("x", vw, 0), num("y", vh, 0)
		local w, h = num("width", vw, 0), num("height", vh, 0)
		if w <= 0 or h <= 0 then
			return {}
		end
		local rx = num("rx", vw, nil)
		local ry = num("ry", vh, nil)
		if rx == nil then
			rx = ry or 0
		end
		if ry == nil then
			ry = rx
		end
		rx = clamp(rx or 0, 0, w / 2)
		ry = clamp(ry or 0, 0, h / 2)
		if rx <= 0 or ry <= 0 then
			return {
				{
					closed = true,
					segs = {
						{ kind = "line", x = x + w, y = y },
						{ kind = "line", x = x + w, y = y + h },
						{ kind = "line", x = x, y = y + h },
						{ kind = "line", x = x, y = y },
					},
					mx = x,
					my = y,
				},
			}
		end
		local subs = { { closed = true, mx = x + rx, my = y, segs = {} } }
		local sg = subs[1].segs
		sg[#sg + 1] = { kind = "line", x = x + w - rx, y = y }
		for _, b in ipairs(arc_to_cubics(x + w - rx, y + ry, rx, ry, 0, false, true, x + w, y + ry)) do
			sg[#sg + 1] = b
		end
		sg[#sg + 1] = { kind = "line", x = x + w, y = y + h - ry }
		for _, b in ipairs(arc_to_cubics(x + w, y + h - ry, rx, ry, 0, false, true, x + w - rx, y + h)) do
			sg[#sg + 1] = b
		end
		sg[#sg + 1] = { kind = "line", x = x + rx, y = y + h }
		for _, b in ipairs(arc_to_cubics(x + rx, y + h - ry, rx, ry, 0, false, true, x, y + h - ry)) do
			sg[#sg + 1] = b
		end
		sg[#sg + 1] = { kind = "line", x = x, y = y + ry }
		for _, b in ipairs(arc_to_cubics(x, y + ry, rx, ry, 0, false, true, x + rx, y)) do
			sg[#sg + 1] = b
		end
		return subs
	elseif tag == "circle" then
		local cx = num("cx", vw, 0)
		local cy = num("cy", vh, 0)
		local r = num("r", vdiag, 0)
		if r <= 0 then
			return {}
		end
		local k = 0.5522847498308316 * r
		return {
			{
				closed = true,
				mx = cx + r,
				my = cy,
				segs = {
					{ kind = "cubic", x1 = cx + r, y1 = cy + k, x2 = cx + k, y2 = cy + r, x = cx, y = cy + r },
					{ kind = "cubic", x1 = cx - k, y1 = cy + r, x2 = cx - r, y2 = cy + k, x = cx - r, y = cy },
					{ kind = "cubic", x1 = cx - r, y1 = cy - k, x2 = cx - k, y2 = cy - r, x = cx, y = cy - r },
					{ kind = "cubic", x1 = cx + k, y1 = cy - r, x2 = cx + r, y2 = cy - k, x = cx + r, y = cy },
				},
			},
		}
	elseif tag == "ellipse" then
		local cx = num("cx", vw, 0)
		local cy = num("cy", vh, 0)
		local rx = num("rx", vw, 0)
		local ry = num("ry", vh, 0)
		if rx <= 0 or ry <= 0 then
			return {}
		end
		local kx, ky = 0.5522847498308316 * rx, 0.5522847498308316 * ry
		return {
			{
				closed = true,
				mx = cx + rx,
				my = cy,
				segs = {
					{ kind = "cubic", x1 = cx + rx, y1 = cy + ky, x2 = cx + kx, y2 = cy + ry, x = cx, y = cy + ry },
					{ kind = "cubic", x1 = cx - kx, y1 = cy + ry, x2 = cx - rx, y2 = cy + ky, x = cx - rx, y = cy },
					{ kind = "cubic", x1 = cx - rx, y1 = cy - ky, x2 = cx - kx, y2 = cy - ry, x = cx, y = cy - ry },
					{ kind = "cubic", x1 = cx + kx, y1 = cy - ry, x2 = cx + rx, y2 = cy - ky, x = cx + rx, y = cy },
				},
			},
		}
	elseif tag == "line" then
		local x1 = num("x1", vw, 0)
		local y1 = num("y1", vh, 0)
		local x2 = num("x2", vw, 0)
		local y2 = num("y2", vh, 0)
		return { { closed = false, mx = x1, my = y1, segs = { { kind = "line", x = x2, y = y2 } } } }
	elseif tag == "polyline" or tag == "polygon" then
		local pts = points_attr(attrs.points)
		if #pts == 0 then
			return {}
		end
		local closed = (tag == "polygon")
		local segs = {}
		for k = 2, #pts do
			segs[#segs + 1] = { kind = "line", x = pts[k][1], y = pts[k][2] }
		end
		return { { closed = closed, mx = pts[1][1], my = pts[1][2], segs = segs } }
	end
	return nil
end

local function flatten_sub(sub, mx, my)
	local poly = {}
	local npoly = 0
	local px, py = mx, my
	local function push(x, y)
		if npoly > 0 then
			local l = poly[npoly]
			if l.x == x and l.y == y then
				return
			end
		end
		npoly = npoly + 1
		poly[npoly] = { x = x, y = y }
	end
	push(px, py)
	for _, s in ipairs(sub.segs) do
		if s.kind == "line" then
			push(s.x, s.y)
			px, py = s.x, s.y
		elseif s.kind == "quad" then
			local approx = (mabs(s.x1 - px) + mabs(s.y1 - py) + mabs(s.x - s.x1) + mabs(s.y - s.y1)) / 2
			local segs = mfloor(approx) + 1
			if segs < 2 then
				segs = 2
			end
			if segs > 24 then
				segs = 24
			end
			for k = 1, segs do
				local t = k / segs
				local mt = 1 - t
				push(mt * mt * px + 2 * mt * t * s.x1 + t * t * s.x, mt * mt * py + 2 * mt * t * s.y1 + t * t * s.y)
			end
			px, py = s.x, s.y
		elseif s.kind == "cubic" then
			local approx = (
				mabs(s.x1 - px)
				+ mabs(s.y1 - py)
				+ mabs(s.x2 - s.x1)
				+ mabs(s.y2 - s.y1)
				+ mabs(s.x - s.x2)
				+ mabs(s.y - s.y2)
			) / 2
			local segs = mfloor(approx) + 1
			if segs < 2 then
				segs = 2
			end
			if segs > 32 then
				segs = 32
			end
			for k = 1, segs do
				local t = k / segs
				local mt = 1 - t
				local aa = mt * mt * mt
				local bb = 3 * mt * mt * t
				local cc = 3 * mt * t * t
				local ee = t * t * t
				push(aa * px + bb * s.x1 + cc * s.x2 + ee * s.x, aa * py + bb * s.y1 + cc * s.y2 + ee * s.y)
			end
			px, py = s.x, s.y
		end
	end
	if npoly > 1 then
		local f, l = poly[1], poly[npoly]
		if f.x == l.x and f.y == l.y then
			poly[npoly] = nil
			npoly = npoly - 1
		end
	end
	if npoly < 2 then
		return nil
	end
	return poly
end

local function stroke_poly(points, closed, width, join, cap, miterlimit)
	local n = #points
	if n < 2 or width <= 0 then
		return {}
	end
	local hw = width / 2
	miterlimit = miterlimit or 4
	join = join or "miter"
	cap = closed and "butt" or (cap or "butt")

	local dirs = {}
	local count = closed and n or (n - 1)
	for k = 1, count do
		local a = points[k]
		local b = points[k % n + 1]
		local dx, dy = b.x - a.x, b.y - a.y
		local len = msqrt(dx * dx + dy * dy)
		if len < 1e-9 then
			dirs[k] = nil
		else
			dirs[k] = { dx / len, dy / len }
		end
	end

	local function seg_dir(k)
		if closed then
			return dirs[(k - 1) % n + 1]
		end
		if k < 1 then
			return dirs[1]
		end
		if k > n - 1 then
			return dirs[n - 1]
		end
		return dirs[k]
	end

	local L, R = {}, {}
	local function join_fan(cx, cy, a0, a1, out)
		local da = a1 - a0
		while da > pi do
			da = da - 2 * pi
		end
		while da < -pi do
			da = da + 2 * pi
		end
		local steps = clamp(mceil(mabs(da) / (pi / 6)), 1, 12)
		for k = 1, steps - 1 do
			local a = a0 + da * k / steps
			out[#out + 1] = { x = cx + mcos(a) * hw, y = cy + msin(a) * hw }
		end
	end

	for k = 1, n do
		if not closed and (k == 1 or k == n) then
			local d = (k == 1) and seg_dir(1) or seg_dir(n - 1)
			if not d then
				L[k], R[k] = { x = points[k].x, y = points[k].y }, { x = points[k].x, y = points[k].y }
			else
				local nx, ny = -d[2], d[1]
				L[k] = { x = points[k].x + nx * hw, y = points[k].y + ny * hw }
				R[k] = { x = points[k].x - nx * hw, y = points[k].y - ny * hw }
			end
		else
			local kp = closed and ((k - 2) % n + 1) or (k - 1)
			local kn = closed and (k % n + 1) or k
			local d0, d1 = seg_dir(kp), seg_dir(kn)
			if not d0 then
				d0 = d1
			end
			if not d1 then
				d1 = d0
			end
			if not d0 then
				L[k], R[k] = { x = points[k].x, y = points[k].y }, { x = points[k].x, y = points[k].y }
			else
				local n0x, n0y = -d0[2], d0[1]
				local n1x, n1y = -d1[2], d1[1]
				local mx, my = n0x + n1x, n0y + n1y
				local ml = msqrt(mx * mx + my * my)
				local dot = clamp(n0x * n1x + n0y * n1y, -1, 1)
				if ml < 1e-6 then
					L[k] = { x = points[k].x + n1x * hw, y = points[k].y + n1y * hw }
					R[k] = { x = points[k].x - n1x * hw, y = points[k].y - n1y * hw }
				elseif join == "round" and dot < 0.999 then
					local a0 = atan2(n0y, n0x)
					local a1 = atan2(n1y, n1x)
					local lf = { { x = points[k].x + n0x * hw, y = points[k].y + n0y * hw } }
					join_fan(points[k].x, points[k].y, a0, a1, lf)
					lf[#lf + 1] = { x = points[k].x + n1x * hw, y = points[k].y + n1y * hw }
					L[k] = lf
					R[k] = {
						x = points[k].x,
						y = points[k].y,
						_bevel = true,
						bx = points[k].x - (n0x + n1x) / ml * hw,
						by = points[k].y - (n0y + n1y) / ml * hw,
					}
				else
					local miter = hw * 2 / ml
					if join == "miter" and miter / hw <= (miterlimit + 1e-9) then
						local ux, uy = mx / ml, my / ml
						L[k] = { x = points[k].x + ux * miter, y = points[k].y + uy * miter }
						R[k] = { x = points[k].x - ux * miter, y = points[k].y - uy * miter }
					else
						L[k] = {
							x = points[k].x + n0x * hw,
							y = points[k].y + n0y * hw,
							_bev = { x = points[k].x + n1x * hw, y = points[k].y + n1y * hw },
						}
						R[k] = {
							x = points[k].x - n0x * hw,
							y = points[k].y - n0y * hw,
							_bev = { x = points[k].x - n1x * hw, y = points[k].y - n1y * hw },
						}
					end
				end
			end
		end
	end

	local out = {}
	local function emit(p)
		if type(p) == "table" and p[1] ~= nil and p.x == nil then
			for _, q in ipairs(p) do
				out[#out + 1] = q
			end
		elseif p._bev then
			out[#out + 1] = { x = p.x, y = p.y }
			out[#out + 1] = p._bev
		elseif p._bevel then
			out[#out + 1] = { x = p.bx, y = p.by }
		else
			out[#out + 1] = { x = p.x, y = p.y }
		end
	end

	if closed then
		local outer, inner = {}, {}
		for k = 1, n do
			local p = L[k]
			if type(p) == "table" and p.x == nil then
				for _, q in ipairs(p) do
					outer[#outer + 1] = q
				end
			elseif p._bev then
				outer[#outer + 1] = { x = p.x, y = p.y }
				outer[#outer + 1] = p._bev
			else
				outer[#outer + 1] = { x = p.x, y = p.y }
			end
			local q = R[k]
			if q._bev then
				inner[#inner + 1] = { x = q.x, y = q.y }
				inner[#inner + 1] = q._bev
			elseif q._bevel then
				inner[#inner + 1] = { x = q.bx, y = q.by }
			else
				inner[#inner + 1] = { x = q.x, y = q.y }
			end
		end
		if #outer >= 3 then
			return { outer, inner }
		end
		return {}
	end

	for k = 1, n do
		emit(L[k])
	end
	local pe, d = points[n], seg_dir(n - 1)
	if d then
		if cap == "round" then
			join_fan(pe.x, pe.y, atan2(-d[2], d[1]), atan2(d[2], -d[1]), out)
		elseif cap == "square" then
			out[#out + 1] = { x = L[n].x + d[1] * hw, y = L[n].y + d[2] * hw }
			out[#out + 1] = { x = R[n].x + d[1] * hw, y = R[n].y + d[2] * hw }
		end
	end
	for k = n, 1, -1 do
		local p = R[k]
		if p._bev then
			out[#out + 1] = p._bev
			out[#out + 1] = { x = p.x, y = p.y }
		elseif p._bevel then
			out[#out + 1] = { x = p.bx, y = p.by }
		elseif type(p) == "table" and p.x == nil then
			for j = #p, 1, -1 do
				out[#out + 1] = p[j]
			end
		else
			out[#out + 1] = { x = p.x, y = p.y }
		end
	end
	local ps = points[1]
	d = seg_dir(1)
	if d then
		if cap == "round" then
			join_fan(ps.x, ps.y, atan2(d[2], -d[1]), atan2(-d[2], d[1]), out)
		elseif cap == "square" then
			out[#out + 1] = { x = R[1].x - d[1] * hw, y = R[1].y - d[2] * hw }
			out[#out + 1] = { x = L[1].x - d[1] * hw, y = L[1].y - d[2] * hw }
		end
	end
	if #out < 3 then
		return {}
	end
	return { out }
end

local function polys_coverage(polys, W, H, ss, rule)
	local cov = {}
	for i = 1, W * H do
		cov[i] = 0
	end
	local ex1, ey1, ex2, ey2, edir = {}, {}, {}, {}, {}
	local ne = 0
	for _, poly in ipairs(polys) do
		local np = #poly
		if np >= 2 then
			local prev = poly[np]
			for i = 1, np do
				local cur = poly[i]
				if prev.y ~= cur.y then
					ne = ne + 1
					ex1[ne], ey1[ne] = prev.x, prev.y
					ex2[ne], ey2[ne] = cur.x, cur.y
					edir[ne] = (cur.y > prev.y) and 1 or -1
				end
				prev = cur
			end
		end
	end
	if ne == 0 then
		return cov
	end
	local xs, ds = {}, {}
	local Hss = H * ss
	local inv = {}
	for e = 1, ne do
		inv[e] = 1 / (ey2[e] - ey1[e])
		xs[e] = 0
		ds[e] = 0
	end
	local ssInv = 1 / ss
	local nonzero = (rule == "nonzero" or rule == "non-zero")
	for sy = 0, Hss - 1 do
		local y = (sy + 0.5) / ss
		local nx = 0
		for e = 1, ne do
			local y1, y2 = ey1[e], ey2[e]
			if (y1 <= y) ~= (y2 <= y) then
				nx = nx + 1
				xs[nx] = ex1[e] + (y - y1) * inv[e] * (ex2[e] - ex1[e])
				ds[nx] = edir[e]
			end
		end
		if nx >= 1 then
			for i = 2, nx do
				local vx, vd = xs[i], ds[i]
				local j = i - 1
				while j >= 1 and xs[j] > vx do
					xs[j + 1], ds[j + 1] = xs[j], ds[j]
					j = j - 1
				end
				xs[j + 1], ds[j + 1] = vx, vd
			end
			local row = mfloor(sy * ssInv)
			local rowBase = row * W
			local k = 1
			if nonzero then
				local wind = 0
				for q = 1, nx - 1 do
					wind = wind + ds[q]
					if wind ~= 0 then
						local xa, xb = xs[q], xs[q + 1]
						if xb > xa then
							local sx0 = mfloor(xa * ss - 0.5) + 1
							if sx0 < 0 then
								sx0 = 0
							end
							local sx1 = mceil(xb * ss - 0.5) - 1
							local maxSx = W * ss - 1
							if sx1 > maxSx then
								sx1 = maxSx
							end
							if sx0 <= sx1 then
								local c0 = mfloor(sx0 * ssInv)
								local c1 = mfloor(sx1 * ssInv)
								if c0 == c1 then
									cov[rowBase + c0 + 1] = cov[rowBase + c0 + 1] + (sx1 - sx0 + 1)
								else
									local leftEnd = (c0 + 1) * ss - 1
									cov[rowBase + c0 + 1] = cov[rowBase + c0 + 1] + (leftEnd - sx0 + 1)
									for col = c0 + 1, c1 - 1 do
										cov[rowBase + col + 1] = cov[rowBase + col + 1] + ss
									end
									local rightStart = c1 * ss
									cov[rowBase + c1 + 1] = cov[rowBase + c1 + 1] + (sx1 - rightStart + 1)
								end
							end
						end
					end
				end
			else
				k = 1
				while k < nx do
					local xa, xb = xs[k], xs[k + 1]
					if xb > xa then
						local sx0 = mfloor(xa * ss - 0.5) + 1
						if sx0 < 0 then
							sx0 = 0
						end
						local sx1 = mceil(xb * ss - 0.5) - 1
						local maxSx = W * ss - 1
						if sx1 > maxSx then
							sx1 = maxSx
						end
						if sx0 <= sx1 then
							local c0 = mfloor(sx0 * ssInv)
							local c1 = mfloor(sx1 * ssInv)
							if c0 == c1 then
								cov[rowBase + c0 + 1] = cov[rowBase + c0 + 1] + (sx1 - sx0 + 1)
							else
								local leftEnd = (c0 + 1) * ss - 1
								cov[rowBase + c0 + 1] = cov[rowBase + c0 + 1] + (leftEnd - sx0 + 1)
								for col = c0 + 1, c1 - 1 do
									cov[rowBase + col + 1] = cov[rowBase + col + 1] + ss
								end
								local rightStart = c1 * ss
								cov[rowBase + c1 + 1] = cov[rowBase + c1 + 1] + (sx1 - rightStart + 1)
							end
						end
					end
					k = k + 2
				end
			end
		end
	end
	local div = ss * ss
	local divInv = 255 / div
	local alpha = {}
	for i = 1, W * H do
		local c = cov[i]
		if c > div then
			c = div
		end
		alpha[i] = mfloor(c * divInv + 0.5)
	end
	return alpha
end

local function parse_viewbox(s)
	if type(s) ~= "string" then
		return nil
	end
	local nums = scan_numbers(s)
	if #nums == 4 and nums[3] > 0 and nums[4] > 0 then
		return { x = nums[1], y = nums[2], w = nums[3], h = nums[4] }
	end
	return nil
end

local function parse_preserve(s)
	local o = { align = "xMidYMid", mode = "meet" }
	if type(s) ~= "string" then
		return o
	end
	s = trim(s)
	if s == "none" then
		o.align = "none"
		return o
	end
	local a, m = s:match("^(%S+)%s*(%S*)%s*$")
	if a then
		if a == "none" then
			o.align = "none"
		elseif a:match("^[xX][^%s]*[yY]") or a:match("^x[Mm]") then
			o.align = a
		end
		if m == "meet" or m == "slice" then
			o.mode = m
		end
	end
	return o
end

local function viewport_matrix(vb, vp_w, vp_h, par, extra)
	local sx, sy, tx, ty
	if not vb then
		sx, sy = 1, 1
		tx, ty = 0, 0
	elseif par.align == "none" then
		sx = vp_w / vb.w
		sy = vp_h / vb.h
		tx = -vb.x * sx
		ty = -vb.y * sy
	else
		local s = vp_w / vb.w
		if par.mode == "meet" then
			s = math.min(vp_w / vb.w, vp_h / vb.h)
		else
			s = math.max(vp_w / vb.w, vp_h / vb.h)
		end
		sx, sy = s, s
		local ex, ey = vp_w - vb.w * s, vp_h - vb.h * s
		local ax, ay = 0.5, 0.5
		local al = par.align
		if al:sub(1, 4) == "xMin" then
			ax = 0
		elseif al:sub(1, 4) == "xMax" then
			ax = 1
		end
		if al:find("yMin", 1, true) then
			ay = 0
		elseif al:find("yMax", 1, true) then
			ay = 1
		end
		tx = ex * ax - vb.x * s
		ty = ey * ay - vb.y * s
	end
	local m = { sx, 0, 0, sy, tx, ty }
	if extra then
		m = mat_mul(extra, m)
	end
	return m
end

local function zlib_lib()
	if type(require) == "function" then
		local ok, lib = pcall(require, "zlib")
		if ok and type(lib) == "table" then
			return lib
		end
	end
	return nil
end

local function gunzip(data)
	if #data < 18 or data:byte(1) ~= 0x1F or data:byte(2) ~= 0x8B then
		return data
	end
	if data:byte(3) ~= 8 then
		return nil, "unsupported gzip method"
	end
	local flg = data:byte(4)
	local p = 11
	if (flg & 4) ~= 0 then
		local xlen = data:byte(p) + data:byte(p + 1) * 256
		p = p + 2 + xlen
	end
	if (flg & 8) ~= 0 then
		while p <= #data and data:byte(p) ~= 0 do
			p = p + 1
		end
		p = p + 1
	end
	if (flg & 16) ~= 0 then
		while p <= #data and data:byte(p) ~= 0 do
			p = p + 1
		end
		p = p + 1
	end
	if (flg & 2) ~= 0 then
		p = p + 2
	end
	if p < 11 or p > #data - 8 then
		return nil, "truncated gzip stream"
	end
	local zl = zlib_lib()
	if not zl or type(zl.inflate_raw) ~= "function" or type(zl.crc32) ~= "function" then
		return nil, "gzip needs the zlib library"
	end
	local out, tpos = zl.inflate_raw(data, p, #data - 8, 8 * 1024 * 1024)
	if not out then
		return nil, "gzip: " .. tostring(tpos)
	end
	-- the member's trailer (CRC-32 then the length mod 2^32, both little endian)
	-- follows the deflate data directly; nothing may sit before or after it
	if tpos ~= #data - 7 then
		return nil, "gzip: trailing garbage"
	end
	local a, b, c, d, e, f, g, h = data:byte(tpos, tpos + 7)
	if zl.crc32(out) ~= a + b * 256 + c * 65536 + d * 16777216 then
		return nil, "gzip: invalid compressed data (crc mismatch)"
	end
	if #out % 4294967296 ~= e + f * 256 + g * 65536 + h * 16777216 then
		return nil, "gzip: invalid compressed data (length mismatch)"
	end
	return out
end

function M.parse(data)
	if type(data) ~= "string" or #data == 0 then
		return nil, "empty svg data"
	end
	if data:byte(1) == 0x1F and data:byte(2) == 0x8B then
		local raw, gerr = gunzip(data)
		if not raw then
			return nil, gerr
		end
		data = raw
	end
	if #data > 8 * 1024 * 1024 then
		return nil, "svg too large"
	end
	local root, rerr = parse_xml(data)
	if not root then
		return nil, rerr
	end
	local svg = find_svg(root)
	if not svg then
		return nil, "no <svg> element found"
	end

	local attrs = svg.attrs or {}
	local vb = parse_viewbox(attrs.viewbox)
	local dw = parse_length(attrs.width, nil)
	local dh = parse_length(attrs.height, nil)
	if dw == nil and attrs.width and attrs.width:find("%%") then
		dw = nil
	end
	if dh == nil and attrs.height and attrs.height:find("%%") then
		dh = nil
	end
	local vw, vh
	if dw and dw > 0 then
		vw = dw
	end
	if dh and dh > 0 then
		vh = dh
	end
	if vw and not vh then
		vh = vb and (vw * vb.h / vb.w) or vw * 0.5
		if vb then
			vh = vw * vb.h / vb.w
		end
	elseif vh and not vw then
		if vb then
			vw = vh * vb.w / vb.h
		end
	end
	if not vw or not vh then
		if vb then
			vw, vh = vb.w, vb.h
		else
			vw, vh = 300, 150
		end
	end
	if vw <= 0 or vh <= 0 or vw > 8192 or vh > 8192 then
		return nil, "bad svg dimensions"
	end
	local par = parse_preserve(attrs.preserveaspectratio)

	local doc = {
		width_px = vw,
		height_px = vh,
		viewBox = vb,
		preserve = par,
		shapes = {},
		warnings = {},
	}

	local function warn(s)
		if #doc.warnings < 16 then
			doc.warnings[#doc.warnings + 1] = s
		end
	end

	local limit_err = nil
	local function collect(node, ctm, style, depth, vp)
		if limit_err then
			return
		end
		if depth > MAX_DEPTH then
			limit_err = "svg too deeply nested"
			return
		end
		local tag = node.tag
		local at = node.attrs or {}
		if tag == "svg" and node ~= svg then
			local x = parse_length(at.x, vp.w) or 0
			local y = parse_length(at.y, vp.h) or 0
			local w = parse_length(at.width, vp.w) or vp.w
			local h = parse_length(at.height, vp.h) or vp.h
			if w <= 0 or h <= 0 then
				return
			end
			local nv = parse_viewbox(at.viewbox)
			local np = parse_preserve(at.preserveaspectratio)
			local m = viewport_matrix(nv, w, h, np)
			local here = mat_mul(ctm, mat_mul({ 1, 0, 0, 1, x, y }, m))
			local st = resolve_style(at, style)
			local inner = { w = w, h = h }
			for _, k in ipairs(node.kids or {}) do
				collect(k, here, st, depth + 1, inner)
			end
			return
		end
		if tag == "defs" or tag == "style" or tag == "title" or tag == "desc" or tag == "metadata" then
			return
		end
		if tag == "g" or tag == "a" then
			local st = resolve_style(at, style)
			if st.display == "none" then
				return
			end
			local here = mat_mul(ctm, parse_transform(at.transform))
			for _, k in ipairs(node.kids or {}) do
				collect(k, here, st, depth + 1, vp)
			end
			return
		end
		local is_shape = tag == "path"
			or tag == "rect"
			or tag == "circle"
			or tag == "ellipse"
			or tag == "line"
			or tag == "polyline"
			or tag == "polygon"
		if not is_shape then
			if node.kids and #node.kids > 0 then
				local st = resolve_style(at, style)
				local here = mat_mul(ctm, parse_transform(at.transform))
				for _, k in ipairs(node.kids or {}) do
					collect(k, here, st, depth + 1, vp)
				end
			elseif tag ~= "namedview" and tag ~= "sodipodi" then
			end
			return
		end
		local st = resolve_style(at, style)
		if st.display == "none" then
			return
		end
		if st.visibility == "hidden" or st.visibility == "collapse" then
			return
		end
		local here = mat_mul(ctm, parse_transform(at.transform))
		local subs = nil
		if tag == "path" then
			local d = at.d or ""
			if d == "" then
				return
			end
			local s2, serr = parse_path_data(d)
			if not s2 then
				warn("bad path data: " .. tostring(serr))
				return
			end
			subs = s2
		else
			subs = shape_to_subs(tag, at, vp)
			if subs == nil then
				return
			end
		end
		if not subs or #subs == 0 then
			return
		end
		if #doc.shapes >= MAX_SHAPES then
			limit_err = "svg too complex (shape limit)"
			return
		end
		local op = st._op or 1
		local fop = parse_alpha(st["fill-opacity"])
		local sop = parse_alpha(st["stroke-opacity"])
		fop = clamp(fop, 0, 1)
		sop = clamp(sop, 0, 1)
		local fill = parse_color(st.fill)
		if fill then
			fill[4] = mfloor(fill[4] * op * fop + 0.5)
		end
		local stroke = parse_color(st.stroke)
		if stroke then
			stroke[4] = mfloor(stroke[4] * op * sop + 0.5)
		end
		if (not fill or fill[4] <= 0) and (not stroke or stroke[4] <= 0) then
			return
		end
		local rule = (st["fill-rule"] or "nonzero"):lower()
		if rule ~= "nonzero" and rule ~= "evenodd" then
			rule = "nonzero"
		end
		local sw = 1
		if stroke and stroke[4] > 0 then
			local vdiag = msqrt(vp.w * vp.w + vp.h * vp.h) / msqrt(2)
			sw = parse_length(st["stroke-width"], vdiag) or 1
			if sw < 0 then
				sw = 0
			end
		end
		doc.shapes[#doc.shapes + 1] = {
			tag = tag,
			subs = subs,
			ctm = here,
			fill = (fill and fill[4] > 0) and fill or nil,
			rule = rule,
			stroke = (stroke and stroke[4] > 0 and sw > 0) and stroke or nil,
			stroke_width = sw,
			join = (st["stroke-linejoin"] or "miter"):lower(),
			cap = (st["stroke-linecap"] or "butt"):lower(),
			miterlimit = tonumber(st["stroke-miterlimit"]) or 4,
		}
	end

	local base_style = resolve_style(svg.attrs, nil)
	local root_vp = { w = vw, h = vh }
	for _, k in ipairs(svg.kids or {}) do
		collect(k, mat_identity(), base_style, 1, root_vp)
	end
	if limit_err then
		return nil, limit_err
	end
	return doc
end

function M.natural_size(data_or_doc)
	local doc = data_or_doc
	if type(doc) == "string" then
		local d2, err = M.parse(doc)
		if not d2 then
			return nil, err
		end
		doc = d2
	end
	if type(doc) ~= "table" or not doc.width_px then
		return nil, "not a parsed svg document"
	end
	return mfloor(doc.width_px + 0.5), mfloor(doc.height_px + 0.5)
end

local function bg_to_rgb(bg)
	if type(bg) == "number" then
		return { mfloor(bg / 65536) % 256, mfloor(bg / 256) % 256, bg % 256 }
	elseif type(bg) == "table" then
		return {
			clamp(mfloor(bg[1] or bg.r or 255), 0, 255),
			clamp(mfloor(bg[2] or bg.g or 255), 0, 255),
			clamp(mfloor(bg[3] or bg.b or 255), 0, 255),
		}
	elseif type(bg) == "string" then
		local c = parse_color(bg)
		if c then
			return { c[1], c[2], c[3] }
		end
	end
	return { 255, 255, 255 }
end

function M.render(data_or_doc, opts)
	opts = opts or {}
	local doc = data_or_doc
	if type(doc) == "string" then
		local d2, err = M.parse(doc)
		if not d2 then
			return nil, nil, nil, err
		end
		doc = d2
	end
	if type(doc) ~= "table" or not doc.width_px or not doc.shapes then
		return nil, nil, nil, "not a parsed svg document"
	end
	local nat_w = doc.width_px
	local nat_h = doc.height_px
	local scale = opts.scale or 1
	local out_w, out_h
	if opts.width and opts.height then
		out_w = mfloor(opts.width + 0.5)
		out_h = mfloor(opts.height + 0.5)
		if out_w < 1 or out_h < 1 then
			return nil, nil, nil, "bad output size"
		end
	else
		local tw = opts.width or opts.max_w or 2048
		local th = opts.height or opts.max_h or 2048
		tw = math.min(tw, 2048)
		th = math.min(th, 2048)
		local s = math.min(tw / nat_w, th / nat_h) * scale
		if s <= 0 then
			return nil, nil, nil, "bad output size"
		end
		out_w = clamp(mfloor(nat_w * s + 0.5), 1, 2048)
		out_h = clamp(mfloor(nat_h * s + 0.5), 1, 2048)
		if out_w * out_h * 4 > 8 * 1024 * 1024 then
			local k = msqrt(8 * 1024 * 1024 / (out_w * out_h * 4))
			out_w = mfloor(out_w * k)
			out_h = mfloor(out_h * k)
			if out_w < 1 or out_h < 1 then
				return nil, nil, nil, "picture too large"
			end
		end
		if out_w > 2048 or out_h > 2048 then
			return nil, nil, nil, "picture too large"
		end
	end
	if out_w > 2048 or out_h > 2048 or out_w * out_h * 4 > 8 * 1024 * 1024 then
		return nil, nil, nil, "picture too large"
	end

	local ss = opts.supersample or 2
	if ss ~= 1 and ss ~= 2 and ss ~= 4 then
		ss = 2
	end
	while ss > 1 and out_w * ss * out_h * ss > 4 * 1024 * 1024 do
		ss = ss == 4 and 2 or 1
	end

	local base = viewport_matrix(doc.viewBox, out_w, out_h, doc.preserve)

	local keep_alpha = opts.alpha == true
	if #doc.shapes > 0 and #doc.shapes * out_w * out_h > MAX_WORK then
		return nil, nil, nil, "svg too complex (work limit)"
	end
	local bg = nil
	if not keep_alpha then
		bg = bg_to_rgb(opts.background)
	end
	if bg == nil and not keep_alpha then
		bg = { 255, 255, 255 }
	end

	local W, H = out_w, out_h
	local dst
	local dr, dg, db, da = {}, {}, {}, {}
	if keep_alpha then
		local transparent = opts.background == false or opts.background == nil
		local br, bgg, bb = 0, 0, 0
		local ba = 0
		if not transparent then
			local c = bg_to_rgb(opts.background)
			br, bgg, bb, ba = c[1], c[2], c[3], 255
		end
		for i = 1, W * H do
			dr[i], dg[i], db[i], da[i] = br, bgg, bb, ba
		end
	else
		for i = 1, W * H do
			dr[i], dg[i], db[i] = bg[1], bg[2], bg[3]
		end
	end

	local function blend_px(i, sr, sg2, sb, a)
		if a <= 0 then
			return
		end
		if keep_alpha then
			local da0 = da[i] or 0
			if da0 == 0 then
				dr[i], dg[i], db[i], da[i] = sr, sg2, sb, a
			else
				local dw = da0 * (255 - a)
				local den = a * 255 + dw
				dr[i] = clamp(mfloor((sr * a * 255 + dr[i] * dw) / den + 0.5), 0, 255)
				dg[i] = clamp(mfloor((sg2 * a * 255 + dg[i] * dw) / den + 0.5), 0, 255)
				db[i] = clamp(mfloor((sb * a * 255 + db[i] * dw) / den + 0.5), 0, 255)
				da[i] = clamp(mfloor(den / 255 + 0.5), 0, 255)
			end
		else
			local ia = 255 - a
			dr[i] = mfloor((sr * a + dr[i] * ia) / 255 + 0.5)
			dg[i] = mfloor((sg2 * a + dg[i] * ia) / 255 + 0.5)
			db[i] = mfloor((sb * a + db[i] * ia) / 255 + 0.5)
		end
	end

	for _, sh in ipairs(doc.shapes) do
		local m = mat_mul(base, sh.ctm)
		local fill_polys = {}
		local stroke_polys_all = {}
		for _, sub in ipairs(sh.subs) do
			local mx, my = mat_apply(m, sub.mx or 0, sub.my or 0)
			local tsub = { closed = sub.closed, segs = {} }
			for _, s in ipairs(sub.segs) do
				if s.kind == "line" then
					local x, y = mat_apply(m, s.x, s.y)
					tsub.segs[#tsub.segs + 1] = { kind = "line", x = x, y = y }
				elseif s.kind == "quad" then
					local x1, y1 = mat_apply(m, s.x1, s.y1)
					local x, y = mat_apply(m, s.x, s.y)
					tsub.segs[#tsub.segs + 1] = { kind = "quad", x1 = x1, y1 = y1, x = x, y = y }
				elseif s.kind == "cubic" then
					local x1, y1 = mat_apply(m, s.x1, s.y1)
					local x2, y2 = mat_apply(m, s.x2, s.y2)
					local x, y = mat_apply(m, s.x, s.y)
					tsub.segs[#tsub.segs + 1] = { kind = "cubic", x1 = x1, y1 = y1, x2 = x2, y2 = y2, x = x, y = y }
				end
			end
			local poly = flatten_sub(tsub, mx, my)
			if poly and #poly >= 2 then
				if sh.fill then
					fill_polys[#fill_polys + 1] = poly
				end
				if sh.stroke then
					local det = m[1] * m[4] - m[2] * m[3]
					local uscale = msqrt(mabs(det))
					if uscale < 1e-9 then
						uscale = 1
					end
					local wdev = sh.stroke_width * uscale
					if wdev > 0.01 then
						local sp = stroke_poly(poly, sub.closed, wdev, sh.join, sh.cap, sh.miterlimit)
						for _, p in ipairs(sp) do
							stroke_polys_all[#stroke_polys_all + 1] = p
						end
					end
				end
			end
		end
		if sh.fill and #fill_polys > 0 then
			local need_close = false
			for _, p in ipairs(fill_polys) do
				if #p >= 3 then
					need_close = true
					break
				end
			end
			if need_close then
				local alpha = polys_coverage(fill_polys, W, H, ss, sh.rule)
				local sr, sg2, sb, sa = sh.fill[1], sh.fill[2], sh.fill[3], sh.fill[4]
				if sa > 0 then
					for i = 1, W * H do
						local cov = alpha[i]
						if cov > 0 then
							local a = mfloor(cov * sa / 255 + 0.5)
							blend_px(i, sr, sg2, sb, a)
						end
					end
				end
			end
		end
		if sh.stroke and #stroke_polys_all > 0 then
			local alpha = polys_coverage(stroke_polys_all, W, H, ss, "evenodd")
			local sr, sg2, sb, sa = sh.stroke[1], sh.stroke[2], sh.stroke[3], sh.stroke[4]
			if sa > 0 then
				for i = 1, W * H do
					local cov = alpha[i]
					if cov > 0 then
						local a = mfloor(cov * sa / 255 + 0.5)
						blend_px(i, sr, sg2, sb, a)
					end
				end
			end
		end
	end

	local parts = {}
	if keep_alpha then
		for i = 1, W * H do
			parts[i] = string.char(dr[i], dg[i], db[i], da[i] or 255)
		end
	else
		for i = 1, W * H do
			parts[i] = string.char(dr[i], dg[i], db[i], 255)
		end
	end
	return W, H, table.concat(parts)
end

return M
