local K, API, X = ...
local V = K.vfs
local P = K.path

local T = {}

local function isAdmin(p)
	return p ~= nil and p.uid == 0
end

local function authlog(fmt, ...)
	if type(K.authlog) == "function" then
		pcall(K.authlog, fmt, ...)
	end
end

local function who(p)
	if p == nil then
		return "pid=?"
	end
	return string.format("uid=%d pid=%d", p.uid, p.pid)
end

local function requestShutdown(p, mode, what)
	if not isAdmin(p) then
		authlog("DENIED %s by %s", what, who(p))
		return nil, "EPERM", what .. " requires administrator (uid 0)"
	end
	K.klog("%s requested by pid %d", what, p.pid)
	authlog("%s by %s", what, who(p))
	K.shutdownRequested = mode
	return true
end

function T.reboot(p)
	return requestShutdown(p, "reboot", "reboot")
end

function T.halt(p)
	return requestShutdown(p, "halt", "halt")
end

function T.klog(p, level)
	if not isAdmin(p) then
		return nil, "EPERM", "kernel log requires administrator (uid 0)"
	end
	if level ~= nil and level ~= "read" then
		return nil, "ENOTSUP", "kernel log filtering, writing and clearing are not supported"
	end
	local ring = K.klog_lines and K.klog_lines() or {}
	local out = {}
	for i = 1, #ring do
		out[i] = ring[i]
	end
	return out
end

T.__top = { klog = T.klog }

local XES_FSTYPES = { xes = true, xesfs = true, auto = true }

local SYNTHETIC = {
	proc = "/proc is synthesized by the kernel",
	procfs = "/proc is synthesized by the kernel",
	sysfs = "/sys is synthesized by the kernel",
	sys = "/sys is synthesized by the kernel",
	devtmpfs = "/dev is synthesized by the kernel",
	devfs = "/dev is synthesized by the kernel",
	tmpfs = "tmpfs is synthesized by the kernel",
}

local MOUNT_CODES = {
	{ "no such disk", "ENODEV" },
	{ "no disk has", "ENODEV" },
	{ "no such partition", "ENODEV" },
	{ "unsupported file system", "ENOTSUP" },
	{ "no such file", "ENOENT" },
	{ "no such directory", "ENOENT" },
	{ "not a directory", "ENOTDIR" },
	{ "is a directory", "ENOTDIR" },
	{ "not empty", "ENOTEMPTY" },
	{ "already mounted", "EBUSY" },
	{ "mountpoint conflicts", "EBUSY" },
	{ "cannot mount the root", "EBUSY" },
	{ "device busy", "EBUSY" },
	{ "permission denied", "EACCES" },
	{ "operation not permitted", "EPERM" },
	{ "read-only", "EROFS" },
	{ "cannot mount here", "EINVAL" },
	{ "must be on the root", "EINVAL" },
	{ "bad path", "EINVAL" },
}

local function mapErr(err, rules)
	local e = type(err) == "string" and err:lower() or ""
	for i = 1, #rules do
		if e:find(rules[i][1], 1, true) then
			return rules[i][2]
		end
	end
	return "EIO"
end

local function resolvePath(p, mp, what)
	if type(mp) ~= "string" or mp == "" then
		return nil, "EINVAL", what .. " must be a non-empty string"
	end
	local ok, full = pcall(P.resolve, mp, p.cwd or p.launchcwd, 3)
	if not ok then
		return nil, "EINVAL", "bad " .. what .. ": " .. tostring(full)
	end
	if not full then
		return nil, "EINVAL", "bad " .. what .. ": " .. tostring(mp)
	end
	return full
end

local function checkDir(full, mp, what)
	local st = V.stat(full)
	if st == nil then
		return nil, "ENOENT", "no such " .. what .. ": " .. mp
	end
	if st ~= "dir" then
		return nil, "ENOTDIR", what .. " is not a directory: " .. mp
	end
	return true
end

local function normFstype(fstype)
	if fstype == nil then
		return "xesfs"
	end
	if type(fstype) ~= "string" or fstype == "" then
		return nil, "EINVAL", "fstype must be a string"
	end
	local f = fstype:lower()
	if XES_FSTYPES[f] then
		return "xesfs"
	end
	if SYNTHETIC[f] then
		return nil, "ENOTSUP", SYNTHETIC[f] .. " and cannot be mounted"
	end
	return nil, "ENOTSUP", "unsupported file system type: " .. fstype
end

local function normOpts(opts)
	if opts == nil then
		return "rw"
	end
	if type(opts) == "string" then
		return opts ~= "" and opts or "rw"
	end
	if type(opts) ~= "table" then
		return nil, "EINVAL", "opts must be a string or table"
	end
	local parts = {}
	for k, v in pairs(opts) do
		if type(k) == "number" then
			parts[#parts + 1] = tostring(v)
		elseif v == true then
			parts[#parts + 1] = tostring(k)
		elseif v ~= nil and v ~= false then
			parts[#parts + 1] = tostring(k) .. "=" .. tostring(v)
		end
	end
	if #parts == 0 then
		return "rw"
	end
	table.sort(parts)
	return table.concat(parts, ",")
end

local function resolveDevice(device)
	if type(device) ~= "string" or device == "" then
		return nil, "EINVAL", "device must be a 'disk:partition' string"
	end
	local dref, part = device:match("^([^:]+):([^:/]+)$")
	if not dref then
		return nil, "EINVAL", "bad device (want disk:partition): " .. device
	end
	local R = K.rawfs
	local disks = R and R.disks() or {}
	if dref == "any" then
		for _, d in ipairs(disks) do
			if R.hasPartition(d.slot, part) then
				return d.slot, part, d.id
			end
		end
		return nil, "ENODEV", "no disk has a partition named '" .. part .. "'"
	end
	local d = R and R.diskByRef(dref) or nil
	if not d then
		return nil, "ENODEV", "no such disk: " .. dref
	end
	if not R.hasPartition(d.slot, part) then
		return nil, "ENODEV", "no such partition: " .. dref .. ":" .. part
	end
	return d.slot, part, d.id
end

function T.mount(p, mp, device, fstype, opts)
	if not isAdmin(p) then
		authlog("DENIED mount %s on %s by %s", tostring(device), tostring(mp), who(p))
		return nil, "EPERM", "mount requires administrator (uid 0)"
	end
	local fs, fscode, fsmsg = normFstype(fstype)
	if not fs then
		return nil, fscode, fsmsg
	end
	local opt, ocode, omsg = normOpts(opts)
	if not opt then
		return nil, ocode, omsg
	end
	local full, pcode, pmsg = resolvePath(p, mp, "mountpoint")
	if not full then
		return nil, pcode, pmsg
	end
	local ok, dcode, dmsg = checkDir(full, mp, "mountpoint")
	if not ok then
		return nil, dcode, dmsg
	end
	local slot, part, disk = resolveDevice(device)
	if not slot then
		return nil, part, disk
	end
	local mounted, err = V.mount(p, full, slot, part, fs, opt)
	if not mounted then
		local code = mapErr(err, MOUNT_CODES)
		K.klog("mount %s on %s failed: %s", device, mp, tostring(err))
		authlog("FAILED mount %s on %s by %s: %s", device, mp, who(p), tostring(err))
		return nil, code, tostring(err)
	end
	authlog("MOUNT %s:%s on %s type %s opts %s by %s", disk, part, P.pretty(full), fs, opt, who(p))
	return true
end

local UMOUNT_CODES = {
	{ "not currently mounted", "ENOENT" },
	{ "device busy", "EBUSY" },
	{ "in use", "EBUSY" },
	{ "permission denied", "EACCES" },
	{ "operation not permitted", "EPERM" },
	{ "bad path", "EINVAL" },
}

function T.umount(p, mp, force)
	if not isAdmin(p) then
		authlog("DENIED umount %s by %s", tostring(mp), who(p))
		return nil, "EPERM", "umount requires administrator (uid 0)"
	end
	if force ~= nil and type(force) ~= "boolean" then
		return nil, "EINVAL", "force must be a boolean"
	end
	local full, pcode, pmsg = resolvePath(p, mp, "mountpoint")
	if not full then
		return nil, pcode, pmsg
	end
	local ok, dcode, dmsg = checkDir(full, mp, "mountpoint")
	if not ok then
		return nil, dcode, dmsg
	end
	local unmounted, err = V.unmount(p, full, force and true or nil)
	if not unmounted then
		local code = mapErr(err, UMOUNT_CODES)
		authlog("FAILED umount %s by %s: %s", mp, who(p), tostring(err))
		return nil, code, tostring(err)
	end
	authlog("UMOUNT %s by %s", P.pretty(full), who(p))
	return true
end

local FS = X.fs
if type(FS) == "table" then
	rawset(FS, "mount", T.mount)
	rawset(FS, "umount", T.umount)
else
	K.klog("ext: system: X.fs is unavailable; fs.mount/umount not attached")
end

T.__ext = { ["x.xesns.system"] = 1 }

return T
